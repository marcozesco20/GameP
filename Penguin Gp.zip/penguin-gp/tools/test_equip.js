// v3.0: equipo comprado (casillas propias, recarga lenta), escudo unico, apuntar atras solo para lanzables, misil hacia atras en 1er puesto
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk(bots) {
  const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true });
  const race = new PG.Race(T, { seed: 3 });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < bots; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0; return { T, race, me };
}
function step(race, n, inp) { for (let i = 0; i < n; i++) { race.time += 1 / 60; race.update(1 / 60, inp || {}); race.fxq.length = 0; race.out.length = 0; } }
{
  const { race, me } = mk(3); step(race, 30);
  check('equipo: usar escudo ok', race.useEquip(me, 'shield', 1) === true && me.fx.shield > 0);
  check('equipo: escudo con recarga', me.eqCd.shield > 0);
  check('equipo: no se puede usar durante la recarga', race.useEquip(me, 'shield', 1) === false);
  me.eqCd.shield = 0; // recarga lista pero el primero sigue activo
  check('escudo: no se activa otro mientras dura el primero', race.useEquip(me, 'shield', 1) === false);
  me.ability = 'shield'; me.abilityQ = [];
  check('escudo: la habilidad tampoco se activa', race.useAbility(me, 1) === false && me.ability === 'shield');
  me.fx.shield = 0;
  check('escudo: al acabar se puede volver a usar', race.useAbility(me, 1) === true);
  me.fx.shield = 0;
  me.ability = 'hyper'; check('otros poderes: simultaneos con escudo', (race.useEquip(me, 'snow', 1), race.useAbility(me, 1)) === true);
  step(race, 60 * 15); check('recarga: baja con el tiempo', me.eqCd.shield <= 22 - 14 && me.eqCd.snow <= 14, JSON.stringify(me.eqCd));
}
{
  const { race, me } = mk(3);
  check('lanzables: bola/trampa/megabola/misil', PG.THROWABLE.snow && PG.THROWABLE.trap && PG.THROWABLE.megaball && PG.THROWABLE.missile);
  check('no lanzables: escudo/alas/turbo', !PG.THROWABLE.shield && !PG.THROWABLE.wings && !PG.THROWABLE.hyper && !PG.THROWABLE.ghost);
  me.rank = 1; check('misil hacia atras si vas 1o', PG.canAimBack(me, 'missile') === true);
  me.rank = 2; check('misil hacia atras NO si no vas 1o', PG.canAimBack(me, 'missile') === false);
  check('bola siempre puede atras', PG.canAimBack(me, 'snow') === true);
  check('escudo nunca atras', PG.canAimBack(me, 'shield') === false);
}
{ // misil hacia atras: sale con velocidad negativa
  const { race, me } = mk(3); step(race, 60);
  me.u = 400; me.vf = 20; me.rank = 1; for (const r of race.racers) if (r !== me) { r.u = 300; }
  const n0 = race.proj.length; const ok = race.useEquip(me, 'missile', -1);
  const mp = race.proj.filter((p) => p.kd === 'msl').pop();
  check('misil atras: se crea', ok && race.proj.length > n0 && mp, JSON.stringify(mp && { u: mp.u, vu: mp.vu, dir: mp.dir }));
  check('misil atras: dir -1 y vu negativa', mp && mp.dir === -1 && mp.vu < 0);
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
