/* Modelos 3D low-poly: pinguinos personalizables, obstaculos, objetos y efectos */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;
  var hex = PG.hex, shade = PG.shade;

  PG.PAL = {
    body: ['#1c2230', '#35476b', '#5b3a2e', '#7c8494', '#2f7d4f', '#b03a3f', '#d8a53a', '#6a47a3', '#2b8fc4', '#e57fb0', '#f3f5f8', '#2b2e36'],
    accent: ['#e33b3b', '#f28a1e', '#f6d433', '#4cc45a', '#27b8cc', '#3a6df0', '#8b4dd6', '#f06aa8', '#ffffff', '#20242c'],
    belly: ['#ffffff', '#f6efe0', '#dfe9f5', '#ffe3ec'],
    feet: ['#f59a23', '#f4c430', '#e8534a', '#3fb6d1']
  };
  PG.OPT = {
    hats: ['Sin gorro', 'Gorro con pompón', 'Casco', 'Corona', 'Sombrero de copa', 'Gorra', 'Cuernos vikingos', 'Audífonos', 'Sombrero de mago', 'Sombrero vaquero', 'Gorro de chef', 'Orejas de gato', 'Gorro de fiesta', 'Aureola'],
    scarves: ['Sin bufanda', 'Bufanda', 'Corbatín', 'Pañuelo', 'Medalla', 'Collar de cascabel', 'Bufanda a rayas'],
    glasses: ['Sin lentes', 'Gafas de esquí', 'Gafas de sol', 'Lentes redondos', 'Visor futurista', 'Corazones', 'Antifaz'],
    outfits: ['Sin ropa', 'Chaqueta', 'Capa', 'Mochila', 'Chaleco acolchado', 'Esmoquin', 'Alas de ángel', 'Jetpack']
  };
  PG.defaultCfg = function () {
    return { name: 'Pingu' + (10 + Math.floor(Math.random() * 90)), body: 0, belly: 0, feet: 0, hat: 1, hatCol: 0, scarf: 1, scarfCol: 0, glasses: 0, outfit: 0, outCol: 5 };
  };
  PG.fixCfg = function (c) {
    var d = PG.defaultCfg(); c = c || {};
    var o = {};
    for (var k in d) o[k] = (c[k] === undefined || c[k] === null) ? d[k] : c[k];
    o.name = String(o.name).slice(0, 12) || d.name;
    o.body = ((o.body | 0) % PG.PAL.body.length + PG.PAL.body.length) % PG.PAL.body.length;
    o.belly = (o.belly | 0) % PG.PAL.belly.length; o.feet = (o.feet | 0) % PG.PAL.feet.length;
    o.hat = (o.hat | 0) % PG.OPT.hats.length; o.hatCol = (o.hatCol | 0) % PG.PAL.accent.length;
    o.scarf = (o.scarf | 0) % PG.OPT.scarves.length; o.scarfCol = (o.scarfCol | 0) % PG.PAL.accent.length;
    o.glasses = (o.glasses | 0) % PG.OPT.glasses.length; o.outfit = (o.outfit | 0) % PG.OPT.outfits.length; o.outCol = (o.outCol | 0) % PG.PAL.accent.length;
    return o;
  };

  var penguinCache = {};
  // el modelo original tiene la cabeza levantada (pose de deslizamiento): de pie se baja para que mire al frente
  var HEAD_NOD = 0.6;
  function warpHead(mesh, np, beta) {
    var y0 = 0.48, y1 = 0.63, c = {};
    mesh.chunks.forEach(function (ch) {
      var f = new Float32Array(ch.buf), i8 = new Int8Array(ch.buf), o, k, q;
      for (o = 0; o < ch.n; o += 3) {
        var oldN = [i8[o * 20 + 12], i8[o * 20 + 13], i8[o * 20 + 14]], P = [];
        for (k = 0; k < 3; k++) {
          q = (o + k) * 5; var y = f[q + 1], z = f[q + 2];
          var t = Math.max(0, Math.min(1, (y - y0) / (y1 - y0))); t = t * t * (3 - 2 * t);
          var a = beta * t, ca = Math.cos(a), sa = Math.sin(a), dy = y - np[1], dz = z - np[2];
          f[q + 1] = np[1] + dy * ca - dz * sa; f[q + 2] = np[2] + dy * sa + dz * ca;
          P.push([f[q], f[q + 1], f[q + 2]]);
        }
        var ux = P[1][0] - P[0][0], uy = P[1][1] - P[0][1], uz = P[1][2] - P[0][2], vx = P[2][0] - P[0][0], vy = P[2][1] - P[0][1], vz = P[2][2] - P[0][2];
        var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
        if (nx * oldN[0] + ny * oldN[1] + nz * oldN[2] < 0) { nx = -nx; ny = -ny; nz = -nz; }
        for (k = 0; k < 3; k++) { var ob = (o + k) * 20; i8[ob + 12] = (nx / len * 127) | 0; i8[ob + 13] = (ny / len * 127) | 0; i8[ob + 14] = (nz / len * 127) | 0; }
      }
    });
    return mesh;
  }
  function buildPenguin(cfg, standing) {
    cfg = PG.fixCfg(cfg);
    var key = (standing ? 's' : 'r') + [cfg.body, cfg.belly, cfg.feet, cfg.hat, cfg.hatCol, cfg.scarf, cfg.scarfCol, cfg.glasses, cfg.outfit, cfg.outCol].join('.');
    if (penguinCache[key]) return penguinCache[key];
    var Ci = Math.cos(PG.FBX.pen.theta), Si = Math.sin(PG.FBX.pen.theta);
    var BODY = hex(PG.PAL.body[cfg.body]), BELLY = hex(PG.PAL.belly[cfg.belly]), FEET = hex(PG.PAL.feet[cfg.feet]);
    var HAT = hex(PG.PAL.accent[cfg.hatCol]), SCF = hex(PG.PAL.accent[cfg.scarfCol]), OUT = hex(PG.PAL.accent[cfg.outCol]);
    var DARK = [0.08, 0.09, 0.12], WHITE = [1, 1, 1], GOLD = [1.0, 0.82, 0.22], HAT_MASK = shade(HAT, 0.9);
    var P = PG.FBX.pen, TH = P.theta, PS = P.scale, YO = P.yo, ZC = P.zc, AL = P.alpha, NP = P.np;
    var ALh = standing ? 0.52 - HEAD_NOD : AL; // inclinacion de la cabeza para gorros y lentes (de pie la cabeza esta menos inclinada)
    var pal = [BODY, BELLY, FEET, [0.04, 0.04, 0.06], WHITE];
    var parts = [];
    var mb = new PG.MB();
    // pose de deslizamiento: el modelo original (de pie) se acuesta sobre la panza y se escala
    function stand() { if (standing) mb.push(); else mb.push().scale(PS, PS, PS).translate(0, YO, -ZC).rotX(TH); }
    // punto del espacio 'pose de deslizamiento' -> espacio de pie (inverso de stand())
    function unslide(p) { var x = p[0] / PS, y = p[1] / PS - YO, z = p[2] / PS + ZC; return [x, y * Ci + z * Si, -y * Si + z * Ci]; }
    // punto del modelo "de pie" -> mundo (para pivotes)
    function slideP(x, y, z) { var c = Math.cos(TH), s = Math.sin(TH); return [x * PS, (y * c - z * s + YO) * PS, (y * s + z * c - ZC) * PS]; }
    var mbb = standing ? new PG.MB() : mb; // de pie: el cuerpo base va aparte para poder bajar la cabeza (mirar al frente)
    mbb.push(); mbb.m = null;
    if (standing) mbb.rotX(-TH).translate(0, -YO, ZC).scale(1 / PS, 1 / PS, 1 / PS);
    mbb.fbx(P.parts[0], pal, 0.07);
    mbb.pop();
    var bodyBase = standing ? warpHead(mbb.finish(), NP, HEAD_NOD) : null;
    // patas palmeadas atras (las del modelo original apuntarian al suelo en esta pose)
    var fi, fx;
    for (fi = 0; !standing && fi < 2; fi++) {
      fx = P.feet[fi];
      mb.ell(fx[0] * 1.05, fx[1] + 0.02, fx[2] - 0.12, 0.115, 0.035, 0.2, 6, 3, FEET, 0, 0.1);
    }
    // ---- ropa y accesorios (se dibujan en el espacio "de pie" y se transforman con la pose) ----
    stand();
    // gorros: se reutilizan los disenos con una transformacion a la cabeza del modelo (centro 0,0.71,-0.03; radio ~0.21)
    mb.push().translate(NP[0], NP[1], NP[2]).rotX(-ALh).translate(-NP[0], -NP[1], -NP[2]);
    var h = cfg.hat;
    // de pie los gorros bajos (pompón, gorra, casco) se echan hacia atrás y arriba para dejar ver los ojos
    if (standing && (h === 1 || h === 2 || h === 5 || h === 6 || h === 9 || h === 10 || h === 11)) mb.push().translate(0, 0.715, -0.03).rotX(-0.42).translate(0, 0.055, -0.045).translate(0, -0.715, 0.03);
    else mb.push();
    mb.push().translate(0, 0.715, -0.03).scale(0.58, 0.58, 0.58).translate(0, -0.80, -0.52);
    if (h === 1) {
      mb.ell(0, 1.00, 0.50, 0.40, 0.31, 0.40, 8, 5, HAT);
      mb.cyl(0, 0.84, 0.50, 0.41, 0.41, 0.14, 8, shade(HAT, 0.8));
      mb.ell(0, 1.36, 0.50, 0.12, 0.12, 0.12, 6, 4, WHITE);
    } else if (h === 2) {
      mb.ell(0, 0.98, 0.50, 0.42, 0.35, 0.42, 8, 5, HAT);
      mb.box(0, 0.90, 0.88, 0.55, 0.07, 0.26, shade(HAT, 0.6));
      mb.box(0, 1.28, 0.50, 0.10, 0.06, 0.7, WHITE);
    } else if (h === 3) {
      mb.cyl(0, 1.08, 0.50, 0.30, 0.36, 0.17, 8, GOLD, 0.2);
      for (var k = 0; k < 5; k++) { var a = 2 * PI * k / 5; mb.cone(Math.cos(a) * 0.30, 1.25, 0.5 + Math.sin(a) * 0.30, 0.07, 0.22, 4, GOLD, 0.2); }
      mb.ell(0, 1.17, 0.81, 0.05, 0.05, 0.05, 4, 3, HAT, 0.5);
    } else if (h === 4) {
      mb.cyl(0, 1.10, 0.50, 0.46, 0.46, 0.05, 10, DARK);
      mb.cyl(0, 1.14, 0.50, 0.27, 0.27, 0.52, 10, DARK);
      mb.cyl(0, 1.20, 0.50, 0.275, 0.275, 0.12, 10, HAT);
    } else if (h === 5) {
      mb.ell(0, 1.00, 0.50, 0.38, 0.24, 0.38, 8, 4, HAT);
      mb.box(0, 1.01, 0.88, 0.42, 0.04, 0.32, shade(HAT, 0.7));
    } else if (h === 6) {
      mb.ell(0, 0.98, 0.50, 0.40, 0.28, 0.40, 8, 5, [0.62, 0.64, 0.70]);
      var sgn;
      for (sgn = -1; sgn <= 1; sgn += 2) {
        mb.push().translate(sgn * 0.36, 1.05, 0.5).rotZ(-sgn * 0.8); mb.cone(0, 0, 0, 0.09, 0.42, 5, [0.96, 0.93, 0.82]); mb.pop();
      }
    } else if (h === 7) {
      for (var q = 0; q <= 6; q++) { var an = PI * q / 6; mb.push().translate(Math.cos(an) * 0.42, 0.82 + Math.sin(an) * 0.36, 0.5).rotZ(an); mb.box(0, 0, 0, 0.05, 0.14, 0.1, DARK); mb.pop(); }
      mb.ell(-0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
      mb.ell(0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
    }
    else if (h === 8) { // mago: cono con ala ancha, cinta dorada, punta doblada y estrellas
      mb.cyl(0, 0.89, 0.50, 0.54, 0.54, 0.05, 12, shade(HAT, 0.78));
      mb.cone(0, 0.91, 0.50, 0.37, 0.56, 10, HAT);
      mb.cyl(0, 0.95, 0.50, 0.375, 0.375, 0.07, 10, GOLD, 0.25);
      mb.push().translate(0, 1.43, 0.50).rotZ(-0.55); mb.cone(0, 0, 0, 0.15, 0.34, 8, HAT); mb.pop();
      mb.push().translate(0.17, 1.72, 0.50).rotZ(-1.1); mb.cone(0, 0, 0, 0.07, 0.19, 6, shade(HAT, 1.1)); mb.pop();
      var wsa = [0.9, 2.7, 4.6, 5.6], wsy = [1.12, 1.26, 1.02, 1.36];
      for (var ws = 0; ws < 4; ws++) { var wr = 0.37 * (1 - (wsy[ws] - 0.91) / 0.56) * 1.03; mb.push().translate(Math.cos(wsa[ws]) * wr, wsy[ws], 0.50 + Math.sin(wsa[ws]) * wr).rotY(-wsa[ws] + PI / 2); mb.ell(0, 0, 0, 0.055, 0.055, 0.02, 5, 3, GOLD, 0.7); mb.pop(); }
    } else if (h === 9) { // vaquero: ala curvada hacia arriba, copa hundida y cinta con hebilla
      mb.cyl(0, 0.89, 0.50, 0.62, 0.62, 0.04, 12, shade(HAT, 0.72));
      for (var vs = -1; vs <= 1; vs += 2) { mb.push().translate(vs * 0.56, 0.96, 0.50).rotZ(-vs * 0.5); mb.box(0, 0, 0, 0.14, 0.035, 0.46, shade(HAT, 0.72)); mb.pop(); }
      mb.push().translate(0, 0.90, 0.88).rotX(-0.2); mb.box(0, 0.02, 0, 0.30, 0.03, 0.2, shade(HAT, 0.72)); mb.pop();
      mb.ell(0, 1.06, 0.50, 0.31, 0.24, 0.31, 9, 5, HAT);
      mb.box(0, 1.27, 0.50, 0.05, 0.05, 0.4, shade(HAT, 0.6)); // hendidura de la copa
      mb.cyl(0, 0.95, 0.50, 0.325, 0.325, 0.07, 9, DARK);
      mb.box(0, 0.95, 0.83, 0.07, 0.07, 0.03, GOLD, 0.3);
    } else if (h === 10) { // chef: banda y copa abombada hecha con varias bolas
      mb.cyl(0, 0.88, 0.50, 0.36, 0.36, 0.17, 10, [0.97, 0.97, 1.0]);
      mb.cyl(0, 0.84, 0.50, 0.37, 0.37, 0.035, 10, HAT);
      mb.ell(0, 1.20, 0.50, 0.40, 0.30, 0.40, 9, 5, [1, 1, 1]);
      for (var cb = 0; cb < 6; cb++) { var ca = cb / 6 * 2 * PI; mb.ell(Math.cos(ca) * 0.31, 1.12, 0.50 + Math.sin(ca) * 0.31, 0.20, 0.22, 0.20, 7, 4, [0.95, 0.96, 1.0]); }
      mb.ell(0, 1.34, 0.50, 0.26, 0.2, 0.26, 7, 4, [1, 1, 1]);
    } else if (h === 11) { // orejas de gato: diadema y dos orejas con interior rosa
      for (var gq = 0; gq <= 8; gq++) { var gan = PI * gq / 8; mb.push().translate(Math.cos(gan) * 0.40, 0.84 + Math.sin(gan) * 0.34, 0.50).rotZ(gan); mb.box(0, 0, 0, 0.045, 0.12, 0.09, DARK); mb.pop(); }
      for (var gs = -1; gs <= 1; gs += 2) {
        mb.push().translate(gs * 0.27, 1.10, 0.46).rotZ(-gs * 0.32); mb.cone(0, 0, 0, 0.17, 0.36, 4, HAT); mb.pop();
        mb.push().translate(gs * 0.265, 1.12, 0.505).rotZ(-gs * 0.32); mb.cone(0, 0, 0, 0.10, 0.24, 4, [1.0, 0.72, 0.8]); mb.pop();
      }
    } else if (h === 12) { // gorro de fiesta: cono con rayas, borla dorada y tiras
      mb.cone(0, 0.93, 0.50, 0.30, 0.82, 10, HAT);
      var fr = [0.18, 0.38, 0.58];
      for (var fq = 0; fq < 3; fq++) mb.cyl(0, 0.93 + fr[fq], 0.50, 0.30 * (1 - fr[fq] / 0.82) + 0.012, 0.30 * (1 - fr[fq] / 0.82) + 0.012, 0.055, 10, [1, 1, 1]);
      mb.cyl(0, 0.93, 0.50, 0.305, 0.305, 0.05, 10, GOLD, 0.2);
      for (var fz = 0; fz < 6; fz++) { var fa = fz / 6 * 2 * PI; mb.ell(Math.cos(fa) * 0.34, 0.99, 0.50 + Math.sin(fa) * 0.34, 0.035, 0.035, 0.035, 4, 3, GOLD, 0.5); }
      mb.ell(0, 1.77, 0.50, 0.11, 0.11, 0.11, 7, 4, GOLD, 0.5);
    } else if (h === 13) { // aureola: anillo dorado flotando sobre la cabeza
      for (var hq = 0; hq < 14; hq++) { var haa = hq / 14 * 2 * PI; mb.push().translate(Math.cos(haa) * 0.34, 1.34, 0.50 + Math.sin(haa) * 0.34).rotY(-haa); mb.box(0, 0, 0, 0.04, 0.04, 0.115, GOLD, 0.9); mb.pop(); }
      mb.ell(0, 1.34, 0.50, 0.30, 0.012, 0.30, 12, 2, [1.0, 0.95, 0.6], 0.6);
    }
    mb.pop(); mb.pop(); mb.pop(); // fin gorro
    // bufandas
    var sc = cfg.scarf;
    if (sc === 1) mb.ell(0, 0.50, -0.065, 0.30, 0.055, 0.275, 10, 3, SCF);
    else if (sc === 2) {
      mb.ell(0, 0.55, 0.19, 0.04, 0.04, 0.04, 5, 3, SCF);
      mb.push().translate(-0.08, 0.55, 0.19).rotZ(PI / 2); mb.cone(0, 0, 0, 0.07, 0.11, 4, SCF); mb.pop();
      mb.push().translate(0.08, 0.55, 0.19).rotZ(-PI / 2); mb.cone(0, 0, 0, 0.07, 0.11, 4, SCF); mb.pop();
    } else if (sc === 3) {
      mb.ell(0, 0.505, -0.065, 0.30, 0.04, 0.275, 10, 3, SCF);
      mb.tri([-0.2, 0.58, 0.14], [0.2, 0.58, 0.14], [0, 0.36, 0.21], SCF);
    } else if (sc === 4) { // medalla de oro con cinta en V y estrella
      mb.ell(0, 0.50, -0.065, 0.285, 0.035, 0.265, 10, 3, shade(SCF, 0.85));
      mb.tri([-0.15, 0.53, 0.10], [-0.07, 0.53, 0.14], [0, 0.34, 0.225], SCF);
      mb.tri([0.15, 0.53, 0.10], [0.07, 0.53, 0.14], [0, 0.34, 0.225], shade(SCF, 0.8));
      mb.push().translate(0, 0.325, 0.232).rotX(PI / 2); mb.cyl(0, 0, 0, 0.05, 0.05, 0.025, 12, GOLD, 0.35); mb.cyl(0, 0.01, 0, 0.034, 0.034, 0.025, 12, [1.0, 0.93, 0.55], 0.5); mb.pop();
    } else if (sc === 5) { // collar con cascabel dorado
      mb.ell(0, 0.50, -0.065, 0.295, 0.04, 0.27, 10, 3, SCF);
      mb.ell(0, 0.455, 0.215, 0.06, 0.06, 0.06, 7, 5, GOLD, 0.45);
      mb.box(0, 0.445, 0.268, 0.05, 0.008, 0.01, DARK); mb.ell(0, 0.43, 0.27, 0.012, 0.012, 0.012, 4, 3, DARK);
      mb.box(0, 0.505, 0.205, 0.05, 0.02, 0.02, shade(SCF, 0.75));
    } else if (sc === 6) { // bufanda a rayas: dos colores y un extremo colgando por delante
      mb.ell(0, 0.525, -0.065, 0.30, 0.03, 0.275, 10, 3, SCF);
      mb.ell(0, 0.495, -0.065, 0.305, 0.03, 0.28, 10, 3, [0.97, 0.97, 1.0]);
      mb.ell(0, 0.465, -0.065, 0.30, 0.03, 0.275, 10, 3, SCF);
      mb.box(0.10, 0.37, 0.205, 0.09, 0.19, 0.025, SCF); mb.box(0.10, 0.40, 0.22, 0.092, 0.035, 0.012, [0.97, 0.97, 1.0]); mb.box(0.10, 0.33, 0.22, 0.092, 0.035, 0.012, [0.97, 0.97, 1.0]);
      for (var tf = 0; tf < 4; tf++) mb.box(0.062 + tf * 0.025, 0.265, 0.21, 0.008, 0.05, 0.01, shade(SCF, 0.8));
    }
    // lentes (sobre los ojos del modelo: x=+-0.10, y=0.71, z=0.18)
    var gl = cfg.glasses;
    mb.push().translate(NP[0], NP[1], NP[2]).rotX(-ALh).translate(-NP[0], -NP[1], -NP[2]);
    if (standing) mb.translate(0, 0.10, -0.075); // v3.0: ajustado a la linea de los ojos y pegado a la cara
    if (gl === 1) {
      mb.cyl(0, 0.685, -0.03, 0.222, 0.222, 0.06, 9, DARK);
      mb.ell(-0.10, 0.712, 0.19, 0.08, 0.06, 0.04, 6, 4, [1.0, 0.55, 0.2], 0.45);
      mb.ell(0.10, 0.712, 0.19, 0.08, 0.06, 0.04, 6, 4, [1.0, 0.55, 0.2], 0.45);
    } else if (gl === 2) {
      mb.box(-0.10, 0.714, 0.205, 0.125, 0.062, 0.03, DARK); mb.box(0.10, 0.714, 0.205, 0.125, 0.062, 0.03, DARK);
      mb.box(0, 0.722, 0.205, 0.06, 0.016, 0.026, DARK);
    } else if (gl === 3) {
      var sx;
      for (sx = -1; sx <= 1; sx += 2) {
        mb.push().translate(sx * 0.10, 0.714, 0.2).rotX(PI / 2); mb.cyl(0, 0, 0, 0.06, 0.06, 0.03, 8, GOLD, 0.2); mb.pop();
        mb.ell(sx * 0.10, 0.714, 0.222, 0.047, 0.047, 0.014, 6, 3, [0.7, 0.9, 1.0], 0.4);
      }
    } else if (gl === 4) { // visor futurista: franja luminosa con marco oscuro y patillas
      mb.box(0, 0.714, 0.205, 0.34, 0.07, 0.03, [0.1, 0.9, 1.0], 0.85);
      mb.box(0, 0.752, 0.206, 0.35, 0.014, 0.034, DARK); mb.box(0, 0.676, 0.206, 0.35, 0.014, 0.034, DARK);
      mb.box(0, 0.714, 0.222, 0.30, 0.012, 0.01, [0.85, 1.0, 1.0], 0.9);
      mb.box(-0.178, 0.714, 0.12, 0.014, 0.05, 0.19, DARK); mb.box(0.178, 0.714, 0.12, 0.014, 0.05, 0.19, DARK);
    } else if (gl === 5) { // lentes de corazon
      var hx;
      for (hx = -1; hx <= 1; hx += 2) {
        mb.ell(hx * 0.10 - 0.024, 0.727, 0.214, 0.042, 0.04, 0.012, 6, 4, [1.0, 0.35, 0.55], 0.45);
        mb.ell(hx * 0.10 + 0.024, 0.727, 0.214, 0.042, 0.04, 0.012, 6, 4, [1.0, 0.35, 0.55], 0.45);
        mb.tri([hx * 0.10 - 0.066, 0.722, 0.214], [hx * 0.10 + 0.066, 0.722, 0.214], [hx * 0.10, 0.665, 0.214], [1.0, 0.35, 0.55], 0.45);
        mb.tri([hx * 0.10 - 0.066, 0.722, 0.2145], [hx * 0.10 + 0.066, 0.722, 0.2145], [hx * 0.10, 0.665, 0.2145], [1.0, 0.35, 0.55], 0.45);
      }
      mb.box(0, 0.722, 0.208, 0.07, 0.012, 0.014, DARK);
    } else if (gl === 6) { // antifaz de superheroe con ojos blancos
      mb.ell(0, 0.714, 0.195, 0.205, 0.058, 0.04, 10, 4, HAT_MASK);
      mb.tri([-0.205, 0.742, 0.17], [-0.275, 0.77, 0.10], [-0.2, 0.69, 0.16], HAT_MASK);
      mb.tri([0.205, 0.742, 0.17], [0.275, 0.77, 0.10], [0.2, 0.69, 0.16], HAT_MASK);
      mb.ell(-0.10, 0.714, 0.226, 0.048, 0.034, 0.012, 6, 3, [1, 1, 1], 0.5); mb.ell(0.10, 0.714, 0.226, 0.048, 0.034, 0.012, 6, 3, [1, 1, 1], 0.5);
    }
    mb.pop();
    // chaqueta / mochila
    var of = cfg.outfit;
    if (of === 1) {
      if (standing) { // v2.9: de pie la chaqueta abraza el cuerpo (antes era un globo mas ancho que el pinguino)
        mb.ell(0, 0.30, -0.02, 0.285, 0.275, 0.275, 10, 6, OUT, 0, 0.02);
        mb.ell(0, 0.50, -0.05, 0.285, 0.095, 0.275, 10, 3, shade(OUT, 0.8), 0, 0.02);
      } else {
        mb.ell(0, 0.32, -0.02, 0.345, 0.31, 0.325, 10, 6, OUT, 0, 0.02);
        mb.ell(0, 0.52, -0.05, 0.315, 0.105, 0.31, 10, 3, shade(OUT, 0.8), 0, 0.02);
      }
    } else if (of === 3) {
      if (standing) { // mochila apoyada en la espalda, a la altura de los omoplatos, con tirantes sobre los hombros
        mb.box(0, 0.33, -0.30, 0.25, 0.27, 0.12, OUT);
        mb.box(0, 0.47, -0.30, 0.26, 0.035, 0.13, shade(OUT, 0.7));
        mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
      } else {
        mb.box(0, 0.40, -0.285, 0.25, 0.27, 0.12, OUT);
        mb.box(0, 0.54, -0.29, 0.26, 0.035, 0.13, shade(OUT, 0.7));
        mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
      }
    } else if (of === 2) {
      // capa: esclavina sobre los hombros + panel pegado a la espalda (tambien de pie)
      if (standing) { // de pie cae como tela: estrecha arriba (en los hombros) y se abre hacia abajo siguiendo la espalda
        mb.ell(0, 0.50, -0.05, 0.285, 0.095, 0.275, 10, 3, shade(OUT, 0.8), 0, 0.02);
        mb.quad([-0.23, 0.50, -0.27], [0.23, 0.50, -0.27], [0.30, 0.10, -0.31], [-0.30, 0.10, -0.31], OUT);
        mb.quad([-0.23, 0.50, -0.27], [-0.30, 0.10, -0.31], [0.30, 0.10, -0.31], [0.23, 0.50, -0.27], shade(OUT, 0.8));
      } else {
        mb.ell(0, 0.52, -0.05, 0.315, 0.105, 0.31, 10, 3, shade(OUT, 0.8), 0, 0.02);
        mb.box(0, 0.36, -0.265, 0.50, 0.44, 0.03, OUT);
      }
    }
    else if (of === 4) { // chaleco acolchado: torso con costuras horizontales y cuello alto
      var vk = standing ? 1 : 1.21, vy = standing ? 0 : 0.02;
      mb.ell(0, 0.28 + vy, -0.01, 0.30 * vk, 0.26, 0.305 * vk, 10, 6, OUT, 0, 0.03);
      for (var vq = 0; vq < 4; vq++) mb.ell(0, 0.16 + vq * 0.1 + vy, -0.01, 0.304 * vk, 0.011, 0.31 * vk, 10, 3, shade(OUT, 0.68));
      mb.ell(0, 0.50 + vy, -0.05, 0.27 * vk, 0.075, 0.26 * vk, 10, 3, shade(OUT, 0.82));
      mb.box(0, 0.30 + vy, 0.23 * vk, 0.012, 0.3, 0.012, [0.9, 0.92, 0.95]);
    } else if (of === 5) { // esmoquin: frac oscuro, pechera blanca, solapas y mono
      var tk = standing ? 1 : 1.21, ty = standing ? 0 : 0.02;
      mb.ell(0, 0.29 + ty, -0.02, 0.292 * tk, 0.26, 0.282 * tk, 10, 6, [0.07, 0.08, 0.11], 0, 0.02);
      mb.ell(0, 0.30 + ty, 0.14 * tk, 0.135 * tk, 0.215, 0.165 * tk, 8, 5, [0.98, 0.98, 1.0]);
      for (var tl = -1; tl <= 1; tl += 2) { mb.push().translate(tl * 0.115 * tk, 0.40 + ty, 0.215 * tk).rotZ(tl * 0.38); mb.box(0, 0, 0, 0.03, 0.17, 0.03, [0.03, 0.03, 0.05]); mb.pop(); }
      for (var tb = 0; tb < 3; tb++) mb.ell(0, 0.34 - tb * 0.07 + ty, 0.255 * tk, 0.014, 0.014, 0.012, 5, 3, GOLD, 0.4);
      mb.ell(0, 0.495 + ty, 0.215 * tk, 0.03, 0.03, 0.03, 5, 3, OUT);
      mb.push().translate(-0.065, 0.495 + ty, 0.215 * tk).rotZ(PI / 2); mb.cone(0, 0, 0, 0.065, 0.1, 4, OUT); mb.pop();
      mb.push().translate(0.065, 0.495 + ty, 0.215 * tk).rotZ(-PI / 2); mb.cone(0, 0, 0, 0.065, 0.1, 4, OUT); mb.pop();
      mb.ell(0, 0.50 + ty, -0.05, 0.27 * tk, 0.07, 0.26 * tk, 10, 3, [0.05, 0.06, 0.09]);
    } else if (of === 6) { // alas de angel: dos alas con tres plumas cada una
      var ay = standing ? 0 : 0.07;
      for (var asg = -1; asg <= 1; asg += 2) {
        mb.push().translate(asg * 0.10, 0.40 + ay, -0.31).rotZ(asg * 0.85).rotY(asg * 0.30);
        mb.ell(asg * 0.19, 0.04, 0, 0.27, 0.035, 0.12, 7, 3, [1, 1, 1], 0.25);
        mb.ell(asg * 0.22, -0.045, 0, 0.23, 0.032, 0.105, 7, 3, [0.95, 0.97, 1.0], 0.25);
        mb.ell(asg * 0.24, -0.125, 0, 0.19, 0.03, 0.09, 7, 3, [0.9, 0.94, 1.0], 0.25);
        mb.ell(asg * 0.04, 0.0, 0, 0.07, 0.07, 0.07, 6, 3, [0.96, 0.98, 1.0], 0.2);
        mb.pop();
      }
    } else if (of === 7) { // jetpack: dos depósitos con tapa, boquillas, llamas y correas
      var jy = standing ? 0 : 0.07;
      for (var jx = -1; jx <= 1; jx += 2) {
        mb.cyl(jx * 0.085, 0.34 + jy, -0.31, 0.065, 0.065, 0.36, 8, [0.72, 0.74, 0.8], 0.05);
        mb.cone(jx * 0.085, 0.52 + jy, -0.31, 0.065, 0.1, 8, OUT);
        mb.cyl(jx * 0.085, 0.36 + jy, -0.31, 0.068, 0.068, 0.04, 8, OUT);
        mb.push().translate(jx * 0.085, 0.15 + jy, -0.31).rotX(PI); mb.cone(0, 0, 0, 0.05, 0.16, 7, [1.0, 0.62, 0.12], 0.9); mb.cone(0, 0, 0, 0.03, 0.1, 6, [1.0, 0.95, 0.6], 1); mb.pop();
        mb.cyl(jx * 0.085, 0.17 + jy, -0.31, 0.055, 0.075, 0.05, 8, DARK);
      }
      mb.box(0, 0.40 + jy, -0.265, 0.2, 0.05, 0.04, DARK);
      mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
    }
    mb.pop();
    parts.push({ mesh: standing ? PG.mergeMeshes([bodyBase, mb.finish()]) : mb.finish(), kind: 'body', pivot: [0, 0, 0] });

    // aletas (aletas hacia los lados): geometria relativa a su hombro
    function wing(entry, piv, kind) {
      var m = new PG.MB(); m.rnd = PG.rng(kind === 'flipR' ? 5 : 6);
      var pv2 = standing ? unslide(piv) : piv;
      m.push().translate(-pv2[0], -pv2[1], -pv2[2]);
      if (standing) m.rotX(-TH).translate(0, -YO, ZC).scale(1 / PS, 1 / PS, 1 / PS);
      m.fbx(entry, pal, 0.07);
      m.pop();
      parts.push({ mesh: m.finish(), kind: kind, pivot: pv2.slice() });
    }
    wing(P.parts[1], P.pivR, 'flipR');
    wing(P.parts[2], P.pivL, 'flipL');
    // cola de bufanda / capa
    var pv;
    if ((sc === 1 || sc === 6) && !standing) {
      pv = slideP(0.10, 0.52, -0.16);
      var mt = new PG.MB(); mt.box(0.0, 0.0, -0.36, 0.17, 0.035, 0.72, SCF); mt.box(0.0, 0.0, -0.70, 0.19, 0.04, 0.12, shade(SCF, 0.75));
      parts.push({ mesh: mt.finish(), kind: 'tail', pivot: pv, amp: 1 });
    }
    if (of === 2 && !standing) {
      pv = [0, 0.80, -0.02];
      var mc = new PG.MB(); mc.box(0, 0, -0.46, 0.80, 0.035, 0.92, OUT); mc.box(0, 0, -0.92, 0.82, 0.04, 0.1, shade(OUT, 0.75));
      parts.push({ mesh: mc.finish(), kind: 'tail', pivot: pv, amp: 0.6 });
    }
    var model = { parts: parts, key: key };
    penguinCache[key] = model;
    return model;
  }
  PG.penguinModel = function (cfg) { return buildPenguin(cfg, false); };
  // el mismo pinguino, de pie (espectadores): cuerpo + aletas animables alrededor de los hombros
  // el modelo de pie queda inclinado hacia atras (pose de deslizamiento = 78 grados, no 90): se endereza al dibujarlo
  PG.STAND_TILT = Math.PI / 2 - PG.FBX.pen.theta;
  PG.spectatorModel = function (cfg) { return buildPenguin(cfg, true); };
  // version barata (lejos): mismos colores y accesorios principales con primitivas
  var liteCache = {};
  PG.spectatorLite = function (cfg) {
    cfg = PG.fixCfg(cfg);
    var key = [cfg.body, cfg.belly, cfg.feet, cfg.hat, cfg.hatCol, cfg.scarf, cfg.scarfCol].join('.');
    if (liteCache[key]) return liteCache[key];
    var BODY = hex(PG.PAL.body[cfg.body]), BELLY = hex(PG.PAL.belly[cfg.belly]), FEET = hex(PG.PAL.feet[cfg.feet]), HAT = hex(PG.PAL.accent[cfg.hatCol]), SCF = hex(PG.PAL.accent[cfg.scarfCol]);
    var m = new PG.MB(); m.rnd = PG.rng(9);
    m.ell(0, 0.46, 0, 0.36, 0.46, 0.30, 6, 4, BODY, 0, 0.05);
    m.ell(0, 0.42, 0.14, 0.27, 0.36, 0.2, 6, 3, BELLY);
    m.ell(0, 0.86, 0.02, 0.2, 0.2, 0.2, 6, 3, BODY);
    m.cone(0, 0.8, 0.2, 0.06, 0.16, 4, FEET);
    m.box(-0.12, 0.03, 0.1, 0.14, 0.06, 0.26, FEET); m.box(0.12, 0.03, 0.1, 0.14, 0.06, 0.26, FEET);
    if (cfg.scarf) m.cyl(0, 0.62, 0, 0.25, 0.24, 0.1, 7, SCF);
    if (cfg.hat) m.ell(0, 1.04, 0, 0.21, 0.15, 0.21, 6, 3, HAT);
    m.box(-0.38, 0.45, 0, 0.07, 0.34, 0.16, BODY); m.box(0.38, 0.45, 0, 0.07, 0.34, 0.16, BODY);
    var mesh = m.finish(); liteCache[key] = mesh; return mesh;
  };

  /* ---------- modelos varios ---------- */
  PG.Models = {};
  PG.buildModels = function (theme) {
    var M = PG.Models = {}, t = theme || PG.THEMES.day, mb;
    var snow = t.snow, rock = t.rock, ice = t.ice, shd = shade;

    function rockMesh(seed) {
      var m = new PG.MB(); m.rnd = PG.rng(seed);
      m.ell(0, 0.75, 0, 1.9, 1.1, 1.7, 6, 4, shd(rock, 0.9), 0, 0.30);
      m.ell(0.2, 1.25, 0, 1.3, 0.55, 1.2, 6, 3, snow, 0, 0.05);
      return m.finish();
    }
    M.rock = [rockMesh(3), rockMesh(9), rockMesh(21)];
    // obstaculo de hielo: racimo de cristales azules inclinados sobre una base de nieve (no es una caja)
    mb = new PG.MB(); mb.rnd = PG.rng(57);
    mb.ell(0, 0.28, 0, 1.75, 0.55, 1.75, 8, 3, snow, 0, 0.05);
    var CR = [[0, 0, 0, 0.62, 3.9, 0, 0], [0.95, 0, 0.3, 0.46, 2.7, 0.0, -0.42], [-0.9, 0, 0.35, 0.5, 3.0, 0.0, 0.4], [0.2, 0, -0.95, 0.44, 2.5, -0.38, 0.0], [-0.1, 0, 0.98, 0.4, 2.1, 0.4, 0.05], [0.7, 0, -0.65, 0.3, 1.5, -0.3, -0.3]];
    for (var ci = 0; ci < CR.length; ci++) {
      var c = CR[ci], col = ci % 2 ? [0.30, 0.66, 0.98] : [0.42, 0.78, 1.0];
      mb.push().translate(c[0], 0.35, c[2]).rotX(c[5]).rotZ(c[6]);
      mb.cyl(0, 0, 0, c[3], c[3] * 0.9, c[4] * 0.62, 6, col, 0.35);
      mb.cone(0, c[4] * 0.62, 0, c[3] * 0.9, c[4] * 0.38, 6, [0.78, 0.94, 1.0], 0.55);
      mb.pop();
    }
    M.ice = mb.finish();
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.80, 0.95, 7, 5, snow, 0, 0.03);
    mb.ell(0, 1.75, 0, 0.70, 0.62, 0.70, 7, 5, snow, 0, 0.03);
    mb.ell(0, 2.55, 0, 0.50, 0.46, 0.50, 7, 5, snow, 0, 0.03);
    mb.push().translate(0, 2.55, 0.45).rotX(PI / 2); mb.cone(0, 0, 0, 0.09, 0.5, 5, [1, 0.5, 0.1]); mb.pop();
    mb.cyl(0, 2.15, 0, 0.55, 0.55, 0.18, 8, [0.85, 0.15, 0.2]);
    mb.cyl(0, 2.92, 0, 0.48, 0.48, 0.06, 8, [0.1, 0.1, 0.12]); mb.cyl(0, 2.95, 0, 0.30, 0.30, 0.42, 8, [0.1, 0.1, 0.12]);
    mb.ell(-0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]);
    M.snowman = mb.finish();
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.7, 1.7, 8, 5, [0.50, 0.46, 0.46], 0, 0.1);
    mb.ell(0, 0.95, 1.5, 0.55, 0.50, 0.55, 7, 5, [0.55, 0.50, 0.50]);
    mb.ell(0, 0.85, 1.95, 0.22, 0.18, 0.2, 5, 3, [0.1, 0.1, 0.1]);
    mb.ell(-0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]);
    mb.ell(-1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]); mb.ell(1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]);
    mb.ell(0, 0.45, -1.8, 0.45, 0.08, 0.3, 5, 3, [0.45, 0.4, 0.4]);
    M.seal = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(5);
    mb.ell(0, 0, 0, 1.9, 1.9, 1.9, 8, 6, [0.95, 0.97, 1.0], 0, 0.12);
    mb.ell(0.6, 0.9, 0.5, 0.7, 0.6, 0.7, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    mb.ell(-0.8, -0.5, 1.0, 0.6, 0.5, 0.6, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    M.ball = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.7, 0.7, 0.7, 7, 5, [1, 1, 1], 0.15, 0.06); M.snowball = mb.finish();
    mb = new PG.MB();
    mb.box(0, 0.5, 0, 1.0, 1.0, 1.0, [0.55, 0.85, 1.0], 0.35);
    mb.cone(0.3, 0.9, 0.2, 0.18, 0.5, 4, [0.8, 0.95, 1.0], 0.4); mb.cone(-0.3, 0.9, -0.2, 0.18, 0.4, 4, [0.8, 0.95, 1.0], 0.4);
    M.trap = mb.finish();
    // ---- esferas luminosas con iconos (objetos y habilidades) ----
    function iconSnow(m, z, col) {
      for (var a = 0; a < 3; a++) {
        m.push().translate(0, 0, z).rotZ(a * PI / 3);
        m.box(0, 0, 0, 0.14, 1.12, 0.2, col, 1);
        for (var sg = -1; sg <= 1; sg += 2) for (var sd = -1; sd <= 1; sd += 2) {
          m.push().translate(0, sg * 0.34, 0).rotZ(sd * 0.85); m.box(0, sd * 0.0 + 0.0, 0, 0.1, 0.34, 0.2, col, 1); m.pop();
        }
        m.pop();
      }
    }
    function iconBolt(m, z, col) {
      m.push().translate(0, 0, z);
      m.push().translate(0.13, 0.40, 0).rotZ(-0.42); m.box(0, 0, 0, 0.27, 0.66, 0.2, col, 1); m.pop();
      m.push().translate(-0.13, -0.40, 0).rotZ(-0.42); m.box(0, 0, 0, 0.27, 0.66, 0.2, col, 1); m.pop();
      m.box(0, 0, 0, 0.66, 0.2, 0.2, col, 1);
      m.pop();
    }
    function beads(m, n, rad, size, col, tilt) {
      m.push().rotZ(tilt);
      for (var i = 0; i < n; i++) { var a = 2 * PI * i / n; m.ell(Math.cos(a) * rad, 0, Math.sin(a) * rad, size, size, size, 5, 3, col, 1); }
      m.pop();
    }
    // objeto: esfera azul con copo de nieve
    mb = new PG.MB();
    mb.ell(0, 0, 0, 0.95, 0.95, 0.95, 12, 8, [0.16, 0.56, 1.0], 0.9);
    mb.ell(-0.3, 0.38, 0.38, 0.26, 0.2, 0.2, 5, 3, [0.7, 0.92, 1.0], 1);
    iconSnow(mb, 0.93, [1, 1, 1]); iconSnow(mb, -0.93, [1, 1, 1]);
    M.orbItem = mb.finish();
    mb = new PG.MB(); beads(mb, 10, 1.45, 0.1, [0.75, 1.0, 1.0], 0.45); M.orbRingI = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.3, 1.3, 1.3, 12, 8, [0.45, 0.85, 1.0], 1); M.orbShellI = mb.finish();
    mb = new PG.MB();
    mb.cyl(0, 0.03, 0, 1.6, 1.6, 0.04, 14, [0.4, 0.85, 1.0], 1);
    mb.cyl(0, 0.05, 0, 0.95, 0.5, 5.5, 10, [0.55, 0.92, 1.0], 1);
    M.glowI = mb.finish();
    // habilidad: esfera violeta con rayo dorado y anillo orbital
    mb = new PG.MB();
    mb.ell(0, 0, 0, 1.15, 1.15, 1.15, 12, 8, [0.62, 0.22, 0.98], 0.9);
    mb.ell(-0.36, 0.46, 0.46, 0.3, 0.22, 0.22, 5, 3, [0.9, 0.7, 1.0], 1);
    iconBolt(mb, 1.12, [1.0, 0.9, 0.25]); iconBolt(mb, -1.12, [1.0, 0.9, 0.25]);
    M.orbAbil = mb.finish();
    mb = new PG.MB(); beads(mb, 12, 1.85, 0.13, [1.0, 0.85, 0.3], 0.5); beads(mb, 12, 1.85, 0.13, [1.0, 0.6, 0.9], -0.5); M.orbRingA = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.55, 1.55, 1.55, 12, 8, [0.85, 0.55, 1.0], 1); M.orbShellA = mb.finish();
    mb = new PG.MB();
    mb.cyl(0, 0.03, 0, 2.0, 2.0, 0.04, 14, [0.8, 0.5, 1.0], 1);
    mb.cyl(0, 0.05, 0, 1.15, 0.6, 7.0, 10, [0.85, 0.6, 1.0], 1);
    M.glowA = mb.finish();
    // arma de nieve (modelo del usuario), montada sobre la espalda del pinguino apuntando al frente
    mb = new PG.MB(); mb.rnd = PG.rng(77);
    mb.push().translate(0, 0.74, 0.08).scale(0.92, 0.92, 0.92);
    mb.fbx(PG.FBX.gun, [[0.66, 0.70, 0.78], [0.17, 0.19, 0.24], [1.0, 0.55, 0.15]], 0.05, [0, 0, 0.6]);
    mb.pop();
    M.cannon = mb.finish();
    // canon de granadas (mismo modelo, otra paleta y algo mayor)
    mb = new PG.MB(); mb.rnd = PG.rng(78);
    mb.push().translate(0, 0.78, 0.08).scale(1.08, 1.08, 1.08);
    mb.fbx(PG.FBX.gun, [[0.38, 0.52, 0.30], [0.14, 0.2, 0.12], [1.0, 0.25, 0.1]], 0.05, [0, 0, 0.6]);
    mb.pop();
    M.cannon2 = mb.finish();
    // granada
    mb = new PG.MB();
    mb.ell(0, 0, 0, 0.55, 0.62, 0.55, 8, 6, [0.28, 0.42, 0.22], 0.05, 0.03);
    mb.cyl(0, 0.52, 0, 0.17, 0.17, 0.2, 6, [0.7, 0.7, 0.75]);
    mb.cyl(0, 0, 0, 0.58, 0.58, 0.12, 8, [0.95, 0.75, 0.1], 0.2);
    mb.ell(0.12, 0.8, 0, 0.1, 0.1, 0.1, 4, 3, [1, 0.5, 0.1], 1);
    M.grenade = mb.finish();
    // mega bola de nieve
    mb = new PG.MB(); mb.rnd = PG.rng(31);
    mb.ell(0, 0, 0, 2.2, 2.2, 2.2, 9, 7, [0.93, 0.98, 1.0], 0.22, 0.14);
    for (var si = 0; si < 9; si++) { var sa = si * 2.399, sy = (si / 8) * 2 - 1, sr = Math.sqrt(1 - sy * sy); mb.ell(Math.cos(sa) * sr * 2.0, sy * 2.0, Math.sin(sa) * sr * 2.0, 0.65, 0.6, 0.65, 5, 3, [0.7, 0.88, 1.0], 0.3, 0.1); }
    mb.ell(-0.8, 0.5, 1.9, 0.38, 0.38, 0.2, 5, 3, [0.1, 0.12, 0.2]); mb.ell(0.8, 0.5, 1.9, 0.38, 0.38, 0.2, 5, 3, [0.1, 0.12, 0.2]);
    mb.box(0, -0.6, 2.0, 1.3, 0.22, 0.3, [0.85, 0.15, 0.2], 0.2);
    M.megaball = mb.finish();
    // arbol (obstaculo): pino nevado
    mb = new PG.MB(); mb.rnd = PG.rng(12);
    var leaf = t.tree || [0.14, 0.42, 0.26];
    mb.cyl(0, 0, 0, 0.55, 0.7, 3.0, 6, [0.38, 0.25, 0.16]);
    for (var ti = 0; ti < 4; ti++) {
      var ty = 2.0 + ti * 2.2, tr = 3.0 - ti * 0.62;
      mb.cone(0, ty, 0, tr, 3.4, 7, shd(leaf, 0.9 - ti * 0.04), 0, 0.12);
      mb.cone(0, ty + 1.2, 0, tr * 0.72, 2.4, 7, snow, 0, 0.05);
    }
    M.tree = mb.finish();
    // carambano de la cueva (punta hacia abajo, origen en la base pegada al techo)
    mb = new PG.MB(); mb.rnd = PG.rng(44);
    mb.push().rotX(PI); mb.cone(0, 0, 0, 1.4, 5.4, 6, [0.80, 0.97, 1.0], 0.85, 0.1); mb.pop();
    mb.push().translate(0.55, 0, 0.3).rotX(PI); mb.cone(0, 0, 0, 0.7, 2.8, 5, [0.92, 1.0, 1.0], 0.9, 0.05); mb.pop();
    mb.ell(0, 0.1, 0, 1.4, 0.45, 1.4, 6, 3, [0.55, 0.62, 0.72], 0, 0.1);
    M.icicle = mb.finish();
    // bola de nieve de la avalancha (varias forman el muro)
    mb = new PG.MB(); mb.rnd = PG.rng(77);
    mb.ell(0, 0, 0, 1, 1, 1, 7, 5, [0.97, 0.99, 1.0], 0.62, 0.16);
    mb.ell(0.35, 0.3, 0.1, 0.62, 0.6, 0.62, 6, 4, [0.9, 0.95, 1.0], 0.55, 0.16);
    M.avBall = mb.finish();
    // misil teledirigido (apunta a +Z)
    mb = new PG.MB(); mb.rnd = PG.rng(66);
    mb.push().translate(0, 0, -1.2).rotX(PI / 2);
    mb.cyl(0, 0, 0, 0.46, 0.46, 2.2, 8, [0.86, 0.14, 0.16], 0.1);
    mb.cyl(0, 0.7, 0, 0.48, 0.48, 0.3, 8, [0.96, 0.96, 0.98], 0.15);
    mb.cone(0, 2.2, 0, 0.46, 1.0, 8, [0.96, 0.96, 0.98], 0.15);
    mb.box(0.62, 0.35, 0, 0.8, 0.8, 0.07, [0.2, 0.25, 0.4], 0.05); mb.box(-0.62, 0.35, 0, 0.8, 0.8, 0.07, [0.2, 0.25, 0.4], 0.05);
    mb.box(0, 0.35, 0.62, 0.07, 0.8, 0.8, [0.2, 0.25, 0.4], 0.05); mb.box(0, 0.35, -0.62, 0.07, 0.8, 0.8, [0.2, 0.25, 0.4], 0.05);
    mb.push().rotX(PI); mb.cone(0, 0, 0, 0.36, 1.3, 7, [1, 0.62, 0.12], 0.96); mb.pop();
    mb.pop();
    M.missile = mb.finish();
    // marcador de aviso en el suelo
    mb = new PG.MB(); mb.up = true;
    mb.cyl(0, 0.04, 0, 2.2, 2.2, 0.03, 14, [1.0, 0.25, 0.2], 1);
    mb.cyl(0, 0.06, 0, 1.2, 1.2, 0.03, 14, [1.0, 0.8, 0.2], 1);
    M.warn = mb.finish();
    // ventisca
    mb = new PG.MB();
    for (var i = 0; i < 7; i++) { var r0 = 1.2 + i * 0.55; mb.cyl(0, i * 1.4, 0, r0, r0 + 0.55, 1.5, 8, [0.9, 0.96, 1.0], 0.3); }
    M.tornado = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.25, 1.05, 1.5, 10, 7, [0.6, 0.85, 1.0], 0.5); M.shield = mb.finish();
    mb = new PG.MB(); mb.up = true;
    mb.cyl(0, 0, 0, 0.62, 0.62, 0.02, 10, [0.05, 0.08, 0.15]); M.shadow = mb.finish();
    // anillo de brillo para pads etc.
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.12, 0.12, 0.12, 4, 3, [1, 1, 1], 1); M.spark = mb.finish();
  };
})();
