# Penguin Slippery Grand Prix 🐧

Carreras de pingüinos deslizándose por el hielo, con multijugador en la misma red WiFi.

- **6 pistas**: 3 circuitos de 3 vueltas y 3 descensos de A → B, todos con pista ancha, rampas, huecos y obstáculos.
- **Poderes**: cajas de objeto (pez turbo, bola de nieve teledirigida, trampa de hielo, escudo) y cristales de habilidad (ventisca, alas, pingüino gigante). Turbo que se carga al deslizar.
- **Personalización**: color del cuerpo, panza, aletas/pies, gorro, bufanda, gafas y atuendo.
- **Multijugador local** (hasta 6 pingüinos, humanos + bots): un teléfono crea la sala y los demás se unen por la misma WiFi.

## 1. Conseguir el APK

El APK hay que compilarlo con el SDK de Android (en el entorno donde se creó este proyecto no era posible descargarlo). Elige **una** opción:

### Opción A — GitHub Actions (sin instalar nada, ~5 min)
1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta** (incluida `.github/`).
2. Entra en la pestaña **Actions** → "Compilar APK" (se ejecuta solo al subir; también puedes pulsar *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **PenguinSlippery-apk** (un zip con `PenguinSlippery.apk`).

### Opción B — Android Studio
1. Abre la carpeta `android/` con Android Studio (acepta instalar el SDK 34 si lo pide).
2. Menú *Build ▸ Build APK(s)*. El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos (JDK 17 + Android SDK)
```
export ANDROID_HOME=/ruta/al/Android/Sdk
./build-apk.sh        # genera PenguinSlippery.apk
```

## 2. Instalar en el teléfono
1. Pasa el APK al móvil (WhatsApp, Drive, cable, etc.). Para el segundo jugador, envíale el mismo archivo.
2. Ábrelo. Android pedirá permitir **instalar apps de orígenes desconocidos** para la app desde la que lo abres (Archivos, Chrome, WhatsApp…): actívalo.
3. Si Play Protect avisa de "app no verificada", elige *Instalar de todos modos* (es un APK firmado con clave de depuración).

## 3. Jugar en multijugador
1. Ambos teléfonos en la **misma WiFi**, o uno comparte datos como **punto de acceso (hotspot)** y el otro se conecta a ese WiFi.
2. Jugador 1: **Multijugador ▸ Crear sala**. Verá su IP en la pantalla.
3. Jugador 2: **Multijugador ▸** aparece la sala automáticamente en la lista (toca *Unirse*). Si no aparece (algunas redes/routers bloquean el broadcast, p. ej. WiFi de invitados), escribe la IP del jugador 1 y pulsa **Unirse**.
4. El anfitrión elige pista, decide si hay bots de relleno y pulsa **¡Iniciar carrera!**

Notas:
- La conexión usa el puerto **47777** (TCP para el juego, UDP para encontrar salas).
- Si el anfitrión sale, otro jugador pasa a ser anfitrión automáticamente.
- El WiFi con "aislamiento de clientes" (típico en redes públicas/invitados) impide jugar; usa el hotspot del teléfono.

## Controles
- **Móvil**: joystick izquierdo para girar/frenar, botón *Boost* (turbo), botón *Item* (usar objeto), y botón de habilidad cuando recoges un cristal. Pausa arriba.
- **PC (navegador)**: WASD/flechas, Espacio = turbo, E = objeto, Q = habilidad.

## Probar en el PC sin APK
```
node server/server.js     # puerto 8080
```
Abre `http://IP-DEL-PC:8080` en cada navegador (móvil o PC). Para multijugador: uno pulsa *Crear sala* y los demás *Unirse* escribiendo la misma dirección.

## Estructura
- `web/` — el juego (HTML/JS/CSS, render WebGL propio, física, IA, red).
- `android/` — envoltorio Android (WebView + servidor de sala TCP + descubrimiento UDP). El juego se empaqueta desde `web/`.
- `server/server.js` — servidor para probar en PC (mismo protocolo que la app).
- `tools/` — pruebas en Node/Playwright usadas durante el desarrollo.
