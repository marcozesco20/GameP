# Penguin Slippery 🐧

Carreras de pingüinos deslizándose por el hielo, con multijugador por Internet (código de sala) y en red local.

- **15 pistas**: 7 circuitos de 3 vueltas (con colinas tipo montaña rusa) y 8 descensos de A → B muy inclinados, entre ellos **Picada Mortal** (caída casi vertical entre pinos y una cueva con picos de hielo que caen). Pista ancha, rampas, huecos, obstáculos y **cuevas altas** con paredes curvas por las que se puede subir con velocidad, techo sólido y **carámbanos que caen** (avisan con una marca roja en el suelo).
- **Meta con gradas**: pingüinos espectadores (el mismo diseño de los corredores, de pie, mirando a la pista y cada uno con su propia animación: aplauden, saludan, saltan, se balancean…), banderines, globos y cartel de SALIDA / META.
- **Pingüino** con tu modelo `PlayerP` (colores y ropa personalizables), aletas abiertas hacia los lados al deslizar. Árboles, iglús, montañas y cañón de nieve con tus modelos FBX.
- **Poderes (v2.3)**: ahora hay solo **dos casillas**. **Turbo** (cohete, abajo a la derecha) se recarga solo: tócalo para acelerar. **Habilidad** (junto a *Saltar*) guarda hasta 3 cargas que llegan de las esferas azules y violetas: bola de nieve teledirigida (pequeña, va al más cercano; **3-4 impactos aturden** un instante), trampa de hielo, **escudo**, **turbo máximo** (mucho más fuerte que el turbo normal; sale más a menudo si vas muy atrás), ventisca, alas de hielo, cañón de nieve, cañón de granadas, **mega bola** (arrasa todo), **misil teledirigido** (busca a los de delante, tiene tiempo limitado, explota con área, tira por los aires a quien toque y avisa con distancia si viene hacia ti), terremoto, fantasma y súper salto. Se lanza hacia adelante o hacia atrás deslizando el dedo hacia abajo.
- **Escudo y velocidad**: con escudo y mucha velocidad **rompes bloques de hielo y rocas**; los árboles no se rompen pero tampoco te aturden.
- **Avalancha**: en algunas carreras (se puede desactivar en *Ajustes*) una avalancha persigue a todos. Alerta discreta arriba con cuenta atrás y distancia (roja si está cerca). Si te alcanza quedas eliminado: ves "¡PERDISTE!" al instante, puedes seguir mirando a los que quedan o salir de la sala.
- **Atajos tipo Mario Kart** (solo circuitos): caminos con su propia geometría que cortan las curvas cerradas; cartel naranja «ATAJO», franjas naranjas, turbos, un cristal, hielo y una grieta que saltar. Los bots también los usan.
- **Progreso**: menú *📊 Mi progreso* con partidas jugadas, victorias, derrotas, porcentajes, podios y mejor tiempo por pista.
- **Sala multijugador**: botón **¡INICIAR CARRERA!** grande y siempre visible, miniatura de la pista, código de sala arriba, **chat de texto** y **chat de voz** (micrófono activable, silenciar mi micro, silenciar a un jugador o a todos).
- **Elegir pista**: cada pista muestra una miniatura real del juego y su mapa.
- **Empujones** suaves (alejan un poco al rival), bolas de nieve que **frenan y empujan** (el escudo las anula), obstáculos de hielo en forma de cristales, cuevas con pocos carámbanos (más brillantes), sin árboles y con muy pocas rocas, **girar tu pingüino** al personalizarlo (arrastrar o botones ◀ ▶), bots más listos con **4 niveles de dificultad** (Fácil, Normal, Difícil, Extremo) en carrera rápida y en la sala multijugador (lo elige el anfitrión).
- **Música** distinta según la pista (3 temas) con opción para quitarla en *Ajustes*, intro de Rockzord Games y mensajes de ánimo (¡Excelente!, ¡Sigue así!, ¡Genial!, último lugar, ¡Ganaste!).
- **Multijugador**: por **Internet con código de sala** (cualquier red) o por red local (hasta 6 pingüinos, humanos + bots).

## Novedades v5.0 (vueltas, fps, bug de pendientes, botón de disparo)
- **Contador de vueltas**: en circuitos marca `0/3` antes de cruzar la meta, `1/3` durante la primera vuelta, y así hasta `3/3`.
- **Menos caídas de fps**: se quitaron las animaciones de `filter: drop-shadow` y `box-shadow` de los botones (Habilidad, Disparo, Turbo), que obligaban a repintar cada cuadro; ahora solo escalan (transform). El respaldo del desenfoque de bordes ya no usa `backdrop-filter` (desenfocar toda la pantalla cada cuadro era muy caro en celulares): usa una neblina de bordes barata. La resolución adaptativa reacciona más rápido (cae hasta 3 niveles de golpe si va muy lento) y pasa a 30 fps fijos antes.
- **Desenfoque y estiramiento** a alta velocidad más fuertes (empieza desde ~100 km/h, radio de desenfoque mayor, estiramiento más marcado).
- **Avalancha**: probabilidad por carrera bajada (0,18).
- **Giro automático en curvas**: bajado (`CENT` 0,29); el pingüino gira menos solo y se nota más tu control.
- **Atajos sin bloques de hielo ni barriles/cajas** atravesados.
- **Bug de rebotes en pendientes pronunciadas corregido**: al tocar el suelo en una pendiente muy inclinada el pingüino perdía contacto y rebotaba; ahora sigue pegado al suelo y se desliza (aterrizajes en Gruta 218→46, Cumbre 167→33, Cañón 101→19).
- **Botón de disparo** (cañón/granadas) movido junto al botón de Habilidad, a la altura de la cola de poderes para no taparla.

## Novedades v4.9 (poderes, castillo, obstáculos, guía, velocidad, ropa nueva)
- **Poderes de disparo**: solo se bloquean entre sí las armas de ráfaga (cañón de bolas de nieve y granadas). Mientras disparas puedes lanzar la bola de nieve suelta, la bola grande y el misil; lo que no puedes es usar a la vez el cañón y las granadas.
- **Castillo Congelado más grande**: pista de 30 m de ancho (antes 26), salones y caminos laterales más anchos (38 m de separación, 24 m de ancho), techo más alto y 50 m más de recorrido. Menos trampas (se quitaron péndulos y filas de pinchos repetidos) y huecos más grandes: los pinchos dejan un hueco de 3 pinchos y los bloques y péndulos reparten más espacio.
- **Obstáculos en todos los mapas**: ~28 % menos obstáculos sueltos y ~30 % menos compuertas; más distancia entre grupos (66 m / 90 m, antes 46 / 60) y nunca dos obstáculos pegados lado a lado (separación lateral mínima de ~9 m en las compuertas).
- **Guía automática (nuevo ajuste, apagado por defecto)**: sin ella, al soltar el control el pingüino conserva el rumbo que le diste (puedes apuntar a un atajo y soltar); la alineación con la pista solo se activa cuando giras hacia el lado contrario. Con la casilla «Guía automática» activada vuelve el comportamiento anterior (se alinea solo). Solo afecta al jugador local; los bots y las partidas en red no cambian.
- **Efecto de velocidad**: muchas menos rayas (de 10–44 a 2–11) y un estiramiento radial sutil hecho en la GPU (desenfoque hacia el centro que crece hacia los bordes). En calidad alta aparece desde ~85 km/h; en media/baja se activa junto con la visión borrosa. Se desactiva con la casilla «Visión borrosa en los bordes».
- **Ropa rediseñada** (ya no son globos alrededor del cuerpo; cada prenda sigue el contorno con 2–3 cm de separación): chaqueta de invierno (canesú, cuello alto, cremallera, bolsillos con solapa, dobladillo elástico, capucha y mangas), chaleco acolchado por bandas (sisas abiertas, cuello, cremallera y bolsillo), esmoquin (pechera, solapas de raso, botones, pañuelo, pajarita, faldones y mangas con puño blanco), capa real (ribete claro, cuello de piel, broche con cadena), mochila (tapa, bolsillos, hebillas, esterilla y correas). **Gorro de Papá Noel** nuevo: casquete que abraza la cabeza con ribete de piel por encima de los ojos y una cola que se curva hacia atrás con pompón. **Ushanka** nueva: copa de piel con banda, orejeras caídas y escudo dorado.
- **Rendimiento**: acceso rápido a los modelos de pingüino (sin recalcular la configuración en cada cuadro), prendas con menos polígonos en carrera.
- Pruebas nuevas: `tools/test_guide.js`, `tools/test_fx_v49.js`; `tools/test_powers_branch.js` actualizada a la regla nueva.

## Novedades v4.8 (menos lag y calor, salir del juego, botones, poderes en atajos)

- **Menús mucho más ligeros**: detrás de los menús corría una carrera demo completa (6 bots + escena 3D con reflejos y bloom) a 60 cuadros, lo que pegaba el juego y calentaba el teléfono. Ahora el menú principal y «Mi pingüino / Mi progreso» se dibujan a 30 cuadros (60 mientras giras al pingüino), el resto de pantallas a ~20 y la pausa a ~10. **La carrera no se limita.**
- Los paneles ya no usan `backdrop-filter` (obligaba a desenfocar el fondo 3D animado en cada cuadro) y los brillos pulsantes (Turbo, Habilidad, botón grande) animan solo `transform`/`opacity` (se componen en la GPU, antes repintaban `box-shadow` cada cuadro).
- Lienzo de líneas de velocidad oculto cuando no se usa; contador de monedas del HUD solo se reescribe si cambia.
- Android: la ventana pide **60 Hz** en pantallas de 90/120 Hz (la mitad de composición, menos calor y batería).
- **Botón «Salir del juego»** en el menú principal (solo en la app; dos toques para confirmar).
- **«Atrás»** de «Mi pingüino» y «Mi progreso» ahora está arriba a la izquierda de la pantalla. En resultados y campeonato: «Salir» a la izquierda y «Siguiente carrera/pista» a la derecha.
- **Poderes en atajos**: bola de nieve, trampa, cañón, granada, mega bola, misil, ventisca y terremoto ya se activan dentro de un atajo. Llevan el ramal (`br`) y solo afectan a quien va por el mismo ramal (los proyectiles desaparecen al salir del atajo). Funciona también en multijugador (el ramal viaja en los mensajes de red).
- **Rafaga activa**: mientras disparas (cañón o granadas) no se puede lanzar otro poder de disparo (bola, granada, mega bola, misil, cañón) hasta que termine; el poder se conserva y el botón se apaga.
- **Rendimiento, 2.ª tanda**: (1) la resolución adaptativa ahora se aplica DESPUÉS del límite de píxeles (antes, en calidad Media, los primeros 4-5 escalones no cambiaban nada) y reacciona en ~1 s en vez de ~4 s; (2) **recuerda el nivel por calidad** (no empieza cada partida en máxima resolución y sufre hasta adaptarse); (3) si ya está en el nivel mínimo y no llega a 40 fps pasa solo a **30 fps fijos** (más estable que 35-50 irregulares); (4) nuevo ajuste **Fluidez: Auto / 60 / 30**; (5) fondo de los menús al 72 % de resolución; (6) las lecturas de ruido del shader (pelaje, tela, rampas) solo se hacen dentro del material que las usa (antes 4 lecturas por píxel brillante incluso en roca/madera/cristal; imagen idéntica); (7) mallas grandes partidas en sub-lotes de ~2400 vértices con su propia caja de descarte (imagen idéntica).
- **Contador de rendimiento** (Ajustes → «Mostrar rendimiento»): fps, ms por cuadro, ms de CPU, resolución real, nivel, vértices y lotes dibujados, DPR y nombre de la GPU. Para diagnosticar en el teléfono real.
- Herramientas nuevas: `tools/prof2.js` (perfil de CPU y asignaciones de memoria sin GPU), `tools/test_powers_branch.js`, `tools/shot_menus.js`.

## Novedades v4.7 (optimización a fondo, sin tocar modelos ni texturas)

Los modelos, texturas, shaders y efectos son los mismos de la v4.6; lo que cambia es **cuánto trabajo le cuesta al teléfono dibujarlos**:

- **Un 80 % menos de llamadas a la GPU por cuadro** (de ~2000 a ~350): cada pieza usa un VAO (un solo enlace en vez de cuatro), el estado de GL se guarda en caché (no se repiten `enable`/`depthMask`) y los uniformes iguales no se reenvían. En celulares el costo del controlador por llamada es lo que más pesa en el hilo principal.
- **Descarte de objetos pequeños fuera de cámara** (obstáculos, pingüinos, espectadores, regalos…) con esfera envolvente y niebla: ya no se envían a la GPU si no se ven.
- **Cielo tardío**: el cielo se dibuja después de la pista y solo donde no hay nada delante (antes se sombreaba toda la pantalla y luego se tapaba).
- **Visión borrosa de velocidad hecha en la GPU**: antes era un `backdrop-filter` del navegador sobre toda la pantalla a más de 125 km/h (muy caro en celular); ahora es una pasada barata dentro del renderizador y con el mismo aspecto.
- **Sin tirones por carga tardía**: los modelos base de los rivales, los espectadores/peatones y todos los programas de shader (escudo, agua, partículas, nieve, post-proceso) se construyen y compilan en la carga de la pista, no el primer cuadro en que se usan.
- **HUD y DOM**: los estilos del HUD solo se escriben cuando cambian, las etiquetas de nombre se mueven con `transform` (sin maquetado cada cuadro) y las líneas de velocidad se redibujan a 30 Hz con colores en caché.
- **Pantallas de 120/144 Hz**: se limita a 60–72 fps estables (la mitad de calor y consumo) en lugar de forzar 120.
- **Resolución adaptativa que apunta a 60 fps de verdad**: baja rápido si se pierde fluidez y vuelve a subir cuando el teléfono aguanta (antes casi nunca subía de nuevo en pantallas de 60 Hz).
- Nuevas herramientas de prueba: `tools/det.js` (banco determinista con reloj falso, cuenta llamadas GL por cuadro y guarda capturas para comparar antes/después).

## Novedades v4.6

- **Estrellas corregidas**: al final de la partida las estrellas dependen de tu posición (1.º = 5, último = 1). Solo se muestran en los resultados finales.
- **HUD limpio**: se quitó el marcador de "estrellas que vas a ganar" junto al tiempo.
- **Escudo normal**: sin estructura metálica; ahora es transparente y rígido (ya no se deforma como gelatina).
- **Optimización sin bajar gráficos**: LOD de pingüinos, textura de ruido en lugar de cálculo por píxel, descarte por niebla/distancia, dibujo ordenado por bloques, celdas más finas, decimado de rocas y resolución adaptable. Calidad visual intacta.
- **Castillo ampliado**: tras los 3 caminos hay un gran salón principal con columnas y braseros, detrás un jardín congelado amurallado (estanques, fuentes, estatuas de hielo) y se sale por una puerta gigante abierta hacia la carretera normal hasta la meta.
- **Barco**: ahora puedes pasar por abajo (como antes) o subir por una rampa y deslizarte por encima de la cubierta, con un caballete de madera y regreso a la carretera.
- **Madera mejorada**: nuevo material con vetas, tablones, clavos y variación de tono.
- **Rocas mejoradas**: rocas más angulosas y nuevo shader con bandas, grietas, vetas, líquenes y escarcha (rocas atravesadas y de cuevas).
- **Mapa de Navidad**: más intersecciones y algunos pingüinos cruzando más.

## Novedades v4.5

- **Estrellas**: corregido el error por el que en carreras en línea llegar 5º podía dar 5 estrellas. Ahora el juego espera el orden de llegada oficial del anfitrión antes de calcular las estrellas y el premio.
- **Castillo Congelado rehecho otra vez**: ahora tiene **una sola entrada** (gran puerta con dos torres). Tras ella hay un **pasillo largo (~300 m) lleno de trampas** (péndulos, pinchos, bloques que caen, rampas). Luego un salón se abre en **3 intersecciones** (centro con más trampas y **dos atajos**: mazmorra y murallas con grietas), con **curvas seguidas**, y todos los caminos se reúnen en un salón y una **única salida** hacia la pista normal.
- **Barcos con mejores texturas**: casco de **madera pintada** (azul con franjas, verde con borda crema, pintura descascarada) o de **hierro remachado** con óxido y brillo metálico según el barco; los naufragios del paisaje mezclan madera, pintura y metal.
- **Rampa del barco enterrado**: la parte que sobresale del hielo ahora tiene **madera congelada** (tablas oscuras con escarcha). Solo esa parte; el resto de la pista sigue siendo hielo.
- **Flechas de dirección**: ahora son **flechas de luz neón 3D con animación** (tubo, núcleo brillante y aura que pulsa) y ya no se apilan: cada camino tiene su propio carril (cian = seguir, naranja/magenta = atajos).
- **Texturas más realistas** de árboles (degradado, motas de aguja, nieve), **rocas** (estratos, grietas, liquen y polvo de nieve, brillo de roca húmeda), **cristales de hielo** (facetas, núcleo luminoso y destello agudo, coherentes con el hielo de la pista), **montañas** (estratos y bruma azulada), y **cristales y rocas de las cuevas** (reaccionan mejor a la luz del sol).
- **Letreros de salida y meta** con panel de acero, remaches, marco luminoso, franja de peligro, cercha y banderines. **Torre de control** con fuste segmentado, contrafuertes, ventanas, escalera, balcón con barandilla, ascensor de cristal, cabina con montantes, parapeto, radar y antenas. Pantalla gigante con marco y refuerzos.
- **Escudo normal**: ya no parece una burbuja; ahora es una **jaula de acero** con remaches, más sólida. Los otros escudos no cambian.

## Novedades v4.4

- **Naufragio Helado rehecho**: ahora es un cementerio de barcos varados en el hielo (más de 40 naufragios alrededor, inclinados y medio enterrados). Cruzas **tres barcos distintos** en cada vuelta: **A)** uno **de lado**, con un boquete en el casco por el que entra la pista; **B)** uno **de frente**, con proa, bauprés y mascarón de pingüino, y un hueco en la proa; **C)** uno **enterrado e inclinado**: subes por su cubierta hasta la punta, tomas una **rampa** y caes a la pista normal (con letrero de hueco).
- **Castillo Congelado rehecho**: ahora es **mucho más largo** (800 m): entras por una gran puerta con tres arcos, recorres un interior con **curvas seguidas** y **tres caminos** (salón, mazmorra y murallas), con torres a lo largo de las murallas, péndulos, trampas y rampas. Después hay un tramo de pista normal hasta la meta.
- **Ciudad Navideña**: **pingüinos que cargan regalos** cruzan la pista de un lado a otro; si chocas con ellos salen volando con sus regalos. La ciudad es más grande, con más cabañas, iglús y muñecos de nieve, y un barrio alrededor del árbol gigante.
- **Letreros de hueco**: en todos los mapas con huecos hay una señal de tránsito a cada lado de la pista, justo antes del hueco.
- **Poder Fantasma**: ahora también te hace **levitar sobre los huecos** y muestra un **aura espectral** de luz azul-verdosa alrededor del pingüino (además de la transparencia).
- **Poder Alas**: corregido el error por el que a veces se quitaba apenas lo activabas.
- **Iconos**: se vuelven a usar los iconos de poderes anteriores a los neón. La tienda tiene **iconos propios** para los conjuntos de pegatinas (antes salían emojis).

## Novedades v4.3

- **3 mapas nuevos**:
  - **Naufragio Helado** (circuito, 3 vueltas): la pista atraviesa por dentro un enorme barco de madera destruido (casco con tablones, cubierta, mástiles con velas rotas, barriles, ancla, partes cubiertas de nieve, carámbanos y faroles). Al salir del barco la pista continúa. Hay poderes flotando que se agarran saltando.
  - **Castillo Congelado** (bajada A → B): al final de la bajada entras a un castillo de hielo con **tres caminos** (salón central, mazmorra y murallas), **péndulos con bolas de pinchos, trampas de pinchos, bloques de hielo, muchas rampas**, antorchas, estandartes y cristales. Sección larga del castillo y poderes en el aire.
  - **Ciudad Navideña** (circuito, 3 vueltas): la ciudad de los pingüinos en Navidad: farolas de bastón de caramelo, guirnaldas y arcos de luces sobre la pista, árboles de Navidad decorados, un **árbol gigante** en la plaza, casitas con ventanas encendidas, iglús, regalos, muñecos de nieve, vallas de caramelo y espectadores por todo el mapa.
  - Obstáculos nuevos: péndulos, pinchos que suben y bajan, cajas y barriles. Poderes y cristales flotantes (se agarran saltando).
- **Iconos de poderes** con el arte neón que enviaste (sin contorno negro).
- **Aviso de avalancha** más arriba para no tapar los textos de «sigue así».
- **Pingüino más cerca y más suave**: en *Mi pingüino* y *Mi progreso* se ve mucho más grande, y el modelo usa subdivisión de superficie (silueta redondeada, menos «low poly») en las pantallas y en la partida (calidad Media/Alta).
- **Iconos del menú principal** rediseñados: fichas de color brillantes por opción.
- Corregido: vértices inválidos (NaN) en el barco y el castillo.

## Novedades v4.2

- **Reflejos más sutiles**: el reflejo del pingüino de adelante ya no se sobrepone al tuyo (solo se refleja lo que va delante de la cámara y bajo su propio rango) y todos los reflejos del mapa son más suaves, sin efecto espejo.
- **Hielo con textura**: manchas de nieve, escarcha y grano en todas las pistas. Hay polvo de nieve que se levanta con el aire y cuando pasas por encima.
- **Azul del hielo más oscuro** en las pistas donde era demasiado claro.
- **Terremoto y tornado** rediseñados: grietas con escombros y polvo, y un tornado en capas con remolino de partículas.
- **Granadas** con modelo nuevo, chispa de mecha, estela y explosión mejorada.
- **Iconos de poderes** más llamativos, con degradados y brillo, en la tienda y en las partidas.
- **Pelaje y ropa**: mechones y volumen en el pelaje; textura de tejido de punto, tela, ribete de piel, plástico y metal en gorros, sombreros y ropa.
- **Miniaturas de pistas** rediseñadas.
- **Gradas y letrero**: letras que iluminan, bombillas, postes y barandas metálicas con textura, paneles iluminados y torres de focos.
- **Rampas** con paneles, remaches y franjas de advertencia.
- **Flechas guía del suelo** en neón, más grandes y con brillo.

## Novedades v4.1

- **Agua realista**: shader propio con olas animadas, reflejo del cielo (fresnel), destello del sol y espuma en las crestas. Visto desde abajo, la superficie es plateada con reflexión total y ventana de luz, y el fondo tiene cáusticas que se mueven.
- **Propulsores**: llamas 3D en capas (núcleo blanco, fuego naranja, borde rojo) con chispas y humo, en turbo, pads, turbo máximo y en las dos boquillas de la mochila cohete.
- **Poderes**: bolas de nieve grande y pequeña con estela de nieve, cristales de hielo y salpicadura al impactar; misil con llama y humo; granada con chispas; bola gigante con nube de nieve; explosiones con destello, bola de fuego, humo y onda de choque; terremoto con anillos de polvo y luz.
- **Pingüino con materiales**: pelaje con vetas y mechones, plumas en filas en el pecho, brillo suave de fibras, halo aterciopelado en el contorno y piel (pico y patas) con luz interior. Se ve igual en la personalización y en las partidas; gorros, bufandas y ropa también reciben la textura.
- **Sin emojis en la interfaz**: más de 55 iconos vectoriales propios (gorros, bufandas, lentes, ropa, trofeos, medallas, monedas, voz, etc.) en el estilo de Penguin Fort. El chat conserva sus emojis porque son contenido de los jugadores.

## Novedades v4.0

- **Malla flotante de los atajos (todas las pistas):** las faldas de nieve de las bermas de los atajos (y de la pista) ahora se recortan siempre a la mitad del espacio libre entre ambos caminos, aunque estén lejos (en la pista 9 una cuña blanca cruzaba la pista principal porque la falda seguía su propia altura mientras la pista bajaba). Las celdas del atajo que tocan la pista se recortan en su borde (nada a ras encima de la calzada), el atajo usa el mismo color de hielo suave que la pista y el plano cercano de la cámara pasó de 0.4 a 0.8 (más precisión de profundidad; evita parpadeos en GPUs de 16 bits).
- **Hielo sin “piscina”:** se eliminaron las venas brillantes y las ondas del shader del hielo y las bandas largas de color a lo largo de la pista; dentro de las cuevas ya no hay brillo azul tipo cáustica. Queda un hielo liso con reflejo y destello limpios.
- **Escudos:** *eléctrico vs normal*: mientras sus campos se tocan se descargan los dos (el normal más rápido; el eléctrico también pierde energía). *Eléctrico vs rebote*: sale un rayo en una dirección cualquiera (como si rebotara) que electrocuta a quien no tenga escudo (si tiene escudo, solo lo gasta; a veces no da a nadie). *Normal vs rebote* (y rebote/eléctrico entre sí): ambos rebotan sin aturdirse ni perder velocidad. Los pingüinos electrocutados muestran rayitos y el estado se ve también en multijugador.
- **Ruleta:** números en Poppins (antes Erica One con borde grueso), monedas, estrella y rayo dibujados en la propia ruleta (sin emojis).
- Pendiente (siguiente entrega): efectos de agua, propulsores y bolas de nieve; texturas de pingüinos y accesorios; iconos propios en todos los botones.

## Novedades v3.9

- **Gráficos mejorados también en carrera:** la resolución adaptativa ya no apaga el brillo del hielo, los reflejos ni el bloom/suavizado cuando el teléfono tarda en dibujar (antes, tras un par de bajadas de resolución, todo eso se desactivaba y la partida se veía como en calidad baja aunque estuviera en *Alto*; el menú no lo notaba porque carga menos). Ahora la calidad elegida decide los efectos y la resolución adaptativa solo baja píxeles (en *Alto* nunca baja del 66 %).
- **Intersecciones de atajos:** la falda de nieve de las bermas (hasta 26–34 m) pasaba por encima del otro camino y formaba una malla flotante sobre la calzada. Ahora se recorta a la mitad del espacio libre entre ambos caminos (y a la misma altura), en la pista y en el atajo. Donde el atajo se pega a la pista usa exactamente su altura (se despega suave hasta 10 m), y las celdas que tocan la pista principal ya no llevan la raya blanca/naranja del borde.

## Novedades v3.8

- **Reflejo real en el hielo (cambio del motor de dibujado):** ahora los pingüinos y las esferas de poder se dibujan en una textura de reflejo (cámara reflejada respecto al plano del suelo) que el hielo muestrea en pantalla con ondulación y efecto fresnel. Se ve también en mapas oscuros/nocturnos (el brillo del reflejo sube cuando la luz ambiente es baja). Solo en calidad Media/Alta con brillo activo; si el teléfono no admite el framebuffer se desactiva solo y queda el reflejo simple anterior. El reflejo usa lo dibujado en el cuadro anterior.
- **Mapas (caminos y atajos):** se eliminaron los caminos elevados/colgados: los atajos ahora siguen el perfil de altura de la pista (diferencia < 0.5 m; antes llegaba a 13 m y quedaba una pista flotando sobre la otra). El terreno entre dos caminos mezcla las alturas (antes hacía un acantilado). El salto sobre la grieta del atajo se coloca donde el camino es más llano y la grieta es algo más corta. Cruzar de un camino a otro ya no puede teletransportar (se verifica que el punto caiga dentro del tramo del otro camino).
- Pendiente: más detalle en pista/entorno, luces reflejadas en el hielo (farolas, arcos), pingüinos y ropa.

## Novedades v3.7

- **Escudos:** si ya tienes 2 escudos guardados, la probabilidad de que te salga otro baja de ~31 % a ~1 % (con 1 guardado, ~18 %; con un escudo activo también baja).
- **Intersecciones:** se quitaron las rendijas dentadas entre el atajo y la pista (antes se omitían celdas enteras y se veía el vacío) y la falda de nieve del atajo ahora baja hasta el suelo cuando va elevado (ya no parece flotar).
- **Hielo:** reflejo de los pingüinos y de las esferas de poder en el hielo (con brillo activo), destellos redondos en vez de cuadrados, y el panel/roca oscuros ya no reciben la textura de hielo.
- **Nieve:** terreno de nieve con color continuo y normales suaves (la roca empinada sigue facetada).
- **Partículas y rastros:** nieve/hielo que salta al deslizar (más con velocidad, giro y turbo) y surcos tenues que quedan en la pista.
- **Letreros:** las letras de SALIDA/META ahora son de trazo redondeado (antes eran cuadritos).
- Pendiente: modelos de pingüinos y ropa, ametralladora, más detalle en entorno/poderes, sombras suaves, y revisar cada intersección en las 12 pistas.

## Novedades v3.6

- **Control más fácil, sobre todo al cruzar entre caminos:** el giro ahora funciona por ángulo objetivo (ya no se acumula hasta quedar de lado); al girar se conserva la velocidad, y pegado a la pared el pingüino se alinea y se desliza en vez de quedarse casi parado (en la prueba: de ~2 a ~30 de velocidad con el giro mantenido). El cruce a otro camino se activa un poco antes de tocar el borde y el roce con la pared frena menos.
- **Apuestas (campeonato) rehechas al estilo Ludo Club:** el bote es apuesta × jugadores (+ monedas recogidas en carrera); se descuenta una comisión del 10 % y el resto se reparte por porcentaje según el número de jugadores: 5–6 jugadores 50 % / 30 % / 20 % (1.º/2.º/3.º), 3–4 jugadores 65 % / 35 %, 2 jugadores el ganador se lo lleva todo. Ejemplo: 6 jugadores × 500 = 3000 → 2700 a repartir → 1350 / 810 / 540. Los bots también ocupan puesto (si un bot queda en el podio, ese premio no lo cobra nadie).
- **Hielo liso:** se eliminó el tono aleatorio por triángulo y el ajedrez que daban el aspecto de cuadritos/pixel art; ahora el color varía de forma continua (vetas largas, escarcha), con normales suavizadas y borde que se funde con la nieve. El patrón de ondas del brillo se suavizó.
- Pendiente (siguientes versiones): modelos y entorno más detallados (árboles con capas de nieve, montañas, pingüino), iluminación/reflejos más ricos, sombras suaves, y revisar intersecciones raras pista por pista.
- Pendiente importante: preparar la publicación en Google Play (.aab firmado, targetSdk 36, política de privacidad pública, formulario de seguridad de datos, reportar/bloquear jugadores, material de la ficha, prueba cerrada) y seguridad.

## Novedades v3.5
- **Dibujado (fase 1)**: en calidad **Alta** hay post-proceso: resplandor (bloom) solo en colores intensos (orbes, turbos, neones, escudos), antialiasing FXAA, curva de color suave y viñeta. Si el teléfono no lo soporta o va justo, se apaga solo (calidad Media/Baja no cambia).
- *Decisión técnica*: no se migra a Three.js (reutilizaría los mismos shaders sin ganar nada); se mejora directamente el motor actual. Three.js se retomará cuando haya modelos con textura (p. ej. el nuevo `PinguinoS.fbx`, que aún necesita sus PNG).
- *Pendiente de dibujado*: reflejos del entorno, sombras suaves, efectos de poderes más ricos, malla del pingüino mejor reducida.
- *PENDIENTE IMPORTANTE (Google Play + seguridad)*: .aab firmado, targetSdk 36, limitar tráfico sin cifrar, política de privacidad con URL pública, formulario de seguridad de datos, clasificación por edades, reportar/bloquear jugadores, material de la ficha y prueba cerrada (12 testers/14 días).

## Novedades v3.4
- **Sombreros y lentes**: los sombreros de copa, mago y vaquero ahora son más pequeños y se echan un poco hacia atrás (ya no tapan ojos ni cara); gorro de fiesta, chef, pompón y gorra suben para dejar ver los lentes; los lentes quedan pegados a la cara (antes flotaban hacia delante).
- **Mapas en carrusel**: desliza con el dedo, usa las flechas ‹ ›, los puntos o el teclado (← →). Al lado están los **modos de juego** (Carrera, Mini campeonato · 3, Campeonato · 5) con su descripción, la dificultad de bots y el botón de empezar. En la sala multijugador el anfitrión elige el modo ahí mismo.
- **Carrera rápida multijugador con apuesta** (campeonato de 1 carrera) y **poderes comprados que no se gastan hasta terminar el campeonato** (3 o 5 carreras); en carrera normal se gastan como antes.
- **Escudos con shader propio**: el azul es una burbuja de cristal con reflejos y borde brillante, el eléctrico un plasma amarillo con venas de rayos que cambian, y el de rebote una burbuja rosa brillante. En calidad baja vuelven al dibujo simple.
- **Cuevas y caminos de hielo**: textura procedural en el hielo (venas, grietas, brillo interior azul), cuevas más luminosas y **rayas de viento** curvas con chispas al ir rápido (más visibles dentro de las cuevas).
- **Conjuntos de ropa** (8) que se compran en la Tienda y se ponen de golpe desde Mi pingüino › Conjuntos: Explorador Ártico, Piloto de Carreras, Esquiador Vintage, Rey del Hielo, Dandy Clásico, Navidad Festiva, Guerrero Vikingo y Aventurero Táctico. Nuevos gorros: **Papá Noel** y **ushanka**.
- *Pendiente / honesto*: el archivo `PinguinoS.fbx` enviado solo contiene el esqueleto (19 huesos, sin malla), por lo que no se pudo importar el modelo; hace falta reexportarlo con la malla (o en .glb). Los conjuntos reutilizan las prendas existentes (no se igualan al 100 % con las imágenes de referencia, que requieren modelos 3D hechos a mano).

## Novedades v3.3
- **Poderes comprados**: corregido el error que impedía registrar su uso (el aviso «poder usado» se pisaba a sí mismo), por eso no se gastaban. Ahora, al usarlos y terminar la carrera (cruzar la meta o salir), se descuentan del inventario y de la Tienda. Las teclas 1-3 también recuerdan un toque muy corto.
- **Foto de perfil ampliada**: ahora se cierra al tocar (el visor no recibía los toques).
- **Escudos sin cuadritos**: esfera suave con aros, franja de luz y rayos.
- **Textos más delgados**: tipografía Poppins en todo el juego (menos el logo, que conserva la letra gruesa).
- **Elegir qué poder lanzar**: toca un círculo pequeño de la cola para pasarlo al botón principal (tecla T rota).
- **Pingüino de pie** (Mi pingüino / Mi progreso): la capa envuelve la espalda en vez de ser un plano rígido, y los sombreros de ala (mago, vaquero, copa) se asientan más arriba sin tapar ojos ni lentes.
- **Poderes en el techo de las cuevas**: orbes sueltos colgando del techo (hay que subir por la pared y rodar por el techo).

## Novedades v3.2
- **Poderes comprados = consumibles reales**: lo que usas en una carrera desaparece del inventario y de la Tienda al terminar (si compraste 2 y usaste 1, queda 1). Dos iguales ocupan **casillas distintas**.
- **Campeonato**: ahora hay **5 carreras** y **mini campeonato de 3**, con apuestas en ambos. En solitario la carrera termina cuando llegas (puestos por posición, sin esperar al último); al terminar (solo o multijugador) puedes empezar **otro campeonato** y elegir las pistas.
- **Cuenta nueva con 🪙500**. **Ruleta** como primera opción del menú (monedas, poderes o puntos; una tirada cada 3 h). Los anuncios quedan para más adelante.
- **Escudos** con más texturas (paneles hexagonales, anillos, banda) y el **eléctrico** con muchos más rayos.
- **Visión borrosa** en los bordes a muy alta velocidad (se quita en Ajustes). **Aviso de impacto** con sonido cuando le das a alguien.
- **Gráficos**: brillo y reflejo en el hielo, destellos de nieve, pingüinos y ropa con sombreado suave (menos «low poly»), chaquetas sin huecos, focas y bolas redondeadas, partículas más suaves, meta con torre de control, pantalla gigante, podio, mástiles de luz y guirnaldas. El brillo se apaga solo en calidad baja o si el teléfono va justo.
- **Mapas**: cañón congelado rehecho (montañas sólidas), menos huecos, más colinas y atajos elevados, y los atajos ya no se sienten más lentos (empuje de entrada y más tracción). 
- **Foto de perfil** ampliable al tocarla. Carteles de aviso con más efectos.
- *Pendiente / honesto*: no se hicieron caminos subterráneos nuevos; no se ha probado en un teléfono real y el selector de fotos de Android (v3.0) sigue sin compilarse hasta que GitHub Actions lo haga.

## Novedades v3.1
- **Fin de carrera**: ya no termina cuando llega el 4.º, sino cuando llega el **penúltimo** jugador; el que queda sin llegar pierde.
- **Trampa de hielo** siempre **detrás** de tu pingüino y con un diseño nuevo (racimo de cristales).
- **Poderes comprados** (equipo) ahora arriba, junto al botón de pausa.
- **Montañas** e iglús: corregida la orientación de las caras (ya no se ven huecas/transparentes en ningún mapa).
- **Personalización**: gorros bien orientados (ya no de lado ni tapando la cara), también con el pingüino de pie. Al personalizar ya **no se oscurece** la pantalla.
- **Menú de inicio**: botones con la misma altura y alineados.
- **Nuevos escudos**: **eléctrico** (electrocuta al tocar, salvo que el otro tenga escudo normal) y **de rebote** (devuelve los ataques en otra dirección, incluso al atacante). Distintos colores y animaciones; se compran en la Tienda (🪙190) y también salen en la carrera.
- **Modo Campeonato**: 5 carreras, puntos 10-7-5-3-2-1. Multijugador **con o sin apuestas** (🪙50 a 🪙5000, las elige el anfitrión); el bote (apuestas + monedas ganadas) se reparte entre los 3 primeros (el 1.º más, el 3.º menos); 4.º en adelante nada. Solo (sin apuestas) también. Quien abandona queda **expulsado**. Pantalla final con todas las estadísticas.
- **Sin botón de pausa en multijugador.**
- **Música**: al empezar cada nivel suena una música (varía) y al terminar la carrera no se corta bruscamente.
- **Controles y menús** con el fondo azul hielo y letras blancas sobre las zonas azul oscuro (más contraste). Seguimos acercando todo al estilo de «Penguin Fort».
- *Nota*: el selector de fotos de Android (v3.0) sigue sin compilarse hasta que GitHub Actions lo haga; no se ha probado en un teléfono real.

## Novedades v3.0
- **Nueva interfaz «Penguin Fort»**: mismo universo visual que el juego hermano. Logo «PENGUIN SLIPPERY» con la tipografía de bloques (Erica One) y letras de hielo, paneles azules con cristales y nieve, botones hexagonales de cristal y botones naranja. Menú principal, selector de pistas, personalización, tienda, amigos, progreso, ajustes y sala rehechos con ese estilo; también el HUD de la carrera (cronómetro, estrellas, monedas, minimapa, vueltas, barra de velocidad, botones hexagonales y turbo circular).
- **Iconos nuevos** en la misma línea gráfica (tienda, personalización, estadísticas, amigos, monedas, estrellas, gorro, bufanda, lentes, ropa…).
- **Equipo comprado**: los poderes de la Tienda tienen sus **propias casillas** (hasta 3) separadas de los poderes de la carrera. Se recargan **más despacio**, se pueden usar **durante toda la carrera** y **solo se consume 1 unidad cuando los usas** (si no los usas, los conservas). Teclas 1, 2 y 3.
- **Escudo**: **barra de tiempo** y no se puede activar un segundo escudo hasta que acabe el anterior (el resto de poderes sí pueden ir a la vez).
- **Apuntar**: solo los poderes que se lanzan muestran «adelante / atrás». El **misil y la mega bola** también se pueden lanzar **hacia atrás** si vas en 1.er lugar.
- **Gafas** en su sitio también con el pingüino de pie. **Más personalización**: 14 gorros, 7 bufandas, 7 lentes y 8 prendas, en low-poly detallado y organizados en pestañas.
- **Montañas** de todos los mapas rehechas (ya no flotan ni se ven transparentes).
- **Cruzar y esquivar** obstáculos es más fácil (colisiones más permisivas).
- **Picada Mortal**: menos inclinada (se siente que te deslizas), menos árboles, camino claramente **blanco** y **sin huecos**.
- **Agua**: el pingüino **nada bajo la superficie**, sin tocar el fondo.
- **Sala multijugador**: tras pulsar «Listo» el botón ya no tapa el chat; el chat es más alto y legible.
- **Amigos**: se quitó el punto verde duplicado y ahora puedes **subir una foto de perfil** (por defecto, un pingüino). La foto se reduce y se comparte con tus amigos (ver Política de privacidad).
- **Atajos**: intersecciones sin malla sobrepuesta y **flechas animadas** (como las de los turbos) que ya no se superponen entre sí.
- *Nota técnica*: el selector de fotos de Android (WebView) es código nuevo en `MainActivity.java`; se compila en GitHub Actions.

## Novedades v2.9
- **Estrellas que sí varían**: ahora dependen del desempeño real de la carrera (posición, tiempo frente al ganador, caídas, golpes recibidos, acrobacias). Salen 1 y 2 estrellas con claridad si vas mal; las 5 solo con una carrera casi perfecta.
- **Niveles más lentos**: cada nivel exige **100 000 puntos** acumulados; para que siga siendo satisfactorio, los puntos por carrera se multiplicaron por 500.
- **Mi progreso**: «Mejor tiempo por pista» ya no es una lista interminable; muestra solo los **últimos 3 tiempos**.
- **Accesorios de pie** (personalización y estadísticas): lentes a la altura de los ojos, chaqueta ajustada al cuerpo, capa que cae como tela y mochila apoyada en la espalda.
- **Amigos**: a quien agregas le sale **dentro del juego** un aviso «<nombre> quiere agregarte como amigo» con **Aceptar** o **Rechazar**; si no estaba conectado, el aviso le aparece al abrir el juego.
- **Multijugador**: cuando el último jugador cruza la meta, los resultados muestran una **cuenta atrás (15 s) para volver a la sala**; desde ahí puedes marcar **«Estoy listo»** (se conserva en la sala; si todos están listos la cuenta se acorta) o **Salir**. El anfitrión puede ir ya a la sala.
- **Avalancha** solo en pistas de A a B (nunca en circuitos). Se quitó el letrero «AGUA» de la laguna.
- **Escudo**: ahora **aguanta varios golpes** (cada ataque lo desgasta; el misil sí lo revienta de golpe) y se ve cómo se debilita.
- **Atajos**: suelo e intersecciones rehechos para que el camino se funda con la pista (ya no se ven sobrepuestos). Las **flechas flotantes** se cambiaron por flechas pintadas en el suelo.
- **Volcán**: cada entrada a la montaña se rehízo para verse natural (sin mallas mal puestas ni caminos cruzados).
- **Montañas**: se corrigieron las que se veían transparentes en todos los mapas (niebla y sombreado).
- **Cuevas**: ya no te pegas ni resbalas por la pared solo por rozarla; hace falta **mucha velocidad y mantener el joystick contra la pared** un instante. La pared y el techo **no te frenan** y al ir por el techo el pingüino queda de panza pegada al arco.
- **Barras de velocidad**: ahora son **flechas de neón animadas** pintadas en el suelo (en vez del recuadro rayado).

## Novedades v2.8
- **Resultados con 5 estrellas** (antes 3): se llenan según tu desempeño en la carrera.
- **Pose de pie** en «Mi progreso» y «Mi pingüino»: de pie sobre el suelo, aletas hacia abajo, pose normal; los gorros ya no tapan la cara.
- **Volcán**: la entrada ahora parece una cueva como las demás, pero con lava (ya no hay una pared), y dentro la luz se vuelve roja. La montaña tiene **3 caminos distintos** para cruzarla (el central con la gran sala del volcán y dos túneles laterales); los bots también los usan.
- **Laguna**: se avisa antes de entrar (cartel «AGUA», franjas de olas pintadas, agua azul bien marcada y boyas). Al entrar el pingüino **se hunde un poco y vuelve a flotar** (nunca a ras del fondo), y dentro el agua se ve transparente.
- **Montañas transparentes** (volcán y laguna): corregido; la niebla ya no las desvanece.

## Novedades v2.7
- **Amigos** (menú y sala de espera, botón «👥 Amigos»): tienes un **código de amigo** de 6 letras; agregas el de tus amigos (les llega una solicitud para aceptar), ves si están **en línea, en una sala o en carrera** y pulsas **Invitar a mi sala**: a ellos les sale un aviso con «Unirme». Funciona con los mismos servidores MQTT públicos que las salas (sin servidor propio). Puedes ocultarte con «Mostrarme en línea».
- **Voz por cercanía** (solo en carrera): el volumen de cada jugador baja con la distancia en pista; en la sala de espera todo suena normal.
- **Techo de las cuevas**: con mucha velocidad pegado a la pared curva y empujando hacia ella, **subes al techo y te deslizas de panza boca abajo** (la cámara gira contigo; cuanto más rápido vas, más dura). **Saltar** te suelta; si caes boca arriba (o a mitad de una voltereta) te **enderezas solo** al aterrizar.
- **Avalancha visible**: el cielo se oscurece, aparece su **sombra** sobre la pista y la nieve que levanta se te adelanta; también un velo blanco en el borde inferior de la pantalla.
- **Volcán** nuevo: mapa de día (nada rojizo) que cruza **por dentro de una montaña** con túneles/cuevas y una gran sala con un volcán y lava; al salir sigue una pista normal.
- **Laguna**: al entrar el pingüino **flota y nada aleteando** (chapoteo, estela y sonido); al salir todo sigue normal.
- **Atajos** rehechos: nunca cerca de la meta ni del inicio, sin paredes invisibles, sin carteles «ATAJO» (solo flechas de neón que marcan los dos caminos). Las **montañas** ya no se atraviesan ni se ven transparentes.
- **Combate**: las focas salen volando si chocas con el escudo a toda velocidad; con **Turbo máximo** sacas volando a los pingüinos que choques; las **bolas de nieve** aturden más y alcanzan antes a los cercanos; **Empujar** manda más lejos y puede hacer volar sin aturdir; el bloque de hielo sale muy poco.
- **Esferas de poder** que reaparecen al instante para quienes vienen detrás.
- **Tienda**: los stickers del chat se compran allí (hay un botón de Tienda también en la sala multijugador).
- **Nivel**: la curva de niveles ahora llega a **100 000 puntos** para el nivel 200.
- **Pose de pie** de «Mi progreso» y «Mi pingüino»: mira al frente.

## Novedades v2.6
- **Tabla de resultados fiel**: el orden de llegada lo decide el anfitrión (o tu propio juego en solitario) y no cambia cuando llegan los demás; si ganas, sigues 1.º, con o sin bots y en multijugador.
- **Regla del 4.º lugar**: cuando el 4.º jugador cruza la meta, la carrera termina; quien no llegó pierde («no llegó») y aparecen las opciones **Siguiente carrera / pista** y **Repetir pista**.
- **Sala multijugador**: ya no se duplica tu nombre al salir y volver a entrar; el anfitrión solo puede iniciar cuando todos marcan **listo**, y puede **expulsar** a cualquier miembro (no es para siempre).
- **Chat**: la pestaña muestra un contador de mensajes nuevos (con sonido y aviso); **emojis y stickers** (hay paquetes gratis y otros que se compran en la tienda).
- **Progresión más lenta**: ahora hay **200 niveles** con una curva mucho más exigente (los giros dan la mitad de puntos).
- **Avalancha** más rápida al aparecer, con nieve que pasa a tu lado cuando está cerca y mejores partículas.
- **Ataques** que alcanzan mejor a los rivales (cajas de impacto más generosas, teledirigidos con más alcance, impacto decidido por quien lanza).
- **Gravedad** algo más pesada (saltos un poco más cortos).
- **Ropa** que ya no atraviesa al pingüino (chaqueta, capa, mochila, bufanda, gorros y lentes ajustados).
- **Espectadores** que miran de frente a la pista (el modelo de pie estaba inclinado hacia atrás; también corregido en *Personalizar*).
- **Cuevas** más altas y con bastantes menos obstáculos (menos carámbanos y casi sin rocas).

## Novedades v2.5
- **Atajos rehechos al estilo Mario Kart**: ya no salen de la misma recta. Los circuitos ahora son polígonos con esquinas redondeadas y, en las curvas cerradas, hay un camino aparte que **corta la esquina** (ahorra entre ~60 y ~125 m según la pista). Se entra pegándose al borde interior; dentro del atajo no se pueden usar armas ni habilidades de movimiento, y si te caes reapareces en la pista principal. Las pistas de bajada (rectas) no tienen atajos.
- **Estrellas y monedas**: ya no se dice cuántas monedas das por cada pirueta; arriba hay un contador de **monedas** y otro de **estrellas** que sube con tu rendimiento (terminar, podio, ganar y muchas piruetas).
- **Suelo corregido**: ya no se atraviesa el suelo al caer de un salto alto, ni te hundes al caer justo en el borde de una grieta ya pasada.
- **Pingüino de pie** y que se puede girar tanto en *Personalizar* como en *Estadísticas*; botón **Atrás** en *Personalizar* (descarta los cambios).
- **Cámara** que acompaña el giro cuando vas por paredes curvas o por el techo de las cuevas.
- **Obstáculos más separados** para poder esquivarlos.
- **3 mapas nuevos**: **Volcán Ardiente** (circuito alrededor de un volcán con lava, cráter brillante, humo y brasas), **Laguna Sumergida** (descenso con un tramo corto bajo el agua: pierdes poca velocidad, los saltos son flotantes y se ve todo azul con peces, algas, coral y burbujas) y **Serpiente del Abismo** (muchísimas curvas y, casi al final, una recta larguísima e inclinadísima).

## Novedades v2.4
- **Mapas rehechos sin portales**: pistas ~20 % más largas y 2-4 **caminos alternativos** por pista (lateral o central), separados por un muro bajo de hielo, con arco celeste y chevrones en el suelo, carril brillante con turbo continuo, pads y un cristal. La pista principal tiene obstáculos en ese tramo. El muro se puede saltar con buen tiempo.
- **Tienda y monedas**: ganas monedas por combos (piruetas) y por llegar 1.º, 2.º o 3.º; en la tienda compras poderes iniciales (máx. 3 de cada uno, precios altos). Se muestran en el menú y al terminar la carrera.
- **Estadísticas**: iconos, tu pingüino de pie, nivel, gráficas de porcentaje de puntos y de dinero.
- **Menos poderes en pista** y el mismo poder no sale más de 2 veces seguidas por jugador.
- **Posición final corregida** (llegar último ya no muestra «ganaste»), política de privacidad con scroll, **voz** con respaldo por la sala cuando falla la conexión directa, y origen seguro en Android para el micrófono.

## 1. Conseguir el APK

El APK hay que compilarlo con el SDK de Android (en el entorno donde se creó este proyecto no era posible descargarlo). Elige **una** opción:

### Opción A — GitHub Actions (sin instalar nada, ~5 min)
1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta** (incluida `.github/`).
2. Entra en la pestaña **Actions** → "Compilar APK" (se ejecuta solo al subir; también puedes pulsar *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **PenguinSlippery-apk** (un zip con `PenguinSlippery.apk`).

### Opción B — Android Studio
1. Abre la carpeta `android/` con Android Studio (acepta instalar el SDK 34 si lo pide).
2. Menú *Build ▸ Build APK(s)*. El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos (JDK 17 + Android SDK)
```
export ANDROID_HOME=/ruta/al/Android/Sdk
./build-apk.sh        # genera PenguinSlippery.apk
```

## 2. Instalar en el teléfono
1. Pasa el APK al móvil (WhatsApp, Drive, cable, etc.). Para el segundo jugador, envíale el mismo archivo.
2. Ábrelo. Android pedirá permitir **instalar apps de orígenes desconocidos** para la app desde la que lo abres (Archivos, Chrome, WhatsApp…): actívalo.
3. Si Play Protect avisa de "app no verificada", elige *Instalar de todos modos* (es un APK firmado con clave de depuración).

## 3. Jugar en multijugador

**Por Internet (código de sala)** — funciona aunque cada jugador esté en una red distinta (WiFi o datos):
1. Todos instalan **la misma versión** del APK.
2. Jugador 1: **Multijugador ▸ Internet ▸ Crear sala online**. Aparece un código de 5 letras; pulsa *Compartir código* y envíaselo a tus amigos.
3. Los demás: **Multijugador ▸ Internet ▸** escriben el código ▸ **Unirse**.
4. El anfitrión elige pista y pulsa **¡Iniciar carrera!**. Mantén abierta la app del anfitrión durante la partida.

Cómo funciona: no hay servidor propio. El juego usa brokers MQTT públicos gratuitos (HiveMQ, EMQX o Mosquitto, por WebSocket seguro) como buzón entre teléfonos; el teléfono anfitrión hace de servidor de la sala. Si alguno de esos servicios cae o tu red lo bloquea, en *Ajustes* puedes escribir un servidor MQTT propio (`wss://…`), igual en todos los jugadores. Los códigos no llevan contraseña: no compartas la tuya con desconocidos.

**Por red local (mismo WiFi):**
1. Todos instalan el APK y se conectan al mismo WiFi (o a la zona WiFi de un teléfono).
2. Jugador 1: **Multijugador ▸ Red local ▸ Crear sala**. Verá su IP en la pantalla.
3. Jugador 2: **Multijugador ▸ Red local ▸** aparece la sala en la lista (toca *Unirse*). Si no aparece (algunas redes bloquean el broadcast, p. ej. WiFi de invitados), escribe la IP del jugador 1 y pulsa **Unirse**.

## Controles
- **Móvil**: joystick izquierdo para girar (arriba = encogerse, abajo = frenar). A la derecha: *Saltar* (y piruetas en el aire), *Habilidad*, *Empujar*, *Disparar* (con el cañón) y el cuadro de *Turbo* (cohete). Pausa arriba.
- **PC (navegador)**: WASD/flechas, Espacio = turbo, E = turbo, Q = habilidad (usa la primera de la cola), C = saltar / voltereta (mantener), X = disparar (cañón).

## Probar en el PC sin APK
```
node server/server.js     # puerto 8080
```
Abre `http://IP-DEL-PC:8080` en cada navegador (móvil o PC). Para multijugador: uno pulsa *Crear sala* y los demás *Unirse* escribiendo la misma dirección.

## Estructura
- `web/` — el juego (HTML/JS/CSS, render WebGL propio, física, IA, red).
- `android/` — envoltorio Android (WebView + servidor de sala TCP + descubrimiento UDP). El juego se empaqueta desde `web/`.
- `server/server.js` — servidor para probar en PC (mismo protocolo que la app).
- `tools/` — pruebas en Node/Playwright usadas durante el desarrollo.

## Chat de voz: notas técnicas
- El audio va directo entre teléfonos (WebRTC). La señalización viaja por la misma sala (código o red local). Usa servidores STUN públicos de Google/Cloudflare; **no hay servidor TURN**, así que en algunas redes móviles muy restrictivas puede no conectar (en el mismo WiFi funciona casi siempre).
- La app pide el permiso de **micrófono** la primera vez que pulsas «Activar chat de voz». Si lo niegas puedes entrar solo para escuchar; para hablar, concede el permiso en los ajustes de Android y vuelve a activar la voz.
- Mejor con auriculares: con altavoz el micrófono puede recoger el sonido del juego.
