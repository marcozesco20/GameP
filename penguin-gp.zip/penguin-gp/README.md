# Penguin Slippery 🐧

Carreras de pingüinos deslizándose por el hielo, con multijugador por Internet (código de sala) y en red local.

- **12 pistas**: 5 circuitos de 3 vueltas (con colinas tipo montaña rusa) y 7 descensos de A → B muy inclinados, entre ellos **Picada Mortal** (caída casi vertical entre pinos y una cueva con picos de hielo que caen). Pista ancha, rampas, huecos, obstáculos y **cuevas altas** con paredes curvas por las que se puede subir con velocidad, techo sólido y **carámbanos que caen** (avisan con una marca roja en el suelo).
- **Meta con gradas**: pingüinos espectadores (el mismo diseño de los corredores, de pie, mirando a la pista y cada uno con su propia animación: aplauden, saludan, saltan, se balancean…), banderines, globos y cartel de SALIDA / META.
- **Pingüino** con tu modelo `PlayerP` (colores y ropa personalizables), aletas abiertas hacia los lados al deslizar. Árboles, iglús, montañas y cañón de nieve con tus modelos FBX.
- **Poderes (v2.3)**: ahora hay solo **dos casillas**. **Turbo** (cohete, abajo a la derecha) se recarga solo: tócalo para acelerar. **Habilidad** (junto a *Saltar*) guarda hasta 3 cargas que llegan de las esferas azules y violetas: bola de nieve teledirigida (pequeña, va al más cercano; **3-4 impactos aturden** un instante), trampa de hielo, **escudo**, **turbo máximo** (mucho más fuerte que el turbo normal; sale más a menudo si vas muy atrás), ventisca, alas de hielo, cañón de nieve, cañón de granadas, **mega bola** (arrasa todo), **misil teledirigido** (busca a los de delante, tiene tiempo limitado, explota con área, tira por los aires a quien toque y avisa con distancia si viene hacia ti), terremoto, fantasma y súper salto. Se lanza hacia adelante o hacia atrás deslizando el dedo hacia abajo.
- **Escudo y velocidad**: con escudo y mucha velocidad **rompes bloques de hielo y rocas**; los árboles no se rompen pero tampoco te aturden.
- **Avalancha**: en algunas carreras (se puede desactivar en *Ajustes*) una avalancha persigue a todos. Alerta discreta arriba con cuenta atrás y distancia (roja si está cerca). Si te alcanza quedas eliminado: ves "¡PERDISTE!" al instante, puedes seguir mirando a los que quedan o salir de la sala.
- **Atajos tipo Mario Kart** (solo circuitos): caminos con su propia geometría que cortan las curvas cerradas; cartel naranja «ATAJO», franjas naranjas, turbos, un cristal, hielo y una grieta que saltar. Los bots también los usan.
- **Progreso**: menú *📊 Mi progreso* con partidas jugadas, victorias, derrotas, porcentajes, podios y mejor tiempo por pista.
- **Sala multijugador**: botón **¡INICIAR CARRERA!** grande y siempre visible, miniatura de la pista, código de sala arriba, **chat de texto** y **chat de voz** (micrófono activable, silenciar mi micro, silenciar a un jugador o a todos).
- **Elegir pista**: cada pista muestra una miniatura real del juego y su mapa.
- **Empujones** suaves (alejan un poco al rival), bolas de nieve que **frenan y empujan** (el escudo las anula), obstáculos de hielo en forma de cristales, cuevas con pocos carámbanos (más brillantes), sin árboles y con muy pocas rocas, **girar tu pingüino** al personalizarlo (arrastrar o botones ◀ ▶), bots más listos con **4 niveles de dificultad** (Fácil, Normal, Difícil, Extremo) en carrera rápida y en la sala multijugador (lo elige el anfitrión).
- **Música** distinta según la pista (3 temas) con opción para quitarla en *Ajustes*, intro de Rockzord Games y mensajes de ánimo (¡Excelente!, ¡Sigue así!, ¡Genial!, último lugar, ¡Ganaste!).
- **Multijugador**: por **Internet con código de sala** (cualquier red) o por red local (hasta 6 pingüinos, humanos + bots).

## Novedades v2.7
- **Amigos** (menú y sala de espera, botón «👥 Amigos»): tienes un **código de amigo** de 6 letras; agregas el de tus amigos (les llega una solicitud para aceptar), ves si están **en línea, en una sala o en carrera** y pulsas **Invitar a mi sala**: a ellos les sale un aviso con «Unirme». Funciona con los mismos servidores MQTT públicos que las salas (sin servidor propio). Puedes ocultarte con «Mostrarme en línea».
- **Voz por cercanía** (solo en carrera): el volumen de cada jugador baja con la distancia en pista; en la sala de espera todo suena normal.
- **Techo de las cuevas**: con mucha velocidad pegado a la pared curva y empujando hacia ella, **subes al techo y te deslizas de panza boca abajo** (la cámara gira contigo; cuanto más rápido vas, más dura). **Saltar** te suelta; si caes boca arriba (o a mitad de una voltereta) te **enderezas solo** al aterrizar.
- **Avalancha visible**: el cielo se oscurece, aparece su **sombra** sobre la pista y la nieve que levanta se te adelanta; también un velo blanco en el borde inferior de la pantalla.
- **Volcán** nuevo: mapa de día (nada rojizo) que cruza **por dentro de una montaña** con túneles/cuevas y una gran sala con un volcán y lava; al salir sigue una pista normal.
- **Laguna**: al entrar el pingüino **flota y nada aleteando** (chapoteo, estela y sonido); al salir todo sigue normal.
- **Atajos** rehechos: nunca cerca de la meta ni del inicio, sin paredes invisibles, sin carteles «ATAJO» (solo flechas de neón que marcan los dos caminos). Las **montañas** ya no se atraviesan ni se ven transparentes.
- **Combate**: las focas salen volando si chocas con el escudo a toda velocidad; con **Turbo máximo** sacas volando a los pingüinos que choques; las **bolas de nieve** aturden más y alcanzan antes a los cercanos; **Empujar** manda más lejos y puede hacer volar sin aturdir; el bloque de hielo sale muy poco.
- **Esferas de poder** que reaparecen al instante para quienes vienen detrás.
- **Tienda**: los stickers del chat se compran allí (hay un botón de Tienda también en la sala multijugador).
- **Nivel**: la curva de niveles ahora llega a **100 000 puntos** para el nivel 200.
- **Pose de pie** de «Mi progreso» y «Mi pingüino»: mira al frente.

## Novedades v2.6
- **Tabla de resultados fiel**: el orden de llegada lo decide el anfitrión (o tu propio juego en solitario) y no cambia cuando llegan los demás; si ganas, sigues 1.º, con o sin bots y en multijugador.
- **Regla del 4.º lugar**: cuando el 4.º jugador cruza la meta, la carrera termina; quien no llegó pierde («no llegó») y aparecen las opciones **Siguiente carrera / pista** y **Repetir pista**.
- **Sala multijugador**: ya no se duplica tu nombre al salir y volver a entrar; el anfitrión solo puede iniciar cuando todos marcan **listo**, y puede **expulsar** a cualquier miembro (no es para siempre).
- **Chat**: la pestaña muestra un contador de mensajes nuevos (con sonido y aviso); **emojis y stickers** (hay paquetes gratis y otros que se compran en la tienda).
- **Progresión más lenta**: ahora hay **200 niveles** con una curva mucho más exigente (los giros dan la mitad de puntos).
- **Avalancha** más rápida al aparecer, con nieve que pasa a tu lado cuando está cerca y mejores partículas.
- **Ataques** que alcanzan mejor a los rivales (cajas de impacto más generosas, teledirigidos con más alcance, impacto decidido por quien lanza).
- **Gravedad** algo más pesada (saltos un poco más cortos).
- **Ropa** que ya no atraviesa al pingüino (chaqueta, capa, mochila, bufanda, gorros y lentes ajustados).
- **Espectadores** que miran de frente a la pista (el modelo de pie estaba inclinado hacia atrás; también corregido en *Personalizar*).
- **Cuevas** más altas y con bastantes menos obstáculos (menos carámbanos y casi sin rocas).

## Novedades v2.5
- **Atajos rehechos al estilo Mario Kart**: ya no salen de la misma recta. Los circuitos ahora son polígonos con esquinas redondeadas y, en las curvas cerradas, hay un camino aparte que **corta la esquina** (ahorra entre ~60 y ~125 m según la pista). Se entra pegándose al borde interior; dentro del atajo no se pueden usar armas ni habilidades de movimiento, y si te caes reapareces en la pista principal. Las pistas de bajada (rectas) no tienen atajos.
- **Estrellas y monedas**: ya no se dice cuántas monedas das por cada pirueta; arriba hay un contador de **monedas** y otro de **estrellas** que sube con tu rendimiento (terminar, podio, ganar y muchas piruetas).
- **Suelo corregido**: ya no se atraviesa el suelo al caer de un salto alto, ni te hundes al caer justo en el borde de una grieta ya pasada.
- **Pingüino de pie** y que se puede girar tanto en *Personalizar* como en *Estadísticas*; botón **Atrás** en *Personalizar* (descarta los cambios).
- **Cámara** que acompaña el giro cuando vas por paredes curvas o por el techo de las cuevas.
- **Obstáculos más separados** para poder esquivarlos.
- **3 mapas nuevos**: **Volcán Ardiente** (circuito alrededor de un volcán con lava, cráter brillante, humo y brasas), **Laguna Sumergida** (descenso con un tramo corto bajo el agua: pierdes poca velocidad, los saltos son flotantes y se ve todo azul con peces, algas, coral y burbujas) y **Serpiente del Abismo** (muchísimas curvas y, casi al final, una recta larguísima e inclinadísima).

## Novedades v2.4
- **Mapas rehechos sin portales**: pistas ~20 % más largas y 2-4 **caminos alternativos** por pista (lateral o central), separados por un muro bajo de hielo, con arco celeste y chevrones en el suelo, carril brillante con turbo continuo, pads y un cristal. La pista principal tiene obstáculos en ese tramo. El muro se puede saltar con buen tiempo.
- **Tienda y monedas**: ganas monedas por combos (piruetas) y por llegar 1.º, 2.º o 3.º; en la tienda compras poderes iniciales (máx. 3 de cada uno, precios altos). Se muestran en el menú y al terminar la carrera.
- **Estadísticas**: iconos, tu pingüino de pie, nivel, gráficas de porcentaje de puntos y de dinero.
- **Menos poderes en pista** y el mismo poder no sale más de 2 veces seguidas por jugador.
- **Posición final corregida** (llegar último ya no muestra «ganaste»), política de privacidad con scroll, **voz** con respaldo por la sala cuando falla la conexión directa, y origen seguro en Android para el micrófono.

## 1. Conseguir el APK

El APK hay que compilarlo con el SDK de Android (en el entorno donde se creó este proyecto no era posible descargarlo). Elige **una** opción:

### Opción A — GitHub Actions (sin instalar nada, ~5 min)
1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta** (incluida `.github/`).
2. Entra en la pestaña **Actions** → "Compilar APK" (se ejecuta solo al subir; también puedes pulsar *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **PenguinSlippery-apk** (un zip con `PenguinSlippery.apk`).

### Opción B — Android Studio
1. Abre la carpeta `android/` con Android Studio (acepta instalar el SDK 34 si lo pide).
2. Menú *Build ▸ Build APK(s)*. El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos (JDK 17 + Android SDK)
```
export ANDROID_HOME=/ruta/al/Android/Sdk
./build-apk.sh        # genera PenguinSlippery.apk
```

## 2. Instalar en el teléfono
1. Pasa el APK al móvil (WhatsApp, Drive, cable, etc.). Para el segundo jugador, envíale el mismo archivo.
2. Ábrelo. Android pedirá permitir **instalar apps de orígenes desconocidos** para la app desde la que lo abres (Archivos, Chrome, WhatsApp…): actívalo.
3. Si Play Protect avisa de "app no verificada", elige *Instalar de todos modos* (es un APK firmado con clave de depuración).

## 3. Jugar en multijugador

**Por Internet (código de sala)** — funciona aunque cada jugador esté en una red distinta (WiFi o datos):
1. Todos instalan **la misma versión** del APK.
2. Jugador 1: **Multijugador ▸ Internet ▸ Crear sala online**. Aparece un código de 5 letras; pulsa *Compartir código* y envíaselo a tus amigos.
3. Los demás: **Multijugador ▸ Internet ▸** escriben el código ▸ **Unirse**.
4. El anfitrión elige pista y pulsa **¡Iniciar carrera!**. Mantén abierta la app del anfitrión durante la partida.

Cómo funciona: no hay servidor propio. El juego usa brokers MQTT públicos gratuitos (HiveMQ, EMQX o Mosquitto, por WebSocket seguro) como buzón entre teléfonos; el teléfono anfitrión hace de servidor de la sala. Si alguno de esos servicios cae o tu red lo bloquea, en *Ajustes* puedes escribir un servidor MQTT propio (`wss://…`), igual en todos los jugadores. Los códigos no llevan contraseña: no compartas la tuya con desconocidos.

**Por red local (mismo WiFi):**
1. Todos instalan el APK y se conectan al mismo WiFi (o a la zona WiFi de un teléfono).
2. Jugador 1: **Multijugador ▸ Red local ▸ Crear sala**. Verá su IP en la pantalla.
3. Jugador 2: **Multijugador ▸ Red local ▸** aparece la sala en la lista (toca *Unirse*). Si no aparece (algunas redes bloquean el broadcast, p. ej. WiFi de invitados), escribe la IP del jugador 1 y pulsa **Unirse**.

## Controles
- **Móvil**: joystick izquierdo para girar (arriba = encogerse, abajo = frenar). A la derecha: *Saltar* (y piruetas en el aire), *Habilidad*, *Empujar*, *Disparar* (con el cañón) y el cuadro de *Turbo* (cohete). Pausa arriba.
- **PC (navegador)**: WASD/flechas, Espacio = turbo, E = turbo, Q = habilidad (usa la primera de la cola), C = saltar / voltereta (mantener), X = disparar (cañón).

## Probar en el PC sin APK
```
node server/server.js     # puerto 8080
```
Abre `http://IP-DEL-PC:8080` en cada navegador (móvil o PC). Para multijugador: uno pulsa *Crear sala* y los demás *Unirse* escribiendo la misma dirección.

## Estructura
- `web/` — el juego (HTML/JS/CSS, render WebGL propio, física, IA, red).
- `android/` — envoltorio Android (WebView + servidor de sala TCP + descubrimiento UDP). El juego se empaqueta desde `web/`.
- `server/server.js` — servidor para probar en PC (mismo protocolo que la app).
- `tools/` — pruebas en Node/Playwright usadas durante el desarrollo.

## Chat de voz: notas técnicas
- El audio va directo entre teléfonos (WebRTC). La señalización viaja por la misma sala (código o red local). Usa servidores STUN públicos de Google/Cloudflare; **no hay servidor TURN**, así que en algunas redes móviles muy restrictivas puede no conectar (en el mismo WiFi funciona casi siempre).
- La app pide el permiso de **micrófono** la primera vez que pulsas «Activar chat de voz». Si lo niegas puedes entrar solo para escuchar; para hablar, concede el permiso en los ajustes de Android y vuelve a activar la voz.
- Mejor con auriculares: con altavoz el micrófono puede recoger el sonido del juego.
