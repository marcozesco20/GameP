# Penguin Slippery Grand Prix 🐧

Carreras de pingüinos deslizándose por el hielo, con multijugador por Internet (código de sala) y en red local.

- **8 pistas**: 4 circuitos de 3 vueltas (con colinas tipo montaña rusa) y 4 descensos de A → B muy inclinados. Pista ancha, rampas, huecos, obstáculos y **cuevas/túneles de roca** con cristales luminosos.
- **Pingüino** con tu modelo `PlayerP` (colores y ropa personalizables), aletas abiertas hacia los lados al deslizar. Árboles, iglús, montañas y cañón de nieve con tus modelos FBX.
- **Poderes** repartidos por toda la pista (se reaparecen a los 2 s): esferas azules de objeto (pez turbo, bola de nieve, trampa de hielo, escudo) y esferas violetas de habilidad (ventisca, alas de hielo y **cañón de nieve**). Junto a *Saltar* están *Habilidad*, *Empujar* y *Disparar*. Se pueden lanzar objetos hacia adelante o hacia atrás deslizando el dedo hacia abajo al apuntar.
- **Empujones** en plena carrera, giro más fácil, bots más listos.
- **Multijugador**: por **Internet con código de sala** (cualquier red) o por red local (hasta 6 pingüinos, humanos + bots).

## 1. Conseguir el APK

El APK hay que compilarlo con el SDK de Android (en el entorno donde se creó este proyecto no era posible descargarlo). Elige **una** opción:

### Opción A — GitHub Actions (sin instalar nada, ~5 min)
1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta** (incluida `.github/`).
2. Entra en la pestaña **Actions** → "Compilar APK" (se ejecuta solo al subir; también puedes pulsar *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **PenguinSlippery-apk** (un zip con `PenguinSlippery.apk`).

### Opción B — Android Studio
1. Abre la carpeta `android/` con Android Studio (acepta instalar el SDK 34 si lo pide).
2. Menú *Build ▸ Build APK(s)*. El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos (JDK 17 + Android SDK)
```
export ANDROID_HOME=/ruta/al/Android/Sdk
./build-apk.sh        # genera PenguinSlippery.apk
```

## 2. Instalar en el teléfono
1. Pasa el APK al móvil (WhatsApp, Drive, cable, etc.). Para el segundo jugador, envíale el mismo archivo.
2. Ábrelo. Android pedirá permitir **instalar apps de orígenes desconocidos** para la app desde la que lo abres (Archivos, Chrome, WhatsApp…): actívalo.
3. Si Play Protect avisa de "app no verificada", elige *Instalar de todos modos* (es un APK firmado con clave de depuración).

## 3. Jugar en multijugador

**Por Internet (código de sala)** — funciona aunque cada jugador esté en una red distinta (WiFi o datos):
1. Todos instalan **la misma versión** del APK.
2. Jugador 1: **Multijugador ▸ Internet ▸ Crear sala online**. Aparece un código de 5 letras; pulsa *Compartir código* y envíaselo a tus amigos.
3. Los demás: **Multijugador ▸ Internet ▸** escriben el código ▸ **Unirse**.
4. El anfitrión elige pista y pulsa **¡Iniciar carrera!**. Mantén abierta la app del anfitrión durante la partida.

Cómo funciona: no hay servidor propio. El juego usa brokers MQTT públicos gratuitos (HiveMQ, EMQX o Mosquitto, por WebSocket seguro) como buzón entre teléfonos; el teléfono anfitrión hace de servidor de la sala. Si alguno de esos servicios cae o tu red lo bloquea, en *Ajustes* puedes escribir un servidor MQTT propio (`wss://…`), igual en todos los jugadores. Los códigos no llevan contraseña: no compartas la tuya con desconocidos.

**Por red local (mismo WiFi):**
1. Todos instalan el APK y se conectan al mismo WiFi (o a la zona WiFi de un teléfono).
2. Jugador 1: **Multijugador ▸ Red local ▸ Crear sala**. Verá su IP en la pantalla.
3. Jugador 2: **Multijugador ▸ Red local ▸** aparece la sala en la lista (toca *Unirse*). Si no aparece (algunas redes bloquean el broadcast, p. ej. WiFi de invitados), escribe la IP del jugador 1 y pulsa **Unirse**.

## Controles
- **Móvil**: joystick izquierdo para girar (arriba = encogerse, abajo = frenar). A la derecha: *Saltar* (y piruetas en el aire), *Habilidad*, *Empujar*, *Disparar* (con el cañón) y el cuadro de *Objeto* (pez turbo, bola de nieve, trampa, escudo; desliza hacia abajo para lanzar hacia atrás). Pausa arriba.
- **PC (navegador)**: WASD/flechas, Espacio = turbo, E = objeto, Q = habilidad, C = saltar / voltereta (mantener), X = disparar (cañón).

## Probar en el PC sin APK
```
node server/server.js     # puerto 8080
```
Abre `http://IP-DEL-PC:8080` en cada navegador (móvil o PC). Para multijugador: uno pulsa *Crear sala* y los demás *Unirse* escribiendo la misma dirección.

## Estructura
- `web/` — el juego (HTML/JS/CSS, render WebGL propio, física, IA, red).
- `android/` — envoltorio Android (WebView + servidor de sala TCP + descubrimiento UDP). El juego se empaqueta desde `web/`.
- `server/server.js` — servidor para probar en PC (mismo protocolo que la app).
- `tools/` — pruebas en Node/Playwright usadas durante el desarrollo.
