# Penguin Slippery 🐧

Carreras de pingüinos deslizándose por el hielo, con multijugador por Internet (código de sala) y en red local.

- **9 pistas**: 4 circuitos de 3 vueltas (con colinas tipo montaña rusa) y 5 descensos de A → B muy inclinados, entre ellos **Picada Mortal** (caída casi vertical entre pinos y una cueva con picos de hielo que caen). Pista ancha, rampas, huecos, obstáculos y **cuevas altas** con paredes curvas por las que se puede subir con velocidad, techo sólido y **carámbanos que caen** (avisan con una marca roja en el suelo).
- **Meta con gradas**: pingüinos espectadores (el mismo diseño de los corredores, de pie, mirando a la pista y cada uno con su propia animación: aplauden, saludan, saltan, se balancean…), banderines, globos y cartel de SALIDA / META.
- **Pingüino** con tu modelo `PlayerP` (colores y ropa personalizables), aletas abiertas hacia los lados al deslizar. Árboles, iglús, montañas y cañón de nieve con tus modelos FBX.
- **Poderes (v2.3)**: ahora hay solo **dos casillas**. **Turbo** (cohete, abajo a la derecha) se recarga solo: tócalo para acelerar. **Habilidad** (junto a *Saltar*) guarda hasta 3 cargas que llegan de las esferas azules y violetas: bola de nieve teledirigida (pequeña, va al más cercano; **3-4 impactos aturden** un instante), trampa de hielo, **escudo**, **turbo máximo** (mucho más fuerte que el turbo normal; sale más a menudo si vas muy atrás), ventisca, alas de hielo, cañón de nieve, cañón de granadas, **mega bola** (arrasa todo), **misil teledirigido** (busca a los de delante, tiene tiempo limitado, explota con área, tira por los aires a quien toque y avisa con distancia si viene hacia ti), terremoto, fantasma y súper salto. Se lanza hacia adelante o hacia atrás deslizando el dedo hacia abajo.
- **Escudo y velocidad**: con escudo y mucha velocidad **rompes bloques de hielo y rocas**; los árboles no se rompen pero tampoco te aturden.
- **Avalancha**: en algunas carreras (se puede desactivar en *Ajustes*) una avalancha persigue a todos. Alerta discreta arriba con cuenta atrás y distancia (roja si está cerca). Si te alcanza quedas eliminado: ves "¡PERDISTE!" al instante, puedes seguir mirando a los que quedan o salir de la sala.
- **Caminos alternativos**: carriles separados por un muro bajo de hielo, con arco celeste discreto, turbo continuo, pads y un cristal; la pista principal tiene obstáculos. Los bots también los usan.
- **Progreso**: menú *📊 Mi progreso* con partidas jugadas, victorias, derrotas, porcentajes, podios y mejor tiempo por pista.
- **Sala multijugador**: botón **¡INICIAR CARRERA!** grande y siempre visible, miniatura de la pista, código de sala arriba, **chat de texto** y **chat de voz** (micrófono activable, silenciar mi micro, silenciar a un jugador o a todos).
- **Elegir pista**: cada pista muestra una miniatura real del juego y su mapa.
- **Empujones** suaves (alejan un poco al rival), bolas de nieve que **frenan y empujan** (el escudo las anula), obstáculos de hielo en forma de cristales, cuevas con pocos carámbanos (más brillantes), sin árboles y con muy pocas rocas, **girar tu pingüino** al personalizarlo (arrastrar o botones ◀ ▶), bots más listos con **4 niveles de dificultad** (Fácil, Normal, Difícil, Extremo) en carrera rápida y en la sala multijugador (lo elige el anfitrión).
- **Música** distinta según la pista (3 temas) con opción para quitarla en *Ajustes*, intro de Rockzord Games y mensajes de ánimo (¡Excelente!, ¡Sigue así!, ¡Genial!, último lugar, ¡Ganaste!).
- **Multijugador**: por **Internet con código de sala** (cualquier red) o por red local (hasta 6 pingüinos, humanos + bots).

## Novedades v2.4
- **Mapas rehechos sin portales**: pistas ~20 % más largas y 2-4 **caminos alternativos** por pista (lateral o central), separados por un muro bajo de hielo, con arco celeste y chevrones en el suelo, carril brillante con turbo continuo, pads y un cristal. La pista principal tiene obstáculos en ese tramo. El muro se puede saltar con buen tiempo.
- **Tienda y monedas**: ganas monedas por combos (piruetas) y por llegar 1.º, 2.º o 3.º; en la tienda compras poderes iniciales (máx. 3 de cada uno, precios altos). Se muestran en el menú y al terminar la carrera.
- **Estadísticas**: iconos, tu pingüino de pie, nivel, gráficas de porcentaje de puntos y de dinero.
- **Menos poderes en pista** y el mismo poder no sale más de 2 veces seguidas por jugador.
- **Posición final corregida** (llegar último ya no muestra «ganaste»), política de privacidad con scroll, **voz** con respaldo por la sala cuando falla la conexión directa, y origen seguro en Android para el micrófono.

## 1. Conseguir el APK

El APK hay que compilarlo con el SDK de Android (en el entorno donde se creó este proyecto no era posible descargarlo). Elige **una** opción:

### Opción A — GitHub Actions (sin instalar nada, ~5 min)
1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta** (incluida `.github/`).
2. Entra en la pestaña **Actions** → "Compilar APK" (se ejecuta solo al subir; también puedes pulsar *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **PenguinSlippery-apk** (un zip con `PenguinSlippery.apk`).

### Opción B — Android Studio
1. Abre la carpeta `android/` con Android Studio (acepta instalar el SDK 34 si lo pide).
2. Menú *Build ▸ Build APK(s)*. El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos (JDK 17 + Android SDK)
```
export ANDROID_HOME=/ruta/al/Android/Sdk
./build-apk.sh        # genera PenguinSlippery.apk
```

## 2. Instalar en el teléfono
1. Pasa el APK al móvil (WhatsApp, Drive, cable, etc.). Para el segundo jugador, envíale el mismo archivo.
2. Ábrelo. Android pedirá permitir **instalar apps de orígenes desconocidos** para la app desde la que lo abres (Archivos, Chrome, WhatsApp…): actívalo.
3. Si Play Protect avisa de "app no verificada", elige *Instalar de todos modos* (es un APK firmado con clave de depuración).

## 3. Jugar en multijugador

**Por Internet (código de sala)** — funciona aunque cada jugador esté en una red distinta (WiFi o datos):
1. Todos instalan **la misma versión** del APK.
2. Jugador 1: **Multijugador ▸ Internet ▸ Crear sala online**. Aparece un código de 5 letras; pulsa *Compartir código* y envíaselo a tus amigos.
3. Los demás: **Multijugador ▸ Internet ▸** escriben el código ▸ **Unirse**.
4. El anfitrión elige pista y pulsa **¡Iniciar carrera!**. Mantén abierta la app del anfitrión durante la partida.

Cómo funciona: no hay servidor propio. El juego usa brokers MQTT públicos gratuitos (HiveMQ, EMQX o Mosquitto, por WebSocket seguro) como buzón entre teléfonos; el teléfono anfitrión hace de servidor de la sala. Si alguno de esos servicios cae o tu red lo bloquea, en *Ajustes* puedes escribir un servidor MQTT propio (`wss://…`), igual en todos los jugadores. Los códigos no llevan contraseña: no compartas la tuya con desconocidos.

**Por red local (mismo WiFi):**
1. Todos instalan el APK y se conectan al mismo WiFi (o a la zona WiFi de un teléfono).
2. Jugador 1: **Multijugador ▸ Red local ▸ Crear sala**. Verá su IP en la pantalla.
3. Jugador 2: **Multijugador ▸ Red local ▸** aparece la sala en la lista (toca *Unirse*). Si no aparece (algunas redes bloquean el broadcast, p. ej. WiFi de invitados), escribe la IP del jugador 1 y pulsa **Unirse**.

## Controles
- **Móvil**: joystick izquierdo para girar (arriba = encogerse, abajo = frenar). A la derecha: *Saltar* (y piruetas en el aire), *Habilidad*, *Empujar*, *Disparar* (con el cañón) y el cuadro de *Turbo* (cohete). Pausa arriba.
- **PC (navegador)**: WASD/flechas, Espacio = turbo, E = turbo, Q = habilidad (usa la primera de la cola), C = saltar / voltereta (mantener), X = disparar (cañón).

## Probar en el PC sin APK
```
node server/server.js     # puerto 8080
```
Abre `http://IP-DEL-PC:8080` en cada navegador (móvil o PC). Para multijugador: uno pulsa *Crear sala* y los demás *Unirse* escribiendo la misma dirección.

## Estructura
- `web/` — el juego (HTML/JS/CSS, render WebGL propio, física, IA, red).
- `android/` — envoltorio Android (WebView + servidor de sala TCP + descubrimiento UDP). El juego se empaqueta desde `web/`.
- `server/server.js` — servidor para probar en PC (mismo protocolo que la app).
- `tools/` — pruebas en Node/Playwright usadas durante el desarrollo.

## Chat de voz: notas técnicas
- El audio va directo entre teléfonos (WebRTC). La señalización viaja por la misma sala (código o red local). Usa servidores STUN públicos de Google/Cloudflare; **no hay servidor TURN**, así que en algunas redes móviles muy restrictivas puede no conectar (en el mismo WiFi funciona casi siempre).
- La app pide el permiso de **micrófono** la primera vez que pulsas «Activar chat de voz». Si lo niegas puedes entrar solo para escuchar; para hablar, concede el permiso en los ajustes de Android y vuelve a activar la voz.
- Mejor con auriculares: con altavoz el micrófono puede recoger el sonido del juego.
