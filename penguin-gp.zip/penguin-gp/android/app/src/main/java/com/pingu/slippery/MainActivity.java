package com.pingu.slippery;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Actividad única: un WebView a pantalla completa que carga el juego desde assets. */
public class MainActivity extends Activity {
    private WebView web;
    private NetBridge net;
    private PermissionRequest pendingMic;
    private ValueCallback<Uri[]> fileCb;
    private static final int REQ_FILE = 78;
    private static final int REQ_MIC = 77;
    /** El juego se sirve desde este origen https virtual (los archivos salen de assets): es un contexto seguro, necesario para el micrófono (getUserMedia). */
    private static final String HOST = "appassets.androidplatform.net";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(10, 20, 40));
        web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLongClickable(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { return true; }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setUseWideViewPort(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        net = new NetBridge(this, web);
        web.addJavascriptInterface(net, "NativeNet");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                android.net.Uri u = req.getUrl();
                if (u == null || !HOST.equals(u.getHost())) return null;
                return serveAsset(u.getPath(), req.getRequestHeaders());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            /** Chat de voz: el juego pide el micrófono (getUserMedia); aquí se pide el permiso de Android y se concede a la página. */
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        boolean wantsAudio = false;
                        for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsAudio = true;
                        if (!wantsAudio) { request.deny(); return; }
                        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                        } else {
                            if (pendingMic != null) pendingMic.deny();
                            pendingMic = request;
                            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                        }
                    }
                });
            }

            /** v3.0: foto de perfil de «Amigos»: el input type=file abre el selector de imágenes del sistema (no pide permisos de almacenamiento). */
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) { fileCb.onReceiveValue(null); fileCb = null; }
                fileCb = cb;
                try {
                    Intent it = new Intent(Intent.ACTION_GET_CONTENT);
                    it.addCategory(Intent.CATEGORY_OPENABLE);
                    it.setType("image/*");
                    startActivityForResult(Intent.createChooser(it, "Elige una foto"), REQ_FILE);
                } catch (Exception e) {
                    fileCb.onReceiveValue(null); fileCb = null; return false;
                }
                return true;
            }

            @Override public boolean onConsoleMessage(ConsoleMessage m) {
                android.util.Log.d("PenguinGP", m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });

        setContentView(web);
        web.loadUrl("https://" + HOST + "/index.html");
        hideSystemUi();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != REQ_FILE || fileCb == null) return;
        Uri[] r = null;
        if (result == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
        fileCb.onReceiveValue(r); fileCb = null;
        hideSystemUi();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_MIC || pendingMic == null) return;
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (ok) pendingMic.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE}); else pendingMic.deny();
        pendingMic = null;
        hideSystemUi();
    }

    private static String mimeOf(String p) {
        String l = p.toLowerCase();
        if (l.endsWith(".html")) return "text/html";
        if (l.endsWith(".js")) return "application/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".ttf")) return "font/ttf";
        if (l.endsWith(".woff2")) return "font/woff2";
        if (l.endsWith(".mp3")) return "audio/mpeg";
        if (l.endsWith(".ogg")) return "audio/ogg";
        if (l.endsWith(".wav")) return "audio/wav";
        return "application/octet-stream";
    }

    /** Sirve un archivo de assets (con soporte de Range para la música). */
    private WebResourceResponse serveAsset(String path, Map<String, String> reqHeaders) {
        Map<String, String> h = new HashMap<String, String>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        h.put("Accept-Ranges", "bytes");
        if (path == null || path.equals("/") || path.length() == 0) path = "/index.html";
        String name = path.startsWith("/") ? path.substring(1) : path;
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            byte[] data = bo.toByteArray();
            String mime = mimeOf(name);
            String enc = (mime.startsWith("text/") || mime.endsWith("javascript") || mime.endsWith("json") || mime.endsWith("svg+xml")) ? "UTF-8" : null;
            String range = reqHeaders == null ? null : reqHeaders.get("Range");
            if (range != null && range.startsWith("bytes=")) {
                try {
                    String[] pr = range.substring(6).split("-", 2);
                    int a = pr[0].length() > 0 ? Integer.parseInt(pr[0]) : 0;
                    int b = (pr.length > 1 && pr[1].length() > 0) ? Integer.parseInt(pr[1]) : data.length - 1;
                    if (b >= data.length) b = data.length - 1;
                    if (a <= b) {
                        byte[] part = new byte[b - a + 1];
                        System.arraycopy(data, a, part, 0, part.length);
                        h.put("Content-Range", "bytes " + a + "-" + b + "/" + data.length);
                        h.put("Content-Length", String.valueOf(part.length));
                        return new WebResourceResponse(mime, enc, 206, "Partial Content", h, new ByteArrayInputStream(part));
                    }
                } catch (NumberFormatException ignore) { /* se sirve completo */ }
            }
            h.put("Content-Length", String.valueOf(data.length));
            return new WebResourceResponse(mime, enc, 200, "OK", h, new ByteArrayInputStream(data));
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
        }
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    /** El botón Atrás lo gestiona el juego (pausa, volver, salir de la sala); si dice false, se cierra la app. */
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){try{return window.PGBack?window.PGBack():false}catch(e){return false}})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String v) {
                        if (!"true".equals(v)) finish();
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (net != null) net.shutdown();
        if (web != null) {
            web.removeJavascriptInterface("NativeNet");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
