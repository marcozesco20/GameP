package com.pingu.slippery;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Puente de red entre el juego (JavaScript) y la red local.
 *
 * - Servidor de sala (TCP): retransmite los mensajes entre jugadores. Es el mismo protocolo que
 *   server/server.js: mensajes JSON de una línea; el servidor añade "f":idRemitente al reenviar.
 * - Cliente (TCP): se conecta a una sala (la del propio teléfono o la de otro).
 * - Descubrimiento (UDP broadcast, puerto 47777): el anfitrión anuncia "PGP1|puerto|nombre|jugadores".
 *
 * Los eventos hacia JS se agrupan y se envían con PGNative.onEvent(tipo, texto).
 */
public class NetBridge {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int DISCOVERY_PORT = 47777;
    private static final String MAGIC = "PGP1";

    private final Activity activity;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ---- cola de eventos hacia JS ----
    private final ConcurrentLinkedQueue<String[]> events = new ConcurrentLinkedQueue<String[]>();
    private boolean flushPending = false;
    private final Object flushLock = new Object();
    private volatile boolean dead = false;

    // ---- servidor ----
    private final Object hostLock = new Object();
    private ServerSocket serverSocket;
    private final TreeMap<Integer, Peer> peers = new TreeMap<Integer, Peer>();
    private int nextId = 1;
    private volatile Thread beaconThread;
    private volatile String hostName = "Sala";
    private volatile int hostPort = 47777;
    private volatile boolean hosting = false;

    // ---- cliente ----
    private final Object clientLock = new Object();
    private Conn client;
    private int clientGen = 0;

    // ---- descubrimiento ----
    private volatile DatagramSocket discSocket;
    private volatile boolean discovering = false;
    private WifiManager.MulticastLock mcLock;

    public NetBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    // =====================================================================
    //  Eventos hacia JavaScript
    // =====================================================================
    private void emit(String type, String payload) {
        if (dead) return;
        events.add(new String[]{type, payload == null ? "" : payload});
        synchronized (flushLock) {
            if (flushPending) return;
            flushPending = true;
        }
        ui.post(new Runnable() {
            @Override public void run() { flush(); }
        });
    }

    private void flush() {
        synchronized (flushLock) { flushPending = false; }
        if (dead) return;
        StringBuilder sb = new StringBuilder("(function(){var p=window.PGNative;if(!p)return;var f=p.onEvent;");
        int n = 0;
        String[] e;
        while ((e = events.poll()) != null) {
            sb.append("f('").append(e[0]).append("',").append(jsQuote(e[1])).append(");");
            if (++n >= 200) break;
        }
        sb.append("})()");
        if (n == 0) return;
        try {
            web.evaluateJavascript(sb.toString(), null);
        } catch (RuntimeException ex) {
            // WebView destruido
        }
        if (!events.isEmpty()) {
            synchronized (flushLock) {
                if (flushPending) return;
                flushPending = true;
            }
            ui.post(new Runnable() {
                @Override public void run() { flush(); }
            });
        }
    }

    /** Literal de cadena JavaScript seguro (comillas dobles). */
    static String jsQuote(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case ' ': sb.append("\\u2028"); break;
                case ' ': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String jsonStr(String s) {
        return jsQuote(s);
    }

    // =====================================================================
    //  Conexión TCP con cola de escritura (usada por cliente y por pares del servidor)
    // =====================================================================
    private abstract static class Conn {
        final Socket socket;
        final LinkedBlockingQueue<String> out = new LinkedBlockingQueue<String>();
        volatile boolean closed = false;

        Conn(Socket s) { this.socket = s; }

        void send(String line) {
            if (closed) return;
            // Si el destino va muy atrasado se descartan mensajes viejos para no acumular retraso.
            if (out.size() > 400) { out.clear(); }
            out.add(line);
        }

        void startWriter() {
            Thread t = new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        OutputStream os = socket.getOutputStream();
                        while (!closed) {
                            String s = out.take();
                            if (s.length() == 0) break; // señal de cierre
                            // Se agrupan los mensajes pendientes en un solo write
                            StringBuilder sb = new StringBuilder(s.length() + 1);
                            sb.append(s).append('\n');
                            String more;
                            while (sb.length() < 16000 && (more = out.poll()) != null) {
                                if (more.length() == 0) { closed = true; break; }
                                sb.append(more).append('\n');
                            }
                            os.write(sb.toString().getBytes(UTF8));
                            os.flush();
                        }
                    } catch (Exception e) {
                        // se cierra abajo
                    } finally {
                        close();
                    }
                }
            }, "pg-writer");
            t.setDaemon(true);
            t.start();
        }

        private final java.util.concurrent.atomic.AtomicBoolean done = new java.util.concurrent.atomic.AtomicBoolean(false);

        void close() {
            closed = true;
            out.offer("");
            try { socket.close(); } catch (IOException ignored) { }
            if (done.compareAndSet(false, true)) onClosed();
        }

        abstract void onClosed();
    }

    private final class Peer extends Conn {
        final int id;
        volatile String hello;

        Peer(int id, Socket s) { super(s); this.id = id; }

        @Override void onClosed() { removePeer(this); }
    }

    // =====================================================================
    //  Servidor de sala
    // =====================================================================
    @JavascriptInterface
    public void startHost(final int port, final String name) {
        synchronized (hostLock) {
            if (hosting) { emit("hosted", "{\"ip\":" + jsonStr(getLocalIp()) + ",\"port\":" + hostPort + "}"); return; }
            hostName = (name == null || name.trim().length() == 0) ? "Sala" : name.trim();
            hostPort = port;
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port));
                serverSocket = ss;
            } catch (IOException e) {
                emit("error", "No se pudo crear la sala (puerto ocupado): " + e.getMessage());
                return;
            }
            hosting = true;
            nextId = 1;
            peers.clear();
        }
        final ServerSocket ss = serverSocket;
        Thread acc = new Thread(new Runnable() {
            @Override public void run() {
                while (hosting && !ss.isClosed()) {
                    try {
                        Socket s = ss.accept();
                        s.setTcpNoDelay(true);
                        addPeer(s);
                    } catch (IOException e) {
                        break;
                    }
                }
            }
        }, "pg-accept");
        acc.setDaemon(true);
        acc.start();
        startBeacon();
        emit("hosted", "{\"ip\":" + jsonStr(getLocalIp()) + ",\"port\":" + port + "}");
    }

    @JavascriptInterface
    public void stopHost() {
        List<Peer> copy;
        synchronized (hostLock) {
            hosting = false;
            if (serverSocket != null) { try { serverSocket.close(); } catch (IOException ignored) { } serverSocket = null; }
            copy = new ArrayList<Peer>(peers.values());
            peers.clear();
        }
        Thread b = beaconThread;
        beaconThread = null;
        if (b != null) b.interrupt();
        for (Peer p : copy) p.close();
    }

    private int hostIdLocked() {
        return peers.isEmpty() ? 0 : peers.firstKey();
    }

    private void addPeer(Socket s) {
        final Peer p;
        List<Peer> others;
        synchronized (hostLock) {
            if (!hosting) { try { s.close(); } catch (IOException ignored) { } return; }
            if (peers.size() >= 12) { try { s.close(); } catch (IOException ignored) { } return; }
            p = new Peer(nextId++, s);
            peers.put(p.id, p);
            others = new ArrayList<Peer>(peers.values());
            // bienvenida
            p.send("{\"t\":\"welcome\",\"id\":" + p.id + ",\"host\":" + hostIdLocked() + ",\"ip\":" + jsonStr(getLocalIp()) + "}");
            // "hello" de los jugadores ya presentes
            for (Peer o : others) {
                if (o != p && o.hello != null) p.send("{\"f\":" + o.id + "," + o.hello.substring(1));
            }
        }
        p.startWriter();
        for (Peer o : others) if (o != p) o.send("{\"t\":\"join\",\"id\":" + p.id + "}");

        Thread rd = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.socket.getInputStream(), UTF8), 8192);
                    String line;
                    while (!p.closed && (line = br.readLine()) != null) {
                        if (line.length() < 2 || line.charAt(0) != '{') continue;
                        if (line.indexOf("\"t\":\"hello\"") >= 0) p.hello = line;
                        String fwd = "{\"f\":" + p.id + "," + line.substring(1);
                        List<Peer> all;
                        synchronized (hostLock) { all = new ArrayList<Peer>(peers.values()); }
                        for (Peer o : all) if (o != p) o.send(fwd);
                    }
                } catch (Exception ignored) {
                } finally {
                    p.close();
                }
            }
        }, "pg-peer-" + p.id);
        rd.setDaemon(true);
        rd.start();
    }

    private void removePeer(Peer p) {
        List<Peer> rest;
        boolean was;
        int newHost;
        synchronized (hostLock) {
            was = peers.remove(p.id) != null;
            if (!was) return;
            rest = new ArrayList<Peer>(peers.values());
            newHost = hostIdLocked();
        }
        // ¿era el anfitrión? (el de menor id)
        boolean leftWasHost = rest.isEmpty() ? false : p.id < newHost;
        String leave = "{\"t\":\"leave\",\"id\":" + p.id + "}";
        for (Peer o : rest) o.send(leave);
        if (leftWasHost) {
            String h = "{\"t\":\"host\",\"id\":" + newHost + "}";
            for (Peer o : rest) o.send(h);
        }
    }

    private int peerCount() {
        synchronized (hostLock) { return peers.size(); }
    }

    // =====================================================================
    //  Cliente
    // =====================================================================
    @JavascriptInterface
    public void connect(final String ip, final int port) {
        final int gen;
        Conn old;
        synchronized (clientLock) {
            gen = ++clientGen;
            old = client;
            client = null;
        }
        if (old != null) old.close();
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                Socket s = new Socket();
                try {
                    s.connect(new InetSocketAddress(ip, port), 5000);
                    s.setTcpNoDelay(true);
                } catch (Exception e) {
                    try { s.close(); } catch (IOException ignored) { }
                    if (isCurrent(gen)) emit("error", e.getMessage() == null ? e.toString() : e.getMessage());
                    return;
                }
                final Conn c = new Conn(s) {
                    @Override void onClosed() {
                        boolean cur;
                        synchronized (clientLock) {
                            cur = (gen == clientGen);
                            if (cur) client = null;
                        }
                        if (cur) emit("close", "cerrada");
                    }
                };
                synchronized (clientLock) {
                    if (gen != clientGen) { try { s.close(); } catch (IOException ignored) { } return; }
                    client = c;
                }
                c.startWriter();
                emit("open", "");
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), UTF8), 8192);
                    String line;
                    while (!c.closed && (line = br.readLine()) != null) {
                        if (line.length() > 1) emit("msg", line);
                    }
                } catch (Exception ignored) {
                } finally {
                    c.close();
                }
            }
        }, "pg-client");
        t.setDaemon(true);
        t.start();
    }

    private boolean isCurrent(int gen) {
        synchronized (clientLock) { return gen == clientGen; }
    }

    @JavascriptInterface
    public void send(String json) {
        Conn c;
        synchronized (clientLock) { c = client; }
        if (c != null && json != null) c.send(json.replace('\n', ' ').replace('\r', ' '));
    }

    @JavascriptInterface
    public void disconnect() {
        Conn old;
        synchronized (clientLock) {
            clientGen++;      // invalida los eventos del cliente anterior
            old = client;
            client = null;
        }
        if (old != null) old.close();
    }

    // =====================================================================
    //  Descubrimiento de salas (UDP)
    // =====================================================================
    private void startBeacon() {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                DatagramSocket ds = null;
                try {
                    ds = new DatagramSocket();
                    ds.setBroadcast(true);
                    while (hosting && !Thread.currentThread().isInterrupted()) {
                        String name = hostName.replace('|', ' ');
                        byte[] data = (MAGIC + "|" + hostPort + "|" + name + "|" + peerCount()).getBytes(UTF8);
                        for (InetAddress a : broadcastAddresses()) {
                            try { ds.send(new DatagramPacket(data, data.length, a, DISCOVERY_PORT)); } catch (IOException ignored) { }
                        }
                        Thread.sleep(1000);
                    }
                } catch (InterruptedException ignored) {
                } catch (Exception ignored) {
                } finally {
                    if (ds != null) ds.close();
                }
            }
        }, "pg-beacon");
        t.setDaemon(true);
        beaconThread = t;
        t.start();
    }

    private static List<InetAddress> broadcastAddresses() {
        List<InetAddress> res = new ArrayList<InetAddress>();
        try {
            res.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) { }
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !res.contains(b)) res.add(b);
                }
            }
        } catch (Exception ignored) { }
        return res;
    }

    @JavascriptInterface
    public void startDiscovery() {
        if (discovering) return;
        discovering = true;
        try {
            WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mcLock = wm.createMulticastLock("pg-discovery");
                mcLock.setReferenceCounted(false);
                mcLock.acquire();
            }
        } catch (Exception ignored) { }

        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                DatagramSocket ds = null;
                final Map<String, String[]> rooms = new HashMap<String, String[]>(); // ip -> {name, players, port}
                final Map<String, Long> seen = new HashMap<String, Long>();
                long lastEmit = 0;
                try {
                    ds = new DatagramSocket(null);
                    ds.setReuseAddress(true);
                    ds.setBroadcast(true);
                    ds.bind(new InetSocketAddress(DISCOVERY_PORT));
                    ds.setSoTimeout(500);
                    discSocket = ds;
                    byte[] buf = new byte[512];
                    while (discovering) {
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            ds.receive(p);
                            String s = new String(p.getData(), 0, p.getLength(), UTF8);
                            String[] parts = s.split("\\|", -1);
                            if (parts.length >= 4 && MAGIC.equals(parts[0])) {
                                String ip = p.getAddress().getHostAddress();
                                rooms.put(ip, new String[]{parts[2], parts[3], parts[1]});
                                seen.put(ip, System.currentTimeMillis());
                            }
                        } catch (java.net.SocketTimeoutException ignored) {
                        }
                        long now = System.currentTimeMillis();
                        Iterator<Map.Entry<String, Long>> it = seen.entrySet().iterator();
                        while (it.hasNext()) {
                            Map.Entry<String, Long> en = it.next();
                            if (now - en.getValue() > 4000) { rooms.remove(en.getKey()); it.remove(); }
                        }
                        if (now - lastEmit >= 1000) {
                            lastEmit = now;
                            StringBuilder sb = new StringBuilder("[");
                            boolean first = true;
                            List<String> ips = new ArrayList<String>(rooms.keySet());
                            Collections.sort(ips);
                            for (String ip : ips) {
                                String[] r = rooms.get(ip);
                                int pl = 0;
                                try { pl = Integer.parseInt(r[1]); } catch (NumberFormatException ignored) { }
                                if (!first) sb.append(',');
                                first = false;
                                sb.append("{\"ip\":").append(jsonStr(ip)).append(",\"name\":").append(jsonStr(r[0]))
                                        .append(",\"players\":").append(pl).append("}");
                            }
                            sb.append(']');
                            emit("rooms", sb.toString());
                        }
                    }
                } catch (Exception e) {
                    // sin descubrimiento: el usuario aún puede escribir la IP a mano
                } finally {
                    discSocket = null;
                    if (ds != null) ds.close();
                }
            }
        }, "pg-discovery");
        t.setDaemon(true);
        t.start();
    }

    @JavascriptInterface
    public void stopDiscovery() {
        discovering = false;
        DatagramSocket d = discSocket;
        if (d != null) d.close();
        try {
            if (mcLock != null && mcLock.isHeld()) mcLock.release();
        } catch (Exception ignored) { }
    }

    // =====================================================================
    //  IP local
    // =====================================================================
    @JavascriptInterface
    public String getLocalIp() {
        String best = null;
        int bestScore = -1;
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                String name = ni.getName() == null ? "" : ni.getName().toLowerCase();
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    int score = 1;
                    if (a.isSiteLocalAddress()) score += 2;
                    if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("swlan") || name.startsWith("eth")) score += 4;
                    if (name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("tun")) score -= 1;
                    if (score > bestScore) { bestScore = score; best = a.getHostAddress(); }
                }
            }
        } catch (Exception ignored) { }
        return best == null ? "" : best;
    }

    // =====================================================================
    public void shutdown() {
        dead = true;
        disconnect();
        stopHost();
        stopDiscovery();
    }
}
