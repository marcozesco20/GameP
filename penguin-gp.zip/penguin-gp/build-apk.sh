#!/usr/bin/env bash
# Compila el APK en tu PC (Linux/macOS). Requisitos: JDK 17 y Android SDK (ANDROID_HOME).
set -e
cd "$(dirname "$0")/android"
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "Define ANDROID_HOME (ruta del Android SDK). Si tienes Android Studio suele ser ~/Android/Sdk o ~/Library/Android/sdk"; exit 1
fi
./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk ../PenguinSlippery.apk
echo "Listo: $(cd .. && pwd)/PenguinSlippery.apk"
