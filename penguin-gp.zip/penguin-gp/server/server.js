#!/usr/bin/env node
/* Servidor local para Penguin Slippery (sin dependencias).
   - Sirve el juego (carpeta ../web) por HTTP.
   - Retransmite los mensajes entre jugadores por WebSocket (misma logica que el servidor interno de la app).
   Uso:  node server/server.js            (puerto 8080)
         PORT=9000 node server/server.js
   Luego abre en cada telefono/PC de la misma red:  http://IP-DE-ESTE-PC:8080  y pulsa Multijugador > Unirse. */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os');
const PORT = +process.env.PORT || 8080;
const ROOT = path.join(__dirname, '..', 'web');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.json': 'application/json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/') p = '/index.html';
  const f = path.normalize(path.join(ROOT, p));
  if (!f.startsWith(ROOT)) { res.writeHead(403); return res.end('403'); }
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});

/* ---- sala ---- */
const clients = new Map(); // id -> {socket, hello}
let nextId = 1;
function frame(str) {
  const payload = Buffer.from(str, 'utf8'), n = payload.length;
  let head;
  if (n < 126) head = Buffer.from([0x81, n]);
  else if (n < 65536) head = Buffer.from([0x81, 126, n >> 8, n & 255]);
  else { head = Buffer.alloc(10); head[0] = 0x81; head[1] = 127; head.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([head, payload]);
}
function sendTo(c, str) { try { if (!c.socket.destroyed) c.socket.write(frame(str)); } catch (e) { } }
function broadcast(str, exceptId) { for (const [id, c] of clients) if (id !== exceptId) sendTo(c, str); }
function hostId() { let m = Infinity; for (const id of clients.keys()) if (id < m) m = id; return m === Infinity ? 0 : m; }

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) return socket.destroy();
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const id = nextId++;
  const me = { socket, hello: null };
  clients.set(id, me);
  sendTo(me, JSON.stringify({ t: 'welcome', id, host: hostId() }));
  for (const [oid, c] of clients) if (oid !== id && c.hello) sendTo(me, '{"f":' + oid + ',' + c.hello.slice(1));
  broadcast(JSON.stringify({ t: 'join', id }), id);
  console.log('[+] jugador', id, '(' + clients.size + ' conectados)');

  let buf = Buffer.alloc(0);
  socket.on('data', (d) => {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      if (buf.length < 2) return;
      const op = buf[0] & 15; let len = buf[1] & 127, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      const masked = !!(buf[1] & 128);
      if (buf.length < off + (masked ? 4 : 0) + len) return;
      let payload;
      if (masked) {
        const mask = buf.slice(off, off + 4); payload = Buffer.from(buf.slice(off + 4, off + 4 + len));
        for (let i = 0; i < len; i++) payload[i] ^= mask[i & 3];
        off += 4;
      } else payload = buf.slice(off, off + len);
      buf = buf.slice(off + len);
      if (op === 8) { socket.end(); return; }
      if (op === 9) { socket.write(Buffer.concat([Buffer.from([0x8A, payload.length]), payload])); continue; }
      if (op === 1) {
        const txt = payload.toString('utf8');
        if (txt.length < 2 || txt[0] !== '{') continue;
        if (txt.indexOf('"t":"hello"') >= 0) me.hello = txt;
        broadcast('{"f":' + id + ',' + txt.slice(1), id);
      }
    }
  });
  const close = () => {
    if (!clients.has(id)) return;
    const wasHost = hostId() === id;
    clients.delete(id);
    broadcast(JSON.stringify({ t: 'leave', id }));
    if (wasHost && clients.size) broadcast(JSON.stringify({ t: 'host', id: hostId() }));
    console.log('[-] jugador', id, '(' + clients.size + ' conectados)');
  };
  socket.on('close', close); socket.on('error', close);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('Penguin Slippery - servidor local');
  console.log('Abre en los dispositivos de la misma red:');
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) for (const a of ifs[name]) if (a.family === 'IPv4' && !a.internal) console.log('  http://' + a.address + ':' + PORT + '   (' + name + ')');
  console.log('  http://localhost:' + PORT);
});
