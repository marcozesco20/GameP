// busca triangulos de la malla estatica sobre una calzada (principal o atajo) y por encima de su superficie
const PG = require('./load')(['util.js', 'tracks.js', 'fbxdata.js', 'fbx.js', 'models.js', 'trackmesh.js']).PG;
const only = process.argv[2] !== undefined ? +process.argv[2] : -1, thr = +(process.argv[3] || 0.15);
for (const d of PG.TRACKS) {
  if (only >= 0 && d.id !== only) continue;
  const T = PG.buildTrack(d);
  const hw = T.W / 2;
  function mk(px, pz, py, tx, tz, n) { // rejilla de puntos de una calzada
    const g = new Map(), C = 8;
    for (let i = 0; i <= n; i++) { const k = Math.floor(px[i] / C) + ',' + Math.floor(pz[i] / C); if (!g.has(k)) g.set(k, []); g.get(k).push(i); }
    return { px, pz, py, tx, tz, n, g, C };
  }
  function nearest(R, x, z) {
    let best = 1e18, bi = -1; const cx = Math.floor(x / R.C), cz = Math.floor(z / R.C);
    for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) { const L = R.g.get((cx + a) + ',' + (cz + b)); if (!L) continue; for (const i of L) { const ex = R.px[i] - x, ez = R.pz[i] - z, e = ex * ex + ez * ez; if (e < best) { best = e; bi = i; } } }
    return bi < 0 ? null : { i: bi, d: Math.sqrt(best), lat: (x - R.px[bi]) * (-R.tz[bi]) + (z - R.pz[bi]) * R.tx[bi] };
  }
  const roads = [{ nm: 'main', hw, R: mk(T.px, T.pz, T.py, T.tx, T.tz, T.N) }];
  (T.branches || []).forEach((B, bi) => roads.push({ nm: 'br' + bi, hw: B.W / 2, R: mk(B.px, B.pz, B.py, B.tx, B.tz, B.Nb) }));
  const found = {};
  for (const ch of T.mesh.chunks) {
    const f = new Float32Array(ch.buf.buffer ? ch.buf.buffer.slice(ch.buf.byteOffset, ch.buf.byteOffset + ch.n * 20) : ch.buf), i8 = new Int8Array(f.buffer);
    for (let t = 0; t + 2 < ch.n; t += 3) {
      let cx = 0, cy = 0, cz = 0, ny = 0, cr = 0, cg = 0, cb = 0;
      for (let k = 0; k < 3; k++) { const o = (t + k) * 5; cx += f[o] / 3; cy += f[o + 1] / 3; cz += f[o + 2] / 3; ny += i8[(t + k) * 20 + 13] / 3; const u8 = new Uint8Array(f.buffer); cr += u8[(t + k) * 20 + 16] / 3; cg += u8[(t + k) * 20 + 17] / 3; cb += u8[(t + k) * 20 + 18] / 3; }
      if (Math.min(cr, cg, cb) < 205) continue;
      for (const r of roads) {
        const q = nearest(r.R, cx, cz); if (!q || Math.abs(q.lat) > r.hw - 0.4) continue;
        const dy = cy - r.R.py[q.i]; if (dy < thr || dy > +(process.argv[4]||12)) continue; if (ny < 0.5 * 127) continue; if (cr / 1 < 0) continue;
        const key = r.nm + ':' + Math.floor(q.i / 10); const e = found[key] || (found[key] = { n: 0, max: 0, ny: 0, row: q.i, lat: 0, c: [0,0,0], x: cx, z: cz });
        e.c[0] += cr; e.c[1] += cg; e.c[2] += cb;
        e.n++; e.max = Math.max(e.max, dy); e.ny += ny / 127; e.lat += q.lat;
      }
    }
  }
  const ks = Object.keys(found);
  console.log('#' + d.id, d.name, 'grupos', ks.length);
  ks.slice(0, 40).forEach(k => { const e = found[k]; console.log('   ', k, 'tris', e.n, 'dyMax', e.max.toFixed(2), 'ny', (e.ny / e.n).toFixed(2), 'lat', (e.lat / e.n).toFixed(1), 'rgb', e.c.map(v => Math.round(v / e.n)).join(','), 'xz', e.x.toFixed(0), e.z.toFixed(0)); });
}
