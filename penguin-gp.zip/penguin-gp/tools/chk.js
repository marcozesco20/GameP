const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  page.on('pageerror', e => console.log('ERR', String(e))); page.on('console', m => { if (m.type() === 'error') console.log('CERR', m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  console.log(await page.evaluate(() => JSON.stringify({ cannon: !!PG.Models.cannon, tris: PG.Models.cannon && PG.Models.cannon.tris })));
  await browser.close();
})();
