const load = require('./load.js');
const ctx = load(['util.js', 'tracks.js', 'fbxdata.js', 'fbx.js', 'models.js']);
const PG = ctx.PG;
PG.buildModels(PG.THEMES.day);
for (const k of ['cannon']) console.log(k, JSON.stringify(PG.Models[k].chunks.map(c => c.bb)));
const m = PG.penguinModel({}); console.log(m.parts.map(p => p.kind + ':' + p.mesh.tris + ' ' + JSON.stringify(p.mesh.chunks[0] && p.mesh.chunks[0].bb.map(x => +x.toFixed(2)))));
const g = PG.fbxMesh(PG.FBX.gun); console.log(g.nt, g.V.slice(0, 9), g.T.slice(0, 6), g.C.slice(0, 6));
