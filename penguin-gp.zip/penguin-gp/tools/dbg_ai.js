const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
ctx.DBGAI = true; const PG = ctx.PG, tid = +process.argv[2], lo = +process.argv[3], hi = +process.argv[4];
const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
const race = new PG.Race(T, { seed: 3 });
for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
race.time = 0; let t = 0, k = 0;
const orig = PG.aiInput;
while (t < 200) { race.time = t; race.update(1 / 60, null); t += 1 / 60;
  const r = race.racers[3], s = T.uToS(r.u);
  if (s > lo && s < hi && (k++ % 6 === 0)) { const q = T.q(s); console.log('s', s.toFixed(0), 'd', r.d.toFixed(2), 'psi', r.psi.toFixed(3), 'vf', r.vf.toFixed(1), 'vl', r.vl.toFixed(2), 'cv', q.cv.toFixed(4), 'sl', q.sl.toFixed(2), 'tgt', r.ai.laneSm.toFixed(2), 'steerVis', r.steerVis.toFixed(2), 'lap', r.lap, 'steer', r.ai.inp.steer.toFixed(2), r.grounded ? 'G' : 'air', 'spin', r.fx.spin.toFixed(1), 'hit', r.hitCd.toFixed(1)); }
  race.fxq.length = 0; race.out.length = 0; if (r.u > 5900) break; }
