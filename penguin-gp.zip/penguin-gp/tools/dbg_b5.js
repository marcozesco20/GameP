const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
const def = PG.TRACKS[9], T = PG.buildTrack(def, { noMesh: true });
const race = new PG.Race(T, { seed: 14, diff: 1 });
for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0;
const dt = 1 / 60; let t = 0;
const B3 = T.branches[2]; console.log('B3', B3.s0, B3.s1, B3.j0, B3.j1, B3.kk, B3.W, B3.side);
while (t < 24) {
  race.time = t; race.update(dt, null); t += dt; race.fxq.length = 0; race.out.length = 0;
  const r = race.racers[5];
  if (t > 22 && (Math.round(t/dt) % 15 === 0)) console.log(t.toFixed(2), 'u', r.u.toFixed(1), 'br', r.br, 'd', r.d.toFixed(2), 'vf', r.vf.toFixed(1), 'vl', r.vl.toFixed(1), 'psi', r.psi.toFixed(2), 'gr', r.grounded, 'py', r.py.toFixed(2), 'gy', r.gy.toFixed(2), 'vy', r.vy.toFixed(2), 'air', r.air, 'hit', r.hitCd.toFixed(2), 'stun', r.stun, r.fx && JSON.stringify(Object.fromEntries(Object.entries(r.fx).filter(e=>e[1]>0))));
}
