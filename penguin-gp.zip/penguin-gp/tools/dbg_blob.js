const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  page.on('pageerror', e => console.log('ERR', e));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.startSolo(1); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const r = await page.evaluate(async () => {
    const G = PG.G, R = G.R, m = G.me; G.goAt -= 3000;
    G.race.proj.push({ id: 'tq', owner: 'zz', u: m.u + 14, d: m.d, vu: 0, life: 30, age: 0, lt: 0, dir: 1, kd: 'gren', mine: false, h: 1.1, vh: 0 });
    await new Promise(r => setTimeout(r, 2500));
    const log = []; const o = R.draw; const names = new Map(); (function walk(obj, p, d) { if (d > 2 || !obj) return; for (const k in obj) { const v = obj[k]; if (v && v.chunks) names.set(v, p + k); else if (typeof v === 'object' && d < 2 && !Array.isArray(v)) walk(v, p + k + '.', d + 1); } })(PG.G.models || {}, '', 0);
    R.draw = function (mesh, model, tint, alpha) { if (alpha !== undefined && alpha < 1) log.push([names.get(mesh) || '?', alpha, model ? [model[12].toFixed(1), model[13].toFixed(1), model[14].toFixed(1)] : null, R.inRefl ? 'refl' : '']); return o.apply(this, arguments); };
    await new Promise(r => setTimeout(r, 2500));
    return { log: log.slice(-14), eye: G.cam && G.cam.eye };
  });
  console.log(JSON.stringify(r)); await browser.close();
})();
