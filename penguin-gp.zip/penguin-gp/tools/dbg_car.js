const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=solo]'); await page.waitForTimeout(900);
  const st = () => page.evaluate(() => { const g = document.getElementById('trackGrid'); return { sl: g.scrollLeft, sel: PG.G.selTrack, mids: [].map.call(g.children, (c, i) => c.classList.contains('mid') ? i : -1).filter(x => x >= 0).join(), offs: [].slice.call(g.children, 0, 4).map(c => c.offsetLeft + '/' + c.offsetWidth).join(' '), cw: g.clientWidth }; });
  console.log(await st());
  await page.click('#carNext'); await page.waitForTimeout(800); console.log(await st());
  await page.click('#carNext'); await page.waitForTimeout(800); console.log(await st());
  await browser.close();
})();
