const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=solo]'); await page.waitForTimeout(900);
  console.log(await page.evaluate(() => ['#scrTracks', '#scrTracks header', '.trkBody', '.trkCar', '.carWrap', '#trackGrid', '#trackGrid .tcard', '#carDots', '#trackInfo', '.trkSide'].map(s => { const e = document.querySelector(s), r = e.getBoundingClientRect(), cs = getComputedStyle(e); return s + ' y' + r.top.toFixed(0) + ' h' + r.height.toFixed(0) + ' disp:' + cs.display + ' ov:' + cs.overflow; }).join('\n')));
  await browser.close();
})();
