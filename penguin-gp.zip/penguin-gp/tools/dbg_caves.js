const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 } })).newPage();
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  console.log(JSON.stringify(await p.evaluate(() => { const T = PG.buildTrack(PG.TRACKS[9], { noMesh: true }); return T.caves.map(c => [Math.round(c.s0), Math.round(c.s1), c.tun || 0]); })));
  await browser.close();
})();
