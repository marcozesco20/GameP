const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 0, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
const race = new PG.Race(T, { seed: 5 + id, diff: 3 });
for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0; const dt = 1 / 60; let t = 0, last = {};
const wp = r => { const q = T.q(T.uToS(r.u), r.br); return [q.x + q.rx * r.d, r.py, q.z + q.rz * r.d]; };
let n = 0;
while (t < 200 && n < 14) {
  race.time = t; race.update(dt, null); t += dt;
  for (const r of race.racers) {
    const w = wp(r), p = last[r.id];
    if (p && Math.hypot(w[0] - p.w[0], w[2] - p.w[2]) > 2.0 && !r.fell && !p.fell) { n++; console.log(`t=${t.toFixed(2)} ${r.id} br ${p.br}->${r.br} jump=${Math.hypot(w[0] - p.w[0], w[2] - p.w[2]).toFixed(2)} u=${r.u.toFixed(1)} d ${p.d.toFixed(2)}->${r.d.toFixed(2)} vf=${r.vf.toFixed(1)} vl=${r.vl.toFixed(1)} psi=${r.psi.toFixed(2)} fell=${r.fell}`); }
    if (p && p.br !== r.br) console.log(`  cruce t=${t.toFixed(2)} ${r.id} br ${p.br}->${r.br} d ${p.d.toFixed(2)}->${r.d.toFixed(2)} u=${r.u.toFixed(1)} vf ${p.vf.toFixed(1)}->${r.vf.toFixed(1)} vl ${p.vl.toFixed(1)}->${r.vl.toFixed(1)} psi ${p.psi.toFixed(2)}->${r.psi.toFixed(2)} py ${p.py.toFixed(2)}->${r.py.toFixed(2)} dpos=${Math.hypot(w[0] - p.w[0], w[2] - p.w[2]).toFixed(2)}`);
    last[r.id] = { w, br: r.br, d: r.d, fell: r.fell, vf: r.vf, vl: r.vl, psi: r.psi, py: r.py };
  }
  race.fxq.length = 0; race.out.length = 0;
}
