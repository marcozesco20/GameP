const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox'] });
  const p = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  console.log(await p.evaluate(() => { const e = document.getElementById('btnJump'); const c = getComputedStyle(e); return { bg: c.backgroundImage.slice(0, 80), hex: c.getPropertyValue('--hex').slice(0, 60), w: c.width, h: c.height, disp: c.display, filter: c.filter }; }));
  await browser.close();
})();
