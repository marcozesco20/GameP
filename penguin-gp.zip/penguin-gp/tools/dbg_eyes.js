const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  const out = await page.evaluate(() => {
    const m = PG.spectatorModel({ hat: 0, glasses: 0, scarf: 0, outfit: 0 }); const pts = [], dark = [];
    m.parts.filter(p => p.kind === 'body').forEach(p => p.mesh.chunks.forEach(c => { const f = new Float32Array(c.buf), u8 = new Uint8Array(c.buf); for (let k = 0; k < c.n; k++) { const r = u8[k * 20 + 16], g = u8[k * 20 + 17], b = u8[k * 20 + 18]; const y = f[k * 5 + 1]; if (y > 0.6 && r >= 252 && g >= 252 && b >= 252) pts.push([f[k * 5], y, f[k * 5 + 2]]); } }));
    const avg = a => a.reduce((s, v) => s + v, 0) / a.length;
    return { n: pts.length, x: [Math.min(...pts.map(p => p[0])), Math.max(...pts.map(p => p[0]))], y: [Math.min(...pts.map(p => p[1])), Math.max(...pts.map(p => p[1])), avg(pts.map(p => p[1]))], z: [Math.min(...pts.map(p => p[2])), Math.max(...pts.map(p => p[2])), avg(pts.map(p => p[2]))] };
  });
  console.log(JSON.stringify(out)); await browser.close();
})();
