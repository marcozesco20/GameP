const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG, tid = +process.argv[2];
const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
console.log('holes', T.holes.map(h => [h.s0.toFixed(0), h.s1.toFixed(0), h.mode, h.d0, h.d1].join(' ')).join(' | '));
console.log('ramps', T.ramps.map(r => [r.s0.toFixed(0), r.len, r.h, r.d0, r.d1, r.jump ? 'J' : ''].join(' ')).join(' | '));
for (const h of T.holes) { const a = T.centerY(h.s0), b = T.centerY(h.s1); console.log('hole', h.s0.toFixed(0), 'dy lip->far', (b - a).toFixed(2), 'slope before', T.q(h.s0 - 10).sl.toFixed(2), 'at', T.q(h.s0).sl.toFixed(2), 'after', T.q(h.s1 + 4).sl.toFixed(2)); }
let n = 0;
const race = new PG.Race(T, { seed: 3 });
for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
race.time = 0; let t = 0;
while (t < 200 && n < 14) { race.time = t; race.update(1 / 60, null); t += 1 / 60;
  for (const e of race.fxq) if (e.k === 'fall') { n++; const r = e.r; console.log('fall', r.id, 's', T.uToS(r.u).toFixed(1), 'd', r.d.toFixed(1), 'vf', r.vf.toFixed(1), 'py-gy', (r.py - (r.gy || 0)).toFixed(2), 'overHole', r.overHole, 'air', r.air.toFixed(2), 'lap', r.lap); }
  race.fxq.length = 0; race.out.length = 0; }
