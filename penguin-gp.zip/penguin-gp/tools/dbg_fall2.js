const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG, tid = +process.argv[2], lo = +process.argv[3], hi = +process.argv[4];
const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
let race;
let shown = 0;
for (let seed = 1; seed <= 8 && shown < 2; seed++) { race = new PG.Race(T, { seed }); for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
race.time = 0; let t = 0, hist = {};
while (t < 200 && shown < 2) { race.time = t; race.update(1 / 60, null); t += 1 / 60;
  for (const r of race.racers) { const s = T.uToS(r.u); (hist[r.id] = hist[r.id] || []).push({ s, d: r.d, vf: r.vf, psi: r.psi, g: r.grounded, py: r.py, gy: r.gy, vy: r.vy, jp: r.jumped, tgt: r.ai && r.ai.laneSm, fell: r.fell, spin: r.fx.spin > 0 }); if (hist[r.id].length > 90) hist[r.id].shift(); }
  for (const e of race.fxq) if (e.k === 'fall' && !e.r.finished) { const s = T.uToS(e.r.u); if (s > lo && s < hi && shown < 2) { shown++; console.log('FALL', e.r.id, 'lap', e.r.lap, 'u', e.r.u.toFixed(0)); for (const h of hist[e.r.id].filter((x, i) => i % 4 === 0)) console.log(' s', h.s.toFixed(1), 'd', h.d.toFixed(2), 'tgt', (h.tgt||0).toFixed(1), 'vf', h.vf.toFixed(1), 'psi', h.psi.toFixed(2), h.g ? 'G' : 'air', 'py', h.py.toFixed(2), 'vy', h.vy.toFixed(1), h.spin ? 'SPIN' : ''); } }
  race.fxq.length = 0; race.out.length = 0; } }
