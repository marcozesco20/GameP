const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
const id = +process.argv[2];
const T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
console.log('L', T.L.toFixed(0), 'startS', T.startS);
T.holes.forEach((h, i) => console.log('hole', i, h.mode, 's0', h.s0.toFixed(1), 's1', h.s1.toFixed(1), 'd', h.d0, h.d1));
T.ramps.forEach((r, i) => console.log('ramp', i, r.jump ? 'JUMP' : '', 's0', r.s0.toFixed(1), 'len', r.len.toFixed(1), 'h', r.h, 'd', r.d0, r.d1));
const race = new PG.Race(T, { seed: 7 });
for (let i = 0; i < 3; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0;
let t = 0; const dt = 1 / 60, seen = {};
while (t < 140) {
  race.time = t; race.update(dt, null); t += dt;
  for (const e of race.fxq) if (e.k === 'fall') { const r = e.r; const k = (r.u + T.startS).toFixed(0); if (!seen[k]) { seen[k] = 1; console.log(`t=${t.toFixed(1)} ${r.id} cae en s=${T.uToS(r.u).toFixed(1)} d=${r.d.toFixed(1)} vf=${r.vf.toFixed(1)} py=${r.py.toFixed(2)} gy=${r.gy.toFixed(2)} psi=${r.psi.toFixed(2)}`); } }
  race.fxq.length = 0; race.out.length = 0;
}
