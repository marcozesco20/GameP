const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 0, diff = +process.argv[3] || 1, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
const race = new PG.Race(T, { seed: 5 + id, diff });
for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0; const dt = 1 / 60; let t = 0; const B = T.branches[0];
console.log('fork s0', B.s0, 'j0', B.j0, 'side', B.side, 'hw', T.W/2);
let k = 0;
while (t < 60) {
  race.time = t; race.update(dt, null); t += dt;
  const r = race.racers[+process.argv[4]||0], s = T.uToS(r.u);
  if (s > B.s0 - 100 && s < B.s0 + B.j0 * T.ds + 40 && (k++ % 15 === 0)) console.log(`t=${t.toFixed(1)} s=${s.toFixed(0)} d=${r.d.toFixed(2)} br=${r.br} plan=${JSON.stringify(r.ai.brPlan)} tgt=${r.ai.laneSm.toFixed(1)} psi=${r.psi.toFixed(2)} vl=${r.vl.toFixed(1)}`);
  race.fxq.length = 0; race.out.length = 0;
}
