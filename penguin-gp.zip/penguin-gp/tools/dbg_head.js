const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  const out = await page.evaluate(() => {
    function verts(cfg) { const m = PG.spectatorModel(Object.assign({ hat: 0, glasses: 0, scarf: 0, outfit: 0 }, cfg)); const set = []; m.parts.filter(p => p.kind === 'body').forEach(p => p.mesh.chunks.forEach(c => { const f = new Float32Array(c.buf); for (let k = 0; k < c.n; k++) set.push([f[k * 5], f[k * 5 + 1], f[k * 5 + 2]]); })); return set; }
    const base = verts({}); const key = v => v.map(x => x.toFixed(3)).join(',');
    const bs = new Set(base.map(key));
    // cabeza: vertices del cuerpo con y>0.55 y z>-0.3
    const head = base.filter(v => v[1] > 0.5);
    const ys = head.map(v => v[1]), zs = head.map(v => v[2]), xs = head.map(v => v[0]);
    const info = { headTop: Math.max(...ys), headZmin: Math.min(...zs), headZmax: Math.max(...zs), xw: Math.max(...xs) };
    // forma de la coronilla: y maximo por franja de z
    const bins = {}; head.forEach(v => { const b = Math.round(v[2] * 20) / 20; bins[b] = Math.max(bins[b] === undefined ? -9 : bins[b], v[1]); });
    info.dome = bins;
    const hats = {};
    for (let h = 1; h <= 13; h++) { const vs = verts({ hat: h }).filter(v => !bs.has(key(v))); const ys2 = vs.map(v => v[1]), zs2 = vs.map(v => v[2]); hats[h] = { minY: +Math.min(...ys2).toFixed(3), maxY: +Math.max(...ys2).toFixed(3), zc: +((Math.min(...zs2) + Math.max(...zs2)) / 2).toFixed(3), zmin: +Math.min(...zs2).toFixed(2), zmax: +Math.max(...zs2).toFixed(2) }; }
    info.hats = hats; return info;
  });
  console.log(JSON.stringify(out, null, 1)); await browser.close();
})();
