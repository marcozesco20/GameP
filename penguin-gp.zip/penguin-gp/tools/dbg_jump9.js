const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
const id = +(process.argv[2]||9), diff = +(process.argv[3]||1);
const def = PG.TRACKS[id], T = PG.buildTrack(def, { noMesh: true });
const race = new PG.Race(T, { seed: 5 + id, diff });
for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0;
const dt = 1 / 60; let t = 0; const last = {};
while (t < 200) {
  race.time = t; race.update(dt, null); t += dt;
  for (const e of race.fxq) { if (e.k === 'fall' || e.k==='respawn') console.log(t.toFixed(1), e.k, e.r && e.r.id, 'u', e.r && e.r.u.toFixed(0), 'br', e.r && e.r.br); } race.fxq.length = 0; race.out.length = 0;
  for (const r of race.racers) {
    const p = last[r.id]; if (p !== undefined) { const du = r.u - p.u; if (Math.abs(du) > 4 && !r.finished) console.log(t.toFixed(2), r.id, 'du', du.toFixed(1), 'u', r.u.toFixed(0), 'br', p.br, '->', r.br, 'vf', r.vf.toFixed(0), 'ab', r.ability); }
    last[r.id] = { u: r.u, br: r.br };
  }
  if (race.racers.every(r => r.finished)) break;
}
console.log(race.racers.map(r => r.finishTime && r.finishTime.toFixed(0)).join(' '), 'L', T.L, 'D', T.D, 'laps', race.laps);
