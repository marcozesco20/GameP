const ctx = require('./load')(['util.js', 'tracks.js']); const PG = ctx.PG;
for (const id of [0, 2, 4, 7]) {
  if (process.env.NOLIFT) (PG.TRACKS[id].cuts || []).forEach(c => c.lift = 0); const T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
  T.branches.forEach((B, bi) => {
    let mx = -1e9, mn = 1e9, maxgap = 0;
    for (let i = 0; i <= B.Nb; i++) { let bd = 1e18, bj = 0; for (let j = B.i0 - 8; j <= B.i0 + B.Nb + 8; j++) { const jm = ((j % T.N) + T.N) % T.N, d = (T.px[jm] - B.px[i]) ** 2 + (T.pz[jm] - B.pz[i]) ** 2; if (d < bd) { bd = d; bj = jm; } } const dy = B.py[i] - T.py[bj]; mx = Math.max(mx, dy); mn = Math.min(mn, dy); maxgap = Math.max(maxgap, Math.sqrt(bd)); }
    console.log(T.name, 'branch', bi, 'lift', B.c.lift || 0, 'dy max', mx.toFixed(1), 'min', mn.toFixed(1), 'maxgap', maxgap.toFixed(0), 'W', B.W, 'mainW', T.W);
  });
}
