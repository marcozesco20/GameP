const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  page.on('pageerror', e => console.log('ERR', String(e).slice(0, 300))); page.on('console', m => { if (m.type() === 'error') console.log('CERR', m.text().slice(0, 400)); });
  await page.goto('http://localhost:8080/'); await page.waitForTimeout(15000);
  await browser.close();
})();
