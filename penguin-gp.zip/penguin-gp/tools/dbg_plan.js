const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 0, diff = +process.argv[3] || 1, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
const race = new PG.Race(T, { seed: 5 + id, diff });
for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0; const dt = 1 / 60; let t = 0;
while (t < 70) { race.time = t; race.update(dt, null); t += dt; race.fxq.length = 0; race.out.length = 0; }
console.log(race.racers.map(r => JSON.stringify(r.ai.brPlan) + ' br=' + r.br).join('\n'));
