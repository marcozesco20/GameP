const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
for (const tid of [0, 1, 4]) for (const av of [false, true]) {
  const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
  const race = new PG.Race(T, { seed: 5, diff: 1, avalanche: av });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < 5; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0;
  const endU = T.type === 'circuit' ? race.laps * T.L : T.D;
  // bots cerca de la meta, yo atras
  race.racers.forEach(r => { if (r.bot) { r.u = endU - 30 - r.slot * 3; r.vf = 40; } else { r.u = endU - 400; r.vf = 20; } r.safeU = r.u; });
  const out = [];
  for (let t = 0; t < 120 && !me.finished; t += 1 / 60) {
    race.time += 1 / 60; race.update(1 / 60, { steer: 0, tuck: 1 });
    for (const e of race.fxq) if (e.k === 'finish') out.push(e.r.id + ' rank=' + e.r.rank + ' t=' + race.time.toFixed(1));
    race.fxq.length = 0; race.out.length = 0;
  }
  console.log('track', tid, 'av', av, out.join(' | '), '| me.rank final', me.rank, 'finished me', me.finished);
}
