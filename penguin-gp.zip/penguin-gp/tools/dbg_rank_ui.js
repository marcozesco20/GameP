const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const tid of [1, 0]) {
    await page.evaluate((t) => PG.G.startSolo(t), tid);
    await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
    await page.evaluate(() => { PG.G.goAt -= 8000; });
    await page.waitForTimeout(1500);
    await page.evaluate(() => {
      const G = PG.G, R = G.race, T = G.T, endU = T.type === 'circuit' ? R.laps * T.L : T.D;
      R.racers.forEach(r => { if (r.bot) { r.u = endU + 1 + r.slot; r.safeU = r.u; r.vf = 40; } });
      window._log = [];
      const orig = PG.G.finishMessage;
    });
    await page.waitForTimeout(6000);
    await page.evaluate(() => {
      const G = PG.G, R = G.race, T = G.T, endU = T.type === 'circuit' ? R.laps * T.L : T.D, me = G.me;
      me.u = endU - 8; me.safeU = me.u; me.vf = 30; if (T.type === 'circuit') me.lap = R.laps;
    });
    await page.waitForTimeout(2500);
    console.log(await page.evaluate(() => JSON.stringify({ track: PG.G.trackIdx, rank: PG.G.me.rank, big: document.getElementById('cheer').textContent, msg: PG.G.resMsg, fin: PG.G.race.racers.map(r => r.id + ':' + r.finished + ':' + (r.finishTime || 0).toFixed(1)).join(' ') })));
    await page.evaluate(() => { PG.G.race = null; PG.G.me = null; PG.G.mode = 'menu'; PG.G.resultsAt = 0; PG.G.finishShown = false; });
  }
  console.log(errs);
  await browser.close();
})();
