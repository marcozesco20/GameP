const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(1); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; });
  for (let k = 0; k < 5; k++) { await page.waitForTimeout(300); console.log(await page.evaluate(() => ({ t: PG.G.race.time, u: PG.G.me.u, vf: PG.G.me.vf, go: PG.G.race.started, st: PG.G.state, keys: Object.keys(PG.G).filter(k => /go|start|count/i.test(k)) }))); }
  await browser.close();
})();
