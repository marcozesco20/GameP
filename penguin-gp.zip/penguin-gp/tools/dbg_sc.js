const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 0, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
console.log('track', T.name, 'branches', T.branches.map(B => ({ s0: B.s0 | 0, s1: B.s1 | 0, W: B.W, kk: +B.kk.toFixed(3) })));
// por cada tramo de ramal: velocidad media por s en main vs branch
const acc = {};
for (let seed = 1; seed <= 6; seed++) {
  const race = new PG.Race(T, { seed, diff: 2 });
  for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
  race.time = 0; const dt = 1 / 60; let t = 0;
  while (t < 70) {
    race.time = t; race.update(dt, null); t += dt;
    race.racers.forEach(r => { if (r.fell || r.finished) return; const s = T.uToS(r.u); T.branches.forEach((B, bi) => { if (s >= B.s0 - 30 && s <= B.s1 + 30) { const bin = Math.floor((s - B.s0) / 10), key = bi + '_' + bin + '_' + (r.br ? 'B' : 'M'); (acc[key] = acc[key] || []).push(r.vf); } }); });
    race.fxq.length = 0; race.out.length = 0;
  }
}
const keys = Object.keys(acc).sort((a, b) => { const A = a.split('_'), B = b.split('_'); return A[0] - B[0] || A[1] - B[1]; });
const bins = {}; keys.forEach(k => { const [b, n, w] = k.split('_'); bins[b + '_' + n] = bins[b + '_' + n] || {}; bins[b + '_' + n][w] = acc[k].reduce((a, c) => a + c, 0) / acc[k].length; bins[b + '_' + n]['n' + w] = acc[k].length; });
Object.keys(bins).filter((k, i) => i % 3 === 0).forEach(k => console.log(k, 'M', (bins[k].M || 0).toFixed(1), 'B', (bins[k].B || 0).toFixed(1), 'n', bins[k].nM || 0, bins[k].nB || 0));
