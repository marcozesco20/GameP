const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 0, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
const rows = [];
for (let seed = 1; seed <= 8; seed++) {
  const race = new PG.Race(T, { seed, diff: 2 });
  for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
  race.time = 0; const dt = 1 / 60; let t = 0; const prev = {}, hist = {};
  while (t < 70) {
    race.time = t; race.update(dt, null); t += dt;
    race.racers.forEach(r => {
      const h = hist[r.id] = hist[r.id] || []; h.push(r.vf); if (h.length > 120) h.shift();
      if (prev[r.id] === 0 && r.br) { rows.push({ ev: 'in', vBefore: h[h.length - 20], vNow: r.vf, tt: t, id: r.id, rec: { id: r.id, k: 0 } }); r._watch = 90; r._v0 = h[h.length - 20]; r._min = r.vf; }
      if (prev[r.id] > 0 && !r.br) { rows.push({ ev: 'out', vBefore: h[h.length - 20], vNow: r.vf }); }
      if (r._watch > 0) { r._watch--; r._min = Math.min(r._min, r.vf); if (!r._watch) rows.push({ ev: 'after1.5s', v0: r._v0, min: r._min, now: r.vf }); }
      prev[r.id] = r.br;
    });
    race.fxq.length = 0; race.out.length = 0;
  }
}
const f = rows.filter(r => r.ev === 'in'); console.log('entradas', f.length, 'v antes media', (f.reduce((a, r) => a + r.vBefore, 0) / f.length).toFixed(1), 'v justo despues media', (f.reduce((a, r) => a + r.vNow, 0) / f.length).toFixed(1));
const g = rows.filter(r => r.ev === 'after1.5s'); console.log('1.5s despues: v0', (g.reduce((a, r) => a + r.v0, 0) / g.length).toFixed(1), 'min', (g.reduce((a, r) => a + r.min, 0) / g.length).toFixed(1), 'now', (g.reduce((a, r) => a + r.now, 0) / g.length).toFixed(1));
const o = rows.filter(r => r.ev === 'out'); console.log('salidas', o.length, 'antes', (o.reduce((a, r) => a + r.vBefore, 0) / (o.length || 1)).toFixed(1), 'ahora', (o.reduce((a, r) => a + r.vNow, 0) / (o.length || 1)).toFixed(1));
console.log(f.slice(0, 8).map(r => r.vBefore.toFixed(1) + '->' + r.vNow.toFixed(1)).join('  '));
