const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const id = +process.argv[2] || 7, T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
let shown = 0;
for (let seed = 1; seed <= 8 && shown < 3; seed++) {
  const race = new PG.Race(T, { seed, diff: 2 });
  for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
  race.time = 0; const dt = 1 / 60; let t = 0; const prev = {}; const watch = {};
  while (t < 70 && shown < 3) {
    race.time = t; race.update(dt, null); t += dt;
    race.racers.forEach(r => {
      if (prev[r.id] === 0 && r.br && !watch[r.id]) watch[r.id] = 100;
      if (watch[r.id] > 0) { if (watch[r.id] % 10 === 0) console.log(`seed${seed} ${r.id} f${100 - watch[r.id]} vf=${r.vf.toFixed(1)} vl=${r.vl.toFixed(1)} psi=${r.psi.toFixed(2)} d=${r.d.toFixed(1)} sl=${T.q(T.uToS(r.u), r.br).sl.toFixed(3)} cv=${T.q(T.uToS(r.u), r.br).cv.toFixed(4)} gr=${r.grounded} py=${r.py.toFixed(1)}`); watch[r.id]--; if (!watch[r.id]) { shown++; console.log('--'); } }
      prev[r.id] = r.br;
    });
    race.fxq.length = 0; race.out.length = 0;
  }
}
