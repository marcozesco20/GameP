const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 400 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(0));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  console.log(await page.evaluate(() => { const G = PG.G, T = G.T, ti = G.tracksInfo[0]; const c = 0.2 * ti.len, a = T.uToS(c - 20), q = T.q(a); return JSON.stringify({ len: ti.len, a, q, cy: T.centerY(a), sh: (T.shortcuts || []).map(x => [x.s0, x.s1]), h: T.holes.map(x => Object.keys(x)).slice(0, 1) }); }));
  await browser.close();
})();
