const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
const id = +process.argv[2], s0 = +process.argv[3], s1 = +process.argv[4], who = process.argv[5] || 'b2';
const T = PG.buildTrack(PG.TRACKS[id], { noMesh: true });
const race = new PG.Race(T, { seed: 7 });
for (let i = 0; i < 3; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0;
let t = 0; const dt = 1 / 60, n = 0;
let last = -9;
while (t < 60) {
  race.time = t; race.update(dt, null); t += dt;
  const r = race.byId[who], s = T.uToS(r.u);
  if (s > s0 && s < s1 && t - last > 0.2) { last = t; console.log(`t=${t.toFixed(1)} s=${s.toFixed(0)} d=${r.d.toFixed(1)} tgt=${r.ai.laneSm.toFixed(1)} vf=${r.vf.toFixed(1)} vl=${r.vl.toFixed(1)} psi=${r.psi.toFixed(2)} cv=${T.q(s).cv.toFixed(4)} fell=${r.fell}`); }
  race.fxq.length = 0; race.out.length = 0;
}
