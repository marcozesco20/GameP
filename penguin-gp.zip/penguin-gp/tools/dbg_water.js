const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.startSolo(10); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const r = await page.evaluate(async () => {
    const G = PG.G, T = G.T, R = G.R; G.goAt -= 3000;
    const s = (T.lake.s0 + T.lake.s1) / 2, i = Math.round(s / T.ds);
    G.me.u = s - T.startS;
    const x = T.px[i], z = T.pz[i], wy = T.lake.y;
    const e = [x, wy - 1.5, z];
    G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = x + T.tx[i] * 10; cam.target[1] = wy + 1.2; cam.target[2] = z + T.tz[i] * 10; cam.fov = 1; cam.roll = 0; };
    const calls = []; const o = R.drawWater; R.drawWater = function (m, a, u, t) { calls.push([a, u, m.chunks.length]); return o.apply(this, arguments); };
    await new Promise(r => setTimeout(r, 1500));
    return { calls: calls.slice(-2), uw: G.uwK, wy, floor: T.centerY(s, 0), lake: T.lake, py: T.py[i], hasWat: !!R.wat, nch: G.twater && G.twater.chunks.length };
  });
  console.log(JSON.stringify(r)); await browser.close();
})();
