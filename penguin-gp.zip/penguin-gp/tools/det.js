// Banco determinista: reloj y Math.random falsos, bucle de cuadros manual. Cuenta llamadas GL por cuadro y guarda capturas del canvas
// uso: node det.js etiqueta [pistas] [calidad]   (por run_with_server.sh)  -> /tmp/.../scratchpad/det/<etiqueta>_<pista>_<k>.png + resumen JSON
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const label = process.argv[2] || 'x', tracks = (process.argv[3] || '0,12,13,14').split(',').map(Number), Q = +(process.argv[4] || 1);
const OUT = process.env.DETOUT || '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/det';
fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: +(process.env.VW || 800), height: +(process.env.VH || 450) }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.addInitScript(() => {
    let s = 123456789; Math.random = () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    let clock = 1000; performance.now = () => clock; const q = []; window.requestAnimationFrame = (cb) => { q.push(cb); return q.length; };
    window.__calls = { n: 0, by: {} };
    for (const k of Object.getOwnPropertyNames(WebGLRenderingContext.prototype)) {
      const dsc = Object.getOwnPropertyDescriptor(WebGLRenderingContext.prototype, k); const f = dsc && dsc.value; if (typeof f !== 'function' || k === 'constructor') continue;
      WebGLRenderingContext.prototype[k] = function () { window.__calls.n++; window.__calls.by[k] = (window.__calls.by[k] || 0) + 1; return f.apply(this, arguments); };
    }
    window.__step = (n) => { let js = 0; const jsA = []; for (let i = 0; i < n; i++) { clock += 16.667; const cbs = q.splice(0); window.__calls.n = 0; window.__calls.by = {}; const a = performance.now ? Date.now() : 0; const t0 = window.__real(); cbs.forEach(cb => cb(clock)); if (window.__sync) { const R = PG.G.R, g = R.gl; g.readPixels(0, 0, 1, 1, g.RGBA, g.UNSIGNED_BYTE, window.__px); } jsA.push(window.__real() - t0); } return jsA; };
    window.__W = +(new URLSearchParams(location.search).get('w') || 20); window.__M = +(new URLSearchParams(location.search).get('m') || 8); window.__px = new Uint8Array(4); window.__sync = (location.search || '').includes('x=1'); window.__setClock = (v) => { clock = v; }; window.__real = ((p) => () => p.call(performance))(Performance.prototype.now);
  });
  await page.goto('http://localhost:8080/?w=' + (process.env.W || 20) + '&m=' + (process.env.M || 8) + (process.env.SYNC ? '&x=1' : '')); await page.waitForFunction(() => document.querySelector('#scrMain.show'), null, { timeout: 60000, polling: 100 });
  const summary = {};
  for (const ti of tracks) {
    await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
    for (let k = 0; k < 400; k++) { const ok = await page.evaluate(() => { window.__step(3); return PG.G.mode === 'race' && !!PG.G.race && !!PG.G.R; }); if (ok) break; await page.waitForTimeout(50); }
    await page.evaluate(() => { window.__step(5); window.__setClock(5000); PG.G.goAt = 5000 - 8000; PG.G.last = 0; });
    const res = [];
    for (const fr of (process.env.FR || '0.08,0.3,0.55,0.8').split(',').map(Number)) {
      const r = await page.evaluate(async (fr) => {
        const G = PG.G, me = G.me, ti = G.tracksInfo[G.trackIdx], R0 = G.R; me.u = fr * ti.len; me.safeU = me.u; me.vf = 0; G.R.dyn = 1;
        window.__step(+(window.__W || 20)); window.__cs = { smallCalls: 0, smallChunks: 0, bigCalls: 0, alpha: 0, mat: 0 }; const od = R0.draw; R0.draw = function (m, md, t, a) { const c = window.__cs; if (m.cull) c.bigCalls++; else { c.smallCalls++; c.smallChunks += m.chunks.length; } if (a !== undefined && a < 1) c.alpha++; if (this.mat) c.mat++; const v0 = this.verts || 0; const r = od.apply(this, arguments); const dv = (this.verts || 0) - v0; const cat = m.cull ? 'big' : (this.mat ? 'peng' : (a !== undefined && a < 1 ? 'alpha' : 'small')); c.v = c.v || {}; c.v[cat] = (c.v[cat] || 0) + dv; if (cat !== 'big' && dv) { c.n = c.n || {}; c.n[cat] = (c.n[cat] || 0) + 1; } return r; }; const js = window.__step(+(window.__M || 8)); R0.draw = od;
        const c = window.__calls, R = G.R; const o = { calls: c.n, draw: c.by.drawArrays || 0, vap: c.by.vertexAttribPointer || 0, bind: c.by.bindBuffer || 0, uni: Object.keys(c.by).filter(k => k.startsWith('uniform')).reduce((s, k) => s + c.by[k], 0), cs: window.__cs, drawn: R.drawn, culled: R.culled, kv: Math.round((R.verts || 0) / 1000), js: +(js.reduce((a, b) => a + b, 0) / js.length).toFixed(2), by: c.by };
        window.__step(1); o.png = R.canvas.toDataURL('image/png'); return o;
      }, fr);
      const png = r.png; delete r.png; fs.writeFileSync(`${OUT}/${label}_${ti}_${fr}.png`, Buffer.from(png.split(',')[1], 'base64'));
      res.push(r);
    }
    summary[ti] = res; console.log('pista', ti, JSON.stringify(res.map(r => ({ calls: r.calls, draw: r.draw, vap: r.vap, bind: r.bind, uni: r.uni, drawn: r.drawn, cs: r.cs, kv: r.kv, js: r.js }))));
  }
  fs.writeFileSync(`${OUT}/${label}.json`, JSON.stringify(summary));
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
