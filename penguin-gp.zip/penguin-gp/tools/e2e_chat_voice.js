const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const wait = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const broker = await start(18832, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist',
      '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--disable-features=WebRtcHideLocalIpsWithMdns', '--autoplay-policy=no-user-gesture-required'] });
  async function mk(name) {
    const ctx = await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true, permissions: ['microphone'] });
    await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18832/mqtt'); });
    const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(name + ': ' + e)); p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) p.errs.push(name + ': ' + m.text()); });
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate((n) => { PG.G.cfg.name = n; }, name);
    return p;
  }
  const A = await mk('Ana'), B = await mk('Beto'), C = await mk('Carla');
  await A.click('[data-act=multi]'); await A.click('#btnHostOnline');
  await A.waitForSelector('#scrLobby.show', { timeout: 15000 });
  const code = await A.textContent('#roomIp');
  for (const P of [B, C]) { await P.click('[data-act=multi]'); await P.fill('#inCode', code); await P.click('[data-act=joinCode]'); await P.waitForSelector('#scrLobby.show', { timeout: 15000 }); }
  await wait(800);
  ok(await A.evaluate(() => Object.keys(PG.G.players).length) === 3, 'tres jugadores en la sala');
  // ---- boton iniciar visible dentro de la pantalla ----
  const bb = await A.evaluate(() => { const r = document.getElementById('btnStart').getBoundingClientRect(); return [r.top, r.bottom, r.left, r.right, innerHeight, innerWidth]; });
  ok(bb[0] >= 0 && bb[1] <= bb[4] && bb[3] <= bb[5], 'boton iniciar completamente visible ' + bb.map(Math.round));
  ok(await B.evaluate(() => document.getElementById('btnStart').disabled), 'el invitado ve el boton deshabilitado (esperando)');
  // ---- chat ----
  await B.click('#lTabC'); await B.fill('#chatInput', 'Hola <b>a todos</b>!'); await B.press('#chatInput', 'Enter');
  await wait(600);
  await A.click('#lTabC');
  ok(await A.evaluate(() => PG.G.chat.some(c => c.text === 'Hola <b>a todos</b>!' && c.name === 'Beto')), 'Ana recibe el chat de Beto');
  ok(await C.evaluate(() => PG.G.chat.some(c => c.text.startsWith('Hola') && c.name === 'Beto')), 'Carla tambien lo recibe (via anfitrion)');
  ok(await A.evaluate(() => !document.querySelector('#chatLog b b') && document.getElementById('chatLog').innerHTML.includes('&lt;b&gt;')), 'el chat escapa HTML');
  await A.fill('#chatInput', 'Bienvenido Beto'); await A.click('[data-act=chatSend]'); await wait(600);
  ok(await B.evaluate(() => PG.G.chat.some(c => c.text === 'Bienvenido Beto' && c.name === 'Ana')), 'Beto recibe la respuesta de Ana');
  ok(await C.evaluate(() => document.getElementById('chatDot').style.display !== 'none'), 'Carla ve el punto de mensajes sin leer');
  // espacio en el campo de chat no debe bloquearse
  await B.fill('#chatInput', ''); await B.type('#chatInput', 'a b');
  ok(await B.inputValue('#chatInput') === 'a b', 'se pueden escribir espacios en el chat');
  await B.fill('#chatInput', '');
  await A.screenshot({ path: OUT + '/lobby_chat.png' });
  // ---- voz ----
  for (const P of [A, B, C]) { await P.click('#lTabP'); await P.click('[data-act=vJoin]'); await wait(300); }
  const conn = async (P) => P.evaluate(() => Object.keys(PG.Voice.peers).map(k => PG.Voice.peers[k].state).join(','));
  let okc = false;
  for (let i = 0; i < 40 && !okc; i++) { await wait(500); okc = [await conn(A), await conn(B), await conn(C)].every(s => s.split(',').length === 2 && s.split(',').every(x => x === 'connected')); }
  console.log('estados', await conn(A), '|', await conn(B), '|', await conn(C));
  ok(okc, 'malla de voz: los 3 jugadores conectados entre si');
  await wait(1500);
  const rx = async (P) => P.evaluate(async () => { let tot = 0; for (const k in PG.Voice.peers) { const st = await PG.Voice.peers[k].pc.getStats(); st.forEach(r => { if (r.type === 'inbound-rtp' && r.kind === 'audio') tot += r.bytesReceived; }); } return tot; });
  const r1 = await rx(A); await wait(1500); const r2 = await rx(A);
  ok(r2 > r1 && r1 > 0, 'Ana recibe audio (bytes ' + r1 + ' -> ' + r2 + ')');
  ok(await A.evaluate(() => Object.values(PG.Voice.peers).every(p => p.audio && p.audio.srcObject && !p.audio.muted)), 'Ana reproduce el audio de los demas');
  await A.screenshot({ path: OUT + '/lobby_voice.png' });
  // silenciar mi micro: los demas ya no reciben audio de mi
  await B.click('[data-act=vMic]'); await wait(500);
  ok(await B.evaluate(() => PG.Voice.stream.getAudioTracks()[0].enabled === false && !PG.Voice.mic), 'Beto silencia su microfono (pista desactivada)');
  const bytesFromBeto = async (P) => P.evaluate(async () => { let tot = 0; const pe = Object.values(PG.Voice.peers); for (const p of pe) { const st = await p.pc.getStats(); st.forEach(r => { if (r.type === 'inbound-rtp' && r.kind === 'audio') { r.__id = p.id; } }); } return 0; });
  // medir energia recibida por Carla desde Beto: totalAudioEnergy debe dejar de crecer
  const energy = async (P, name) => P.evaluate(async (name) => { const id = +Object.keys(PG.G.players).find(k => PG.G.players[k].name === name); const p = PG.Voice.peers[id]; let e = 0; const st = await p.pc.getStats(); st.forEach(r => { if (r.type === 'inbound-rtp' && r.kind === 'audio') e = r.totalAudioEnergy || 0; }); return e; }, name);
  const e1 = await energy(C, 'Beto'); await wait(1500); const e2 = await energy(C, 'Beto');
  const f1 = await energy(C, 'Ana'); await wait(1500); const f2 = await energy(C, 'Ana');
  ok(e2 - e1 < 0.0005 && f2 - f1 > 0.0005, 'Carla no oye a Beto silenciado (' + (e2 - e1).toFixed(5) + ') pero si a Ana (' + (f2 - f1).toFixed(5) + ')');
  await B.click('[data-act=vMic]'); await wait(300);
  ok(await B.evaluate(() => PG.Voice.stream.getAudioTracks()[0].enabled === true), 'Beto reactiva el microfono');
  // silenciar a otro: Carla silencia a Ana, no a Beto
  await C.evaluate(() => { const id = +Object.keys(PG.G.players).find(k => PG.G.players[k].name === 'Ana'); document.querySelector('[data-act=vPeer][data-id="' + id + '"]').click(); });
  await wait(300);
  ok(await C.evaluate(() => { const o = {}; for (const k in PG.Voice.peers) o[PG.G.players[k].name] = PG.Voice.peers[k].audio.muted; return o.Ana === true && o.Beto === false; }), 'Carla silencia solo a Ana');
  await C.click('[data-act=vDeaf]'); await wait(200);
  ok(await C.evaluate(() => Object.values(PG.Voice.peers).every(p => p.audio.muted)), 'Carla deja de oir a todos (ensordecer)');
  await C.click('[data-act=vDeaf]'); await wait(200);
  ok(await C.evaluate(() => { const o = {}; for (const k in PG.Voice.peers) o[PG.G.players[k].name] = PG.Voice.peers[k].audio.muted; return o.Ana === true && o.Beto === false; }), 'al volver a oir, Ana sigue silenciada individualmente');
  await C.screenshot({ path: OUT + '/lobby_voice_c.png' });
  // salir de voz: Beto sale, los demas lo sueltan
  await B.click('[data-act=vLeave]'); await wait(700);
  ok(await A.evaluate(() => Object.values(PG.Voice.peers).filter(p => p.pc).length === 1), 'Ana suelta a Beto tras salir de voz');
  // sin voz Beto aun chatea
  ok(await B.evaluate(() => !PG.Voice.on && !PG.Voice.stream), 'Beto sin voz: micro liberado');
  // la voz sigue durante la carrera
  await A.evaluate(() => document.getElementById('btnStart').click());
  await A.waitForFunction(() => PG.G.mode === 'race', null, { timeout: 60000 }); await C.waitForFunction(() => PG.G.mode === 'race', null, { timeout: 60000 });
  await wait(1500);
  ok(await A.evaluate(() => PG.Voice.on && document.getElementById('btnMic').style.display !== 'none'), 'en carrera: boton de micro visible en el HUD');
  await A.evaluate(() => { PG.G.goAt -= 9000; });
  await wait(1200); await A.screenshot({ path: OUT + '/race_mic.png' });
  const s1 = await C.evaluate(() => Object.values(PG.Voice.peers).filter(p => p.state === 'connected').length);
  ok(s1 >= 1, 'la conexion de voz sigue activa en carrera');
  console.log('errores:', [...A.errs, ...B.errs, ...C.errs].slice(0, 8));
  ok(![...A.errs, ...B.errs, ...C.errs].length, 'sin errores de JS');
  console.log(fails ? 'FALLOS: ' + fails : 'TODO OK');
  await browser.close(); broker.close(); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
