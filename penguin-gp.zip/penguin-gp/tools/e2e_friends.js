// Amigos: codigo, agregar, solicitud, aceptar, estado en linea, invitar a la sala y unirse desde la invitacion
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const wait = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const broker = await start(18834, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  async function mk(name) {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true });
    await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18834/mqtt'); });
    const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(name + ': ' + e)); p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) p.errs.push(name + ': ' + m.text()); });
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate((n) => { PG.G.cfg.name = n; }, name);
    return p;
  }
  const A = await mk('Ana'), B = await mk('Beto');
  for (const P of [A, B]) { await P.click('[data-act=friends]'); await P.waitForSelector('#scrFriends.show'); }
  await wait(1500);
  const codeA = await A.evaluate(() => PG.Friends.code), codeB = await B.evaluate(() => PG.Friends.code);
  ok(codeA && codeA.length === 6 && codeB && codeB.length === 6 && codeA !== codeB, 'cada jugador tiene su código de amigo: ' + codeA + ' / ' + codeB);
  ok((await A.textContent('#frMyCode')).replace(/\s/g, '') === codeA, 'el código se muestra en pantalla');
  // Ana agrega a Beto
  await A.fill('#frIn', codeB.toLowerCase()); await A.click('[data-act=frAdd]'); await wait(1500);
  ok(await A.evaluate((c) => PG.Friends.isFriend(c), codeB), 'Ana tiene a Beto en su lista');
  const reqs = await B.evaluate(() => PG.Friends.reqs.map(r => r.n));
  ok(reqs.length === 1 && reqs[0] === 'Ana', 'Beto recibe la solicitud de Ana: ' + JSON.stringify(reqs));
  ok(await B.evaluate(() => document.getElementById('frReqs').innerText.includes('Ana')), 'la solicitud se ve en la pantalla de Beto');
  const errA = await A.evaluate(() => PG.Friends.add('zzz'));
  ok(errA.length > 0, 'código inválido rechazado: ' + errA);
  ok((await A.evaluate((c) => PG.Friends.add(c), codeB)).length > 0, 'no se puede agregar dos veces');
  await B.click('[data-act=frAcc]'); await wait(2500);
  ok(await B.evaluate((c) => PG.Friends.isFriend(c), codeA), 'Beto aceptó: Ana está en su lista');
  // estado en linea
  let stA = await A.evaluate((c) => PG.Friends.status(c), codeB), stB = await B.evaluate((c) => PG.Friends.status(c), codeA);
  ok(stA.on && stA.n === 'Beto' && stA.s === 0, 'Ana ve a Beto en línea (menú): ' + JSON.stringify(stA));
  ok(stB.on && stB.n === 'Ana', 'Beto ve a Ana en línea: ' + JSON.stringify(stB));
  ok((await A.textContent('#frList')).includes('En línea'), 'la lista muestra "En línea"');
  // Ana crea sala online y lo invita
  await A.click('#scrFriends [data-act=back]'); await A.click('[data-act=multi]'); await A.click('#btnHostOnline'); await A.waitForSelector('#scrLobby.show', { timeout: 15000 });
  const room = (await A.textContent('#roomIp')).trim();
  await A.click('#btnLobbyFr', { force: true }); await A.waitForSelector('#scrFriends.show'); await wait(500);
  ok((await A.textContent('#frList')).includes('Invitar a mi sala'), 'con sala creada aparece el botón Invitar');
  await A.click('[data-act=frInv]'); await wait(2500);
  const bShown = await B.evaluate(() => document.getElementById('invBanner').classList.contains('show') && document.getElementById('invBanner').innerText);
  ok(bShown && bShown.includes('Ana') && bShown.includes(room), 'Beto ve la invitación con el código de sala: ' + JSON.stringify(bShown));
  await B.click('#invYes'); await B.waitForSelector('#scrLobby.show', { timeout: 15000 });
  await wait(1500);
  const names = await B.evaluate(() => Object.values(PG.G.players).map(p => p.name).sort());
  ok(names.length === 2 && names.includes('Ana') && names.includes('Beto'), 'Beto entró a la sala de Ana: ' + JSON.stringify(names));
  await wait(11000);
  stA = await A.evaluate((c) => PG.Friends.status(c), codeB);
  ok(stA.on && stA.s === 1, 'Ana ve a Beto "en una sala de espera": ' + JSON.stringify(stA));
  // Beto se oculta
  await B.evaluate(() => PG.Friends.setVisible(false)); await wait(1500);
  stA = await A.evaluate((c) => PG.Friends.status(c), codeB);
  ok(!stA.on, 'si Beto se oculta, Ana lo ve desconectado');
  await B.evaluate(() => PG.Friends.setVisible(true)); await wait(1500);
  // Beto cierra: la ultima voluntad lo marca desconectado
  await B.close(); await wait(1500);
  stA = await A.evaluate((c) => PG.Friends.status(c), codeB);
  ok(!stA.on, 'al cerrar Beto, Ana lo ve desconectado');
  // persistencia
  const ls = await A.evaluate(() => JSON.parse(localStorage.getItem('pgp_friends')));
  ok(ls && ls.code === codeA && ls.list.length === 1, 'la lista de amigos se guarda');
  const errs = [...A.errs]; ok(errs.length === 0, 'sin errores de consola ' + errs.join('|'));
  await browser.close(); broker.close(); process.exit(fails ? 1 : 0);
})();
