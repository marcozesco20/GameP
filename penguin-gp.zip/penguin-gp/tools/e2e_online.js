const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const broker = await start(18831, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  async function mk(name) {
    const ctx = await browser.newContext({ viewport: { width: 1000, height: 520 }, hasTouch: true });
    await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18831/mqtt'); });
    const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(name + ': ' + e)); p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) p.errs.push(name + ': ' + m.text()); });
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate((n) => { PG.G.cfg.name = n; }, name);
    return p;
  }
  const A = await mk('Ana'), B = await mk('Beto');
  await A.click('[data-act=multi]'); await A.waitForSelector('#scrMulti.show');
  await A.screenshot({ path: OUT + '/mp_menu.png' });
  await A.click('#btnHostOnline');
  await A.waitForSelector('#scrLobby.show', { timeout: 15000 });
  const code = await A.textContent('#roomIp');
  console.log('codigo de sala:', code);
  await A.screenshot({ path: OUT + '/mp_lobbyA.png' });
  await B.click('[data-act=multi]'); await B.waitForSelector('#scrMulti.show');
  await B.fill('#inCode', code.toLowerCase());
  await B.click('[data-act=joinCode]');
  await B.waitForSelector('#scrLobby.show', { timeout: 15000 });
  await wait(600);
  console.log('jugadores en A:', await A.evaluate(() => Object.values(PG.G.players).map(p => p.name).join(',')), '| en B:', await B.evaluate(() => Object.values(PG.G.players).map(p => p.name).join(',')));
  await B.screenshot({ path: OUT + '/mp_lobbyB.png' });
  await A.evaluate(() => { PG.G.lobby.track = 6; });
  await A.click('#btnStart');
  await A.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await B.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await wait(9000);
  const st = async (p) => p.evaluate(() => ({ me: PG.G.me && PG.G.me.name, track: PG.G.trackIdx, racers: PG.G.race.racers.map(r => r.name + (r.own ? '*' : '') + ':' + r.u.toFixed(0)).join(' '), t: PG.G.race.time.toFixed(1) }));
  console.log('A', JSON.stringify(await st(A))); console.log('B', JSON.stringify(await st(B)));
  // el jugador B acelera: comprobar que A ve moverse a B
  const uB = await A.evaluate(() => { const r = PG.G.race.racers.find(x => x.name === 'Beto'); return r ? r.u : null; });
  await wait(3000);
  const uB2 = await A.evaluate(() => { const r = PG.G.race.racers.find(x => x.name === 'Beto'); return r ? r.u : null; });
  console.log('Beto visto desde Ana: u', uB && uB.toFixed(1), '->', uB2 && uB2.toFixed(1));
  await A.screenshot({ path: OUT + '/mp_raceA.png' }); await B.screenshot({ path: OUT + '/mp_raceB.png' });
  console.log('errores:', [...A.errs, ...B.errs].slice(0, 8));
  console.log('broker', JSON.stringify(broker.stats()));
  await browser.close(); broker.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
