// multijugador: al terminar todos, cuenta atras en resultados, «Estoy listo» desde ahi, y vuelta a la sala
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const wait = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const broker = await start(18835, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  async function mk(name) {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true });
    await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18835/mqtt'); });
    const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(name + ': ' + e)); p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) p.errs.push(name + ': ' + m.text()); });
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate((n) => { PG.G.cfg.name = n; }, name);
    return p;
  }
  const A = await mk('Ana'), B = await mk('Beto');
  await A.click('[data-act=multi]'); await A.waitForSelector('#scrMulti.show'); await A.click('#btnHostOnline'); await A.waitForSelector('#scrLobby.show', { timeout: 15000 });
  const code = await A.textContent('#roomIp');
  await B.click('[data-act=multi]'); await B.waitForSelector('#scrMulti.show'); await B.fill('#inCode', code.toLowerCase()); await B.click('[data-act=joinCode]'); await B.waitForSelector('#scrLobby.show', { timeout: 15000 });
  await wait(800);
  await B.evaluate(() => document.getElementById('btnStart').click()); await wait(800); // Beto listo
  await A.evaluate(() => document.getElementById('btnStart').click());
  for (const P of [A, B]) await P.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  ok(await B.evaluate(() => Object.keys(PG.G.ready).length) === 0, 'al empezar la carrera se reinician los «listo»');
  await wait(1500);
  // todos cruzan la meta salvo el ultimo
  for (const P of [A, B]) await P.evaluate(() => { const R = PG.G.race.racers; R.forEach((r, i) => { if (i < R.length - 1) { r.finished = true; r.finishTime = 40 + i; } }); PG.G.showResults(); });
  await wait(1200);
  const cdTxt = async (P) => P.evaluate(() => document.getElementById('resCd').innerText);
  ok(/Esperando/.test(await cdTxt(A)), 'sin terminar todos: "' + await cdTxt(A) + '"');
  for (const P of [A, B]) await P.evaluate(() => PG.G.race.racers.forEach((r, i) => { if (!r.finished) { r.finished = true; r.finishTime = 60; } }));
  for (let i = 0; i < 16 && !(/Volviendo/.test(await cdTxt(B)) && /Volviendo/.test(await cdTxt(A))); i++) await wait(500);
  const ta = await cdTxt(A), tb = await cdTxt(B);
  ok(/Volviendo a la sala en (1[0-5]|[0-9]) s/.test(ta) && /Volviendo a la sala/.test(tb), 'cuenta atrás en ambos: "' + ta + '" / "' + tb + '"');
  const vis = async (P, id) => P.evaluate((id) => getComputedStyle(document.getElementById(id)).display !== 'none', id);
  ok(await vis(B, 'btnResReady') && !(await vis(A, 'btnResReady')) && await vis(A, 'btnResLobby'), 'Beto ve «Estoy listo», Ana (anfitriona) «Ir a la sala»');
  ok(await B.evaluate(() => [...document.querySelectorAll('#scrResults [data-act]')].some(b => b.dataset.act === 'toMenu' && getComputedStyle(b).display !== 'none')), 'la opción Salir está visible');
  await B.click('#btnResReady'); await wait(1500);
  ok(await A.evaluate(() => document.getElementById('resList').innerText.includes('listo')), 'Ana ve a Beto marcado como listo en los resultados');
  // con todos listos la cuenta se acorta a ~3 s y se vuelve a la sala
  await A.waitForSelector('#scrLobby.show', { timeout: 9000 }); await B.waitForSelector('#scrLobby.show', { timeout: 9000 });
  ok(true, 'ambos volvieron a la sala de espera');
  ok(await B.evaluate(() => !!PG.G.ready[PG.G.myId]) && /Listo/.test(await B.textContent('#btnStart')), 'Beto sigue marcado «listo» en la sala: "' + (await B.textContent('#btnStart')) + '"');
  ok(await A.evaluate(() => document.getElementById('btnStart').textContent.includes('INICIAR')), 'Ana puede iniciar de inmediato');
  // segunda ronda: nadie marca listo, la cuenta llega a 0 sola
  await A.evaluate(() => document.getElementById('btnStart').click());
  for (const P of [A, B]) await P.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await wait(1200);
  for (const P of [A, B]) await P.evaluate(() => { PG.G.race.racers.forEach((r, i) => { r.finished = true; r.finishTime = 40 + i; }); PG.G.showResults(); });
  await wait(1500);
  const t0 = await cdTxt(A); const n0 = +(/en (\d+) s/.exec(t0) || [0, 99])[1];
  await wait(3500); const n1 = +(/en (\d+) s/.exec(await cdTxt(A)) || [0, 99])[1];
  ok(n0 >= 12 && n1 <= n0 - 2, 'la cuenta baja: ' + n0 + ' -> ' + n1);
  await A.waitForSelector('#scrLobby.show', { timeout: 20000 }); await B.waitForSelector('#scrLobby.show', { timeout: 20000 });
  ok(true, 'sin pulsar nada, vuelven a la sala al llegar a 0');
  const errs = [...A.errs, ...B.errs]; ok(errs.length === 0, 'sin errores de consola ' + errs.slice(0, 3).join('|'));
  await browser.close(); broker.close(); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
