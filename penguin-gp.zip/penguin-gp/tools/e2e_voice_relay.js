// Prueba del respaldo de voz por la sala: se desactiva WebRTC y el audio debe llegar igualmente
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const wait = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const broker = await start(18833, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist',
      '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'] });
  async function mk(name) {
    const ctx = await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true, permissions: ['microphone'] });
    await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18833/mqtt'); });
    const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(name + ': ' + e)); p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) p.errs.push(name + ': ' + m.text()); });
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate((n) => { PG.G.cfg.name = n; PG.Voice.noRTC = true; }, name);   // sin conexion directa
    return p;
  }
  const A = await mk('Ana'), B = await mk('Beto');
  await A.click('[data-act=multi]'); await A.click('#btnHostOnline'); await A.waitForSelector('#scrLobby.show', { timeout: 15000 });
  const code = await A.textContent('#roomIp');
  await B.click('[data-act=multi]'); await B.fill('#inCode', code); await B.click('[data-act=joinCode]'); await B.waitForSelector('#scrLobby.show', { timeout: 15000 });
  await wait(600);
  for (const P of [A, B]) { await P.click('[data-act=vJoin]'); await wait(300); }
  await wait(7000);
  const info = async (P, nm) => P.evaluate((nm) => { const id = +Object.keys(PG.G.players).find(k => PG.G.players[k].name === nm); const p = PG.Voice.peers[id]; return p ? { frames: p.relayFrames | 0, lvl: +(p.relayLevel || 0).toFixed(3), st: PG.Voice.stateOf(id), relayOn: PG.Voice.relayOn, tx: PG.Voice.relayTx | 0, gain: p.gain ? p.gain.gain.value : null } : null; }, nm);
  const a1 = await info(A, 'Beto'), b1 = await info(B, 'Ana');
  console.log('A<-Beto', JSON.stringify(a1), ' B<-Ana', JSON.stringify(b1));
  ok(a1 && a1.frames > 5, 'Ana recibe y reproduce voz de Beto por la sala (' + (a1 && a1.frames) + ' bloques)');
  ok(b1 && b1.frames > 5, 'Beto recibe voz de Ana por la sala');
  ok(a1 && a1.st === 'ok', 'el estado de la conexion se muestra como OK');
  const mu = await A.evaluate(() => { let worst = 0; for (let x = -1; x <= 1; x += 0.01) { const y = PG.Voice._mulaw.dec(PG.Voice._mulaw.enc(x)); const e = Math.abs(y - x) / Math.max(0.05, Math.abs(x)); if (Math.abs(x) > 0.02 && e > worst) worst = e; } return worst; });
  ok(mu < 0.08, 'compresion mu-law fiel (error relativo max ' + (mu * 100).toFixed(1) + '%)');
  // silenciar mi micro: dejan de llegar bloques
  await B.click('[data-act=vMic]'); await wait(800);
  const f1 = (await info(A, 'Beto')).frames; await wait(2500); const f2 = (await info(A, 'Beto')).frames;
  ok(f2 - f1 <= 1, 'Beto silencia su micro: no llegan bloques nuevos (' + (f2 - f1) + ')');
  await B.click('[data-act=vMic]'); await wait(2500);
  const f3 = (await info(A, 'Beto')).frames; ok(f3 > f2 + 3, 'al reactivar vuelve a llegar audio');
  // silenciar a otro: la ganancia queda en 0
  await A.evaluate(() => { const id = +Object.keys(PG.G.players).find(k => PG.G.players[k].name === 'Beto'); document.querySelector('[data-act=vPeer][data-id="' + id + '"]').click(); });
  await wait(1500); ok((await info(A, 'Beto')).gain === 0, 'Ana silencia a Beto: volumen 0');
  console.log('errores:', [...A.errs, ...B.errs].slice(0, 5)); ok(![...A.errs, ...B.errs].length, 'sin errores JS');
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK');
  await browser.close(); broker.close(); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
