// v4.8: experimento de eliminacion: cuanto cuesta cada categoria de dibujo (min de N cuadros, lectura sincrona) -- proxy de SwiftShader
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks=(process.argv[2]||'0,9').split(',').map(Number), Q=+(process.argv[3]||1), N=+(process.argv[4]||7);
(async()=>{
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:640,height:360},deviceScaleFactor:1})).newPage();
page.on('pageerror', e=>console.log('PAGEERROR', e.message));
await page.addInitScript(()=>{ let clock=1000; performance.now=()=>clock; const q=[]; window.requestAnimationFrame=(cb)=>{q.push(cb);return q.length};
 window.__real=((p)=>()=>p.call(performance))(Performance.prototype.now); window.__px=new Uint8Array(4);
 window.__step=(n)=>{ const a=[]; for(let i=0;i<n;i++){ clock+=16.667; const cbs=q.splice(0); const t0=window.__real(); cbs.forEach(cb=>cb(clock)); const g=PG.G.R.gl; g.readPixels(0,0,1,1,g.RGBA,g.UNSIGNED_BYTE,window.__px); a.push(window.__real()-t0);} return Math.min.apply(null,a); }; });
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
for (const ti of tracks){
  await page.evaluate(([i,q])=>{PG.G.set.ava=false; PG.G.set.quality=q; PG.G.startSolo(i);},[ti,Q]);
  await page.waitForFunction(()=>PG.G.mode==='race'&&PG.G.race&&PG.G.R,null,{timeout:120000,polling:100});
  const out=await page.evaluate((N)=>{ window.__step(5); PG.G.goAt-=9000; const G=PG.G, me=G.me, T=G.tracksInfo[G.trackIdx]; me.u=0.4*T.len; me.safeU=me.u; me.vf=0; const R=G.R; R.dyn=1; window.__step(10);
    const r={size:R.canvas.width+'x'+R.canvas.height}; const od=R.draw;
    const mode={skip:null}; R.draw=function(m,md,t,a){ const big=!!m.cull, al=(a!==undefined&&a<1), pg=!!this.mat; const cat= big?(al?'bigAlpha':'big'):(pg?'peng':(al?'alpha':'small')); if(mode.skip===cat) return; return od.apply(this,arguments); };
    r.full=window.__step(N);
    for(const c of ['big','bigAlpha','small','alpha','peng']){ mode.skip=c; r['sin_'+c]=window.__step(N); }
    mode.skip=null; const o={}; for(const f of ['drawParticles','drawSnow','drawWater','shieldFx','_flushSky']){ o[f]=R[f]; }
    for(const f of ['drawParticles','drawSnow','drawWater','shieldFx']){ R[f]=function(){}; r['sin_'+f]=window.__step(N); R[f]=o[f]; }
    R.draw=od; return r; }, N);
  const f=out.full; console.log('pista',ti,'q'+Q,out.size,'full',f.toFixed(0),'ms |',Object.keys(out).filter(k=>k.startsWith('sin_')).map(k=>k.slice(4)+':'+(f-out[k]).toFixed(0)).join(' '));
}
await browser.close(); })();
