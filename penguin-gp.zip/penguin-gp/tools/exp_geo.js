// v4.8: composicion de los vertices dibujados en un cuadro (distancia a la camara, tamano del lote)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks=(process.argv[2]||'0,13').split(',').map(Number), FR=+(process.argv[3]||0.01);
(async()=>{
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:640,height:360},deviceScaleFactor:1})).newPage();
page.on('pageerror', e=>console.log('PAGEERROR', e.message));
await page.addInitScript(()=>{ let clock=1000; performance.now=()=>clock; const q=[]; window.requestAnimationFrame=(cb)=>{q.push(cb);return q.length}; window.__step=(n)=>{for(let i=0;i<n;i++){clock+=16.667; q.splice(0).forEach(cb=>cb(clock));}}; window.__setClock=(v)=>{clock=v}; });
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
for (const ti of tracks){
  await page.evaluate(([i])=>{PG.G.set.ava=false; PG.G.set.quality=1; PG.G.startSolo(i);},[ti]);
  await page.waitForFunction(()=>{ window.__step(3); return PG.G.mode==='race'&&PG.G.race&&PG.G.R; },null,{timeout:120000,polling:100});
  const out=await page.evaluate((FR)=>{ window.__step(5); window.__setClock(5000); PG.G.goAt=5000-8000; const G=PG.G, me=G.me, T=G.tracksInfo[G.trackIdx], R=G.R; me.u=FR*T.len; me.safeU=me.u; me.vf=0; R.dyn=1; window.__step(10);
    const log=[]; const ob=R._bindChunk; let curBig=false; const od=R.draw; R.draw=function(m){ curBig=!!m.cull; return od.apply(this,arguments); };
    R._bindChunk=function(c){ if(curBig) log.push(c); return ob.apply(this,arguments); };
    const dg=R.gl.drawArrays; window.__step(1); R._bindChunk=ob; R.draw=od;
    const e=R.eye, bands=[0,25,50,100,200,400,800,1e9], hist=new Array(bands.length-1).fill(0), sz=[0,0,0,0]; let tot=0, N=0;
    for(const c of log){ const bb=c.bb; const cx=(bb[0]+bb[3])/2-e[0], cy=(bb[1]+bb[4])/2-e[1], cz=(bb[2]+bb[5])/2-e[2]; const d=Math.sqrt(cx*cx+cy*cy+cz*cz); for(let k=0;k<bands.length-1;k++) if(d>=bands[k]&&d<bands[k+1]){hist[k]+=c.n;break;} tot+=c.n; N++; const ext=Math.max(bb[3]-bb[0],bb[4]-bb[1],bb[5]-bb[2]); sz[ext<20?0:ext<60?1:ext<150?2:3]+=c.n; }
    return {tot,N,hist:hist.map((v,i)=>bands[i]+'-'+bands[i+1]+'m:'+Math.round(v/1000)+'k').join(' '),ext:'<20m:'+Math.round(sz[0]/1000)+'k 20-60:'+Math.round(sz[1]/1000)+'k 60-150:'+Math.round(sz[2]/1000)+'k >150:'+Math.round(sz[3]/1000)+'k', fog:R._fogD, tris:'?'}; }, FR);
  console.log('pista',ti,'fr',FR,JSON.stringify(out));
}
await browser.close(); })();
