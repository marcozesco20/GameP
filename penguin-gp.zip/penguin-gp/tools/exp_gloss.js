// v4.8: experimento: coste de pixel del shader principal (gloss 1 vs 0) en SwiftShader con lectura sincrona
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks=(process.argv[2]||'0,9,13').split(',').map(Number);
(async()=>{
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:960,height:540},deviceScaleFactor:1})).newPage();
page.on('pageerror', e=>console.log('PAGEERROR', e.message));
await page.addInitScript(()=>{ let clock=1000; performance.now=()=>clock; const q=[]; window.requestAnimationFrame=(cb)=>{q.push(cb);return q.length};
 window.__real=((p)=>()=>p.call(performance))(Performance.prototype.now); window.__px=new Uint8Array(4);
 window.__step=(n)=>{ const a=[]; for(let i=0;i<n;i++){ clock+=16.667; const cbs=q.splice(0); const t0=window.__real(); cbs.forEach(cb=>cb(clock)); const g=PG.G.R.gl; g.readPixels(0,0,1,1,g.RGBA,g.UNSIGNED_BYTE,window.__px); a.push(window.__real()-t0);} a.sort((x,y)=>x-y); return a[a.length>>1]; }; });
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
for (const ti of tracks){
  await page.evaluate(([i])=>{PG.G.set.ava=false; PG.G.set.quality=1; PG.G.startSolo(i);},[ti]);
  await page.waitForFunction(()=>PG.G.mode==='race'&&PG.G.race&&PG.G.R,null,{timeout:120000,polling:100});
  const out=await page.evaluate(()=>{ window.__step(5); PG.G.goAt-=9000; const G=PG.G, me=G.me, T=G.tracksInfo[G.trackIdx]; me.u=0.4*T.len; me.safeU=me.u; me.vf=0; const R=G.R; R.dyn=1; window.__step(8);
    const r={}; r.size=R.canvas.width+'x'+R.canvas.height; r.gloss1=window.__step(6); R.gloss=0; r.gloss0=window.__step(6); R.gloss=1; return r; });
  console.log('pista',ti,JSON.stringify(out));
}
await browser.close(); })();
