// genera web/img/tracks/t{i}.jpg: capturas reales de cada pista
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const OUT = process.env.OUT || '/home/claude/penguin-gp/web/img/tracks';
const FR = (process.env.FR || '0.2,0.3,0.12,0.25,0.2,0.2,0.2,0.2').split(',').map(Number);
const only = process.env.ONLY ? process.env.ONLY.split(',').map(Number) : null;
fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  const n = await page.evaluate(() => PG.TRACKS.length);
  for (let i = 0; i < n; i++) {
    if (only && !only.includes(i)) continue;
    await page.evaluate((i) => { PG.G.set.ava = false; PG.G.startSolo(i); }, i);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, i, { timeout: 90000 });
    await page.evaluate(() => { PG.G.goAt -= 6000; });
    await page.waitForTimeout(700);
    await page.evaluate(([i, fr]) => {
      const G = PG.G, T = G.T, R = G.race, me = G.me, ti = G.tracksInfo[i];
      document.getElementById('hud').style.display = 'none';
      const sOf = u => T.uToS(u), bad = [];
      (T.shortcuts || []).forEach(x => bad.push([x.s0 - 30, (x.s1 || x.s0 + 40) + 30]));
      (T.holes || []).forEach(x => bad.push([x.s0 - 25, (x.s1 || (x.len ? x.s0 + x.len : x.s0 + 25)) + 25]));
      (T.ramps || []).forEach(x => bad.push([x.s0 - 25, (x.s1 || (x.len ? x.s0 + x.len : x.s0 + 25)) + 25]));
      let u0 = fr * ti.len, best = null;
      for (let k = 0; k < 60; k++) {
        const c = (0.08 + k * 0.012) * ti.len, a = sOf(c - 20), b = sOf(c + 50);
        if (bad.some(r => b > r[0] && a < r[1])) continue;
        // pendiente suave y poca curva
        const q0 = T.q(a), q1 = T.q(b), dy = Math.abs(T.centerY(b) - T.centerY(a)), dyaw = Math.abs(PG.angDiff(q0.yaw, q1.yaw));
        const score = dy * 0.4 + dyaw * 8 + Math.abs(c / ti.len - fr) * 6;
        if (!best || score < best.score) best = { c, score };
      }
      if (best) u0 = best.c;
      R.racers.forEach((x, k) => { x.u = u0 + 8 + k * 5; x.d = (k % 3 - 1) * 4.2; x.psi = 0; x.vf = 0; x.vl = 0; x.safeU = x.u; x.py = T.centerY(T.uToS(x.u)) + 0.3; x.gy = x.py; x.fx.ghost = 99; });
      G.dbgCamFn = (cam) => {
        const sc = T.uToS(u0 - 1), qc = Object.assign({}, T.q(sc)), st = T.uToS(u0 + 30), qt = Object.assign({}, T.q(st));
        cam.eye[0] = qc.x; cam.eye[1] = T.centerY(sc) + 4.6; cam.eye[2] = qc.z;
        cam.target[0] = qt.x; cam.target[1] = T.centerY(st) + 1.8; cam.target[2] = qt.z; cam.fov = 1.0; cam.roll = 0;
      };
      G.paused = false;
    }, [i, FR[i % FR.length]]);
    await page.waitForTimeout(1500);
    await page.evaluate(() => { PG.G.race.racers.forEach(x => { x.vf = 0; x.vl = 0; }); });
    await page.waitForTimeout(500);
    await page.screenshot({ path: `${OUT}/t${i}.jpg`, type: 'jpeg', quality: 78 });
    console.log('thumb', i);
    await page.evaluate(() => { PG.G.dbgCamFn = null; document.getElementById('hud').style.display = ''; });
    await page.evaluate(() => { PG.G.race = null; PG.G.me = null; PG.G.mode = 'menu'; PG.G.demo = false; });
  }
  console.log('errors', errs.slice(0, 5));
  await browser.close();
})();
