import android.app.Activity; import android.webkit.WebView; import com.pingu.slippery.NetBridge; import java.util.*; import java.util.regex.*;
public class NetTest {
  static int fails=0;
  static void check(String n, boolean ok){ System.out.println((ok?"OK   ":"FAIL ")+n); if(!ok) fails++; }
  // extrae lista de [tipo, payload] de los scripts generados
  static List<String[]> events(WebView w){
    List<String[]> r=new ArrayList<>(); List<String> copy; synchronized(w.js){copy=new ArrayList<>(w.js);}
    Pattern p=Pattern.compile("f\\('(\\w+)',\"((?:[^\"\\\\]|\\\\.)*)\"\\);");
    for(String s:copy){ Matcher m=p.matcher(s); while(m.find()){ String pl=m.group(2).replace("\\\"","\"").replace("\\\\","\\").replace("\\n","\n"); r.add(new String[]{m.group(1),pl}); } }
    return r;
  }
  static String find(WebView w,String type,String contains){ for(String[] e:events(w)) if(e[0].equals(type)&&e[1].contains(contains)) return e[1]; return null; }
  static boolean wait(WebView w,String type,String contains,int ms) throws Exception { long t=System.currentTimeMillis(); while(System.currentTimeMillis()-t<ms){ if(find(w,type,contains)!=null) return true; Thread.sleep(25);} return false; }
  public static void main(String[] a) throws Exception {
    Activity act=new Activity();
    WebView wa=new WebView(act), wb=new WebView(act), wc=new WebView(act);
    NetBridge A=new NetBridge(act,wa), B=new NetBridge(act,wb), C=new NetBridge(act,wc);
    int port=47790;
    A.startHost(port,"Sala de Ana");
    check("hosted emitido", wait(wa,"hosted","\"port\":"+port,2000));
    A.connect("127.0.0.1",port);
    check("A open", wait(wa,"open","",2000));
    check("A welcome id=1 host=1", wait(wa,"msg","\"t\":\"welcome\",\"id\":1,\"host\":1",2000));
    A.send("{\"t\":\"hello\",\"name\":\"Ana \\\"la\\\" pingüino ñ\",\"cfg\":{}}");
    Thread.sleep(150);
    B.connect("127.0.0.1",port);
    check("B welcome id=2 host=1", wait(wb,"msg","\"t\":\"welcome\",\"id\":2,\"host\":1",2000));
    check("B recibe hello cacheado de A con f:1 (y unicode/escapes)", wait(wb,"msg","\"f\":1,\"t\":\"hello\",\"name\":\"Ana \\\"la\\\" pingüino ñ\"",2000));
    check("A recibe join de 2", wait(wa,"msg","\"t\":\"join\",\"id\":2",2000));
    B.send("{\"t\":\"hello\",\"name\":\"Beto\",\"cfg\":{}}");
    check("A recibe hello de B con f:2", wait(wa,"msg","\"f\":2,\"t\":\"hello\",\"name\":\"Beto\"",2000));
    // estado
    for(int i=0;i<200;i++){ A.send("{\"t\":\"s\",\"r\":\"p1\",\"u\":"+i+"}"); }
    check("B recibe estados de A", wait(wb,"msg","\"f\":1,\"t\":\"s\",\"r\":\"p1\",\"u\":150",3000));
    check("A no recibe eco de lo suyo", find(wa,"msg","\"f\":1,")==null);
    B.send("{\"t\":\"e\",\"ev\":[{\"k\":\"hit\"}]}");
    check("A recibe evento de B", wait(wa,"msg","\"f\":2,\"t\":\"e\"",2000));
    // discovery: C escucha y A (host) anuncia
    C.startDiscovery();
    boolean got=wait(wc,"rooms","Sala de Ana",5000);
    System.out.println("   rooms: "+find(wc,"rooms","Sala de Ana"));
    check("descubrimiento UDP encuentra la sala", got);
    C.stopDiscovery();
    // salida de B (no host)
    B.disconnect();
    check("A recibe leave de 2", wait(wa,"msg","\"t\":\"leave\",\"id\":2",2000));
    check("B no recibe 'close' tras desconectar a propósito", find(wb,"close","")==null);
    // B vuelve a entrar (id 3), luego sale el host: 3 pasa a ser host
    B.connect("127.0.0.1",port);
    check("B reentra id=3", wait(wb,"msg","\"t\":\"welcome\",\"id\":3",2000));
    A.disconnect();
    check("B recibe leave de 1", wait(wb,"msg","\"t\":\"leave\",\"id\":1",2000));
    check("B recibe host=3", wait(wb,"msg","\"t\":\"host\",\"id\":3",2000));
    // conexión a puerto cerrado -> error
    C.connect("127.0.0.1",1);
    check("error al conectar a puerto cerrado", wait(wc,"error","",3000));
    // stopHost cierra a B -> evento close
    A.stopHost();
    check("B recibe close al parar el servidor", wait(wb,"close","",3000));
    A.shutdown(); B.shutdown(); C.shutdown();
    System.out.println(fails==0?"TODO OK":fails+" FALLOS"); System.exit(fails==0?0:1);
  }
}
