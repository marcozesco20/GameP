const PG = require('../load')(['util.js', 'tracks.js']).PG;
const ids = process.argv[2] ? process.argv[2].split(',').map(Number) : null;
const out = [];
for (const d of PG.TRACKS) {
  if (ids && !ids.includes(d.id)) continue;
  const T = PG.buildTrack(d, { noMesh: true });
  const main = []; for (let i = 0; i < T.N; i += 3) main.push([T.px[i], T.pz[i]]);
  const br = T.branches.map(B => { const a = []; for (let i = 0; i <= B.Nb; i++) a.push([B.px[i], B.pz[i]]); return a; });
  const info = T.branches.map(B => `br${B.id} Lm=${(B.s1 - B.s0).toFixed(0)} Lb=${B.L.toFixed(0)} save=${(B.s1 - B.s0 - B.L).toFixed(0)} minGap=${B.minGap.toFixed(0)} j0=${B.j0} j1=${B.j1}/${B.Nb}`).join(' | ');
  let mn = 1e9, mx = -1e9, maxsl = 0; for (let i = 0; i <= T.N; i++) { mn = Math.min(mn, T.py[i]); mx = Math.max(mx, T.py[i]); maxsl = Math.max(maxsl, Math.abs(T.sl[i])); }
  console.error(d.id, d.name, 'L', T.L.toFixed(0), 'dy', (mx - mn).toFixed(0), 'maxsl', (maxsl * 100).toFixed(0) + '%', info, 'corners', (T.cornerS || []).map(x => x.toFixed(0)).join(','));
  out.push({ name: d.id + ' ' + d.name, main, br, L: T.L, info: '' });
}
require('fs').writeFileSync(process.argv[3] || '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/lay.json', JSON.stringify(out));
