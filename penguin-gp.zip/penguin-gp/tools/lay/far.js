const PG = require('../load')(['util.js', 'tracks.js']).PG;
for (const d of PG.TRACKS) { const T = PG.buildTrack(d, { noMesh: true });
  for (const B of T.branches) { let mg = 1e9, at=0; for (let i = B.j0 + 12; i <= B.j1 - 12; i++) for (let j = 0; j <= T.N; j++) { const dd = Math.hypot(T.px[j] - B.px[i], T.pz[j] - B.pz[i]); if (dd < mg) {mg = dd; at=i;} }
    console.log(d.id, 'br', B.id, 'min dist rows middle:', mg.toFixed(1), 'at row', at, 'of', B.Nb, ' sep at j0+12:', B.gap[B.j0+12].toFixed(0)); } }
