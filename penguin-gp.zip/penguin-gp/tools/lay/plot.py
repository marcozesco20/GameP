import json,sys,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
d=json.load(open(sys.argv[1])); out=sys.argv[2]
n=len(d); cols=3; rows=(n+cols-1)//cols
fig,axs=plt.subplots(rows,cols,figsize=(6*cols,5*rows)); import numpy as np
axs=np.array(axs).flatten()
for ax,t in zip(axs,d):
    m=t['main']; ax.plot([p[0] for p in m]+[m[0][0]],[p[1] for p in m]+[m[0][1]],'b-',lw=2)
    ax.plot(m[0][0],m[0][1],'go')
    for b in t.get('br',[]): ax.plot([p[0] for p in b],[p[1] for p in b],'r-',lw=2)
    ax.set_aspect('equal'); ax.set_title(t['name']+'  L=%d %s'%(t['L'],t.get('info','')),fontsize=9); ax.grid(True,alpha=.3)
plt.tight_layout(); plt.savefig(out,dpi=60)
