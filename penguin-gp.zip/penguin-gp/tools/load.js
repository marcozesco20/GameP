// Carga los scripts del juego en Node (sin DOM) para pruebas
const fs = require('fs'), vm = require('vm'), path = require('path');
module.exports = function (files) {
  const ctx = { console, Math, Date, Float32Array, Int8Array, Uint8Array, ArrayBuffer, Uint32Array, Int32Array, Uint16Array, Float64Array, JSON, Object, Array, Map, Set, isNaN, parseInt, parseFloat, setTimeout, clearTimeout };
  ctx.window = ctx; ctx.performance = { now: () => Date.now() };
  vm.createContext(ctx);
  for (const f of files) vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'web', 'js', f), 'utf8'), ctx, { filename: f });
  return ctx;
};
