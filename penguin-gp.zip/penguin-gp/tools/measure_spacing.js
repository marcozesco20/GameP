const ctx = require('./load')(['util.js', 'tracks.js']); const PG = ctx.PG;
const thr = +process.argv[2] || 30;
for (let tid = 0; tid < PG.TRACKS.length; tid++) {
  const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
  const ob = T.obs.filter(o => o.type !== 'icicle' && !T.inCave(o.s, 0)).slice().sort((a, b) => a.s - b.s);
  // grupos (filas): obstaculos a menos de 1 m en s
  const rows = []; ob.forEach(o => { const last = rows[rows.length - 1]; if (last && o.s - last.s1 < 1.5) { last.s1 = o.s; last.items.push(o); } else rows.push({ s0: o.s, s1: o.s, items: [o] }); });
  let close = 0, minGap = 1e9; const bad = [];
  for (let i = 1; i < rows.length; i++) { const g = rows[i].s0 - rows[i - 1].s1; if (g < minGap) minGap = g; if (g < thr) { close++; if (bad.length < 4) bad.push([Math.round(rows[i - 1].s1), Math.round(g)]); } }
  // anchura libre minima de cada fila (hueco entre obstaculos o bordes, descontando obstaculo y pinguino r=0.8)
  let minFree = 1e9;
  rows.forEach(r => { const ds = r.items.map(o => [o.d - o.r - 0.8, o.d + o.r + 0.8]).sort((a, b) => a[0] - b[0]); let x = -12.2, best = 0; ds.forEach(iv => { best = Math.max(best, iv[0] - x); x = Math.max(x, iv[1]); }); best = Math.max(best, 12.2 - x); if (r.items.length > 1 && best < minFree) minFree = best; });
  console.log(String(tid).padEnd(2), PG.TRACKS[tid].name.padEnd(26), 'filas', rows.length, 'obst', ob.length, 'min sep s', minGap.toFixed(1), 'm; filas a <' + thr + ' m:', close, JSON.stringify(bad), ' hueco libre min', minFree.toFixed(1));
}
