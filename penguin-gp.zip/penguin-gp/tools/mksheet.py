import sys
from PIL import Image
S='/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots/'
names=sys.argv[1].split(','); yaws=sys.argv[2].split(','); out=sys.argv[3]
w,h=400,300
m=Image.new('RGB',(w*len(yaws),h*len(names)))
for i,n in enumerate(names):
    for j,y in enumerate(yaws):
        m.paste(Image.open(S+f'cl_{n}_{y}.png').resize((w,h)),(j*w,i*h))
m.save(S+out)
