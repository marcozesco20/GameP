// Broker MQTT 3.1.1 minimo sobre WebSocket (solo para pruebas locales: QoS0, exacto y '+'/'#')
'use strict';
const http = require('http'), crypto = require('crypto');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function wsFrame(buf) {
  const n = buf.length; let head;
  if (n < 126) head = Buffer.from([0x82, n]); else if (n < 65536) head = Buffer.from([0x82, 126, n >> 8, n & 255]);
  else { head = Buffer.alloc(10); head[0] = 0x82; head[1] = 127; head.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([head, buf]);
}
function match(filter, topic) {
  const f = filter.split('/'), t = topic.split('/');
  for (let i = 0; i < f.length; i++) { if (f[i] === '#') return true; if (i >= t.length) return false; if (f[i] !== '+' && f[i] !== t[i]) return false; }
  return f.length === t.length;
}
function varLen(n) { const a = []; do { let b = n % 128; n = Math.floor(n / 128); if (n > 0) b |= 128; a.push(b); } while (n > 0); return Buffer.from(a); }
module.exports = function start(port, opts) {
  opts = opts || {};
  const subs = new Set(); let published = 0, delivered = 0, conns = 0;
  const server = http.createServer((req, res) => { res.writeHead(200); res.end('mock mqtt'); });
  function publish(topic, payload, exceptSock) {
    const tb = Buffer.from(topic), body = Buffer.concat([Buffer.from([tb.length >> 8, tb.length & 255]), tb, payload]);
    const pkt = Buffer.concat([Buffer.from([0x30]), varLen(body.length), body]);
    published++;
    for (const s of subs) for (const f of s.filters) if (match(f, topic)) { try { s.sock.write(wsFrame(pkt)); delivered++; } catch (e) { } break; }
  }
  server.on('upgrade', (req, sock) => {
    const key = req.headers['sec-websocket-key'];
    const proto = (req.headers['sec-websocket-protocol'] || '').split(',').map(x => x.trim()).includes('mqtt');
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + crypto.createHash('sha1').update(key + GUID).digest('base64') + '\r\n' + (proto ? 'Sec-WebSocket-Protocol: mqtt\r\n' : '') + '\r\n');
    sock.setNoDelay(true); conns++;
    const me = { sock, filters: [], will: null, clean: false }; subs.add(me);
    let wbuf = Buffer.alloc(0), mbuf = Buffer.alloc(0);
    function onPacket(first, body) {
      const type = first >> 4;
      if (type === 1) { // CONNECT
        let o = 0; const pl = body.readUInt16BE(o); o += 2 + pl; const lvl = body[o++]; const fl = body[o++]; o += 2;
        const cl = body.readUInt16BE(o); o += 2 + cl;
        if (fl & 4) { const tl = body.readUInt16BE(o); o += 2; const topic = body.slice(o, o + tl).toString(); o += tl; const ml = body.readUInt16BE(o); o += 2; me.will = { topic, payload: body.slice(o, o + ml) }; }
        if (opts.reject) { sock.write(wsFrame(Buffer.from([0x20, 2, 0, 5]))); return; }
        sock.write(wsFrame(Buffer.from([0x20, 2, 0, 0])));
      } else if (type === 8) { // SUBSCRIBE
        let o = 2; const rcs = [];
        while (o < body.length) { const tl = body.readUInt16BE(o); o += 2; me.filters.push(body.slice(o, o + tl).toString()); o += tl + 1; rcs.push(0); }
        sock.write(wsFrame(Buffer.concat([Buffer.from([0x90, 2 + rcs.length, body[0], body[1]]), Buffer.from(rcs)])));
      } else if (type === 3) { // PUBLISH
        const tl = body.readUInt16BE(0), topic = body.slice(2, 2 + tl).toString(); const qos = (first >> 1) & 3; const off = 2 + tl + (qos ? 2 : 0);
        publish(topic, body.slice(off), sock);
      } else if (type === 12) sock.write(wsFrame(Buffer.from([0xD0, 0])));
      else if (type === 14) { me.will = null; }
    }
    function drainMqtt() {
      for (;;) {
        if (mbuf.length < 2) return; let i = 1, mul = 1, len = 0, x;
        do { if (i >= mbuf.length) return; x = mbuf[i++]; len += (x & 127) * mul; mul *= 128; } while (x & 128);
        if (mbuf.length < i + len) return;
        const first = mbuf[0], body = mbuf.slice(i, i + len); mbuf = mbuf.slice(i + len); onPacket(first, body);
      }
    }
    sock.on('data', d => {
      wbuf = Buffer.concat([wbuf, d]);
      for (;;) {
        if (wbuf.length < 2) return; const op = wbuf[0] & 15; let len = wbuf[1] & 127, off = 2;
        if (len === 126) { if (wbuf.length < 4) return; len = wbuf.readUInt16BE(2); off = 4; } else if (len === 127) { if (wbuf.length < 10) return; len = Number(wbuf.readBigUInt64BE(2)); off = 10; }
        const masked = !!(wbuf[1] & 128); if (wbuf.length < off + (masked ? 4 : 0) + len) return;
        let payload; if (masked) { const mask = wbuf.slice(off, off + 4); payload = Buffer.from(wbuf.slice(off + 4, off + 4 + len)); for (let k = 0; k < len; k++) payload[k] ^= mask[k & 3]; off += 4; } else payload = wbuf.slice(off, off + len);
        wbuf = wbuf.slice(off + len);
        if (op === 8) { sock.end(); return; }
        if (op === 2) { // un paquete MQTT puede venir partido: acumular
          if (opts.fragment && payload.length > 3) { mbuf = Buffer.concat([mbuf, payload.slice(0, 3)]); drainMqtt(); mbuf = Buffer.concat([mbuf, payload.slice(3)]); } else mbuf = Buffer.concat([mbuf, payload]);
          drainMqtt();
        }
      }
    });
    const gone = () => { if (!subs.has(me)) return; subs.delete(me); if (me.will) { const w = me.will; me.will = null; publish(w.topic, w.payload); } };
    sock.on('close', gone); sock.on('error', gone);
  });
  return new Promise(res => server.listen(port, '127.0.0.1', () => res({ server, stats: () => ({ published, delivered, conns }), close: () => { for (const s of subs) s.sock.destroy(); server.close(); } })));
};
