const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 9), tag = process.argv[3] || 'm', n = +(process.argv[4] || 6);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 320 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.ava = false; PG.G.startSolo(t); }, tid);
  await page.waitForFunction((t) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === t, tid, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  const ms = await page.evaluate(() => PG.G.T.mountains.map(m => [m.x, m.z, m.r, m.h]));
  console.log(ms.length);
  for (let i = 0; i < Math.min(n, ms.length); i++) {
    await page.evaluate(([m, ang]) => {
      const G = PG.G, T = G.T; G.dbgCamFn = (cam) => {
        const y0 = T.centerY ? 0 : 0; let q = {}; T.nearest(m[0], m[1], q);
        const gy = q.y || 0;
        cam.eye[0] = m[0] + Math.cos(ang) * m[2] * 2.1; cam.eye[1] = gy + m[3] * 0.5; cam.eye[2] = m[1] + Math.sin(ang) * m[2] * 2.1;
        cam.target[0] = m[0]; cam.target[1] = gy + m[3] * 0.35; cam.target[2] = m[1]; cam.fov = 0.9; cam.roll = 0; };
    }, [ms[i], i * 1.3]);
    await page.waitForTimeout(1400);
    await page.screenshot({ path: `${OUT}/${tag}_${i}.png` });
  }
  console.log(errs.slice(0, 5)); await browser.close();
})();
