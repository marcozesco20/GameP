const ctx = require('./load')(['util.js', 'tracks.js', 'fbxdata.js', 'fbx.js', 'models.js', 'trackmesh.js', 'sim.js']);
const PG = ctx.PG;
const ids = process.argv[2] ? process.argv[2].split(',').map(Number) : [0, 2, 4, 7, 9];
for (const id of ids) {
  const T = PG.buildTrack(PG.TRACKS[id], {});
  let n = 0, tot = 0, big = 0;
  T.mesh.chunks.forEach((c, ci) => { const f = new Float32Array(c.buf); for (let k = 0; k < c.n; k++) { const o = k * 5; tot++; if (!isFinite(f[o]) || !isFinite(f[o + 1]) || !isFinite(f[o + 2])) { n++; if (n < 4) console.log(' nan vertex chunk', ci, 'k', k, f[o], f[o + 1], f[o + 2], 'bb', c.bb.map(v => Math.round(v))); } if (Math.abs(f[o]) > 1e5 || Math.abs(f[o+1]) > 1e5 || Math.abs(f[o+2]) > 1e5) big++; } });
  console.log(id, PG.TRACKS[id].name, 'vertices', tot, 'nan xyz', n, 'huge', big);
}
