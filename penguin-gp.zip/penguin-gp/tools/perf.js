// Prueba de rendimiento relativa (SwiftShader = GPU por CPU, sirve para comparar antes/despues): node perf.js [pistas] [calidad]
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks = (process.argv[2] || '0,12,13,14').split(',').map(Number), Q = +(process.argv[3] || 1);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: +(process.env.VW || 800), height: +(process.env.VH || 450) }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.addInitScript(() => {
    window.__ft = []; window.__ts = []; const raf = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (cb) => raf((t) => { const a = performance.now(); cb(t); window.__ft.push(performance.now() - a); window.__ts.push(t); });
  });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const ti of tracks) {
    const t0 = Date.now();
    await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 120000 });
    const loadMs = Date.now() - t0;
    await page.evaluate(() => { PG.G.goAt -= 8000; });
    const res = [];
    for (const fr of (process.env.FR || '0.08,0.3,0.55,0.8').split(',').map(Number)) {
      await page.evaluate((fr) => { const G = PG.G, r = G.me; const ti = G.tracksInfo[G.trackIdx]; r.u = fr * ti.len; r.safeU = r.u; r.vf = 0; G.R.dyn = 1; window.__ft.length = 0; window.__ts.length = 0; }, fr);
      await page.waitForTimeout(1500); await page.waitForFunction((NFR) => window.__ft.length >= NFR, +(process.env.NF || 40), { timeout: 120000 });
      const o = await page.evaluate(() => { const R = PG.G.R, ts = window.__ts.slice(-60), iv = []; for (let k = 1; k < ts.length; k++) iv.push(ts[k] - ts[k - 1]); iv.sort((a, b) => a - b); const f = window.__ft.slice(-60).sort((a, b) => a - b); return { ms: +(iv.reduce((s, x) => s + x, 0) / iv.length).toFixed(0), ms95: +iv[Math.floor(iv.length * 0.95)].toFixed(0), js: +(f.reduce((s, x) => s + x, 0) / f.length).toFixed(1), p95: +f[Math.floor(f.length * 0.95)].toFixed(1), n: window.__ft.length, drawn: R.drawn, culled: R.culled, kv: Math.round((R.verts || 0) / 1000), dyn: +R.dyn.toFixed(2), w: R.canvas.width }; });
      res.push(o);
    }
    console.log('pista', ti, 'carga', loadMs + 'ms', JSON.stringify(res));
  }
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
