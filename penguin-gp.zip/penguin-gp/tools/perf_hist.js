const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks = (process.argv[2] || '0,13,14').split(',').map(Number), Q = +(process.argv[3] || 1);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const ti of tracks) {
    await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 120000 });
    await page.evaluate(() => { PG.G.goAt -= 8000; });
    for (const fr of [0.1, 0.5]) {
      await page.evaluate((fr) => { const G = PG.G, r = G.me, ti = G.tracksInfo[G.trackIdx]; r.u = fr * ti.len; r.safeU = r.u; r.vf = 0; }, fr);
      await page.waitForTimeout(1500);
      const o = await page.evaluate(() => {
        const G = PG.G, R = G.R, th = R.env, eye = R.eye; const B = [0, 50, 100, 200, 300, 500, 700, 900, 1e9], hv = B.map(() => 0), hn = B.map(() => 0);
        let tv = 0;
        G.tmesh.chunks.forEach(c => { if (!R._visible(c.bb)) return; const bb = c.bb; const dx = Math.max(bb[0] - eye[0], 0, eye[0] - bb[3]), dy = Math.max(bb[1] - eye[1], 0, eye[1] - bb[4]), dz = Math.max(bb[2] - eye[2], 0, eye[2] - bb[5]); const d = Math.sqrt(dx * dx + dy * dy + dz * dz); tv += c.n; for (let k = 0; k < B.length - 1; k++) if (d >= B[k] && d < B[k + 1]) { hv[k] += c.n; hn[k]++; break; } });
        return { fogN: th.fogN, fogF: th.fogF, totalKV: Math.round(R.verts / 1000), trackKV: Math.round(tv / 1000), byDistKV: B.slice(0, -1).map((b, k) => b + '+:' + Math.round(hv[k] / 1000) + 'k/' + hn[k]).join(' ') };
      });
      console.log('pista', ti, 'fr', fr, JSON.stringify(o));
    }
  }
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
