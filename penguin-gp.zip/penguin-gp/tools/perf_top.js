const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tracks = (process.argv[2] || '0').split(',').map(Number), Q = +(process.argv[3] || 1), FR = (process.argv[4] || '0.1,0.5').split(',').map(Number);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const ti of tracks) {
    await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 120000 });
    await page.evaluate(() => { PG.G.goAt -= 8000; });
    for (const fr of FR) {
      await page.evaluate((fr) => { const G = PG.G, r = G.me, ti = G.tracksInfo[G.trackIdx]; r.u = fr * ti.len; r.safeU = r.u; r.vf = 0; }, fr);
      await page.waitForTimeout(2000);
      const o = await page.evaluate(() => new Promise(res => {
        const G = PG.G, R = G.R, orig = R.draw, st = new Map();
        R.draw = function (mesh, model, tint, alpha) {
          const b0 = R.verts, d0 = R.drawn; orig.call(this, mesh, model, tint, alpha);
          let e = st.get(mesh); if (!e) { e = { calls: 0, verts: 0, n: mesh.chunks.reduce((s, c) => s + c.n, 0), isTrack: mesh === G.tmesh, refl: R.inRefl }; st.set(mesh, e); }
          e.calls++; e.verts += R.verts - b0;
        };
        requestAnimationFrame(() => requestAnimationFrame(() => {
          R.draw = orig; const arr = [...st.values()].sort((a, b) => b.verts - a.verts).slice(0, 14);
          res({ total: Math.round(R.verts / 1000) + 'k', drawn: R.drawn, top: arr.map(e => `${e.isTrack ? 'TRACK ' : ''}calls=${e.calls} vertsDrawn=${Math.round(e.verts / 1000)}k meshVerts=${e.n}`) });
        }));
      }));
      console.log('pista', ti, 'fr', fr, o.total, 'drawn', o.drawn); o.top.forEach(t => console.log('   ', t));
    }
  }
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
