# post-proceso de las miniaturas: color, viñeta, degradado inferior, destello y marco de cristal (estilo Penguin Fort)
import sys, glob, os
from PIL import Image, ImageEnhance, ImageDraw, ImageFilter, ImageChops
RAW = sys.argv[1] if len(sys.argv) > 1 else '/tmp/thumbs_raw'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/penguin-gp/web/img/tracks'
for f in sorted(glob.glob(RAW + '/t*.png')):
    im = Image.open(f).convert('RGB')
    im = im.resize((640, 400), Image.LANCZOS)
    im = ImageEnhance.Color(im).enhance(1.18); im = ImageEnhance.Contrast(im).enhance(1.08)
    w, h = im.size
    # viñeta
    vg = Image.new('L', (w, h), 0); d = ImageDraw.Draw(vg); d.ellipse((-w*0.25, -h*0.3, w*1.25, h*1.3), fill=255); vg = vg.filter(ImageFilter.GaussianBlur(70))
    dark = Image.new('RGB', (w, h), (10, 30, 70)); im = Image.composite(im, Image.blend(im, dark, 0.55), vg)
    # degradado inferior azul profundo (para que el nombre de la pista se lea)
    grad = Image.new('L', (1, h)); 
    for y in range(h): grad.putpixel((0, y), int(max(0, (y - h*0.58) / (h*0.42)) ** 1.6 * 200))
    grad = grad.resize((w, h)); im = Image.composite(Image.new('RGB', (w, h), (8, 36, 96)), im, grad)
    # destello suave arriba a la izquierda
    glow = Image.new('RGB', (w, h), (0, 0, 0)); gd = ImageDraw.Draw(glow); gd.ellipse((-90, -120, 230, 140), fill=(120, 150, 190)); glow = glow.filter(ImageFilter.GaussianBlur(60)); im = ImageChops.screen(im, glow)
    # marco: borde blanco-azulado con esquinas redondeadas y cristales en las esquinas
    mask = Image.new('L', (w, h), 0); ImageDraw.Draw(mask).rounded_rectangle((0, 0, w-1, h-1), 26, fill=255)
    fr = Image.new('RGBA', (w, h), (0, 0, 0, 0)); fd = ImageDraw.Draw(fr)
    fd.rounded_rectangle((3, 3, w-4, h-4), 24, outline=(150, 215, 255, 255), width=6)
    fd.rounded_rectangle((9, 9, w-10, h-10), 19, outline=(255, 255, 255, 150), width=2)
    for (cx, cy, s) in [(w-34, h-30, 1), (34, h-30, -1)]:
        for k, (dx, dy, hh) in enumerate([(0, 0, 34), (13*s, 6, 24), (-12*s, 8, 20)]):
            fd.polygon([(cx+dx-7, cy+dy), (cx+dx, cy+dy-hh), (cx+dx+7, cy+dy)], fill=(190, 235, 255, 235), outline=(255, 255, 255, 255))
    im = im.convert('RGBA'); im.alpha_composite(fr)
    out = Image.new('RGB', (w, h), (7, 30, 80)); out.paste(im.convert('RGB'), (0, 0), mask)
    i = os.path.basename(f)[:-4]
    out.save(OUT + '/' + i + '.jpg', quality=84)
    print('ok', i)
