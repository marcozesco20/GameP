// probe: cruzar de la pista principal a un ramal empujando hacia su lado; mide velocidad y golpes de pared
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const tid = +process.argv[2] || 0, T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
T.obs.length = 0; T.pads.length = 0; T.holes.length = 0;
if (!T.branches.length) { console.log('sin ramales'); process.exit(0); }
const res = []; globalThis.__p = 0;
for (let bi = 0; bi < T.branches.length; bi++) for (const sgn of [-1, 1]) for (const off of [20, 60]) {
  const B = T.branches[bi], race = new PG.Race(T, { seed: 3 }), me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  race.time = 0; const s = B.s0 + off; me.u = T.type === 'circuit' ? s : s - T.startS; me.vf = 38; me.d = 0; me.safeU = me.u - 30; me.grounded = true; me.gy = T.ground(s, 0, 0); me.py = me.gy + 0.05; me.psi = 0;
  let t = 0, walls = 0, v0 = 38, vmin = 99, crossed = false, tcross = -1;
  while (t < 6) { race.time += 1 / 60; t += 1 / 60; const steer = t < 2.5 ? sgn * 1 : 0; race.update(1 / 60, { steer, tuck: 1, brake: 0, boost: false, jump: false });
    for (const e of race.fxq) { if (e.k === 'wall') walls++; if (['fall','respawn','stumble','hit','land'].includes(e.k) && !globalThis.__p) { console.log('ev', e.k, t.toFixed(2)); } } race.fxq.length = 0; race.out.length = 0;
    vmin = Math.min(vmin, me.vf); if (me.br && !crossed) { crossed = true; tcross = t; } }
  res.push({ b: bi, sgn, off, crossed, tcross: +tcross.toFixed(2), walls, vmin: +vmin.toFixed(1), vEnd: +me.vf.toFixed(1) });
}
console.table(res);
