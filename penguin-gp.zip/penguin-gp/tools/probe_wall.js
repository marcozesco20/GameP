// uso: node probe_wall.js <pista> <d0> <steer> <vf>  -> evolucion de d, vf, py y techo
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const tid = +process.argv[2] || 0, d0 = +process.argv[3] || 9, st = +process.argv[4] || 0, v0 = +process.argv[5] || 52;
const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
const c = T.caves.filter(c => !c.tun)[0] || T.caves[0];
const race = new PG.Race(T, { seed: 3, avalanche: false });
race.addRacer({ id: 'me', name: 'Yo', own: true, local: true, slot: 0 });
const r = race.racers[0]; race.time = 0; race.nowMs = 0;
const sStart = c.s0 + 20;
r.u = T.type === 'circuit' ? sStart : sStart - T.startS; r.d = d0; r.vf = v0; r.psi = 0; r.py = T.ground(T.uToS(r.u), d0) + 0.2; r.vy = 0;
const dt = 1 / 60; let t = 0, out = [];
while (t < 6) { race.time = t; race.update(dt, { steer: st, tuck: 1 }); t += dt; race.fxq.length = 0; race.out.length = 0;
  if (Math.abs(t * 10 - Math.round(t * 10)) < dt && t < 2.1) out.push(`t=${t.toFixed(1)} d=${r.d.toFixed(1)} vf=${r.vf.toFixed(1)} vl=${r.vl.toFixed(1)} ceil=${r.onCeil} psi=${r.psi.toFixed(2)} hold=${(r.wallHold||0).toFixed(2)} roll=${r.bankRoll.toFixed(2)}`); }
console.log(out.join('\n'));
