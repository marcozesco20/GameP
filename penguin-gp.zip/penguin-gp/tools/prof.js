const { chromium } = require('/opt/node-tools/node_modules/playwright');
const ti = +(process.argv[2] || 13), Q = +(process.argv[3] || 1), FR = (process.argv[4] || '0.55').split(',').map(Number), SECS = +(process.argv[5] || 6);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
  await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 120000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Profiler.enable'); await cdp.send('Profiler.setSamplingInterval', { interval: 200 });
  for (const fr of FR) {
    await page.evaluate((fr) => { const G = PG.G, r = G.me, ti = G.tracksInfo[G.trackIdx]; r.u = fr * ti.len; r.safeU = r.u; r.vf = 0; }, fr);
    await page.waitForTimeout(1500);
    await cdp.send('Profiler.start'); await page.waitForTimeout(SECS * 1000);
    const { profile } = await cdp.send('Profiler.stop');
    const self = new Map(), byId = new Map(); profile.nodes.forEach(n => byId.set(n.id, n));
    const dt = profile.timeDeltas; let tot = 0;
    profile.samples.forEach((id, k) => { const n = byId.get(id), d = dt[k] || 0; tot += d; const cf = n.callFrame, key = (cf.functionName || '(anon)') + ' ' + cf.url.split('/').pop() + ':' + cf.lineNumber; self.set(key, (self.get(key) || 0) + d); });
    const arr = [...self.entries()].sort((a, b) => b[1] - a[1]).slice(0, 22);
    console.log('pista', ti, 'fr', fr, 'total ms', Math.round(tot / 1000));
    arr.forEach(([k, v]) => console.log('  ' + (v / 1000).toFixed(0).padStart(6) + 'ms ' + (100 * v / tot).toFixed(1).padStart(5) + '% ' + k));
  }
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
