// v4.8: perfil de CPU (solo JS): bucle manual y GL sin trabajo de GPU (drawArrays/clear vacios) para ver donde gasta la CPU del telefono
// uso: node prof2.js pista calidad frac cuadros   (por run_with_server.sh)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const ti = +(process.argv[2] || 13), Q = +(process.argv[3] || 1), FR = +(process.argv[4] || 0.55), N = +(process.argv[5] || 300);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--js-flags=--expose-gc','--enable-precise-memory-info'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message));
  await page.addInitScript(() => {
    let clock = 1000; performance.now = () => clock; const q = []; window.requestAnimationFrame = (cb) => { q.push(cb); return q.length; };
    window.__real = ((p) => () => p.call(performance))(Performance.prototype.now);
    for (const k of ['drawArrays', 'drawElements', 'clear']) { WebGLRenderingContext.prototype[k] = function () { }; }
    window.__step = (n) => { const a = []; for (let i = 0; i < n; i++) { clock += 16.667; const cbs = q.splice(0); const t0 = window.__real(); cbs.forEach(cb => cb(clock)); a.push(window.__real() - t0); } return a; };
  });
  await page.goto('http://localhost:8080/'); await page.waitForFunction(() => document.querySelector('#scrMain.show'), null, { timeout: 60000, polling: 100 });
  if (ti >= 0) {
    await page.evaluate(([i, q]) => { PG.G.set.ava = false; PG.G.set.quality = q; PG.G.startSolo(i); }, [ti, Q]);
    for (let k = 0; k < 400; k++) { const ok = await page.evaluate(() => { window.__step(3); return PG.G.mode === 'race' && !!PG.G.race && !!PG.G.R; }); if (ok) break; await page.waitForTimeout(50); }
    await page.evaluate((fr) => { window.__step(5); PG.G.goAt -= 9000; const G = PG.G, me = G.me, t = G.tracksInfo[G.trackIdx]; me.u = fr * t.len; me.safeU = me.u; }, FR);
  } else { await page.evaluate((q) => { PG.G.set.quality = q; PG.G.R.resize(q); window.__step(10); }, Q); }
  await page.evaluate(() => window.__step(60));
  const cdp = await page.context().newCDPSession(page); await cdp.send('Profiler.enable'); await cdp.send('Profiler.setSamplingInterval', { interval: 100 });
  await page.evaluate(() => { gc(); window.__h0 = performance.memory.usedJSHeapSize; });
  await cdp.send('Profiler.start'); await cdp.send('HeapProfiler.enable'); await cdp.send('HeapProfiler.startSampling', { samplingInterval: 256, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  const ms = await page.evaluate((n) => { const a = []; let alloc = 0, prev = performance.memory.usedJSHeapSize; for (let i = 0; i < n; i++) { a.push(window.__step(1)[0]); const h = performance.memory.usedJSHeapSize; if (h > prev) alloc += h - prev; prev = h; } window.__alloc = alloc; return a; }, N);
  const { profile } = await cdp.send('Profiler.stop'); const hp = (await cdp.send('HeapProfiler.stopSampling')).profile; { const m = new Map(); (function w(n) { const cf = n.callFrame; const key = (cf.functionName || '(anon)') + ' ' + cf.url.split('/').pop() + ':' + cf.lineNumber; m.set(key, (m.get(key) || 0) + n.selfSize); n.children.forEach(w); })(hp.head); console.log('--- asignaciones por funcion (KB/cuadro)'); [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 18).forEach(([k, v]) => console.log('  ' + (v / 1024 / N).toFixed(1).padStart(7) + ' ' + k)); }
  const heap = await page.evaluate(() => performance.memory.usedJSHeapSize - window.__h0);
  const sorted = ms.slice().sort((a, b) => a - b);
  const al = await page.evaluate(() => window.__alloc); console.log('asignacion aprox KB/cuadro', (al / 1024 / N).toFixed(1));
  console.log('frame JS ms: media', (ms.reduce((a, b) => a + b, 0) / ms.length).toFixed(2), 'p50', sorted[sorted.length >> 1].toFixed(2), 'p95', sorted[Math.floor(sorted.length * .95)].toFixed(2), 'max', sorted[sorted.length - 1].toFixed(2), '| heap +KB/cuadro', (heap / 1024 / N).toFixed(1));
  const self = new Map(), byId = new Map(); profile.nodes.forEach(n => byId.set(n.id, n));
  let tot = 0; profile.samples.forEach((id, k) => { const n = byId.get(id), d = profile.timeDeltas[k] || 0; tot += d; const cf = n.callFrame, key = (cf.functionName || '(anon)') + ' ' + cf.url.split('/').pop() + ':' + cf.lineNumber; self.set(key, (self.get(key) || 0) + d); });
  [...self.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25).forEach(([k, v]) => console.log('  ' + (v / 1000 / N).toFixed(3).padStart(7) + ' ms/cuadro ' + (100 * v / tot).toFixed(1).padStart(5) + '% ' + k));
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
