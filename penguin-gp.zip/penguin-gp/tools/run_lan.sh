#!/bin/bash
# uso: run_lan.sh test.js  -> levanta server/server.js (HTTP + WebSocket LAN) en 8080, ejecuta la prueba y lo apaga
cd /home/claude/penguin-gp && PORT=8080 node server/server.js >/dev/null 2>&1 &
SP=$!
sleep 1.5
cd /home/claude/penguin-gp/tools && node "$@"
RC=$?
kill $SP 2>/dev/null
exit $RC
