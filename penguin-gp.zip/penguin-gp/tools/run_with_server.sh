#!/bin/bash
# uso: run_with_server.sh script.js [args]  -> levanta el servidor estatico, ejecuta el script y lo apaga
cd /home/claude/penguin-gp/web && python3 -m http.server 8080 >/dev/null 2>&1 &
SP=$!
sleep 1
cd /home/claude/penguin-gp/tools && node "$@"
RC=$?
kill $SP 2>/dev/null
exit $RC
