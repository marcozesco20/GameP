#!/bin/bash
# uso: run_with_server.sh script.js [args]  -> levanta el servidor estatico, ejecuta el script y lo apaga
# (v4.7: antes el "&" abarcaba "cd && python" y al final se mataba solo el subshell: el servidor quedaba vivo y la siguiente prueba usaba el servidor viejo)
WEB=${WEB_ROOT:-/home/claude/penguin-gp/web}
for p in $(ps -eo pid,cmd | awk '/http\.server 8080/ && !/awk/ {print $1}'); do kill $p 2>/dev/null; done
(cd "$WEB" && exec python3 -m http.server 8080 >/dev/null 2>&1) &
SP=$!
sleep 1
cd /home/claude/penguin-gp/tools && node "$@"
RC=$?
kill $SP 2>/dev/null
exit $RC
