// Pruebas visuales con Chrome headless (WebGL por software)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const path = require('path');
const OUT = process.env.OUT || '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const URL = process.env.URL || 'http://localhost:8080/';
(async () => {
  const browser = await chromium.launch({
    executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl', '--disable-gpu-sandbox']
  });
  const ctx = await browser.newContext({ viewport: { width: 1376, height: 768 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto(URL);
  await page.waitForFunction(() => document.querySelector('#scrMain.show') || document.querySelector('#loadTxt').textContent.startsWith('Error'), null, { timeout: 60000 });
  console.log('load text:', await page.textContent('#loadTxt'));
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '/01_menu.png' });
  const steps = (process.env.STEPS || 'menu,custom,tracks,race').split(',');
  if (steps.includes('custom')) {
    await page.click('[data-act=custom]'); await page.waitForTimeout(1500);
    await page.screenshot({ path: OUT + '/02_custom.png' });
    await page.click('#scrCustom [data-act=back]'); 
  }
  if (steps.includes('tracks')) {
    await page.click('[data-act=solo]'); await page.waitForTimeout(800);
    await page.screenshot({ path: OUT + '/03_tracks.png' });
  }
  if (steps.includes('race')) {
    const idx = +(process.env.TRACK || 0);
    await page.evaluate((i) => PG.G.startSolo(i), idx);
    await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
    await page.waitForTimeout(2500);
    await page.screenshot({ path: OUT + '/04_grid.png' });
    // adelantar el reloj hasta la salida
    await page.evaluate(() => { PG.G.goAt -= 4600; });
    await page.waitForTimeout(6000);
    await page.screenshot({ path: OUT + '/05_race1.png' });
    const st = await page.evaluate(() => { const r = PG.G.me; return { t: PG.G.race.time.toFixed(1), u: r.u.toFixed(1), vf: r.vf.toFixed(1), rank: r.rank, fps: PG.G.frames }; });
    console.log('state', JSON.stringify(st));
  }
  console.log('console errors:', errors.length ? '\n' + errors.slice(0, 15).join('\n') : 'none');
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
