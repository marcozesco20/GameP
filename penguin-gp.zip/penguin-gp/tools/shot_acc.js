// hoja de contacto de accesorios en pose de pie (personalizacion): node shot_acc.js tag
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'acc';
const LIST = [['hat', 1], ['hat', 2], ['hat', 3], ['hat', 4], ['hat', 5], ['hat', 6], ['hat', 7], ['glasses', 1], ['glasses', 2], ['glasses', 3], ['scarf', 1], ['scarf', 2], ['scarf', 3], ['outfit', 1], ['outfit', 2], ['outfit', 3]];
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  const base = await page.evaluate(() => { const T = PG.G.T; return T.q(T.startS + 6).yaw; });
  for (const [k, v] of LIST) {
    await page.evaluate(([k, v]) => { const c = PG.G.cfg; c.hat = 0; c.glasses = 0; c.scarf = 0; c.outfit = 0; c[k] = v; }, [k, v]);
    for (const y of [2, 3, 1]) {
      await page.evaluate((y) => { PG.G.dbgStandYaw = y; }, base + y * Math.PI / 2);
      await page.waitForTimeout(700);
      await page.screenshot({ path: `${OUT}/${tag}_${k}${v}_y${y}.png`, clip: { x: 130, y: 70, width: 260, height: 270 } });
    }
  }
  console.log(errs); await browser.close();
})();
