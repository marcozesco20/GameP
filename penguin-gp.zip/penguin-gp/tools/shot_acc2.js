// primer plano de accesorios en pose de pie: node shot_acc2.js tag "hat:1,glasses:2" "yawMult,..."
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'z';
const LIST = (process.argv[3] || 'hat:0').split(',').map(s => s.split(':'));
const YAWS = (process.argv[4] || '2,3').split(',').map(Number);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true, deviceScaleFactor: 2 })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  const base = await page.evaluate(() => { const T = PG.G.T; return T.q(T.startS + 6).yaw; });
  for (const [k, v] of LIST) {
    await page.evaluate(([k, v]) => { const c = PG.G.cfg; c.hat = 0; c.glasses = 0; c.scarf = 0; c.outfit = 0; c[k] = +v; }, [k, v]);
    for (const y of YAWS) {
      await page.evaluate((y) => { PG.G.dbgStandYaw = y; }, base + y * Math.PI / 2);
      await page.waitForTimeout(700);
      await page.screenshot({ path: `${OUT}/${tag}_${k}${v}_y${y}.png`, clip: { x: 150, y: 80, width: 220, height: 220 } });
    }
  }
  console.log(errs); await browser.close();
})();
