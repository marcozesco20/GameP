// hoja de accesorios del pinguino de pie: node shot_acc3.js tag '[{"glasses":1},...]'
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2], list = JSON.parse(process.argv[3]), scr = process.argv[4] || 'custom', auto = process.argv[5] === 'auto';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true, deviceScaleFactor: +(process.env.DSF || 2) })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=' + scr + ']'); await page.waitForTimeout(1200);
  const base = await page.evaluate(() => { const T = PG.G.T; return T.q(T.startS + 6).yaw; });
  let i = 0;
  for (const cfg of list) {
    await page.evaluate((c) => { Object.assign(PG.G.cfg, { hat: 0, glasses: 0, scarf: 0, outfit: 0 }, c); }, cfg);
    for (const k of [2, 3]) {
      if (!auto) await page.evaluate((y) => { PG.G.dbgStandYaw = y; }, base + k * Math.PI / 2);
      await page.waitForTimeout(700);
      await page.screenshot({ path: `${OUT}/${tag}_${i}_${k}.png`, clip: process.env.CLIP ? JSON.parse(process.env.CLIP) : { x: 110, y: 40, width: 280, height: 300 } });
    }
    i++;
  }
  console.log(errs); await browser.close();
})();
