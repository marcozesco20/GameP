// uso: node shot_at.js <pista> <expr-u|fork:N|cave:N> <nombre> [espera_ms] [vista]
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), where = process.argv[3] || 'fork:0', name = process.argv[4] || 'at', wait = +(process.argv[5] || 2500);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.text().slice(0, 200)); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate((where) => {
    const G = PG.G, T = G.T; G.goAt -= 6000; G.me.auto = true; G.me.ai = null;
    let u;
    const [k, v] = where.split(':');
    if (k === 'fork') { const B = T.branches[+v || 0]; u = B.s0 - 70 - T.startS; if (T.type === 'circuit') u = B.s0 - 70; }
    else if (k === 'cave') { const c = T.caves[+v || 0]; u = c.s0 + 60 - T.startS; }
    else u = +v;
    G.me.u = u; G.me.safeU = u; G.camInit = false;
  }, where);
  await page.waitForTimeout(wait);
  await page.screenshot({ path: OUT + '/' + name + '.png' });
  console.log('errors', errs); await browser.close();
})();
