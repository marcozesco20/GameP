const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate(() => { PG.G.dbgAva = true; PG.G.startSolo(1); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 4500; });
  await page.waitForTimeout(1500);
  const info = await page.evaluate(() => { const R = PG.G.race; return JSON.stringify(R.av); });
  console.log(info);
  const setT = async (t) => page.evaluate((t) => { PG.G.goAt = performance.now() - t * 1000; }, t);
  const av = JSON.parse(info);
  // aviso
  await setT(av.tW + 1.5); await page.waitForTimeout(800); await page.screenshot({ path: `${OUT}/av_warn.png` });
  // activa, jugador a 150 m del frente
  await page.evaluate((av) => { const G = PG.G, R = G.race, me = G.me; const t = R.time; const uF = R.avFront(av.tGo + 3); me.u = uF + 140; me.d = 0; me.safeU = me.u; me.py = G.T.centerY(G.T.uToS(me.u)) + 0.3; me.vf = 5; me.gy = me.py; G.camInit = false; G.race.racers.forEach(x => { if (x !== me) x.u = me.u + 30 + Math.random() * 40; }); }, av);
  await setT(av.tGo + 3); await page.waitForTimeout(900); await page.screenshot({ path: `${OUT}/av_far.png` });
  // cerca (35 m)
  await page.evaluate(() => { const G = PG.G, R = G.race, me = G.me; me.u = R.avFront(R.time) + 35; me.vf = 1; me.safeU = me.u; });
  await page.waitForTimeout(500); await page.screenshot({ path: `${OUT}/av_near.png` });
  // vista desde atras (espectador del frente): jugador parado se queda hasta ser alcanzado
  await page.evaluate(() => { const G = PG.G; G.dbgSeeFront = true; });
  await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/av_dead.png` });
  console.log(await page.evaluate(() => JSON.stringify({ dead: PG.G.me.dead, spec: document.getElementById('hud').className, specTxt: document.getElementById('specTxt').textContent })));
  await page.waitForTimeout(1200); await page.screenshot({ path: `${OUT}/av_dead2.png` });
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
