const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate(() => { PG.G.dbgAva = true; PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 4500; });
  await page.waitForTimeout(1200);
  const av = await page.evaluate(() => PG.G.race.av);
  await page.evaluate((av) => {
    const G = PG.G, R = G.race, T = G.T; G.goAt = performance.now() - (av.tGo + 4) * 1000; R.av.v = 0; R.av.acc = 0;
    const me = G.me; const uF = R.av.u0 + 0; me.u = uF + 40; me.d = 0; me.vf = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.gy = me.py; me.fx.ghost = 99; me.fx.boost = 0;
    R.racers.forEach(x => { if (x !== me) x.u = me.u + 200; });
    G.dbgCamFn = (cam) => { const q = T.q(T.uToS(uF + 18)); const x = q.x, z = q.z, y = T.centerY(T.uToS(uF + 18));
      cam.eye[0] = x + Math.sin(q.yaw) * 40 * 1; cam.eye[1] = y + 7; cam.eye[2] = z + Math.cos(q.yaw) * 40; cam.target[0] = x - Math.sin(q.yaw) * 10; cam.target[1] = y + 5; cam.target[2] = z - Math.cos(q.yaw) * 10; cam.fov = 1.0; cam.roll = 0; };
  }, av);
  await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/av_wall.png` });
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
