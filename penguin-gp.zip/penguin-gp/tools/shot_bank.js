const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(8));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  for (const side of [1, -1]) {
    await page.evaluate((side) => { const G = PG.G, T = G.T, me = G.me, c = T.caves[0]; const s = (c.s0 + c.s1) / 2; me.u = s - T.startS; me.d = side * 10.3; me.vf = 38; me.vl = side * 6; me.psi = 0; me.py = T.ground(s, me.d) + 0.2; me.vy = 0; G.camInit = false; window._side = side; G.race.racers.forEach(x => { if (x !== me) x.u = me.u - 200; }); }, side);
    await page.waitForTimeout(700); await page.evaluate((side) => { const me = PG.G.me; me.d = side * 10.3; me.vl = side * 4; }, side); await page.waitForTimeout(150);
    const st = await page.evaluate(() => { const me = PG.G.me; return { d: +me.d.toFixed(2), roll: +me.bankRoll.toFixed(2), py: +me.py.toFixed(2) }; });
    console.log(side, JSON.stringify(st));
    await page.screenshot({ path: `${OUT}/bank_${side > 0 ? 'R' : 'L'}.png` });
  }
  console.log('errors', errs);
  await browser.close();
})();
