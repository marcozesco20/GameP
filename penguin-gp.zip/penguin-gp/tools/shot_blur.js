// Vision borrosa de velocidad en GPU: capturas con y sin efecto, calidades 1 (lite) y 2 (completa)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = process.env.OUT || '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (/error|warn/i.test(m.type()) ) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.set.quality = 1; PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 120000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; const G = PG.G, me = G.me, ti = G.tracksInfo[G.trackIdx]; me.u = 0.3 * ti.len; me.safeU = me.u; });
  for (const q of [1, 2]) {
    await page.evaluate((q) => { const G = PG.G, R = G.R; G.set.quality = q; PG.penguinHi = q >= 1; R.aa = false; R.blurFx = true; R.resize(q); window.__beg = R.begin; R.begin = function (a, b, c) { this.blurK = window.__bk || 0; return window.__beg.call(this, a, b, c); }; }, q);
    for (const bk of [0, 1]) {
      await page.evaluate((bk) => { window.__bk = bk; PG.G.me.u = 0.3 * PG.G.tracksInfo[PG.G.trackIdx].len; PG.G.me.safeU = PG.G.me.u; PG.G.me.vf = 0; }, bk);
      await page.waitForTimeout(2500);
      const info = await page.evaluate(() => ({ eng: PG.G.R.engineBlur, full: PG.G.R.ppFull, ppOn: PG.G.R.ppOn, hasPp: !!PG.G.R.pp, bk: window.__bk }));
      console.log('q', q, 'bk', bk, JSON.stringify(info));
      await page.screenshot({ path: `${OUT}/blur_q${q}_b${bk}.png` });
    }
    await page.evaluate(() => { PG.G.R.begin = window.__beg; });
  }
  console.log('errores', JSON.stringify(errs.slice(0, 6)));
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
