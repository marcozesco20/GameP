const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('ERR', e.message));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.set.quality = 1; PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 120000 });
  await page.evaluate(() => { const G = PG.G, R = G.R; G.goAt -= 8000; const me = G.me, ti = G.tracksInfo[G.trackIdx]; me.u = 0.3 * ti.len; me.safeU = me.u; R.aa = false; R.blurFx = true; R.resize(1); window.__beg = R.begin; R.begin = function (a, b, c) { this.blurK = window.__bk; return window.__beg.call(this, a, b, c); }; window.__bk = 0.0031; });
  await page.waitForTimeout(2500); await page.evaluate(() => { PG.G.paused = true; }); await page.waitForTimeout(2500);
  for (const [nm, bk] of [['a', 0.0031], ['b', 1]]) {
    await page.evaluate((bk) => { window.__bk = bk; }, bk); await page.waitForTimeout(1500);
    const url = await page.evaluate(() => new Promise(res => { requestAnimationFrame(() => requestAnimationFrame(() => res(PG.G.R.canvas.toDataURL('image/png')))); }));
    fs.writeFileSync(`${OUT}/bl_${nm}.png`, Buffer.from(url.split(',')[1], 'base64'));
  }
  await browser.close();
})();
