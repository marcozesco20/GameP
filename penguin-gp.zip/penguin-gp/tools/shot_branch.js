const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tracks = (process.argv[2] || '0').split(',').map(Number);
const only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const ti of tracks) {
    await page.evaluate((i) => { PG.G.set.ava = false; PG.G.startSolo(i); }, ti);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 90000 });
    await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
    await page.waitForTimeout(500);
    const shots = [['pre', 'main', -45, 7], ['fork', 'main', 22, 10], ['fork2', 'main', 50, 0], ['mid', 'br', 0.30, 0], ['salto', 'br', 0.42, 0], ['merge', 'br', 0.93, 0], ['merge2', 'main', 'mrg', 0], ['aereo', 'air', 0, 0], ['aereo2', 'air2', 0, 0]];
    for (const [name, mode, a, d] of shots) {
      if (only && !only.includes(name)) continue;
      await page.evaluate(([mode, a, d]) => {
        const G = PG.G, T = G.T, me = G.me, B = T.branches[0]; G.dbgCamFn = null;
        let s, br = 0;
        if (mode === 'main') { s = typeof a === 'number' ? B.s0 + a : B.s1 - 40; }
        else if (mode === 'br') { s = B.s0 + (B.s1 - B.s0) * a; br = 1; }
        else s = B.s0 + 120;
        if (mode === 'br' && a > 0.4 && a < 0.5) s = B.hole.s0 - 30;
        me.br = br; me.u = s; me.d = d; me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = me.u; me.py = T.centerY(s, br) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
        G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 90; x.br = 0; } });
        if (mode === 'air' || mode === 'air2') {
          const q0 = T.q(B.s0 + (B.s1 - B.s0) * 0.5, 1), qa = { x: q0.x, y: q0.y, z: q0.z };
          const hgh = mode === 'air' ? 330 : 190;
          G.dbgCamFn = (cam) => { const f0 = mode === 'air' ? 0 : 1; const ft = T.q(B.s0 + 40, 0); const tx = f0 ? ft.x : qa.x, tz = f0 ? ft.z : qa.z; cam.eye[0] = tx + 2; cam.eye[1] = qa.y + hgh; cam.eye[2] = tz - 25; cam.target[0] = tx; cam.target[1] = qa.y; cam.target[2] = tz; cam.fov = 1.0; cam.roll = 0; };
        }
      }, [mode, a, d]);
      await page.waitForTimeout(1100);
      await page.screenshot({ path: `${OUT}/br_${ti}_${name}.png` });
    }
  }
  console.log(errs.slice(0, 6)); await browser.close();
})();
