// vista aerea de un atajo: node shot_branch2.js pista rama nombre
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), bi = +(process.argv[3] || 0), name = process.argv[4] || 'br2', frac = +(process.argv[5] || 0.5), back = +(process.argv[6] || 60);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const info = await page.evaluate(([bi, frac, back]) => {
    const G = PG.G, T = G.T, B = T.branches[bi]; G.goAt -= 3000; G.me.u = 5;
    const j = Math.round(B.Nb * frac), j2 = Math.min(B.Nb, j + 14), j1 = Math.max(0, j - 10);
    // vista lateral desde la pista principal hacia el atajo
    const im = Math.min(T.N, B.i0 + j), e = [T.px[im] - T.rx[im] * B.side * 10, T.py[im] + 4, T.pz[im] - T.rz[im] * B.side * 10], t = [B.px[j], B.py[j] + 1, B.pz[j]];
    G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.1; cam.roll = 0; };
    let mx = -1e9; for (let i = 0; i <= B.Nb; i++) mx = Math.max(mx, B.py[i] - T.py[Math.min(T.N, B.i0 + i)]);
    return 'Nb ' + B.Nb + ' maxLiftVsMain ' + mx.toFixed(1);
  }, [bi, frac, back]);
  await page.waitForTimeout(2500);
  await page.screenshot({ path: OUT + '/' + name + '.png' });
  console.log(info, errs); await browser.close();
})();
