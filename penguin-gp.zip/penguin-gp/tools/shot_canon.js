const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 3), us = (process.argv[3] || '30,500,1000,1800,2600').split(',').map(Number);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  for (const u of us) {
    await page.evaluate((u) => {
      const G = PG.G, T = G.T; G.goAt -= 6000; G.me.auto = true; G.me.ai = null; G.me.u = u; G.me.safeU = u; G.me.vf = 5;
      var ss = T.type === 'circuit' ? u : u + T.startS; G.me.d = 0; G.me.py = T.centerY(ss) + 0.2; G.me.gy = G.me.py; G.me.grounded = true;
      const i = Math.max(0, Math.min(T.N, Math.round(ss / T.ds))), j = Math.min(T.N, i + 12);
      const e = [T.px[i] , T.py[i] + 14, T.pz[i]], t = [T.px[j], T.py[j] + 2, T.pz[j]];
      // atras y arriba
      const dx = t[0] - e[0], dz = t[2] - e[2], L = Math.hypot(dx, dz) || 1; e[0] -= dx / L * 30; e[2] -= dz / L * 30;
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.1; cam.roll = 0; };
    }, u);
    await page.waitForTimeout(1800);
    await page.screenshot({ path: `${OUT}/cn_${tid}_${u}.png` });
  }
  console.log('errors', errs); await browser.close();
})();
