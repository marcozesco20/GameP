const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const W = +(process.argv[2] || 800), H = +(process.argv[3] || 360);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: W, height: H }, hasTouch: true, deviceScaleFactor: 2 })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=solo]'); await page.waitForTimeout(900);
  await page.screenshot({ path: `${OUT}/car_${W}_a.png` });
  await page.click('#carNext'); await page.waitForTimeout(150); await page.click('#carNext'); await page.waitForTimeout(700);
  await page.screenshot({ path: `${OUT}/car_${W}_b.png` });
  console.log('sel', await page.evaluate(() => PG.G.selTrack), errs);
  await browser.close();
})();
