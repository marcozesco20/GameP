const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const idx = +(process.env.TRACK || 1), ci = +(process.env.CAVE || 0), back = +(process.env.BACK || 40);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), idx);
  await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, idx, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  const info = await page.evaluate(([ci, back]) => {
    const T = PG.G.T, r = PG.G.me, c = T.caves[ci];
    const target = c.s0 - back;
    r.u = (T.type === 'circuit' ? target : target - T.startS); r.d = 0; r.psi = 0; r.vf = 30; r.vl = 0; r.safeU = r.u; r.py = T.centerY(T.uToS(r.u)) + 0.3; r.gy = r.py; r.vy = 0;
    PG.G.race.racers.forEach(x => { if (x !== r) x.u = r.u - 80 - Math.random() * 20; });
    return { caves: T.caves.length, len: c.s1 - c.s0 };
  }, [ci, back]);
  console.log(JSON.stringify(info));
  for (let k = 0; k < 4; k++) { await page.waitForTimeout(900); await page.screenshot({ path: `${OUT}/cave${idx}_${k}.png` }); }
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
