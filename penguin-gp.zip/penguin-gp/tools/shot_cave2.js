const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 1);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { const G = PG.G; G.goAt -= 6000; G.me.auto = true; G.me.ai = null; const c = G.T.caves[0]; G.me.u = c.s0 + 60 - G.T.startS; G.me.safeU = G.me.u; G.camInit = false; });
  for (let i = 0; i < 25; i++) { await page.waitForTimeout(250); await page.evaluate(() => { PG.G.me.vf = Math.max(PG.G.me.vf, 38); }); }
  await page.screenshot({ path: OUT + '/cave2_' + tid + '.png' });
  console.log('spd', await page.evaluate(() => PG.G.me.speed * 3.6), errs); await browser.close();
})();
