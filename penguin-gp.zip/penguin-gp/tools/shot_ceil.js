const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 8);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { const G = PG.G; G.goAt -= 6000; const c = G.T.caves.filter(c => !c.tun)[0] || G.T.caves[0]; G.me.u = c.s0 + 20 - G.T.startS; G.me.d = 0; G.me.vf = 50; G.me.safeU = G.me.u; G.me.py = G.T.ground(G.T.uToS(G.me.u), 0) + 0.2; G.me.vy = 0; G.dbgInp = { steer: (G.T.id % 2 ? -0.3 : 0.3), tuck: 1 }; G.camInit = false; G.race.racers.forEach(r => { if (r !== G.me) r.u -= 400; }); });
  let n = 0;
  for (let i = 0; i < 120; i++) {
    await page.waitForTimeout(250);
    const st = await page.evaluate(() => { const m = PG.G.me; return { on: m.onCeil, k: +m.ceilK.toFixed(2), vf: +m.vf.toFixed(1), d: +m.d.toFixed(1), py: +(m.py - m.gy).toFixed(1), br: +m.bankRoll.toFixed(2) }; });
    if (i % 4 === 0 && n === 0) console.log(i, JSON.stringify(st));
    if (st.on && n === 0) { await page.evaluate(() => { PG.G.dbgInp.steer = 0; }); n = 1; }
    if (n >= 1) { console.log(JSON.stringify(st)); if (n <= 7 && (st.k >= 0.2 || n > 1)) { await page.screenshot({ path: OUT + `/ceil_${tid}_${n}.png` }); n++; } }
    if (n > 7) break;
    if (n >= 1 && !st.on && st.py < 1) { await page.screenshot({ path: OUT + `/ceil_${tid}_land.png` }); break; }
  }
  console.log('errors', errs.slice(0, 5)); await browser.close();
})();
