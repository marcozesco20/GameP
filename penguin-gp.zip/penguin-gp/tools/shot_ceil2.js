const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.nav = ['scrMain']; PG.G.startSolo(1); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; }); await page.waitForTimeout(500);
  await page.evaluate(() => {
    const G = PG.G, T = G.T, me = G.me, Cr = T.crys.find(c => c.ceil);
    me.auto = false; me.u = Cr.s - T.startS - 30; me.d = 0; me.vf = 45; me.vl = 0; me.py = T.ground(Cr.s - 30, 0); G.dbgHold = Cr.s;
    G.dbgCamFn = function (cam) { const f = (s) => { const q = T.q(s); return [q.x, T.centerY(s), q.z]; }; const a = f(Cr.s - 26), b = f(Cr.s + 20); cam.eye[0] = a[0]; cam.eye[1] = a[1] + 6; cam.eye[2] = a[2]; cam.target[0] = b[0]; cam.target[1] = b[1] + 14; cam.target[2] = b[2]; cam.fov = 1.2; cam.roll = 0; };
  });
  await page.waitForTimeout(600); await page.screenshot({ path: OUT + '/ceil_orb.png' });
  console.log(errs); await browser.close();
})();
