const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  for (const vp of [{ width: 860, height: 400 }, { width: 700, height: 340 }]) {
    const p = await (await browser.newContext({ viewport: vp, hasTouch: true })).newPage();
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.click('[data-act=solo]'); await p.waitForSelector('#scrTracks.show');
    await p.click('#segModeSolo button[data-m=c]'); await p.click('#btnTrackGo');
    await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
    await p.waitForTimeout(600); await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(500);
    await p.evaluate(() => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; R.racers.forEach((r, k) => { r.u = endU + 1 + k * 0.5; if (T.type === 'circuit') r.lap = R.laps; }); });
    await p.waitForSelector('#scrResults.show', { timeout: 40000 });
    await p.waitForFunction(() => PG.G.champ && PG.G.champ.rec[0], null, { timeout: 40000 }); await p.waitForTimeout(800);
    await p.screenshot({ path: OUT + '/chr_' + vp.height + '.png' });
  }
  await browser.close();
})();
