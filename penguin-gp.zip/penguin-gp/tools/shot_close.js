const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  await page.evaluate(() => { PG.G.dbgCannon = true; PG.G.dbgYaw = PG.G.dbgYaw; });
  for (const [name, yawOff, flip] of [['c1', 0.0, 0], ['c2', 1.2, 0], ['c3', 2.1, 2.2]]) {
    await page.evaluate(([y, f]) => { PG.G.dbgFlip = f; PG.G.dbgYaw = undefined; window.__yo = y; }, [yawOff, flip]);
    await page.waitForTimeout(1400);
    await page.screenshot({ path: OUT + '/' + name + '.png' });
  }
  await browser.close();
})();
