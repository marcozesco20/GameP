const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const sets = JSON.parse(process.argv[2] || '[]'); // [{name, cfg}]
const yaws = (process.argv[3] || '0,1.6,3.14').split(',').map(Number);
const slide = process.argv[4] === 'slide';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 400 }, deviceScaleFactor: 2, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  await page.evaluate(() => { document.getElementById('screens').style.visibility = 'hidden'; });
  for (const st of sets) {
    for (const y of yaws) {
      await page.evaluate(([cfg, y, slide]) => { Object.assign(PG.G.cfg, cfg); if (slide) PG.G.dbgYaw = y; else PG.G.dbgStandYaw = y; }, [st.cfg, y, slide]);
      await page.waitForTimeout(450);
      await page.screenshot({ path: `${OUT}/cl_${st.name}_${String(y).replace('.', '')}.png`, clip: { x: 150, y: 105, width: 200, height: 150 } });
    }
  }
  console.log('errors', errs); await browser.close();
})();
