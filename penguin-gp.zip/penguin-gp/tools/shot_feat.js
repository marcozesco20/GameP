const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1100, height: 540 } })).newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' && !/404|agent-proxy/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(0));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  // colocar al jugador justo antes de una caja y un cristal
  const info = await page.evaluate(() => {
    const T = PG.G.T, r = PG.G.me, B = T.boxes[0];
    r.u = (T.type === 'circuit' ? B.s : B.s - T.startS) - 22; r.d = B.d; r.psi = 0; r.vf = 14; r.safeU = r.u;
    PG.G.race.racers.forEach(x => { if (x !== r) x.u = r.u - 80; });
    return { s: B.s, d: B.d, crys: T.crys.length, boxes: T.boxes.length };
  });
  console.log(JSON.stringify(info));
  await sleep(1800);
  await page.screenshot({ path: OUT + 'f1_orbs.png'.replace('f1', '/f1') });
  const st = await page.evaluate(() => ({ drawn: PG.G.R.drawn, culled: PG.G.R.culled, dyn: PG.G.R.dyn, w: PG.G.R.canvas.width }));
  console.log('culling', JSON.stringify(st));
  // dar cañón y disparar
  await page.evaluate(() => { const r = PG.G.me; r.ability = 'cannon'; PG.G.race.racers.forEach(x => { if (x !== r) { x.u = r.u + 25 + Math.random() * 30; } }); });
  await page.keyboard.press('KeyQ');
  await sleep(600);
  await page.keyboard.down('KeyX');
  await sleep(1500);
  await page.screenshot({ path: OUT + '/f2_cannon.png' });
  const c1 = await page.evaluate(() => ({ proj: PG.G.race.proj.length, cannon: PG.G.me.fx.cannon.toFixed(1) }));
  console.log('cannon', JSON.stringify(c1));
  await page.keyboard.up('KeyX');
  // salto + voltereta
  await page.evaluate(() => { const r = PG.G.me; r.vf = 25; });
  await page.keyboard.down('KeyC'); await sleep(120); await page.keyboard.up('KeyC');
  await sleep(150);
  await page.keyboard.down('KeyC'); await sleep(100); await page.keyboard.up('KeyC');
  await sleep(250);
  await page.screenshot({ path: OUT + '/f3_flip.png' });
  const f = await page.evaluate(() => { const r = PG.G.me; return { grounded: r.grounded, flipping: r.flipping, acc: +r.flipAcc.toFixed(2), py: +(r.py - r.gy).toFixed(2) }; });
  console.log('flip', JSON.stringify(f));
  // ventisca forzada
  await page.evaluate(() => { PG.G.__wx && 0; });
  console.log('errors:', errors.length ? errors.slice(0, 8).join('\n') : 'none');
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
