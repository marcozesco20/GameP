// uso: node shot_free.js <pista> <nombre> "<s,d,h>" "<s,d,h>" [espera_ms] [fov]   (camara libre en coordenadas de pista: s a lo largo, d lateral, h sobre el eje)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), name = process.argv[3] || 'free', E = process.argv[4].split(',').map(Number), Tg = process.argv[5].split(',').map(Number), wait = +(process.argv[6] || 6000), fov = +(process.argv[7] || 1.05);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 200)); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(([E, Tg, fov]) => {
    const G = PG.G, T = G.T; G.goAt -= 6000;
    function P(s, d, h) { const i = Math.max(0, Math.min(T.N, Math.round(s / T.ds))); return [T.px[i] + T.rx[i] * d, T.py[i] + h, T.pz[i] + T.rz[i] * d]; }
    const e = P(E[0], E[1], E[2]), t = P(Tg[0], Tg[1], Tg[2]);
    G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = fov; cam.roll = 0; };
    G.me.u = 0;
  }, [E, Tg, fov]);
  await page.waitForTimeout(wait);
  await page.screenshot({ path: OUT + '/' + name + '.png' });
  console.log('errors', errs); await browser.close();
})();
