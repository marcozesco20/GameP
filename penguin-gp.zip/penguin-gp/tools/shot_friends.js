const { chromium } = require('/opt/node-tools/node_modules/playwright');
const start = require('./mockbroker');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const broker = await start(18835, {});
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true });
  await ctx.addInitScript(() => { localStorage.setItem('pg_broker', 'ws://127.0.0.1:18835/mqtt'); });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 }); await p.waitForTimeout(800);
  await p.screenshot({ path: OUT + '/menu_friends.png' });
  await p.click('[data-act=friends]'); await p.waitForSelector('#scrFriends.show'); await p.waitForTimeout(1500);
  await p.evaluate(() => { const F = PG.Friends; F.add('ABCDEA'); F.add('KLMNPB'); F.reqs.push({ c: 'QRSTU4', n: 'Marta' }); F.seen['ABCDEA'] = { off: false, t: Date.now(), n: 'Lucho', s: 0 }; F.seen['KLMNPB'] = { off: false, t: Date.now(), n: 'Pingu', s: 2 }; F.list[0].n = 'Lucho'; F.cb(); });
  await p.waitForTimeout(500); await p.screenshot({ path: OUT + '/friends.png' });
  await p.evaluate(() => { PG.Friends.invs.push({ c: 'ABCDEA', n: 'Lucho', r: 'K7M2Q', t: Date.now() }); });
  await p.waitForTimeout(2200); await p.screenshot({ path: OUT + '/friends_inv.png' });
  console.log(errs); await browser.close(); broker.close();
})();
