// uso: shot_fx.js etiqueta "js previo" espera_ms  -> captura en carrera con un efecto activado
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2], pre = process.argv[3] || '', waits = (process.argv[4] || '1500').split(',').map(Number), tid = +(process.env.TID || 1);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(([t, pre]) => { PG.G.set.quality = 2; eval(pre.split('@@')[0]); PG.G.startSolo(t); }, [tid, pre]);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate((pre) => { PG.G.goAt -= 3000; if (pre.includes('@@')) eval(pre.split('@@')[1]); }, pre);
  let k = 0;
  for (const w of waits) { await page.waitForTimeout(w); await page.screenshot({ path: `${OUT}/${tag}_${k++}.png` }); }
  console.log(errs); await browser.close();
})();
