const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  page.on('pageerror', e => console.log('ERR', String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  console.log(await page.evaluate(() => { PG.G.dbgCannon = true; return JSON.stringify(Object.keys(PG.G).filter(k => /dbg/.test(k))); }));
  let i = 0;
  for (const yaw of [0.3, 1.9, 4.0]) {
    await page.evaluate((y) => { PG.G.dbgYaw = y; PG.G.cfg.hat = 0; }, yaw);
    await page.waitForTimeout(700);
    await page.screenshot({ path: OUT + '/gun' + (i++) + '.png', clip: { x: 0, y: 0, width: 450, height: 450 } });
  }
  await browser.close();
})();
