// v4.9: captura del HUD en carrera (telefono horizontal) con cañon activo y equipo comprado
const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async()=>{
const SPD = +(process.argv[6] || 0), Q = +(process.argv[7] || 0), W = +(process.argv[2] || 844), H = +(process.argv[3] || 390), out = process.argv[4] || 'hud.png', gun = process.argv[5] || 'snow';
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:W,height:H}, hasTouch:true})).newPage();
page.on('pageerror', e=>console.log('PAGEERROR', e.message));
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
await page.evaluate((Q)=>{PG.G.set.ava=false; PG.G.set.quality=Q; PG.G.eq=['grenade','cannon','shield','missile']; PG.G.startSolo(3);}, Q);
await page.waitForFunction(()=>PG.G.mode==='race'&&PG.G.race&&PG.G.R,null,{timeout:120000,polling:100});
await page.evaluate(()=>{ PG.G.goAt -= 9000; }); await page.waitForTimeout(2500);
await page.evaluate((gun)=>{ const G=PG.G, me=G.me; me.ability='superjump'; me.abilityQ=['shield','ghost']; me.fx.cannon=6; me.gun=gun==='gren'?'gren':'snow'; me.gunT=8; if (gun==='none') me.fx.cannon=0; }, gun); await page.waitForTimeout(1200);
if (SPD) { await page.evaluate((v)=>{ setInterval(()=>{ const me=PG.G.me; me.vf=v; }, 16); }, SPD); await page.waitForTimeout(3000); }
await page.screenshot({path: out});
await browser.close(); })();
