const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const track = +(process.env.TRACK || 0);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), track);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  await page.waitForTimeout(3500);
  await page.screenshot({ path: OUT + '/hud1.png' });
  // dar habilidad y objeto y simular recogida
  await page.evaluate(() => { const me = PG.G.me; me.ability = 'cannon'; me.item = 'snow'; me.race = 0; PG.G.race.fxq.push({ k: 'abilityget', id: me.id, r: me, ability: 'cannon' }); });
  await page.waitForTimeout(450);
  await page.screenshot({ path: OUT + '/hud2.png' });
  await page.waitForTimeout(700);
  await page.screenshot({ path: OUT + '/hud3.png' });
  await page.evaluate(() => { const me = PG.G.me; me.fx.cannon = 8; });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '/hud4.png' });
  console.log('errors', errs.slice(0, 5));
  await browser.close();
})();
