const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(8));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  // sitúa al jugador dentro de la cueva, parado, mirando hacia un carambano; congela el tiempo en distintas fases
  const info = await page.evaluate(() => {
    const G = PG.G, T = G.T, me = G.me, c = T.caves[0];
    const ic = T.obs.filter(o => o.type === 'icicle' && o.s > c.s0 + 60 && o.s < c.s1 - 60)[0];
    const s = ic.s - 38; me.u = s - T.startS; me.d = ic.d; me.psi = 0; me.vf = 0; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.gy = me.py; me.vy = 0;
    G.race.racers.forEach(x => { if (x !== me) x.u = me.u - 90; });
    window._ic = ic; G.camInit = false;
    return { s: ic.s, d: ic.d, per: ic.per, ph: ic.ph };
  });
  console.log(JSON.stringify(info)); await page.waitForTimeout(2500);
  async function atPhase(tNorm, name) {
    // fija G.goAt para que race.time -> t con (t+ph)%per == tNorm
    await page.evaluate((tn) => { const G = PG.G, ic = window._ic; const base = Math.floor((G.race.time + ic.ph) / ic.per) * ic.per + 2 * ic.per; const t = base - ic.ph + tn; G.goAt = performance.now() - t * 1000; const me = G.me; me.u = ic.s - 38 - G.T.startS; me.vf = 0; me.py = me.gy; G.camInit = false; }, tNorm);
    await page.waitForTimeout(160); await page.screenshot({ path: `${OUT}/ice_${name}.png` });
  }
  const per = info.per;
  await atPhase(per - 3.0, 'hang'); await atPhase(per - 1.0, 'warn'); await atPhase(per - 0.30, 'fall'); await atPhase(per - 0.30 + 0.2, 'fall2'); await atPhase(0.2, 'shatter');
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
