const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '/ic_main.png' });
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  const tabs = await page.$$('#ctabs button');
  console.log('tabs', tabs.length);
  for (const [i, t] of tabs.entries()) { if (i >= 1 && i <= 4) { await t.click(); await page.waitForTimeout(500); await page.screenshot({ path: OUT + '/ic_cust' + i + '.png' }); } }
  await page.evaluate(() => PG.G.go ? PG.G.go('scrMain') : 0);
  console.log(errs.slice(0, 5)); await browser.close();
})();
