const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(800);
  const acts = process.argv.slice(2);
  let k = 0;
  for (const a of acts) {
    await page.evaluate(() => PG.G.go && PG.G.go('scrMain')); await page.waitForTimeout(300);
    await page.click(`[data-act=${a}]`); await page.waitForTimeout(1300);
    await page.screenshot({ path: OUT + '/ic2_' + a + '.png' });
  }
  const left = await page.evaluate(() => { const re = /[\u{1F300}-\u{1FAFF}☀-➿]/u; const out = []; const tw = document.createTreeWalker(document.body, 4); let n; while ((n = tw.nextNode())) { if (re.test(n.nodeValue) && !n.parentNode.closest('#chatLog,#chatPick,.stkPrev,.cm,script,style')) out.push(n.nodeValue.trim().slice(0, 30)); } return out; });
  console.log('emojis restantes', left);
  console.log(errs.slice(0, 5)); await browser.close();
})();
