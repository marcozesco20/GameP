const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 330 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { const d = document.createElement('div'); d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#12418f;display:flex;flex-wrap:wrap;gap:10px;padding:10px;align-content:flex-start'; Object.keys(PG.G.ICONS).forEach(k => { const c = document.createElement('div'); c.style.cssText = 'width:100px;height:100px;filter:drop-shadow(0 0 5px rgba(170,230,255,.85))'; c.innerHTML = PG.G.ICONS[k]; c.firstChild.style.cssText = 'width:100%;height:100%'; d.appendChild(c); }); document.body.appendChild(d); });
  await page.waitForTimeout(500); await page.screenshot({ path: OUT + '/iconsheet.png' }); await browser.close();
})();
