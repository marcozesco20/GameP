const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), bi = +(process.argv[3] || 0), tag = process.argv[4] || 'j';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1100, height: 560 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.quality = 1; PG.G.startSolo(t); }, tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const nb = await page.evaluate((bi) => PG.G.T.branches[bi].Nb, bi);
  const spots = [['a', 20], ['b', 34]];
  for (const [nm, j] of spots) {
    await page.evaluate(([bi, j]) => {
      const G = PG.G, T = G.T, B = T.branches[bi]; G.goAt -= 3000; G.me.u = 5;
      const im = Math.min(T.N, B.i0 + j), mx = (T.px[im] + B.px[j]) / 2, my = (T.py[im] + B.py[j]) / 2, mz = (T.pz[im] + B.pz[j]) / 2;
      const e = [mx - T.tx[im] * 20 - T.rx[im] * B.side * -14, my + 9, mz - T.tz[im] * 20 - T.rz[im] * B.side * -14], t = [mx + T.tx[im] * 6, my, mz + T.tz[im] * 6];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.1; cam.roll = 0; };
    }, [bi, j]);
    await page.waitForTimeout(1800);
    await page.screenshot({ path: `${OUT}/${tag}_${nm}.png` });
  }
  console.log(errs); await browser.close();
})();
