// uso: shot_junc3.js pista rama etiqueta  -> capturas con camara tipo juego en entrada y salida de la rama
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), bi = +(process.argv[3] || 0), tag = process.argv[4] || 'k', q = +(process.argv[5] || 2);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 960, height: 540 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(([t, q]) => { PG.G.set.quality = q; PG.G.startSolo(t); }, [tid, q]);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const info = await page.evaluate((bi) => { const B = PG.G.T.branches[bi]; return { i0: B.i0, j0: B.j0, j1: B.j1, Nb: B.Nb, side: B.side }; }, bi);
  const spots = [['in1', info.j0 - 14, 16], ['in2', info.j0 + 2, 14], ['in3', info.j0 + 12, 14], ['out1', info.j1 - 16, 14], ['out2', info.j1 - 2, 14], ['out3', info.j1 + 10, 14]];
  for (const [nm, j, back] of spots) {
    await page.evaluate(([bi, j, back]) => {
      const G = PG.G, T = G.T, B = T.branches[bi]; G.goAt -= 3000; G.me.u = 5;
      const im = Math.max(2, Math.min(T.N - 2, B.i0 + j)), ib = Math.max(0, Math.min(B.Nb, j));
      const e = [T.px[im] - T.tx[im] * back, T.py[im] + 5.5, T.pz[im] - T.tz[im] * back], t = [T.px[im] + T.tx[im] * 12, T.py[im] + 0.3, T.pz[im] + T.tz[im] * 12];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.0; cam.roll = 0; };
    }, [bi, j, back]);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/${tag}_${nm}.png` });
  }
  console.log(JSON.stringify(info), errs); await browser.close();
})();
