// uso: shot_junc4.js pista rama etiqueta -> vistas elevadas a lo largo de todo el atajo + montaje
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 0), bi = +(process.argv[3] || 0), tag = process.argv[4] || 'n', MAIN = process.argv[5] === 'main';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.quality = 1; PG.G.startSolo(t); }, tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const info = await page.evaluate((bi) => { const B = PG.G.T.branches[bi]; return { i0: B.i0, j0: B.j0, j1: B.j1, Nb: B.Nb, side: B.side }; }, bi);
  const js = [2, info.j0 - 8, info.j0 + 4, info.j0 + 20, info.j0 + 40, Math.round((info.j0 + info.j1) / 2), info.j1 - 40, info.j1 - 18, info.j1 - 4, info.j1 + 8, info.Nb - 6];
  let k = 0;
  for (const j of js) {
    await page.evaluate(([bi, j, MAIN]) => {
      const G = PG.G, T = G.T, B = T.branches[bi]; G.goAt -= 3000; G.me.u = 5;
      const jj = Math.max(0, Math.min(B.Nb, j)), im = ((B.i0 + jj) % T.N + T.N) % T.N;
      const S = MAIN ? { px: T.px, py: T.py, pz: T.pz, tx: T.tx, tz: T.tz, k: im } : { px: B.px, py: B.py, pz: B.pz, tx: B.tx, tz: B.tz, k: jj };
      const bx = S.px[S.k], bz = S.pz[S.k], by = S.py[S.k], tx = S.tx[S.k], tz = S.tz[S.k];
      const e = [bx - tx * 22, by + 13, bz - tz * 22], t = [bx + tx * 10, by, bz + tz * 10];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.0; cam.roll = 0; };
    }, [bi, j, MAIN]);
    await page.waitForTimeout(900);
    await page.screenshot({ path: `${OUT}/${tag}_${k++}.png` });
  }
  console.log(JSON.stringify(info), js.join(','), errs); await browser.close();
})();
