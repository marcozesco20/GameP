const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate(() => {
    const G = PG.G; G.myId = 1; G.hostId = 1; G.online = true; G.roomCode = 'K7M2Q'; G.mp = true;
    G.players = { 1: { id: 1, name: 'Marco', cfg: G.cfg }, 2: { id: 2, name: 'Frosty', cfg: PG.fixCfg({ body: 3 }) }, 3: { id: 3, name: 'Pebble', cfg: PG.fixCfg({ body: 5 }) } };
    document.querySelector('#scrMain').classList.remove('show');
    G.nav = ['scrMain']; document.getElementById('scrLobby').classList.add('show'); G.screen = 'scrLobby';
  });
  await page.evaluate(() => { PG.G.toast && 0; });
  await page.evaluate(() => { const ev = new Event('x'); });
  // render via onNetMsg welcome-like path: call exposed renderer through a lobby message
  await page.evaluate(() => { PG.G.onNetMsg({ t: 'lobby', track: 2, bots: true, diff: 1 }); });
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/lobby_a.png` });
  console.log('errors', errs, await page.evaluate(() => typeof PG.G.onNetMsg));
  await browser.close();
})();
