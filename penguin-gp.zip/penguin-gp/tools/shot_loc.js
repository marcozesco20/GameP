// uso: node shot_loc.js <pista> <tag> "<s,lat,h>;<s,lat,h>" ... cada vista = ojo -> objetivo en coords de pista (s absoluto, lateral, altura sobre la pista). s puede ser 'h+N' (desde inicio camara), 'c+N' (desde centro volcan)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +process.argv[2], tag = process.argv[3], views = process.argv.slice(4).map(v => v.split('>').map(p => p.split(',')));
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.ava = false; PG.G.startSolo(t); }, tid);
  await page.waitForFunction((t) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === t, tid, { timeout: 90000 });
  if (process.env.FOGOLD) await page.evaluate(() => { window.__fogOld = true; });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  let i = 0;
  for (const [e, t] of views) {
    await page.evaluate(([e, t]) => {
      const G = PG.G, T = G.T; const base = T.volcano ? T.volcano.sc : (T.lake ? T.lake.s0 : 0);
      const P = (p) => { const s = +p[0]; const q = T.q(base + s, 0); const x = q.x + q.rx * +p[1], z = q.z + q.rz * +p[1]; return [x, q.y + +p[2], z]; };
      const E = P(e), Tg = P(t);
      G.dbgCamFn = (cam) => { cam.eye[0] = E[0]; cam.eye[1] = E[1]; cam.eye[2] = E[2]; cam.target[0] = Tg[0]; cam.target[1] = Tg[1]; cam.target[2] = Tg[2]; cam.fov = 1.0; cam.roll = 0; };
      if (window.__fogOld) { T.theme.fogN = 120; T.theme.fogF = 560; T.theme.fog = [0.78, 0.9, 0.98]; } const me = G.me; me.u = base - 300; me.safeU = me.u; me.br = 0;
    }, [e, t]);
    await page.waitForTimeout(1600);
    await page.screenshot({ path: `${OUT}/${tag}_${i++}.png` });
  }
  console.log(errs.slice(0, 5)); await browser.close();
})();
