const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  for (const [w, h, tag] of [[1000, 460, 'land'], [420, 860, 'port']]) {
    const p = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true })).newPage();
    const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.screenshot({ path: `${OUT}/menu_main_${tag}.png` });
    await p.click('[data-act=solo]'); await p.waitForSelector('#scrTracks.show'); await p.waitForTimeout(600);
    await p.screenshot({ path: `${OUT}/menu_tracks_${tag}.png` });
    await p.click('[data-act=back]'); await p.click('[data-act=multi]'); await p.waitForSelector('#scrMulti.show'); await p.click('[data-act=tabLan]'); await p.waitForTimeout(300);
    await p.screenshot({ path: `${OUT}/menu_lan_${tag}.png` });
    console.log(tag, errs);
  }
  await browser.close();
})();
