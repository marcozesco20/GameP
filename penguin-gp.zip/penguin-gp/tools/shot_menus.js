// v4.8: capturas de menus (salir, atras arriba-izquierda, resultados) con NativeApp simulado
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = process.env.OUT || '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/menus';
require('fs').mkdirSync(OUT, { recursive: true });
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 844, height: 390 }, deviceScaleFactor: 1 })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR', e.message)); page.on('console', m => { if (m.type() === 'error') console.log('CONSOLE', m.text()); });
  await page.addInitScript(() => { window.NativeApp = { exit() { window.__exited = (window.__exited || 0) + 1; } }; });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(2500);
  await page.screenshot({ path: OUT + '/main.png' });
  const info = await page.evaluate(() => { const b = document.getElementById('btnExit'); const r = b.getBoundingClientRect(); return { disp: getComputedStyle(b).display, x: r.x, y: r.y, w: r.width, h: r.height, txt: b.textContent.trim() }; });
  console.log('exit', JSON.stringify(info));
  await page.click('#btnExit'); const t1 = await page.evaluate(() => document.querySelector('#btnExit span').textContent); await page.click('#btnExit'); console.log('2 toques ->', t1, 'exited=', await page.evaluate(() => window.__exited));
  for (const [act, id] of [['custom', 'scrCustom'], ['stats', 'scrStats']]) {
    await page.evaluate(() => document.querySelector('.screen.show') && 0);
    await page.click(`#scrMain [data-act="${act}"]`); await page.waitForTimeout(1500);
    const bb = await page.evaluate((id) => { const b = document.querySelector('#' + id + ' .backTL'); const r = b.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), vis: getComputedStyle(b).display }; }, id);
    console.log(id, 'atras', JSON.stringify(bb)); await page.screenshot({ path: OUT + '/' + id + '.png' });
    await page.click(`#${id} .backTL`); await page.waitForTimeout(600);
    console.log('  tras Atras ->', await page.evaluate(() => document.querySelector('.screen.show').id));
  }
  // resultados
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000, polling: 100 });
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '/race.png' });
  await page.evaluate(() => { PG.G.showResults(); });
  await page.waitForTimeout(1800); await page.screenshot({ path: OUT + '/results.png' });
  const rb = await page.evaluate(() => [...document.querySelectorAll('#scrResults .resBtns button')].filter(b => b.offsetParent).map(b => b.textContent.trim() + '@' + Math.round(b.getBoundingClientRect().x)));
  console.log('botones resultados:', rb.join(' | '));
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
