// montañas: para cada pista, camara en la pista mirando a la montaña mas cercana. node shot_mt.js [ids] -> shots/mt_<id>.png
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const ids = (process.argv[2] || '0,1,2,3,4,5,6,7,8,9,10,11').split(',').map(Number);
const S = +(process.argv[3] || 500);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 320 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const tid of ids) {
    await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
    await page.evaluate((t) => PG.G.startSolo(t), tid);
    await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
    const info = await page.evaluate((S) => {
      const G = PG.G, T = G.T; G.goAt -= 6000;
      const i = Math.max(0, Math.min(T.N, Math.round(S / T.ds)));
      const e = [T.px[i], T.py[i] + 8, T.pz[i]];
      let best = null, bd = 1e9; (T.mountains || []).forEach(m => { const d = Math.hypot(m.x - e[0], m.z - e[2]); if (d < bd) { bd = d; best = m; } });
      if (!best) return 'sin montañas';
      const t = [best.x, e[1] + best.h * 0.35, best.z];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.0; cam.roll = 0; };
      G.me.u = 0; return 'mt dist ' + bd.toFixed(0) + ' r ' + best.r.toFixed(0) + ' h ' + best.h.toFixed(0) + ' n=' + T.mountains.length;
    }, S);
    await page.waitForTimeout(3500);
    await page.screenshot({ path: `${OUT}/mt_${tid}.png` });
    console.log(tid, info);
  }
  console.log('errors', errs); await browser.close();
})();
