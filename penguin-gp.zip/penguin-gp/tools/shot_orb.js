const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1000, height: 500 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.R.resize(2); PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { const G = PG.G, T = G.T; G.goAt -= 5000; G.me.u = 3;
    const B = T.boxes[0], q = T.q(B.s, B.br), gy = T.ground(B.s, B.d, B.br), bx = q.x + q.rx * B.d, bz = q.z + q.rz * B.d;
    const e = [bx - Math.sin(q.yaw) * 7 + q.rx * 2.5, gy + 2.6, bz - Math.cos(q.yaw) * 7 + q.rz * 2.5], t = [bx, gy + 1.8, bz];
    G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 0.8; cam.roll = 0; }; });
  await page.waitForTimeout(2000);
  await page.screenshot({ path: OUT + '/orb.png' });
  console.log(errs); await browser.close();
})();
