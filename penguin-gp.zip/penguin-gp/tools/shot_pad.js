// uso: node shot_pad.js <pista> <tag> pad|fork [indice]
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +process.argv[2], tag = process.argv[3], kind = process.argv[4] || 'pad', idx = +(process.argv[5] || 0);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.ava = false; PG.G.startSolo(t); }, tid);
  await page.waitForFunction((t) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === t, tid, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  const info = await page.evaluate(([kind, idx]) => {
    const G = PG.G, T = G.T; let s0, br = 0, d = 0;
    if (kind === 'pad') { const p = T.pads.filter(q => !q.br)[idx]; s0 = p.s; d = (p.d0 + p.d1) / 2; }
    else { const B = T.branches[idx]; s0 = B.s0; }
    G.dbgCamFn = (cam) => { let q = T.q(s0 - (kind === 'pad' ? 12 : 50), 0); const ex = q.x + q.rx * d, ey = q.y + (kind === 'pad' ? 4 : 7), ez = q.z + q.rz * d; q = T.q(s0 + 12, 0); cam.eye[0] = ex; cam.eye[1] = ey; cam.eye[2] = ez; cam.target[0] = q.x + q.rx * d; cam.target[1] = q.y; cam.target[2] = q.z + q.rz * d; cam.fov = 1.0; cam.roll = 0; };
    G.dbgPadFrame = 2; const me = G.me; me.u = s0 - 300 - T.startS; me.safeU = me.u; me.br = 0; me.fx.ghost = 99;
    return { s0, nPads: T.pads.length };
  }, [kind, idx]);
  console.log(JSON.stringify(info));
  for (let i = 0; i < 3; i++) { await page.waitForTimeout(130); await page.screenshot({ path: `${OUT}/${tag}_${i}.png` }); }
  console.log(errs.slice(0, 6)); await browser.close();
})();
