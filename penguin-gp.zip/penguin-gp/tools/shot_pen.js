const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 450 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.click('[data-act=custom]'); await page.waitForTimeout(1500);
  const cfgs = process.argv.slice(2).map(s => JSON.parse(s));
  let i = 0;
  for (const c of (cfgs.length ? cfgs : [{}])) {
    await page.evaluate((c) => { Object.assign(PG.G.cfg, c); PG.G.dbgYaw = c.__yaw; delete PG.G.cfg.__yaw; }, c);
    await page.waitForTimeout(900);
    await page.screenshot({ path: OUT + '/pen' + (i++) + '.png' });
  }
  console.log('errors', errs.slice(0, 5));
  await browser.close();
})();
