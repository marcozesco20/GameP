const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'p';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=stats]'); await page.waitForTimeout(2500);
  await page.screenshot({ path: `${OUT}/${tag}_stats.png` });
  await page.click('#scrStats [data-act=back]'); await page.waitForTimeout(500);
  for (const hat of [1, 4, 2, 7]) {
    await page.evaluate((h) => { PG.G.cfg.hat = h; }, hat);
    await page.click('[data-act=custom]'); await page.waitForTimeout(2200);
    await page.screenshot({ path: `${OUT}/${tag}_cust_h${hat}.png` });
    await page.evaluate(() => { document.querySelector('#scrCustom [data-act=back]').click(); }); await page.waitForTimeout(500);
  }
  console.log(errs); await browser.close();
})();
