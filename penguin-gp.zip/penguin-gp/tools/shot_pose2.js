const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'q';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true, deviceScaleFactor: 2 })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  for (const [hat, yawOff] of [[0,0],[0,1.57],[1,3.14],[4,3.14],[2,3.14],[7,3.14]]) {
    await page.evaluate((a) => { PG.G.cfg.hat = a[0]; PG.G.dbgStandYaw = undefined; }, [hat]);
    await page.click('[data-act=custom]'); await page.waitForTimeout(800);
    await page.evaluate((o) => { PG.G.dbgStandYaw = (PG.G.T ? 0 : 0) + o; }, yawOff).catch(()=>{});
    await page.waitForTimeout(1600);
    await page.screenshot({ path: `${OUT}/${tag}_h${hat}_${yawOff}.png`, clip: { x: 100, y: 60, width: 340, height: 300 } });
    await page.evaluate(() => { document.querySelector('#scrCustom [data-act=back]').click(); }); await page.waitForTimeout(500);
  }
  console.log(errs); await browser.close();
})();
