const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'q', hat = +(process.argv[3]||0);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 420 }, hasTouch: true, deviceScaleFactor: 2 })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate((h) => { PG.G.cfg.hat = h; }, hat);
  await page.click('[data-act=custom]'); await page.waitForTimeout(1200);
  const base = await page.evaluate(() => { const T = PG.G.T; return T.q(T.startS + 6).yaw; });
  for (const k of [0,1,2,3]) {
    await page.evaluate((y) => { PG.G.dbgStandYaw = y; }, base + k * Math.PI / 2);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/${tag}_y${k}.png`, clip: { x: 130, y: 100, width: 260, height: 240 } });
  }
  console.log(errs); await browser.close();
})();
