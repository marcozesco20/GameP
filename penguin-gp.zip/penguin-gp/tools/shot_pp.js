const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  console.log('quality', await page.evaluate(() => PG.G.set.quality));
  for (const q of [2, 1]) {
    await page.evaluate((q) => { PG.G.set.quality = q; PG.G.R.resize(q); }, q);
    if (q === 2) { await page.evaluate(() => PG.G.startSolo(0)); await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 }); await page.evaluate(() => { PG.G.goAt -= 5000; PG.G.me.auto = true; }); await page.waitForTimeout(3500); }
    else await page.waitForTimeout(1200);
    console.log('q', q, 'ppOn', await page.evaluate(() => PG.G.R.ppOn));
    await page.screenshot({ path: `${OUT}/pp_q${q}.png` });
  }
  console.log('errors', errs); await browser.close();
})();
