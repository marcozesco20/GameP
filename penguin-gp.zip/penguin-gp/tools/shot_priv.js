const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  for (const [w, h, n] of [[800, 360, 'land'], [360, 740, 'port']]) {
    const page = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true })).newPage();
    await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(500);
    await page.click('.privLink'); await page.waitForTimeout(300);
    await page.screenshot({ path: `${OUT}/priv_${n}1.png` });
    console.log(n, await page.evaluate(() => { const b = document.querySelector('#scrPrivacy .setBody'); const c = document.querySelector('#scrPrivacy .card'); return JSON.stringify({ sh: b.scrollHeight, ch: b.clientHeight, cardW: c.getBoundingClientRect().width, bodyW: b.clientWidth, over: c.scrollWidth > c.clientWidth }); }));
    await page.evaluate(() => { document.querySelector('#scrPrivacy .setBody').scrollTop = 99999; }); await page.waitForTimeout(200);
    await page.screenshot({ path: `${OUT}/priv_${n}2.png` });
    await page.click('#scrPrivacy [data-act=back]'); await page.click('[data-act=settings]'); await page.waitForTimeout(300);
    await page.screenshot({ path: `${OUT}/set_${n}.png` });
    await page.close();
  }
  await browser.close();
})();
