const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tracks = (process.argv[2] || '0,1').split(',').map(Number);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const ti of tracks) {
    await page.evaluate((i) => { PG.G.set.ava = false; PG.G.startSolo(i); }, ti);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 90000 });
    await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
    await page.waitForTimeout(500);
    for (const [name, off, d] of [['entra', -16, 0], ['entra2', -26, 0], ['dentro', 40, null]]) {
      await page.evaluate(([off, d, ti]) => {
        const G = PG.G, T = G.T, me = G.me, R = T.routes[0];
        const s = R.s0 + off; me.u = T.type === 'circuit' ? s : s - T.startS; me.d = d === null ? R.lc : d; me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
        G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 80; } });
      }, [off, d, ti]);
      await page.waitForTimeout(900);
      await page.screenshot({ path: `${OUT}/route_${ti}_${name}.png` });
    }
  }
  console.log(errs.slice(0, 5)); await browser.close();
})();
