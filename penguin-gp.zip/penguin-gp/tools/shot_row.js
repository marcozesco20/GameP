// uso: shot_row.js pista etiqueta main|brN fila [fila...]  -> vista de juego en esas filas
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +process.argv[2], tag = process.argv[3], rd = process.argv[4], rows = process.argv.slice(5).map(Number);
const hgt = +(process.env.H || 4.5), back = +(process.env.BACK || 13);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.quality = 1; PG.G.startSolo(t); }, tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  let k = 0;
  for (const r of rows) {
    await page.evaluate(([rd, r, hgt, back]) => {
      const G = PG.G, T = G.T; G.goAt -= 3000; G.me.u = 5;
      const S = rd === 'main' ? T : T.branches[+rd.slice(2)], n = rd === 'main' ? T.N : S.Nb, i = Math.max(1, Math.min(n - 1, r));
      const x = S.px[i], y = S.py[i], z = S.pz[i], tx = S.tx[i], tz = S.tz[i];
      const e = [x - tx * back, y + hgt, z - tz * back], t = [x + tx * 12, y + 0.5, z + tz * 12];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.0; cam.roll = 0; };
    }, [rd, r, hgt, back]);
    await page.waitForTimeout(900);
    await page.screenshot({ path: `${OUT}/${tag}_${k++}.png` });
  }
  console.log(errs); await browser.close();
})();
