// corre con IA y toma capturas en tiempos: node shot_run.js pista t1,t2,t3 prefijo
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +(process.argv[2] || 3), ts = (process.argv[3] || '6,14,24').split(',').map(Number), pre = process.argv[4] || 'run';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 4500; PG.G.me.auto = true; });
  let last = 0;
  for (const t of ts) {
    await page.waitForFunction((t) => PG.G.race && PG.G.race.time >= t, t, { timeout: 120000 });
    if (process.env.HI) await page.evaluate((HI) => { const G = PG.G; G.dbgCamFn = function (cam) { const me = G.me, w = [0, 0, 0]; const a = PG.wposUD ? 0 : 0; const T = G.T; const f = (u) => { const ss = T.uToS(u), q = T.q(ss); return [q.x, T.centerY(ss), q.z]; }; const p0 = f(me.u - 22), p1 = f(me.u + 50); cam.eye[0] = p0[0]; cam.eye[1] = p0[1] + HI; cam.eye[2] = p0[2]; cam.target[0] = p1[0]; cam.target[1] = p1[1] + 3; cam.target[2] = p1[2]; cam.fov = 1.15; cam.roll = 0; }; }, +process.env.HI);
    if (process.env.HI) await page.waitForTimeout(500);
    await page.screenshot({ path: `${OUT}/${pre}_${tid}_${t}.png` });
  }
  console.log('errors', errs); await browser.close();
})();
