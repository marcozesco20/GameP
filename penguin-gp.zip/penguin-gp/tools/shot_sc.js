const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate(() => { PG.G.startSolo(4); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 4500; });
  await page.waitForTimeout(1200);
  for (const [name, off, d] of [['sc_a', 45, 0], ['sc_b', 14, 8.5]]) {
    await page.evaluate(([off, d]) => { const G = PG.G, T = G.T, me = G.me, sc = T.shortcuts[0]; me.u = sc.s0 - off - T.startS * (T.type === 'circuit' ? 0 : 1); me.d = d * (sc.side); me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false; G.race.racers.forEach(x => { if (x !== me) x.u = me.u - 60; }); }, [off, d]);
    await page.waitForTimeout(2200); await page.screenshot({ path: `${OUT}/${name}.png` });
  }
  // cruzar
  await page.evaluate(() => { const G = PG.G, me = G.me; me.vf = 25; me.fx.ghost = 0; });
  await page.waitForTimeout(250); await page.screenshot({ path: `${OUT}/sc_c.png` });
  await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/sc_d.png` });
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
