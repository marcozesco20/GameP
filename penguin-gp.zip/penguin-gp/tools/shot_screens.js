// capturas de pausa, resultados y multijugador. node shot_screens.js -> shots/sc_*.png
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.click('[data-act=multi]'); await p.waitForSelector('#scrMulti.show'); await p.waitForTimeout(500); await p.screenshot({ path: OUT + '/sc_multi.png' });
  await p.click('.screen.show [data-act=back]'); await p.waitForTimeout(300);
  await p.evaluate(() => PG.G.startSolo(0)); await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await p.evaluate(() => { PG.G.goAt -= 6000; }); await p.waitForTimeout(1500);
  await p.evaluate(() => { document.getElementById('btnPause').dispatchEvent(new PointerEvent('pointerdown')); }); await p.waitForTimeout(600); await p.screenshot({ path: OUT + '/sc_pause.png' });
  await p.evaluate(() => { document.querySelector('[data-act=resume]').click(); });
  await p.waitForTimeout(500);
  await p.evaluate(() => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; G.me.u = endU + 1; if (T.type === 'circuit') G.me.lap = R.laps; });
  await p.waitForSelector('#scrResults.show', { timeout: 40000 }); await p.waitForTimeout(2500); await p.screenshot({ path: OUT + '/sc_results.png' });
  console.log(errs); await browser.close();
})();
