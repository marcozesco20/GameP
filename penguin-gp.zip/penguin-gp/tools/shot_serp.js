const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(11); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === 11, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  console.log(await page.evaluate(() => 1));
  const shots = [['pre', -80], ['top', 40], ['mid', 200]];
  for (const [name, off, end] of shots) {
    await page.evaluate(([off, end]) => {
      const G = PG.G, T = G.T, me = G.me; G.dbgCamFn = null;
      const s = T.startS + 2650 + off; me.br = 0; me.u = s - T.startS; me.d = 0; me.psi = 0; me.vf = 30; me.vl = 0; me.safeU = me.u; me.py = T.centerY(s, 0) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
      G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 90; x.br = 0; } });
    }, [off, end]);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/serp_${name}.png` });
  }
  console.log(errs.slice(0, 6)); await browser.close();
})();
