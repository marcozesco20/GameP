const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.R.resize(2); PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 5000; PG.G.me.auto = true; });
  await page.waitForFunction(() => PG.G.race.time > 2, null, { timeout: 60000 });
  for (const ty of [0, 1, 2]) {
    await page.evaluate((ty) => { const me = PG.G.me; me.fx.shield = 9; me.shHp = 4; me.shType = ty; PG.G.dbgCamFn = null; }, ty);
    for (let k = 0; k < 2; k++) { await page.waitForTimeout(400 + k * 130); await page.screenshot({ path: `${OUT}/sh${ty}_${k}.png` }); }
  }
  console.log('errors', errs); await browser.close();
})();
