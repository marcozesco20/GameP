const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 450 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 5000; });
  const setup = (types) => page.evaluate((types) => {
    const G = PG.G, rs = G.race.racers, me = G.me; window.__t = setInterval(() => {
      const [a, b, c] = [me, rs.find(r => r !== me), rs.filter(r => r !== me)[1]];
      [[a, 0], [b, 1]].forEach(([r, k]) => { r.u = me.u; r.d = k ? me.d + 0.6 : me.d; r.vf = 14; r.py = r.gy; r.fell = false; if (types[k] >= 0) { r.fx.shield = 8; r.shType = types[k]; r.shHp = 4; } });
      if (c) { c.u = me.u + 6; c.d = me.d + 3; c.vf = 14; c.fx.shield = 0; }
    }, 16);
  }, types);
  await setup([1, 2]);   // electrico vs rebote
  await page.waitForTimeout(700); await page.screenshot({ path: OUT + '/shield_a.png' });
  await page.waitForTimeout(500); await page.screenshot({ path: OUT + '/shield_b.png' });
  console.log(errs); await browser.close();
})();
