const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrMain.show', { timeout: 90000 }); await page.waitForTimeout(800);
  await page.evaluate(() => PG.G.startSolo(1));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  await page.waitForTimeout(3000);
    const info = await page.evaluate(() => {
    const T = PG.G.T, me = PG.G.me; const target = T.finishS - 40;
    me.u = target - T.startS; me.d = 0; me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.vy = 0;
    return { specs: T.specs.length };
  });
  console.log(info);
  await page.evaluate(() => { document.querySelectorAll('.screen').forEach(e => e.classList.remove('show')); });
  for (let i = 0; i < 3; i++) { await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/spec_${i}.png` }); }
  for (const [n, psi] of [['L', 0.9], ['R', -0.9]]) {
    await page.evaluate((psi) => { const me = PG.G.me; me.psi = psi; me.vf = 0.5; me.d = 0; }, psi);
    await page.waitForTimeout(2500); await page.screenshot({ path: `${OUT}/spec_${n}.png` });
  }
  console.log('drawn', await page.evaluate(() => PG.G.specDrawn));
  console.log('errors', errs.slice(0, 8));
  await browser.close();
})();
