const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=stats]');
  for (const v of [-1.45, 1.45, 0.0]) { await page.evaluate((v) => { PG.G.standPitch = v; }, v); await page.waitForTimeout(500); await page.screenshot({ path: `${OUT}/stand_${v}.png`, clip: { x: 0, y: 0, width: 300, height: 360 } }); }
  console.log(errs); await browser.close();
})();
