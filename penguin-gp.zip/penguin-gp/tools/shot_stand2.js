const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=custom]'); await page.waitForTimeout(1500);
  await page.screenshot({ path: `${OUT}/c1.png` });
  // girar con arrastre
  const b = await page.evaluate(() => { const r = document.getElementById('pvDrag').getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2, r.width, r.height]; });
  console.log('drag box', b);
  await page.mouse.move(b[0], b[1]); await page.mouse.down(); await page.mouse.move(b[0] + 120, b[1], { steps: 6 }); await page.mouse.up();
  await page.waitForTimeout(800);
  console.log('manual', await page.evaluate(() => PG.G.cfg && 1));
  await page.screenshot({ path: `${OUT}/c2.png` });
  // cambiar algo y cancelar -> debe restaurar
  const before = await page.evaluate(() => JSON.stringify(PG.G.cfg));
  await page.evaluate(() => { PG.G.cfg.body = (PG.G.cfg.body + 1) % 5; PG.G.cfg.hat = 3; });
  await page.click('[data-act=customCancel]'); await page.waitForTimeout(500);
  const after = await page.evaluate(() => JSON.stringify(PG.G.cfg));
  console.log('cancel restores:', before === after, 'screen:', await page.evaluate(() => PG.G.screen));
  await page.click('[data-act=stats]'); await page.waitForTimeout(1500);
  await page.screenshot({ path: `${OUT}/s1.png` });
  console.log('errors', errs);
  await browser.close();
})();
