const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  const r = await page.evaluate(() => {
    const G = PG.G; const o = [];
    G.stats = { games: 0, wins: 0, podiums: 0, elim: 0, best: {}, tracks: {} };
    o.push(G.recordRace('finish', 1, 95.5, 0, 6));
    o.push(G.recordRace('finish', 4, 99.2, 0, 6));
    o.push(G.recordRace('finish', 2, 90.1, 0, 6));
    o.push(G.recordRace('dead', 0, 0, 1, 6));
    o.push(G.recordRace('finish', 1, 80.0, 2, 6));
    return { o, s: JSON.stringify(G.stats), saved: localStorage.getItem('pgp_stats') };
  });
  console.log(JSON.stringify(r));
  await page.click('[data-act=stats]'); await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/stats.png` });
  console.log('errors', errs);
  await browser.close();
})();
