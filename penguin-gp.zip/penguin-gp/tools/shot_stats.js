const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  const r = await page.evaluate(() => {
    const G = PG.G; const o = [];
    G.stats = { games: 0, wins: 0, podiums: 0, elim: 0, best: {}, tracks: {}, points: 0, coins: 0, tricks: 0, hist: [], places: [0,0,0,0,0,0] };
    o.push(G.recordRace('finish', 1, 95.5, 0, 6, {coins:74,points:14,tricks:4}));
    o.push(G.recordRace('finish', 4, 99.2, 0, 6));
    o.push(G.recordRace('finish', 2, 90.1, 0, 6));
    o.push(G.recordRace('dead', 0, 0, 1, 6, {coins:0,points:0,tricks:0}));
    for (let i=0;i<9;i++) G.recordRace('finish', 1+(i*5)%6, 90+i, i%4, 6, {coins:8+i*7,points:2+i,tricks:i});
    PG.Eco.data.earned=420; PG.Eco.data.spent=210; PG.Eco.data.coins=210;
    o.push(G.recordRace('finish', 1, 80.0, 2, 6));
    return { o, s: JSON.stringify(G.stats), saved: localStorage.getItem('pgp_stats') };
  });
  console.log(JSON.stringify(r));
  await page.click('[data-act=stats]'); await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/stats.png` });
  for (const y of [260, 560]) { await page.evaluate((y) => { document.getElementById('statsBody').scrollTop = y; }, y); await page.waitForTimeout(250); await page.screenshot({ path: `${OUT}/stats_${y}.png` }); }
  console.log('errors', errs);
  await browser.close();
})();
