const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1000, height: 500 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/404|agent-proxy/.test(m.text())) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(2));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 60000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '/s0_calm.png' });
  await page.evaluate(() => { PG.G.wx.on = true; PG.G.wx.t = 0; PG.G.wx.dur = 60; PG.G.wx.dir = 1.0; });
  await page.waitForTimeout(6000);
  await page.screenshot({ path: OUT + '/s1_storm.png' });
  console.log(JSON.stringify(await page.evaluate(() => ({ k: PG.G.wx.k, gust: PG.G.wx.gust, fx: document.getElementById('stormFx').style.opacity }))));
  // sonido: salir de la carrera y comprobar que el deslizamiento se silencia
  const aud = await page.evaluate(() => { PG.Audio.init(); return !!PG.Audio.ctx; });
  await page.evaluate(() => { PG.Audio.slide(1, true); });
  await page.evaluate(() => PG.G.toMenuTest && 0);
  await page.evaluate(() => { document.querySelector('[data-act=quitRace]'); });
  console.log('errors', errs.length ? errs.join('\n') : 'none', 'audio ctx', aud);
  await browser.close();
})();
