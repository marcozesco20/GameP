const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.quality = 2; PG.G.R.resize(2); PG.G.startSolo(0); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 5000; PG.G.me.auto = true; });
  for (let i = 0; i < 14; i++) { await page.waitForTimeout(350); await page.evaluate(() => { PG.G.me.vf = Math.max(PG.G.me.vf, 30); }); if (i == 9) await page.screenshot({ path: OUT + '/tr_a.png' }); }
  await page.screenshot({ path: OUT + '/tr_b.png' });
  console.log(errs); await browser.close();
})();
