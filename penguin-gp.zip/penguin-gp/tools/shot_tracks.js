const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const only = process.env.ONLY ? process.env.ONLY.split(',').map(Number) : [0, 1, 2, 3, 4, 5];
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
  const page = await (await browser.newContext({ viewport: { width: 1376, height: 768 } })).newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errors.push(m.text()); });
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  for (const idx of only) {
    await page.evaluate((i) => PG.G.startSolo(i), idx);
    await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, idx, { timeout: 60000 });
    await page.evaluate(() => { PG.G.goAt -= 8000; });
    // colocar al jugador cerca del primer hueco y avanzar
    const info = await page.evaluate(() => {
      const T = PG.G.T, r = PG.G.me, h = T.holes[0], j = T.ramps.find(x => x.jump) || T.ramps[0];
      const target = (j && j.jump ? j.s0 : h.s0) - 38;
      r.u = (T.type === 'circuit' ? target : target - T.startS); r.d = 0; r.psi = 0; r.vf = 38; r.vl = 0; r.safeU = r.u;
      PG.G.race.racers.forEach(x => { if (x !== r) { x.u = r.u - 60 - Math.random() * 20; } });
      return { target, hole: h.s0, mode: h.mode };
    });
    await page.waitForTimeout(1800);
    await page.screenshot({ path: `${OUT}/t${idx}_approach.png` });
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/t${idx}_jump.png` });
    console.log('track', idx, JSON.stringify(info));
    await page.evaluate(() => PG.G.toMenuTest && 0);
    await page.evaluate(() => { document.querySelector('[data-act=quitRace]'); PG.G.race = null; PG.G.mode = 'menu'; });
  }
  console.log('errors:', errors.length ? errors.slice(0, 10).join('\n') : 'none');
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
