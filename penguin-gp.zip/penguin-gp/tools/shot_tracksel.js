const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 900, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.click('[data-act=solo]'); await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/tracksel.png` });
  await page.evaluate(() => { const g = document.querySelector('#scrTracks .grid, #trackGrid') || document.querySelector('#scrTracks'); document.querySelectorAll('#scrTracks *').forEach(e => { if (e.scrollWidth > e.clientWidth + 50) e.scrollLeft = 99999; if (e.scrollHeight > e.clientHeight + 50) e.scrollTop = 99999; }); });
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/tracksel2.png` });
  console.log('errors', errs);
  await browser.close();
})();
