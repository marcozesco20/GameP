const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(0));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { const G = PG.G, R = G.race; G.goAt -= 6000; G.me.auto = true; G.me.ai = null; G.me.vf = 6;
    G.me.ability = 'trap'; R.doAbility(G.me, 'trap', 1); G.me.vf = 0;
    const tr = R.traps[R.traps.length - 1]; R.traps.push({ id: 'x', owner: 'zz', u: G.me.u + 9, d: G.me.d + 2, life: 99, age: 5 }); tr.age = 5; G.camMode = 'race'; window.__t = tr.u - G.me.u; });
  await page.waitForTimeout(300);
  console.log('trap offset', await page.evaluate(() => window.__t));
  await page.evaluate(() => { PG.G.cam && 0; });
  await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '/trap1.png' });
  console.log('errors', errs); await browser.close();
})();
