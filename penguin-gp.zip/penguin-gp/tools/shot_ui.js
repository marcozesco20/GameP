// capturas de la interfaz v3.0: node shot_ui.js [land|port] ; salida en scratchpad/shots/ui_*.png
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const which = process.argv[2] || 'land';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const [w, h] = which === 'port' ? [420, 860] : [860, 400];
  const p = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true, deviceScaleFactor: 1.5 })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 160)); });
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 }); await p.waitForTimeout(900);
  const shot = async (n) => { await p.waitForTimeout(500); await p.screenshot({ path: `${OUT}/ui_${which}_${n}.png` }); };
  await p.evaluate(() => { PG.Eco.data.coins = 1279; PG.Eco.data.inv = { snow: 2, missile: 1 }; PG.Eco.data.load = ['snow', 'missile']; PG.Eco.refreshWallet(); });
  await shot('main');
  await p.click('[data-act=solo]'); await p.waitForSelector('#scrTracks.show'); await shot('tracks');
  await p.click('.screen.show [data-act=back]'); await p.click('[data-act=custom]'); await p.waitForTimeout(900); await shot('custom0');
  await p.click('[data-ct=hat]'); await shot('custom_hat');
  await p.click('[data-ct=outfit]'); await shot('custom_out');
  await p.click('.screen.show footer [data-act=back]'); await p.waitForTimeout(400);
  await p.click('[data-act=friends]'); await p.waitForSelector('#scrFriends.show'); await shot('friends');
  await p.click('.screen.show [data-act=back]'); await p.click('[data-act=shop]'); await p.waitForSelector('#scrShop.show'); await shot('shop');
  await p.click('.screen.show [data-act=back]'); await p.click('[data-act=stats]'); await p.waitForSelector('#scrStats.show'); await shot('stats');
  await p.click('.screen.show [data-act=back]'); await p.click('[data-act=settings]'); await p.waitForSelector('#scrSettings.show'); await shot('settings');
  console.log(which, errs); await browser.close();
})();
