const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const only = process.env.ONLY || '';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  const shot = async (n) => { await page.screenshot({ path: `${OUT}/v21_${n}.png` }); };
  await page.goto('http://localhost:8080/');
  await page.waitForSelector('#scrIntro.show', { timeout: 60000 }); await page.waitForTimeout(1600); await shot('intro');
  await page.waitForSelector('#scrMain.show', { timeout: 20000 }); await page.waitForTimeout(500); await shot('menu');
  await page.evaluate(() => { document.querySelector('[data-act=solo]').click(); }); await page.waitForTimeout(500); await shot('tracks');
  await page.evaluate(() => { document.querySelector('#segDiffSolo button[data-d="3"]').click(); });
  console.log('diff', await page.evaluate(() => PG.G.set.diff));
  // carrera en pista 1: cuenta atras (pinguino detras)
  await page.evaluate(() => PG.G.startSolo(1));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  console.log('race diff', await page.evaluate(() => PG.G.race.diff));
  await page.waitForTimeout(1200);
  await page.evaluate(() => { const me = PG.G.me, T = PG.G.T; const b = PG.G.race.racers.find(r => r !== me); b.u = me.u - 3.2; b.d = me.d; });
  await page.waitForTimeout(500); await shot('grid');
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  // habilidades acumuladas
  await page.evaluate(() => { const me = PG.G.me; me.ability = 'grenade'; me.abilityQ = ['megaball', 'quake']; PG.G.race.fxq.push({ k: 'abilityget', id: me.id, r: me, ability: 'quake' }); });
  await page.waitForTimeout(500); await shot('queue');
  await page.waitForTimeout(1200);
  await page.evaluate(() => { const me = PG.G.me; PG.G.race.useAbility(me, 1); });
  await page.waitForTimeout(600); await shot('gun');
  // disparar granada hacia un grupo y explotar foca
  await page.evaluate(() => { const me = PG.G.me; me.fireCd = 0; PG.G.race.fire(me, 1); });
  await page.waitForTimeout(500); await shot('gren_fly');
  await page.waitForTimeout(900); await shot('gren_after');
  // mega bola
  await page.evaluate(() => { const me = PG.G.me; me.ability = 'megaball'; me.abilityQ = []; PG.G.race.useAbility(me, 1); });
  await page.waitForTimeout(700); await shot('mega');
  await page.waitForTimeout(1000); await shot('mega2');
  // terremoto
  await page.evaluate(() => { const me = PG.G.me; me.ability = 'quake'; PG.G.race.useAbility(me, 1); });
  await page.waitForTimeout(300); await shot('quake');
  // meta: espectadores
  const info = await page.evaluate(() => {
    const T = PG.G.T, me = PG.G.me; const target = T.finishS - 70;
    me.u = target - T.startS; me.d = 0; me.psi = 0; me.vf = 20; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.gy = me.py; me.vy = 0;
    PG.G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 30 - Math.random() * 30; x.finished = false; } });
    return { fin: T.finishS, L: T.L };
  });
  await page.waitForTimeout(700); await shot('finish_a');
  await page.waitForTimeout(1100); await shot('finish_b');
  await page.evaluate(() => { PG.G.me.u = PG.G.T.finishS - PG.G.T.startS - 8; PG.G.me.vf = 30; });
  await page.waitForTimeout(1600); await shot('win');
  await page.waitForTimeout(2500); await shot('win2');
  console.log('errors', errs.slice(0, 8));
  await browser.close();
})();
