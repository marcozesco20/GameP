const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  // personalizar: girar
  await page.evaluate(() => document.querySelector('[data-act=custom]') ? document.querySelector('[data-act=custom]').click() : 0);
  await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/v22_pen_a.png` });
  await page.click('#pvR'); await page.click('#pvR'); await page.waitForTimeout(500); await page.screenshot({ path: `${OUT}/v22_pen_b.png` });
  const box = await page.locator('#pvDrag').boundingBox();
  await page.mouse.move(box.x + 100, box.y + 200); await page.mouse.down(); await page.mouse.move(box.x + 250, box.y + 200, { steps: 6 }); await page.mouse.up();
  console.log('rot', await page.evaluate(() => 'manual'));
  await page.waitForTimeout(500); await page.screenshot({ path: `${OUT}/v22_pen_c.png` });
  await page.evaluate(() => document.querySelector('#scrCustom [data-act=back]').click());
  await page.waitForTimeout(500);
  // hielo en pista 0
  for (const tr of [0, 8]) {
    await page.evaluate((tr) => PG.G.startSolo(tr), tr);
    await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
    await page.evaluate(() => { PG.G.goAt -= 9000; });
    await page.waitForTimeout(1500);
    const info = await page.evaluate(() => {
      const G = PG.G, T = G.T, me = G.me;
      const o = T.obs.filter(o => o.type === 'ice')[0]; const cnt = {};
      T.obs.forEach(o => { const c = T.inCave(o.s, 0) ? 'cave_' : ''; cnt[c + o.type] = (cnt[c + o.type] || 0) + 1; });
      if (o) { const s = o.s - 22; me.u = s - T.startS; me.d = o.d; me.psi = 0; me.vf = 0; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.vy = 0; G.camInit = false; }
      return cnt;
    });
    console.log(tr, JSON.stringify(info));
    await page.waitForTimeout(2500); await page.screenshot({ path: `${OUT}/v22_ice_${tr}.png` });
    await page.evaluate(() => { document.querySelector('#btnPause').dispatchEvent(new PointerEvent('pointerdown')); });
    await page.waitForTimeout(300);
    await page.evaluate(() => { PG.G.toMenu ? PG.G.toMenu() : 0; });
  }
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
