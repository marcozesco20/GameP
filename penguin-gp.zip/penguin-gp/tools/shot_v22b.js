const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 1180, height: 540 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.evaluate(() => PG.G.startSolo(8));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 9000; });
  await page.waitForTimeout(2000);
  async function at(sel, off, name) {
    const ok = await page.evaluate(([sel, off]) => {
      const G = PG.G, T = G.T, me = G.me; const f = new Function('T', 'return ' + sel); const o = f(T); if (!o) return false;
      const s = o.s - off; me.u = s - T.startS; me.d = 0; me.psi = 0; me.vf = 0; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 0.3; me.vy = 0; G.camInit = false;
      G.race.racers.forEach(x => { if (x !== me) x.u = me.u - 90; }); me.ability = null; return true;
    }, [sel, off]);
    await page.waitForTimeout(2500); await page.screenshot({ path: `${OUT}/v22_${name}.png` }); console.log(name, ok);
  }
  await at("T.obs.filter(o=>o.type==='ice')[1]", 13, 'ice');
  await at("T.obs.filter(o=>o.type==='rock'&&T.inCave(o.s,0))[0]", 25, 'caverock');
  await at("T.obs.filter(o=>o.type==='icicle')[5]", 34, 'cave_ic');
  console.log('errors', errs.slice(0, 6));
  await browser.close();
})();
