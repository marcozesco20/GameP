const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/v23b_menu.png` });
  await page.click('.privLink'); await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/v23b_priv.png` });
  await page.click('#scrPrivacy [data-act=back]'); await page.waitForTimeout(300);
  await page.evaluate(() => PG.G.startSolo(0));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  await page.waitForTimeout(3500);
  await page.screenshot({ path: `${OUT}/v23b_race.png` });
  // mantener pulsado "Atras"
  const box = await page.evaluate(() => { const r = document.getElementById('btnLook').getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2]; });
  await page.evaluate(() => document.getElementById('btnLook').dispatchEvent(new PointerEvent('pointerdown', { pointerId: 5, bubbles: true })));
  await page.waitForTimeout(900);
  const lb1 = await page.evaluate(() => PG.G.lb);
  await page.screenshot({ path: `${OUT}/v23b_look.png` });
  await page.evaluate(() => document.getElementById('btnLook').dispatchEvent(new PointerEvent('pointerup', { pointerId: 5, bubbles: true })));
  await page.waitForTimeout(900);
  const lb2 = await page.evaluate(() => PG.G.lb);
  console.log('lb mantenido', lb1.toFixed(2), 'al soltar', lb2.toFixed(2));
  await page.keyboard.down('KeyV'); await page.waitForTimeout(700); const lb3 = await page.evaluate(() => PG.G.lb); await page.keyboard.up('KeyV'); console.log('tecla V', lb3.toFixed(2));
  // pausa
  await page.evaluate(() => document.getElementById('btnPause').dispatchEvent(new PointerEvent('pointerdown', { pointerId: 6, bubbles: true })));
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/v23b_pause.png` });
  await page.click('#pChkMusic'); await page.click('#pChkSound'); await page.click('#pSegQuality button[data-q="2"]'); await page.waitForTimeout(400);
  console.log('ajustes', await page.evaluate(() => JSON.stringify({ s: PG.G.set.sound, m: PG.G.set.music, q: PG.G.set.quality, chkS: document.getElementById('chkSound').checked, chkM: document.getElementById('chkMusic').checked, qsel: document.querySelector('#segQuality .sel').dataset.q })));
  await page.screenshot({ path: `${OUT}/v23b_pause2.png` });
  console.log('errors', errs);
  await browser.close();
})();
