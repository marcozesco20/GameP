const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(9); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === 9, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  const info = await page.evaluate(() => { const T = PG.G.T; return JSON.stringify({ v: T.volcano, L: T.L }); });
  console.log(info);
  const shots = [['near', 0.97, 0], ['near2', 0.02, 0], ['far', 0.05, 1]];
  for (const [name, f, hi] of shots) {
    await page.evaluate(([f, hi]) => {
      const G = PG.G, T = G.T, me = G.me; G.dbgCamFn = null;
      const s = T.L * f; me.br = 0; me.u = s; me.d = 0; me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = s; me.py = T.centerY(s, 0) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
      G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 90; x.br = 0; } });
      if (hi) { const V = T.volcano; G.dbgCamFn = (cam) => { cam.eye[0] = V.x; cam.eye[1] = V.y + 110; cam.eye[2] = V.z + 360; cam.target[0] = V.x; cam.target[1] = V.y + 120; cam.target[2] = V.z; cam.fov = 0.95; cam.roll = 0; }; }
    }, [f, hi]);
    await page.waitForTimeout(1200);
    await page.screenshot({ path: `${OUT}/volc_${name}.png` });
  }
  console.log(errs.slice(0, 6)); await browser.close();
})();
