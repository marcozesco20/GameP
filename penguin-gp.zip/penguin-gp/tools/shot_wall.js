const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  const ti = +process.argv[2] || 1;
  await page.evaluate((i) => { PG.G.set.ava = false; PG.G.startSolo(i); }, ti);
  await page.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === i, ti, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  await page.waitForTimeout(400);
  for (const side of [1, -1]) {
    await page.evaluate((side) => { const G = PG.G, T = G.T, me = G.me, c = T.caves[0]; const s = c.s0 + 60; me.u = T.type === 'circuit' ? s : s - T.startS; me.d = 10.5 * side; me.psi = 0; me.vf = 36; me.vl = 0; me.safeU = me.u; me.py = T.ground(s, me.d) + 0.2; me.gy = me.py; me.fx.ghost = 99; G.camInit = false; G.bankHack = -side * 0.7; PG.G.__h = setInterval(() => { me.bankRoll = G.bankHack; }, 5); G.race.racers.forEach(x => { if (x !== me) x.u = me.u - 80; }); }, side);
    for (let k = 0; k < 6; k++) { await page.waitForTimeout(120); console.log(side, await page.evaluate(() => ({ bank: +PG.G.me.bankRoll.toFixed(2), d: +PG.G.me.d.toFixed(1), gr: PG.G.me.grounded, roll: +PG.G.cam.roll.toFixed(2), vl: +PG.G.me.vl.toFixed(1) }))); }
    await page.waitForTimeout(2500); await page.screenshot({ path: `${OUT}/wall_${side}.png` }); await page.evaluate(() => clearInterval(PG.G.__h));
  }
  console.log(errs); await browser.close();
})();
