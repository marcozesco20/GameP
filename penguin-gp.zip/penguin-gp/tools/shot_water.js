// uso: shot_water.js pista etiqueta  -> vistas del agua desde arriba y desde abajo
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tid = +process.argv[2], tag = process.argv[3];
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.quality = 2; PG.G.startSolo(t); }, tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const views = [['up', 6, 13, 12], ['low', 2.2, 8, 12], ['under', -1.5, 8, 10], ['under2', -3.0, 4, 14]];
  let k = 0;
  for (const [nm, dh, back, ahead] of views) {
    const ok = await page.evaluate(([dh, back, ahead]) => {
      const G = PG.G, T = G.T; if (!T.lake) return false; G.goAt -= 3000;
      const s = (T.lake.s0 + T.lake.s1) / 2, i = Math.round(s / (T.ds || 1)), n = T.N;
      let ii = Math.max(2, Math.min(n - 2, i));
      const x = T.px[ii], z = T.pz[ii], tx = T.tx[ii], tz = T.tz[ii], wy = T.lake.y;
      
      G.me.u = s - T.startS; const e = [x - tx * back, wy + dh, z - tz * back], t = [x + tx * ahead, wy + (dh < 0 ? 1.2 : -0.5), z + tz * ahead];
      G.dbgCamFn = function (cam) { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = 1.0; cam.roll = 0; };
      return true;
    }, [dh, back, ahead]);
    if (!ok) { console.log('sin laguna'); break; }
    await page.waitForTimeout(1200);
    await page.screenshot({ path: `${OUT}/${tag}_${nm}.png` });
  }
  console.log(errs); await browser.close();
})();
