// busca caidas "falsas": el pinguino cae (fell) estando sobre suelo sin huecos cerca
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const only = process.argv[2] !== undefined ? [+process.argv[2]] : PG.TRACKS.map((_, i) => i);
for (const tid of only) {
  const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true }); const rng = PG.rng(tid * 31 + 7);
  let falseFalls = 0, tot = 0; const where = [];
  for (let n = 0; n < 400; n++) {
    const race = new PG.Race(T, { seed: 3, avalanche: false }); const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 }); race.time = 0;
    const s0 = (T.type === 'circuit' ? 100 : T.startS + 100) + rng() * (T.L - 300 - 100);
    me.u = T.type === 'circuit' ? s0 : s0 - T.startS; me.d = (rng() * 2 - 1) * 10; me.psi = 0; me.vf = 20 + rng() * 40; me.vl = 0; me.safeU = me.u - 30;
    me.py = T.centerY(s0) + 1; me.gy = me.py; me.vy = 5 + rng() * 40; me.grounded = false; me.air = 0.01;
    let t = 0, fell = false, fs = 0, fd = 0, near = false;
    for (let i = 0; i < 360 && !fell; i++) {
      race.time += 1 / 60; t += 1 / 60;
      const sPrev = T.uToS(me.u), dPrev = me.d, pyPrev = me.py;
      race.update(1 / 60, { steer: 0, tuck: 0, jump: false });
      for (const e of race.fxq) if (e.k === 'fall') { fell = true; fs = sPrev; fd = dPrev; } race.fxq.length = 0; race.out.length = 0;
      if (fell) { // hueco o grieta cerca?
        near = T.holes.some(h => T.dS(fs, h.s0) < 12 && T.dS(fs, h.s1) > -12); const nh = T.holes.map(h => [Math.round(T.dS(fs, h.s0)), Math.round(T.dS(fs, h.s1)), h.mode]).filter(x => Math.abs(x[0]) < 80 || Math.abs(x[1]) < 80);
        const g = T.ground(fs, fd); const below = pyPrev - (g > -1e8 ? g : -999);
        if (!near) { falseFalls++; if (where.length < 6) where.push({ s: Math.round(fs), d: +fd.toFixed(1), py: +pyPrev.toFixed(1), g: +g.toFixed(1), vf: +me.vf.toFixed(0), cave: T.inCave(fs, 5), holes: nh, ramp: T.ramps.some(r => fs > r.s0 - 2 && fs < r.s0 + r.len + 2) }); }
      }
    }
    tot++;
  }
  console.log('pista', tid, PG.TRACKS[tid].name, 'caidas falsas', falseFalls, '/', tot, JSON.stringify(where));
}
