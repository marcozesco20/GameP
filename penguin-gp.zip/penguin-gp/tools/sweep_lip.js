const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
let bad = 0, tot = 0, stum = 0;
for (let tid = 0; tid < PG.TRACKS.length; tid++) {
  const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
  for (const H of T.holes) for (const vf0 of [26, 34, 42]) for (let jt = -10; jt <= 6; jt += 2) {
    if (H.mode !== 'full') continue;
    const race = new PG.Race(T, { seed: 3, avalanche: false }); const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 }); race.time = 0;
    const s0 = H.s0 - 40; me.u = T.type === 'circuit' ? s0 : s0 - T.startS; me.d = 0; me.psi = 0; me.vf = vf0; me.safeU = me.u - 20; me.py = T.centerY(s0) + 0.1; me.gy = me.py; me.grounded = true; me.vy = 0;
    let fellAt = null, ev = {};
    for (let i = 0; i < 420; i++) { race.time += 1 / 60; const sn = T.uToS(me.u);
      race.update(1 / 60, { steer: 0, tuck: 0, jump: sn > H.s0 + jt - 4 && sn < H.s0 + jt - 4 + 0.6 });
      for (const e of race.fxq) { ev[e.k] = (ev[e.k] || 0) + 1; if (e.k === 'fall' && fellAt === null) fellAt = T.uToS(me.u); } race.fxq.length = 0; race.out.length = 0; if (fellAt !== null) break; }
    tot++; if (ev.stumble) stum++;
    if (fellAt !== null && fellAt > H.s1 + 0.3) { bad++; console.log('pista', tid, 'caida DESPUES del hueco', 'vf', vf0, 'jt', jt, 'u', fellAt.toFixed(1), 'hueco', H.s0.toFixed(1), H.s1.toFixed(1)); }
  }
}
console.log('total', tot, 'caidas tras pasar el hueco', bad, 'tropiezos de perdon', stum);
