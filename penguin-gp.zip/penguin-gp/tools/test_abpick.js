// v3.2.1: elegir qué poder lanzar primero (tocar un círculo pequeño de la cola)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.evaluate(() => { PG.G.nav = ['scrMain']; PG.G.startSolo(1); });
  await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(800);
  await p.evaluate(() => { const me = PG.G.me; me.ability = 'snow'; me.abilityQ = ['shield', 'trap']; });
  await p.waitForFunction(() => document.querySelectorAll('#abQ i').length === 2, null, { timeout: 8000 });
  const st0 = await p.evaluate(() => PG.G.me.ability + '|' + PG.G.me.abilityQ.join());
  const bb = await (await p.$('#abQ i:nth-child(2)')).boundingBox();
  await p.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2); await p.waitForTimeout(700);
  const st1 = await p.evaluate(() => ({ s: PG.G.me.ability + '|' + PG.G.me.abilityQ.join(), used: PG.G.me.ability }));
  console.log(st0, '->', st1.s);
  ok(st0 === 'snow|shield,trap' && st1.s === 'trap|shield,snow', 'tocar el 2.º círculo pequeño lo pasa al principal y el principal ocupa su lugar');
  ok(await p.evaluate(() => document.querySelectorAll('#abQ i').length === 2), 'siguen 2 círculos pequeños (no se gastó ningún poder)');
  await p.keyboard.press('KeyT'); await p.waitForTimeout(700);
  ok(await p.evaluate(() => PG.G.me.ability + '|' + PG.G.me.abilityQ.join()) === 'shield|snow,trap', 'tecla T rota la cola');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
