// pruebas de avalancha: probabilidad por semilla, eliminacion, dificultad
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
// 1) probabilidad ~40% y determinista
{
  const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true }); let n = 0, N = 600;
  for (let sd = 1; sd <= N; sd++) { const a = new PG.Race(T, { seed: sd * 7919 }), b = new PG.Race(T, { seed: sd * 7919 }); if (a.av) n++; if (!!a.av !== !!b.av || (a.av && a.av.tW !== b.av.tW)) fails++; }
  check('avalancha ~40% de carreras y determinista', n / N > 0.3 && n / N < 0.5, (100 * n / N).toFixed(0) + '%');
  const c = new PG.Race(T, { seed: 5, avalanche: false }); check('se puede desactivar', !c.av);
}
// 2) eliminacion: un corredor parado muere cuando el frente lo cubre; los demas no
for (const tid of [0, 8, 3]) {
  const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
  const race = new PG.Race(T, { seed: 1, avForce: true, diff: 1 });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < 5; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0; let t = 0, deadEv = 0, engulf = 0;
  while (t < 140 && race.racers.some(r => !r.finished)) {
    race.time = t; race.update(1 / 60, { steer: 0, tuck: 0, brake: 1 }); t += 1 / 60;
    for (const e of race.fxq) if (e.k === 'engulf') engulf++; race.fxq.length = 0; for (const o of race.out) if (o.k === 'dead') deadEv++; race.out.length = 0;
  }
  check('pista ' + tid + ': el jugador parado es eliminado', me.dead && me.finished, 'cuando t=' + (me.deadAt || 0).toFixed(1) + ' eventos dead=' + deadEv);
  const aliveBots = race.racers.filter(r => r.bot && !r.dead).length;
  console.log('   bots vivos al final:', aliveBots + '/5', ' ranks:', race.racers.map(r => r.id + ':' + r.rank + (r.dead ? 'x' : '')).join(' '));
}
// 3) ritmo: con bots normales, cuantos caen (varias semillas por dificultad)
for (let diff = 0; diff < 4; diff++) {
  let caught = 0, total = 0, races = 0;
  for (const tid of [0, 2, 4, 6, 7, 8]) for (const sd of [11, 23, 37]) {
    const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
    const race = new PG.Race(T, { seed: sd, avForce: true, diff });
    for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
    race.time = 0; let t = 0;
    while (t < 200 && race.racers.some(r => !r.finished)) { race.time = t; race.update(1 / 60, null); t += 1 / 60; race.fxq.length = 0; race.out.length = 0; }
    races++; total += 6; caught += race.racers.filter(r => r.dead).length;
  }
  console.log('dificultad', diff, ': eliminados por avalancha', caught + '/' + total, '(' + (100 * caught / total).toFixed(0) + '%)');
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
