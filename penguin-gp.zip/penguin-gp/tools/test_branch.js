// Atajos tipo Mario Kart: geometria separada, paso entre caminos, bots que los toman, sin teletransportes
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let bad = 0;
function ok(c, m) { if (!c) { bad++; console.log('FALLA:', m); } }
const ids = process.argv[2] ? process.argv[2].split(',').map(Number) : [0, 2, 4, 7, 9];
for (const id of ids) {
  const def = PG.TRACKS[id], T = PG.buildTrack(def, { noMesh: true });
  ok(T.branches.length > 0, def.name + ' sin atajos');
  for (const B of T.branches) {
    ok(B.kk > 1.1, 'atajo no acorta ' + B.kk);
    // en s0 y s1 el ramal coincide con la pista
    const q0 = T.q(B.s0 + 0.01, 0), x0 = q0.x, z0 = q0.z, q1 = T.q(B.s0 + 0.01, B.id);
    ok(Math.hypot(q1.x - x0, q1.z - z0) < 1.5, 'ramal no empieza en la pista');
    const e0 = T.q(B.s1 - 0.01, 0), ex = e0.x, ez = e0.z, e1 = T.q(B.s1 - 0.01, B.id);
    ok(Math.hypot(e1.x - ex, e1.z - ez) < 1.5, 'ramal no termina en la pista ' + Math.hypot(e1.x - ex, e1.z - ez));
  }
  // carrera de bots: cuantos toman el atajo, tiempos, sin NaN, sin saltos de posicion
  for (const diff of [1, 3]) {
    const race = new PG.Race(T, { seed: 5 + id, diff });
    for (let i = 0; i < 8; i++) race.addRacer({ id: 'b' + i, name: 'B' + i, own: true, bot: true, slot: i });
    race.time = 0; race.nowMs = 0;
    const dt = 1 / 60; let t = 0, used = {}, jumps = 0, falls = 0, lastW = {}, rsp = {}, fl = [], maxJump = 0, nan = 0, stuck = 0;
    const wp = r => { const q = T.q(T.uToS(r.u), r.br); return [q.x + q.rx * r.d, q.z + q.rz * r.d]; };
    while (t < 330) {
      race.time = t; race.update(dt, null); t += dt;
      for (const e of race.fxq) { if (e.k === 'respawn' && e.r) rsp[e.r.id] = 1; if (e.k === 'fall') { falls++; fl.push((e.r.br ? 'ramal' : 'pista') + '@u' + e.r.u.toFixed(0) + ' d' + e.r.d.toFixed(1) + ' v' + e.r.vf.toFixed(0)); } } race.fxq.length = 0; race.out.length = 0;
      for (const r of race.racers) {
        if (!isFinite(r.u) || !isFinite(r.d) || !isFinite(r.py)) nan++;
        if (r.br) used[r.id + ':' + r.br + ':' + Math.floor(r.u / T.L)] = 1;
        const w = wp(r), p = lastW[r.id]; if (p && !r.fell && !rsp[r.id]) { const dj = Math.hypot(w[0] - p[0], w[1] - p[1]); if (dj > maxJump) maxJump = dj; }
        lastW[r.id] = w; rsp[r.id] = 0;
      }
      if (race.racers.every(r => r.finished)) break;
    }
    const fin = race.racers.map(r => r.finished ? r.finishTime.toFixed(0) : 'DNF').join(' ');
    console.log(`${id} ${def.name.padEnd(22)} diff${diff} t=${t.toFixed(0)} atajos(bot-vuelta)=${Object.keys(used).length} caidas=${falls} maxSaltoPos=${maxJump.toFixed(2)}m NaN=${nan} | ${fin} ${fl.join(' ; ')}`);
    ok(nan === 0, 'NaN'); ok(maxJump < 3.6, 'salto de posicion ' + maxJump);
    ok(race.racers.every(r => r.finished), 'no todos terminan');
  }
}
console.log(bad ? 'FALLOS: ' + bad : 'OK atajos');
process.exit(bad ? 1 : 0);
