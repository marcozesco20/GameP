// la camara no debe atravesar suelo ni techo: conduce al jugador con la IA y mide el margen en cada frame
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const tid = +(process.env.TRACK || 8), secs = +(process.env.SECS || 40);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/' + (process.env.START ? '#' + process.env.START : '')); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => PG.G.startSolo(t), tid);
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  await page.evaluate(() => {
    const G = PG.G; G.goAt -= 6000; window._start = +(location.hash.slice(1)) || 0; G.me.auto = true; G.me.ai = null; window._m = { worst: 1e9, worstTop: 1e9, n: 0, inCave: 0, at: null };
    // salta a la zona de la cueva si se pide
    const c = G.T.caves[+(window._cave || 0)];
    G.me.u = (c ? c.s0 - 30 : 100) - G.T.startS; if (window._start) G.me.u = window._start; G.me.safeU = G.me.u; G.camInit = false;
    setInterval(() => {
      const T = G.T, me = G.me, cam = G.cam, s = T.uToS(me.u), q = T.q(s);
      const lat = (cam.eye[0] - q.x) * q.rx + (cam.eye[2] - q.z) * q.rz;
      // busca la s mas cercana a la camara a lo largo de la pista
      let best = 1e9, bs = s;
      for (let k = -4; k <= 22; k += 0.5) { const sc = s - k, qq = T.q(sc), dx = cam.eye[0] - qq.x - qq.rx * lat, dz = cam.eye[2] - qq.z - qq.rz * lat; const dd = dx * dx + dz * dz; if (dd < best) { best = dd; bs = sc; } }
      let g = T.ground(bs, lat); if (g < -1e8) g = T.centerY(bs);
      const clr = cam.eye[1] - g, ce = T.ceilAt(bs, Math.max(-12, Math.min(12, lat)));
      const top = ce < 1e8 ? (T.centerY(bs) + ce) - cam.eye[1] : 1e9;
      const m = window._m; m.n++; if (T.inCave(s, 0)) m.inCave++;
      if (clr < m.worst) { m.worst = clr; m.at = [Math.round(s), +lat.toFixed(1)]; }
      if (top < m.worstTop) m.worstTop = top;
    }, 100);
  });
  await page.waitForTimeout(secs * 1000);
  console.log('pista', tid, JSON.stringify(await page.evaluate(() => window._m)), 'errores', errs);
  await browser.close();
})();
