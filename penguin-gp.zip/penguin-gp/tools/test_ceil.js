// techo de las cuevas: un jugador (no bot) entra a mucha velocidad empujando contra la pared
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
let bad = 0;
for (const def of PG.TRACKS) {
  const T = PG.buildTrack(def, { noMesh: true });
  if (!T.caves.length) continue;
  const c = T.caves.filter(c => !c.tun)[0] || T.caves[0];
  const race = new PG.Race(T, { seed: 3, avalanche: false });
  race.addRacer({ id: 'me', name: 'Yo', own: true, local: true, slot: 0 });
  const r = race.racers[0];
  race.time = 0; race.nowMs = 0;
  const sStart = c.s0 + 20;
  r.u = T.type === 'circuit' ? sStart : sStart - T.startS; r.d = 0; r.vf = 52; r.psi = 0; r.py = T.ground(T.uToS(r.u), 0) + 0.2; r.vy = 0;
  const dt = 1 / 60; let t = 0, on = false, onT = 0, maxH = 0, ev = {}, maxRoll = 0, lastOn = -1, offT = -1, minPyMargin = 9, landT = -1, rollAtLand = null;
  const sgn = def.id % 2 ? -1 : 1;
  while (t < 14) {
    race.time = t;
    const inp = { steer: (!r.onCeil && t < 9 && !ev.ceil) ? sgn * 0.3 : 0, tuck: 1 };
    race.update(dt, inp); t += dt;
    for (const e of race.fxq) { ev[e.k] = (ev[e.k] || 0) + 1; if (e.k === 'ceil') console.log(`   t=${t.toFixed(2)} ceil ${e.on ? 'ON' : 'OFF'} vf=${r.vf.toFixed(1)} s=${(T.uToS(r.u) - c.s0).toFixed(0)}/${(c.s1 - c.s0).toFixed(0)} d=${r.d.toFixed(1)}`); if (e.k === 'righted') console.log(`   t=${t.toFixed(2)} righted roll=${r.rightA.toFixed(2)}`); }
    race.fxq.length = 0; race.out.length = 0;
    const s = T.uToS(r.u);
    if (r.onCeil) { onT += dt; const cy = T.centerY(s) + T.ceilAt(s, r.d); minPyMargin = Math.min(minPyMargin, cy - r.py); maxRoll = Math.max(maxRoll, Math.abs(r.bankRoll)); if (!isFinite(r.py)) { bad++; break; } }
    if (!r.onCeil && r.grounded && landT < 0 && ev.ceil >= 2) { landT = t; rollAtLand = r.bankRoll; }
    if (landT > 0 && t > landT + 1.5) break;
  }
  console.log(`${def.id} ${def.name.padEnd(22)} ceil events=${ev.ceil || 0} ride=${onT.toFixed(2)}s maxRoll=${maxRoll.toFixed(2)} margin=${minPyMargin.toFixed(2)} landed=${landT.toFixed(1)} rollAtLand=${rollAtLand} final: bank=${r.bankRoll.toFixed(2)} grounded=${r.grounded} d=${r.d.toFixed(1)} py-gy=${(r.py - r.gy).toFixed(2)}`);
  if (!ev.ceil || ev.ceil < 2 || landT < 0 || Math.abs(rollAtLand) > 0.3) bad++;
}
console.log(bad ? 'FALLO ' + bad : 'OK');
process.exit(bad ? 1 : 0);
