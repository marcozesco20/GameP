// v3.2.1: poderes sueltos en el techo de las cuevas
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  const info = await p.evaluate(() => PG.TRACKS.map((d, i) => { const T = PG.buildTrack(d, { noMesh: true }); return T ? [i, T.caves.length, T.crys.filter(c => c.ceil).length] : null; }));
  console.log(JSON.stringify(info));
  const idx = (info.find(x => x && x[2] > 0) || [0])[0];
  ok(info.some(x => x && x[2] > 0), 'hay poderes en el techo de las cuevas (pistas con cuevas: ' + info.filter(x => x && x[2] > 0).map(x => x[0] + ':' + x[2]).join(' ') + ')');
  console.log('pistas con cuevas sin orbes de techo:', info.filter(x => x && x[1] > 0 && x[2] === 0).map(x => x[0]).join());
  await p.evaluate((i) => { PG.G.nav = ['scrMain']; PG.G.startSolo(i); }, idx);
  await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(600);
  const r = await p.evaluate(() => {
    const G = PG.G, R = G.race, T = G.T, me = G.me, k = T.crys.findIndex(c => c.ceil), Cr = T.crys[k];
    const out = { s: Cr.s, d: Cr.d, ceilY: T.centerY(Cr.s) + T.ceilAt(Cr.s, Cr.d) };
    // lejos del techo: no recoge
    me.ability = null; me.abilityQ = []; R.crysT[k] = 0;
    me.u = (T.type === 'circuit' ? Cr.s : Cr.s - T.startS); me.d = Cr.d; me.py = T.ground(Cr.s, Cr.d); me.onCeil = 0; me.vf = 40;
    R.update(1 / 60, { steer: 0, tuck: 0, brake: 0 });
    out.groundGot = R.crysT[k] > R.time; out.t = R.time; out.cT = R.crysT[k]; out.oc = me.onCeil; R.crysT[k] = 0;
    // pegado al techo: recoge
    me.u = (T.type === 'circuit' ? Cr.s : Cr.s - T.startS); me.d = Cr.d; me.py = out.ceilY - 1.2; me.onCeil = 1; me.ceilK = 1; me.ceilAdh = 1; me.ceilPy0 = me.py; me.ceilRoll0 = 0; me.ceilSide = 1; me.vf = 45; me.grounded = true;
    R.crysLast = -1; me.crysLast = -1;
    R.update(1 / 60, { steer: 0, tuck: 0, brake: 0 });
    out.dbg = { onCeil: me.onCeil, d: me.d, py: me.py, vf: me.vf, rank: me.rank, fin: me.finished, u: me.u, uShould: (T.type === 'circuit' ? Cr.s : Cr.s - T.startS), s2: T.uToS(me.u) };
    out.ceilGot = R.crysT[k] > R.time; out.respawn = out.ceilGot;
    return out;
  });
  console.log(JSON.stringify(r));
  ok(!r.groundGot, 'desde el suelo no se recoge un orbe del techo');
  ok(r.ceilGot && r.respawn, 'rodando por el techo sí se recoge y reaparece luego');
  await p.waitForTimeout(300); await p.screenshot({ path: '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots/ceilorb.png' });
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
