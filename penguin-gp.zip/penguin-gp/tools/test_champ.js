// v3.1: campeonato en solitario de punta a punta (5 carreras) + pantalla final
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
let fails = 0; function ok(c, m) { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; }
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.click('[data-act=solo]'); await p.waitForSelector('#scrTracks.show');
  await p.click('#segModeSolo button[data-m=c]'); await p.waitForTimeout(300);
  await p.screenshot({ path: OUT + '/ch_tracks.png' });
  await p.click('#btnTrackGo');
  const seen = [];
  for (let i = 0; i < 5; i++) {
    await p.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.champ && PG.G.champ.idx === i && PG.G.goAt && !PG.G.demo, i, { timeout: 90000 });
    await p.waitForTimeout(600);
    seen.push(await p.evaluate(() => PG.G.trackIdx));
    await p.evaluate(() => { PG.G.goAt -= 8000; });
    await p.waitForTimeout(500);
    await p.evaluate(() => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; R.racers.forEach((r, k) => { r.u = endU + 1 + k * 0.5; if (T.type === 'circuit') r.lap = R.laps; }); });
    await p.waitForSelector('#scrResults.show', { timeout: 40000 });
    await p.waitForFunction(() => PG.G.champ && PG.G.champ.rec[PG.G.champ.idx], null, { timeout: 40000 });
    await p.waitForTimeout(800);
    if (i === 1) await p.screenshot({ path: OUT + '/ch_results.png' });
    if (i < 4) await p.click('#btnNext');
    else await p.click('#btnNext');
  }
  await p.waitForSelector('#scrChamp.show', { timeout: 20000 }); await p.waitForTimeout(600);
  await p.screenshot({ path: OUT + '/ch_final.png' });
  const st = await p.evaluate(() => { const c = PG.G.champ; return { tracks: c.tracks, rows: Object.values(c.rows).map(r => ({ n: r.name, pts: r.pts, ranks: r.ranks, wins: r.wins })) }; });
  console.log(JSON.stringify(st));
  ok(new Set(seen).size === 5, 'cinco pistas distintas ' + seen.join(','));
  ok(JSON.stringify(seen) === JSON.stringify(st.tracks), 'las pistas siguen el orden del campeonato');
  const tot = st.rows.reduce((a, r) => a + r.pts, 0); ok(tot === (10 + 7 + 5 + 3 + 2 + 1) * 5, 'se reparten 28 puntos por carrera: ' + tot);
  ok(st.rows.length === 6 && st.rows.every(r => r.ranks.length === 5), 'seis participantes con su puesto en las 5 carreras');
  ok(st.rows.reduce((a, r) => a + r.wins, 0) === 5, 'cinco victorias repartidas');
  await p.click('#btnChampDone'); await p.waitForSelector('#scrMain.show', { timeout: 10000 });
  ok(await p.evaluate(() => PG.G.champ === null), 'al salir se borra el campeonato');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
