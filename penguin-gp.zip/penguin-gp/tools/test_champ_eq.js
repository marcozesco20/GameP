// v3.3: en campeonato los poderes usados se gastan SOLO al terminar todas las carreras
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; function ok(c, m) { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; }
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.evaluate(() => { const E = PG.Eco; E.buy('bshield'); E.buy('bshield'); E.buy('snow'); });
  await p.click('[data-act=solo]'); await p.waitForSelector('#scrTracks.show');
  await p.click('#segModeSolo button[data-m=m]'); await p.waitForTimeout(300);
  await p.click('#btnTrackGo');
  for (let i = 0; i < 3; i++) {
    await p.waitForFunction((i) => PG.G.mode === 'race' && PG.G.race && PG.G.champ && PG.G.champ.idx === i && PG.G.goAt && !PG.G.demo, i, { timeout: 90000 });
    await p.waitForTimeout(500);
    ok(await p.evaluate(() => document.querySelectorAll('#eqBox .eqB').length) === 3, 'carrera ' + (i + 1) + ': siguen las 3 casillas del equipo');
    await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(600);
    if (i !== 1) { await p.keyboard.press('Digit1'); await p.waitForFunction(() => (PG.G.eqUsed || [])[0], null, { timeout: 15000 }).catch(() => {}); }
    await p.evaluate(() => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; R.racers.forEach((r, k) => { r.u = endU + 1 + k * 0.5; if (T.type === 'circuit') r.lap = R.laps; }); });
    await p.waitForSelector('#scrResults.show', { timeout: 40000 });
    await p.waitForFunction(() => PG.G.champ && PG.G.champ.rec[PG.G.champ.idx], null, { timeout: 40000 });
    await p.waitForTimeout(500);
    const inv = await p.evaluate(() => PG.Eco.own('bshield') + ',' + PG.Eco.own('snow'));
    if (i < 2) ok(inv === '2,1', 'tras la carrera ' + (i + 1) + ' (usé el poder) el inventario sigue intacto: ' + inv);
    await p.click('#btnNext');
  }
  await p.waitForSelector('#scrChamp.show', { timeout: 20000 }); await p.waitForTimeout(500);
  ok(await p.evaluate(() => PG.Eco.own('bshield') + ',' + PG.Eco.own('snow')) === '1,1', 'al terminar el campeonato se gasta 1 (aunque lo usé en 2 carreras): 1,1');
  ok(await p.evaluate(() => PG.Eco.data.load.join()) === 'bshield,snow', 'la casilla gastada desaparece del equipo');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
