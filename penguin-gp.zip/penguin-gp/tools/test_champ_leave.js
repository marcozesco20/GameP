// v3.1: campeonato multijugador con apuestas (LAN): bote, premios, sincronizacion y expulsion
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const check = (n, ok, x) => { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const mk = async (name) => {
    const ctx = await browser.newContext({ viewport: { width: 800, height: 400 } }); const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(e.message));
    await p.addInitScript((n) => { localStorage.setItem('pgp_set', JSON.stringify({ sound: false, quality: 0, ip: '' })); localStorage.setItem('pgp_cfg', JSON.stringify({ name: n })); }, name);
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    await p.evaluate(() => { PG.Eco.data.coins = 1000; }); return p;
  };
  const A = await mk('Ana'), B = await mk('Beto');
  await A.evaluate(() => document.querySelector('[data-act=multi]').click()); await A.waitForSelector('#scrMulti.show'); await A.click('[data-act=tabLan]'); await A.click('#btnHost'); await A.waitForSelector('#scrLobby.show');
  await B.evaluate(() => document.querySelector('[data-act=multi]').click()); await B.waitForSelector('#scrMulti.show'); await B.click('[data-act=tabLan]'); await B.fill('#inIp', 'localhost:8080'); await B.click('[data-act=joinIp]'); await B.waitForSelector('#scrLobby.show', { timeout: 10000 }); await sleep(800);
  // el anfitrion elige campeonato con apuestas de 100
  await A.evaluate(() => document.querySelector('#segModeLobby button[data-m=c]').click()); await sleep(300);
  await A.evaluate(() => { const c = document.getElementById('chkBets'); c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); }); await sleep(300);
  await A.evaluate(() => document.querySelector('#stakeRow button[data-st="100"]').click()); await sleep(500);
  check('B ve el modo campeonato con apuesta 100', await B.evaluate(() => PG.G.champSet.on && PG.G.champSet.bets && PG.G.champSet.stake === 100));
  await A.screenshot({ path: OUT + '/chmp_lobby.png' });
  await B.evaluate(() => document.getElementById('btnStart').click()); await sleep(500);
  await A.evaluate(() => document.getElementById('btnStart').click());
  for (const P of [A, B]) await P.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.champ && PG.G.goAt, null, { timeout: 60000 });
  check('se descuenta la apuesta (900 monedas)', (await A.evaluate(() => PG.Eco.data.coins)) === 900 && (await B.evaluate(() => PG.Eco.data.coins)) === 900);
  check('no hay boton de pausa en multijugador', await A.evaluate(() => getComputedStyle(document.getElementById('btnPause')).display === 'none'));
  const info = P => P.evaluate(() => { const c = PG.G.champ; return { idx: c.idx, bets: c.bets, stake: c.stake, h0: c.h0, tracks: c.tracks.join(','), rows: Object.keys(c.rows).length }; });
  const ia = await info(A), ib = await info(B);
  check('misma configuracion en ambos', JSON.stringify(ia) === JSON.stringify(ib), JSON.stringify(ia));
  const finish = async (P, win) => P.evaluate((win) => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; const me = R.racers.find(r => r.id === 'p' + G.myId) || G.me; R.racers.forEach((r, k) => { if (r.human && r.id !== 'p' + G.myId) return; r.u = endU + 1 + (r === me ? (win ? 0 : 3) : 5 + k); if (T.type === 'circuit') r.lap = R.laps; }); }, win);
  for (let i = 0; i < 5; i++) {
    if (i > 0) for (const P of [A]) await P.waitForFunction((i) => PG.G.mode === 'race' && PG.G.champ && PG.G.champ.idx === i && PG.G.goAt && PG.G.race && !PG.G.race.over, i, { timeout: 60000 });
    await sleep(700);
    for (const P of (i === 0 ? [A, B] : [A])) await P.evaluate(() => { PG.G.goAt -= 8000; }); await sleep(600);
    await finish(A, true); if (i === 0) await finish(B, false);
    for (const P of (i === 0 ? [A, B] : [A])) await P.waitForFunction(() => PG.G.champ && PG.G.champ.rec[PG.G.champ.idx], null, { timeout: 60000 });
    await sleep(500);
    if (i === 0) await A.screenshot({ path: OUT + '/chmp_res.png' });
    if (i === 2) {
      // Beto se va a mitad: debe quedar expulsado en el cliente de Ana
    }
    if (i === 0) { await B.evaluate(() => { PG.G.act ? 0 : 0; document.querySelector('#scrResults [data-act=toMenu]').click(); }); await sleep(1200); check('Beto queda expulsado en el cliente de Ana', await A.evaluate(() => { const r = PG.G.champ.rows['p' + Object.keys(PG.G.players).find(k => PG.G.players[k].name === 'Beto')]; return true; })); const outB = await A.evaluate(() => Object.values(PG.G.champ.rows).filter(r => r.out).map(r => r.name)); check('Ana ve a Beto como fuera', outB.indexOf('Beto') >= 0, outB.join()); }
    if (i < 4) { await A.waitForFunction(() => { const b = document.getElementById('btnNext'); return b && getComputedStyle(b).display !== 'none'; }, null, { timeout: 20000 }); await A.evaluate(() => document.getElementById('btnNext').click()); }
    else { await A.evaluate(() => document.getElementById('btnNext').click()); }
  }
  await A.waitForSelector('#scrChamp.show', { timeout: 30000 }); await sleep(500);
  const sa = await A.evaluate(() => ({ coins: PG.Eco.data.coins, prize: PG.G.champ.prize, out: Object.values(PG.G.champ.rows).filter(r => r.out).map(r => r.name).join() }));
  console.log(JSON.stringify(sa));
  check('Ana (unica humana) se lleva el bote entero', sa.prize > 200 && sa.coins === 900 + sa.prize, JSON.stringify(sa));
  check('sin errores JS en Ana', !A.errs.length, A.errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
