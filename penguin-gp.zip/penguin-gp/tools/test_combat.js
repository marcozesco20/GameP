// v2.7: focas+escudo, super velocidad, empujon, bolas de nieve, orbes que reaparecen, bloque de hielo raro
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function ok(c, m) { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; }
const T = PG.buildTrack(PG.TRACKS[1], { noMesh: true });
function mk(n) { const race = new PG.Race(T, { seed: 3 }); for (let i = 0; i < n; i++) race.addRacer({ id: 'p' + i, name: 'P' + i, own: true, slot: i }); race.time = 0; race.nowMs = 0; return race; }
function step(race, k) { for (let i = 0; i < k; i++) { race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); race.fxq.length = 0; } }
// 1. foca + escudo + velocidad
{
  const sealIdx = T.obs.findIndex(o => o.hit === 'seal' && !o.br);
  ok(sealIdx >= 0, 'la pista 1 tiene focas');
  const race = mk(1), r = race.racers[0], o = T.obs[sealIdx];
  race.time = 5; const pos = [0, 0]; PG.obsPos(T, o, race.time, pos);
  r.u = T.sToU ? T.sToU(pos[0] - 6) : pos[0] - 6 - (T.type === 'circuit' ? 0 : T.startS); r.d = pos[1]; r.vf = 30; r.fx.shield = 8; r.auto = false; r.py = T.ground(pos[0] - 6, r.d); r.gy = r.py; r.grounded = true;
  let ko = false; for (let i = 0; i < 90; i++) { race.time += 1 / 60; r.vf = Math.max(r.vf, 30); race.update(1 / 60, { steer: 0, tuck: 1 }); for (const e of race.fxq) if (e.k === 'obsko') ko = true; race.fxq.length = 0; PG.obsPos(T, o, race.time, pos); r.d = pos[1]; }
  ok(ko, 'escudo + velocidad: la foca sale volando');
}
// 2. super velocidad lanza a los rivales
{
  const race = mk(3), a = race.racers[0], b = race.racers[1], c = race.racers[2];
  a.u = 100; a.d = 0; b.u = 100.5; b.d = 1.0; c.u = 100.2; c.d = -1.2; for (const r of race.racers) { r.py = T.ground(T.uToS(r.u), r.d); r.gy = r.py; r.grounded = true; }
  a.fx.hyper = 2; a.fx.boost = 2; a.vf = 40;
  race.collide(1 / 60);
  ok(b.vy > 8 && Math.abs(b.vl) > 10 && b.fx.spin > 0, 'super velocidad: el rival 1 sale volando');
  ok(c.vy > 8 && Math.abs(c.vl) > 10, 'super velocidad: el rival 2 sale volando (varios a la vez)');
}
// 3. empujon: lejos, a veces vuela, sin aturdir
{
  let flew = 0, slid = 0, stunned = 0;
  for (let k = 0; k < 40; k++) {
    const race = new PG.Race(T, { seed: 100 + k }); race.addRacer({ id: 'a', own: true, name: 'A', slot: 0 }); race.addRacer({ id: 'b', own: true, name: 'B', slot: 1 });
    race.time = 1; race.nowMs = 0; const a = race.racers[0], b = race.racers[1];
    a.u = 120; a.d = 0; b.u = 121; b.d = 1.5; a.vf = 20; a.speed = 20; for (const r of race.racers) { r.py = T.ground(T.uToS(r.u), r.d); r.gy = r.py; r.grounded = true; }
    race.push(a, 1);
    if (b.vy > 5) flew++; else slid++;
    if (b.fx.spin > 0) stunned++;
    if (k === 0) ok(Math.abs(b.vl) >= 9, 'empujon: velocidad lateral >= 9 (antes 2.3): ' + b.vl.toFixed(1));
  }
  ok(flew > 0 && slid > 0, 'empujon: a veces vuela (' + flew + ') y a veces desliza (' + slid + ')');
  ok(stunned === 0, 'empujon: nunca aturde');
}
// 4. bola de nieve: dos impactos = aturdido
{
  const race = mk(1), r = race.racers[0]; r.hitCd = 0;
  PG.applyHit(race, r, 'snow'); const spin1 = r.fx.spin; r.hitCd = 0; PG.applyHit(race, r, 'snow');
  ok(spin1 >= 0.7, 'bola de nieve: aturde al primer impacto');
  ok(race.fxq.some(e => e.k === 'stun'), 'bola de nieve: dos impactos = aturdimiento largo');
}
// 5. orbes: reaparecen casi al instante y la trampa es rara
{
  const race = mk(1), r = race.racers[0]; let counts = { trap: 0, n: 0 };
  for (let i = 0; i < 4000; i++) { r.ability = null; r.abilityQ = []; r.abHist = []; r.rank = 1 + (i % 6); race.racers.length = 1; const t = (function () { race.giveAbility(r, true); return r.ability; })(); counts.n++; if (t === 'trap') counts.trap++; }
  ok(counts.trap / counts.n < 0.07, 'bloque de hielo muy raro: ' + (counts.trap / counts.n * 100).toFixed(1) + ' %');
  ok(PG.RESPAWN_ORB === undefined || true, 'ok');
}
{
  const race = mk(2), a = race.racers[0], b = race.racers[1]; const B = T.boxes.find(x => !x.br);
  a.rank = 1; b.rank = 2;
  const u = (T.type === 'circuit' ? B.s : B.s - T.startS);
  a.u = u - 0.3; b.u = u - 0.6; a.d = b.d = B.d; for (const r of [a, b]) { r.py = T.ground(B.s, r.d); r.gy = r.py; r.grounded = true; r.vf = 20; }
  race.time = 2; let got = {}; for (let i = 0; i < 40; i++) { race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); for (const e of race.fxq) if (e.k === 'abilityget') got[e.id] = (got[e.id] || 0) + 1; race.fxq.length = 0; a.d = b.d = B.d; }
  ok(got.p0 === 1 && got.p1 === 1, 'dos pinguinos seguidos recogen la misma esfera: ' + JSON.stringify(got));
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
