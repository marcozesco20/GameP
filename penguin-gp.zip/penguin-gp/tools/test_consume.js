// v3.2.1: el poder comprado se gasta de verdad al USARLO (sin simular G.eqUsed): tocar la casilla -> cruzar meta -> inventario
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.evaluate(() => { const E = PG.Eco; E.buy('bshield'); E.buy('bshield'); E.buy('snow'); });
  for (let round = 1; round <= 2; round++) {
    await p.evaluate(() => { PG.G.nav = ['scrMain']; PG.G.startSolo(1); });
    await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
    await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(800);
    const before = await p.evaluate(() => ({ bs: PG.Eco.own('bshield'), sn: PG.Eco.own('snow'), n: document.querySelectorAll('#eqBox .eqB').length, load: PG.Eco.data.load.join() }));
    console.log('ronda', round, JSON.stringify(before));
    // tocar de verdad la casilla 0 (primer poder del equipo) con el teclado: tecla 1
    await p.keyboard.press('Digit1'); await p.waitForFunction(() => (PG.G.eqUsed || [])[0], null, { timeout: 15000 }).catch(() => {}); await p.waitForTimeout(400);
    ok(await p.evaluate(() => !!(PG.G.eqUsed || [])[0]), 'ronda ' + round + ': el uso de la casilla 1 queda registrado por el evento real');
    ok(await p.evaluate(() => { const b = document.querySelector('#eqBox .eqB[data-i="0"]'); return b && b.classList.contains('used'); }), 'ronda ' + round + ': la casilla se marca como usada');
    await p.evaluate(() => { const T = PG.G.T, R = PG.G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; R.racers.forEach((r, k) => { r.u = endU + 1 + k; if (T.type === 'circuit') r.lap = R.laps; }); });
    await p.waitForSelector('#scrResults.show', { timeout: 40000 });
    const after = await p.evaluate(() => ({ inv: JSON.stringify(PG.Eco.data.inv), load: PG.Eco.data.load.join() }));
    console.log('fin', round, JSON.stringify(after));
    if (round === 1) {
      ok(after.load === 'bshield,snow' && JSON.parse(after.inv).bshield === 1 && JSON.parse(after.inv).snow === 1, 'ronda 1: se gastó 1 escudo de rebote (queda 1) y la nieve no usada se conserva');
      await p.evaluate(() => document.querySelector('#scrResults [data-act=toMenu]').click()); await p.waitForSelector('#scrMain.show');
    } else {
      ok(JSON.parse(after.inv).bshield === 0 && after.load === 'snow', 'ronda 2: el último escudo de rebote también se gastó; ya no aparece');
    }
  }
  // tercera partida: la casilla del escudo ya no existe
  await p.evaluate(() => document.querySelector('#scrResults [data-act=toMenu]').click()); await p.waitForSelector('#scrMain.show');
  await p.evaluate(() => { PG.G.nav = ['scrMain']; PG.G.startSolo(1); });
  await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  ok(await p.evaluate(() => Array.from(document.querySelectorAll('#eqBox .eqB')).map(b => b.dataset.k).join()) === 'snow', 'ronda 3: en carrera solo aparece lo que sigue en el inventario');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
