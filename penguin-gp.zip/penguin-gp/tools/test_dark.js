const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(1500);
  const cv = await page.evaluate(() => { const T = PG.G.T; const c = T.caves && T.caves[0]; return c ? c.s0 + 60 - T.startS : -1; });
  // menu: el corredor del fondo dentro de la cueva => oscuro (comportamiento normal del demo)
  await page.evaluate((u) => { const r = PG.G.race.racers; r.forEach((q, i) => { q.u = u + i; }); }, cv);
  await page.waitForTimeout(1500); const kMenu = await page.evaluate(() => PG.G.caveK);
  await page.click('[data-act=custom]'); await page.waitForTimeout(500);
  await page.evaluate((u) => { PG.G.race.racers.forEach((q, i) => { q.u = u + i; }); }, cv);
  await page.waitForTimeout(8000); const kCustom = await page.evaluate(() => PG.G.caveK);
  console.log('cueva u', cv, 'caveK menu', kMenu.toFixed(2), 'caveK personalizar', kCustom.toFixed(2));
  console.log((kCustom < 0.05 ? 'OK   ' : 'FAIL ') + 'personalizar no se oscurece'); await browser.close(); process.exit(kCustom < 0.05 ? 0 : 1);
})();
