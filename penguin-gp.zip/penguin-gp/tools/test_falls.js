const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG, tid = +process.argv[2], noflip = process.argv[3] === 'noflip';
const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
let tot = 0, runs = 0, where = {};
for (let seed = 1; seed <= 8; seed++) {
  const race = new PG.Race(T, { seed });
  for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i });
  if (noflip) race.racers.forEach(r => { r.ai.rr0 = r.ai.rr; r.ai.rr = () => 0.99; });
  race.time = 0; let t = 0;
  const origEmit = null;
  while (t < 200) { race.time = t; race.update(1 / 60, null); t += 1 / 60;
    for (const e of race.fxq) if (e.k === 'fall') { const s = T.uToS(e.r.u); const key = Math.round(s / 20) * 20; where[key] = (where[key] || 0) + 1; }
    race.fxq.length = 0; race.out.length = 0; if (race.racers.every(r => r.finished)) break; }
  const f = race.racers.reduce((a, r) => a + r.falls, 0); tot += f; runs++;
}
console.log('track', tid, noflip ? 'sin piruetas' : 'con piruetas', 'caidas/carrera:', (tot / runs).toFixed(2), JSON.stringify(where));
