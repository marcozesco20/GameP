const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk(trackId, bots) {
  const T = PG.buildTrack(PG.TRACKS[trackId], { noMesh: true });
  const race = new PG.Race(T, { seed: 3 });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < bots; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0; return { T, race, me };
}
function run(race, me, secs, inputFn) {
  const evs = {}; let t = 0;
  while (t < secs) {
    race.time += 1 / 60; t += 1 / 60;
    const inp = inputFn(t, me); race.update(1 / 60, inp);
    for (const e of race.fxq) evs[e.k] = (evs[e.k] || 0) + 1; race.fxq.length = 0; race.out.length = 0;
  }
  return evs;
}
// 1) salto: despega, completa una voltereta y recibe turbo al aterrizar
function flatSpot(T) {
  for (let s = 150; s < T.L - 200; s += 5) {
    let ok = true;
    for (const R of T.ramps) if (R.s0 < s + 190 && R.s0 + R.len > s - 40) ok = false;
    for (const H of T.holes) if (H.s0 < s + 190 && H.s1 > s - 40) ok = false;
    for (const R of T.branches || []) if (R.s0 < s + 190 && R.s1 > s - 60) ok = false;
    for (const P of T.pads) if (P.s < s + 190 && P.s + P.len > s - 40) ok = false;
    for (const O of T.obs) if (O.s < s + 190 && O.s > s - 40) ok = false;
    for (let q = s; q < s + 60; q += 6) if (Math.abs(T.q(q).sl) > 0.06) ok = false;
    if (ok) return s;
  }
  return 150;
}
{
  const { T, race, me } = mk(0, 0); T.obs.length = 0; T.pads.length = 0;
  const s0 = flatSpot(T);
  me.u = T.type === "circuit" ? s0 : s0 - T.startS; me.vf = 25; me.safeU = me.u - 20; me.py = T.centerY(s0) + 0.1; me.gy = me.py; me.vy = 0; me.grounded = true;
  let pressed = 0, maxAir = 0;
  const evs = run(race, me, 3, (t) => {
    maxAir = Math.max(maxAir, me.py - me.gy);
    const inp = { steer: 0, tuck: 1, brake: 0, boost: false, jump: false };
    if (t > 0.5 && t < 1.0) inp.jump = true;                 // mantener = salto + voltereta
    return inp;
  });
  check('salto despega', evs.jump === 1, JSON.stringify(evs));
  check('altura de salto razonable (1.2–3.5 m)', maxAir > 1.2 && maxAir < 3.5, 'max=' + maxAir.toFixed(2));
  check('voltereta completa + pirueta con turbo', evs.flip >= 1 && evs.trick >= 1, JSON.stringify({ flip: evs.flip, trick: evs.trick, stumble: evs.stumble }));
}
// 2) voltereta incompleta: aterrizaje torpe
{
  const { T, race, me } = mk(0, 0); T.obs.length = 0; T.pads.length = 0;
  const s0 = flatSpot(T);
  me.u = T.type === 'circuit' ? s0 : s0 - T.startS; me.vf = 25; me.py = T.centerY(s0) + 0.1; me.gy = me.py; me.vy = 0; me.grounded = true;
  const evs = run(race, me, 2.5, (t) => {
    const inp = { steer: 0, tuck: 1, brake: 0, jump: false };
    if (t > 0.5 && t < 0.56) inp.jump = true;
    if (t > 0.55 && t < 0.6) inp.jump = true;   // casi seguido: voltereta empieza muy cerca del aterrizaje
    if (t > 1.0 && t < 1.05 && !me.grounded) inp.jump = true;
    return inp;
  });
  console.log('   eventos incompleta:', JSON.stringify(evs));
  check('no se rompe el estado tras aterrizar', me.flipping === false && me.flipAcc === 0 && me.grounded !== undefined);
}
// 3) cañon: habilidad, 9 s, dispara y los proyectiles ralentizan a un rival
{
  const { race, me } = mk(0, 0);
  const rival = race.addRacer({ id: 'rv', own: true, bot: false, slot: 1 });
  me.u = 100; me.vf = 30; rival.u = 135; rival.vf = 28; rival.d = me.d;
  me.ability = 'cannon';
  let useA = true, shots = 0;
  const evs = run(race, me, 5, (t) => {
    const inp = { steer: 0, tuck: 1, brake: 0, jump: false, fire: true };
    if (useA) { inp.useAbility = true; useA = false; }
    rival.vf = Math.max(rival.vf, 28); rival.d = me.d;
    return inp;
  });
  check('cañón activado', evs.cannon === 1 && me.ability !== 'cannon', JSON.stringify(evs));
  check('dispara ráfaga (≈ 3/s)', evs.shoot >= 8 && evs.shoot <= 20, 'shoot=' + evs.shoot);
  check('impactos al rival con "pellet" (hit)', (evs.hit || 0) >= 1, 'hit=' + evs.hit);
  const rem = run(race, me, 6, () => ({ steer: 0, tuck: 1, fire: true }));
  check('cañón se agota (no dispara tras ~9 s)', me.fx.cannon === 0 && !race.fire(me));
}
// 4) respawn: nunca reaparece sobre/dentro de un hueco, en todos los modos
for (const def of PG.TRACKS) {
  const T = PG.buildTrack(def, { noMesh: true });
  const race = new PG.Race(T, { seed: 1 });
  let bad = 0, total = 0;
  for (const H of T.holes) {
    if (H.br) continue; // los huecos de los atajos no afectan a la pista principal
    // simula caídas desde distintos puntos dentro y alrededor del hueco
    for (let off = -20; off <= (H.s1 - H.s0) + 20; off += 3) {
      for (const dd of [-10, -4, 0, 4, 10]) {
        const s = H.s0 + off, uFall = T.type === 'circuit' ? s : s - T.startS;
        const r = { u: uFall, safeU: uFall - 1, safeD: dd };
        const u2 = PG.safeRespawnU(race, Math.min(r.safeU, r.u));
        const s2 = T.uToS(u2), d2 = Math.max(-5, Math.min(5, dd * 0.4)); total++;
        // seguro = suelo en el punto y sin hueco en [-8, +48] por delante
        let ok = T.ground(s2, d2) > -1e8;
        for (const G2 of T.holes) { if (G2.br) continue; const a = T.dS(s2, G2.s0), b = T.dS(s2, G2.s1); if (b > -8 && a < 48) ok = false; }
        if (!ok && !(T.type === 'sprint' && u2 <= -T.startS + 4.01)) bad++;
      }
    }
  }
  check('respawn seguro pista ' + def.id + ' (' + total + ' casos)', bad === 0, 'malos=' + bad);
}
// 5) respawn real: tirar al jugador a un hueco 'mid' y ver que no cae en bucle
{
  const T0 = PG.buildTrack(PG.TRACKS[2], { noMesh: true });
  const mid = T0.holes.findIndex(h => h.mode === 'mid' || h.mode === 'L' || h.mode === 'R');
  const { T, race, me } = mk(2, 0);
  const H = T.holes[mid >= 0 ? mid : 0];
  me.u = (T.type === 'circuit' ? H.s0 : H.s0 - T.startS) - 12; me.d = (H.d0 + H.d1) / 2; me.vf = 20; me.safeU = me.u; me.safeD = me.d; me.auto = true;
  const evs = run(race, me, 25, (t) => ({ steer: 0, tuck: 0.6, brake: 0 }));
  check('sin bucle de caídas (' + (mid >= 0 ? H.mode : 'full') + ')', (evs.fall || 0) <= 2, JSON.stringify({ fall: evs.fall, respawn: evs.respawn, falls: me.falls }));
}
console.log(fails ? fails + ' FALLOS' : 'TODO OK'); process.exit(fails ? 1 : 0);
