// v4.9: el efecto de estiramiento (shader) compila y se activa a gran velocidad; la guia automatica esta apagada por defecto; el castillo es mas ancho
const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async()=>{
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:480,height:270}})).newPage(); let err=0, fails=0;
const ok=(c,m)=>{console.log((c?'OK   ':'FAIL ')+m); if(!c) fails++;};
page.on('pageerror', e=>{err++;console.log('PAGEERROR', e.message)});
page.on('console', m=>{ if(m.type()==='error'||/shader|compile|GLSL/i.test(m.text())) { err++; console.log('CONSOLE', m.text().slice(0,300)); } });
await page.addInitScript(()=>{ let clock=1000; performance.now=()=>clock; const q=[]; window.requestAnimationFrame=(cb)=>{q.push(cb);return q.length}; window.__step=(n,dt)=>{for(let i=0;i<n;i++){clock+=dt; q.splice(0).forEach(cb=>cb(clock))}}; window.__setClock=(c)=>{clock=c}; });
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
for (const Q of (process.argv[2] ? [+process.argv[2]] : [2])) {
  await page.evaluate((Q)=>{PG.G.set.ava=false; PG.G.set.quality=Q; PG.G.startSolo(13);}, Q);
  await page.waitForFunction(()=>{ window.__step(3,16.7); return PG.G.mode==='race'&&PG.G.race&&PG.G.R; },null,{timeout:120000,polling:100});
  const r = await page.evaluate(()=>{ const G=PG.G,R=G.R; window.__step(5,16.7); window.__setClock(5000); G.goAt=5000-9000;
    const me=G.me; me.vf=48; me.speed=48; for(let i=0;i<40;i++){ me.vf=48; window.__step(1,16.7); }
    const u=R.ppComp&&R.ppComp.u||{}; return { hasSt: !!u.uSt, st: R.stretchK, bk: R.blurK, ppFull: R.ppFull, eng: R.engineBlur, guide: PG.guideAssist, W: G.T.W, kmh: me.speed*3.6 }; });
  console.log('Q'+Q, JSON.stringify(r));
  ok(r.hasSt, 'Q'+Q+': el shader tiene uSt');
  ok(r.st > 0.05 || !r.eng, 'Q'+Q+': el estiramiento se activa a '+Math.round(r.kmh)+' km/h (st='+(+r.st).toFixed(2)+(r.eng?'':', sin pasada final en este navegador: MSAA nativo')+')');
  ok(!r.guide, 'guia automatica apagada por defecto');
  ok(r.W === 30, 'el castillo mide 30 m de ancho');
  await page.evaluate(()=>{ PG.G.quitRace && PG.G.quitRace(true); window.__step(10,16.7); });
  await page.waitForTimeout(300);
}
await browser.close(); console.log(fails||err?'FALLOS':'TODO OK'); process.exit(fails||err?1:0); })();
