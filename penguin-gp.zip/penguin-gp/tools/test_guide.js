// v4.9: guia automatica (apagada por defecto): al soltar el control el pinguino conserva su rumbo; con la guia activa se alinea con la pista; girar al lado contrario lo endereza
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG; let fails = 0;
const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
function run(guide, bot) {
  PG.guideAssist = guide;
  const T = PG.buildTrack(PG.TRACKS[1], { noMesh: true });
  const race = new PG.Race(T, { seed: 3 }); race.addRacer({ id: 'p', name: 'P', own: true, local: !bot, bot: !!bot, slot: 0 }); race.time = 3; race.nowMs = 0;
  const r = race.racers[0]; r.u = 120; r.d = 0; r.py = T.ground(T.uToS(r.u), 0); r.gy = r.py; r.grounded = true; r.vf = 25;
  const step = (n, steer) => { for (let i = 0; i < n; i++) { race.time += 1 / 60; race.update(1 / 60, { steer: steer }); } };
  step(30, 1); const p1 = r.psi; step(30, 0); const p2 = r.psi; step(30, -1); const p3 = r.psi;
  return { p1, p2, p3 };
}
let a = run(false, false); console.log('libre', JSON.stringify(a));
ok(a.p1 > 0.3, 'girar a la derecha da rumbo'); ok(a.p2 > a.p1 * 0.8, 'sin guia: al soltar conserva el rumbo (' + a.p2.toFixed(2) + ' de ' + a.p1.toFixed(2) + ')'); ok(a.p3 < 0.1, 'girar al lado contrario lo endereza (' + a.p3.toFixed(2) + ')');
a = run(true, false); console.log('guia', JSON.stringify(a)); ok(Math.abs(a.p2) < 0.1, 'con guia: al soltar se alinea con la pista (' + a.p2.toFixed(2) + ')');
a = run(false, true); ok(Math.abs(a.p2) < 0.1, 'bots: no cambian (se alinean)');
console.log(fails ? 'FALLOS: ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
