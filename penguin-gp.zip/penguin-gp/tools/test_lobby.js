// v2.6: listos, expulsar, nombre duplicado, notificación de chat y stickers
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const check = (n, ok, x) => { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const mk = async (name) => {
    const ctx = await browser.newContext({ viewport: { width: 800, height: 400 } }); const p = await ctx.newPage(); p.errs = [];
    p.on('pageerror', e => p.errs.push(e.message));
    await p.addInitScript((n) => { localStorage.setItem('pgp_set', JSON.stringify({ sound: false, quality: 0, ip: '' })); localStorage.setItem('pgp_cfg', JSON.stringify({ name: n })); }, name);
    await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 }); return p;
  };
  const join = async (P) => { await P.evaluate(() => document.querySelector('[data-act=multi]').click()); await P.waitForSelector('#scrMulti.show'); await P.click('[data-act=tabLan]'); await P.fill('#inIp', 'localhost:8080'); await P.click('[data-act=joinIp]'); await P.waitForSelector('#scrLobby.show', { timeout: 10000 }); };
  const A = await mk('Ana'), B = await mk('Beto');
  await A.evaluate(() => document.querySelector('[data-act=multi]').click()); await A.waitForSelector('#scrMulti.show'); await A.click('[data-act=tabLan]'); await A.click('#btnHost'); await A.waitForSelector('#scrLobby.show');
  await join(B); await sleep(800);
  const start = P => P.evaluate(() => { const b = document.getElementById('btnStart'); return { dis: b.disabled, t: b.textContent }; });
  let sa = await start(A); check('anfitrión no puede iniciar si B no está listo', sa.dis, sa.t);
  await B.evaluate(() => document.getElementById('btnStart').click()); await sleep(500);
  sa = await start(A); check('al marcar listo B, A puede iniciar', !sa.dis, sa.t);
  check('A ve a B como listo', await A.evaluate(() => /Listo/.test(document.getElementById('playerList').textContent)));
  await B.evaluate(() => document.getElementById('btnStart').click()); await sleep(400);
  check('B cancela listo y A vuelve a bloquearse', (await start(A)).dis);
  // chat: notificación y stickers
  await A.evaluate(() => { document.getElementById('lTabC').click(); });
  await A.fill('#chatInput', 'hola Beto'); await A.click('[data-act=chatSend]'); await sleep(500);
  const dot = await B.evaluate(() => { const d = document.getElementById('chatDot'); return { vis: getComputedStyle(d).display !== 'none', n: d.textContent }; });
  check('B ve la notificación del chat', dot.vis && dot.n === '1', JSON.stringify(dot));
  await sleep(700); await A.evaluate(() => { document.querySelector('[data-act=chatEmoji]').click(); });
  await A.evaluate(() => document.querySelector('[data-act=pkTab][data-t=base]').click());
  await A.evaluate(() => document.querySelector('[data-act=pkSt]').click()); await sleep(500);
  const dot2 = await B.evaluate(() => document.getElementById('chatDot').textContent);
  check('B recibe el sticker (contador 2)', dot2 === '2', dot2);
  await B.evaluate(() => document.getElementById('lTabC').click()); await sleep(300);
  check('B ve el sticker en el chat y el contador se borra', await B.evaluate(() => !!document.querySelector('#chatLog .stkMsg') && getComputedStyle(document.getElementById('chatDot')).display === 'none'));
  await sleep(700); await A.evaluate(() => document.querySelector('[data-act=pkTab][data-t=pol]').click());
  await A.evaluate(() => document.querySelector('[data-act=pkSt]').click()); await sleep(300);
  check('sticker bloqueado no se envía', await B.evaluate(() => document.querySelectorAll('#chatLog .stkMsg').length === 1));
  await sleep(700); await A.evaluate(() => { PG.Eco.data.coins = 500; document.querySelector('[data-act=pkBuy]').click(); });
  await A.evaluate(() => document.querySelector('[data-act=pkSt]').click()); await sleep(400);
  check('tras comprar el paquete se envía', await B.evaluate(() => document.querySelectorAll('#chatLog .stkMsg').length === 2));
  // nombre duplicado: entrada vieja con el mismo dispositivo
  const pidB = await B.evaluate(() => PG.G.pid);
  await A.evaluate((pid) => { PG.G.players[77] = { id: 77, name: 'Beto', pid: pid, cfg: PG.G.cfg }; PG.G.renderLobby(); }, pidB);
  check('(simulado) entrada vieja de Beto aparece duplicada', await A.evaluate(() => Object.keys(PG.G.players).length === 3));
  await B.evaluate(() => PG.Net.send({ t: 'hello', name: 'Beto', cfg: PG.G.cfg, pid: PG.G.pid })); await sleep(500);
  check('al volver a decir hola, se quita la entrada vieja', await A.evaluate(() => Object.keys(PG.G.players).length === 2));
  // salir y volver a entrar
  await B.evaluate(() => document.querySelector('#scrLobby [data-act=leave]').click()); await sleep(600);
  await join(B); await sleep(800);
  check('tras volver a entrar A ve 2 jugadores (sin duplicado)', await A.evaluate(() => Object.keys(PG.G.players).length === 2 && document.querySelectorAll('#playerList .prow').length === 2));
  check('B ve 2 jugadores', await B.evaluate(() => document.querySelectorAll('#playerList .prow').length === 2));
  // expulsar
  await A.evaluate(() => document.querySelector('#scrLobby').click());
  await A.evaluate(() => { document.getElementById('lTabP').click(); });
  await A.evaluate(() => document.querySelector('.kick').click()); await sleep(200);
  check('expulsar pide confirmación', await A.evaluate(() => /Seguro/.test(document.querySelector('.kick').textContent)));
  await A.evaluate(() => document.querySelector('.kick').click()); await sleep(900);
  check('B sale de la sala (menú principal)', await B.evaluate(() => document.getElementById('scrMain').classList.contains('show')));
  check('A queda solo', await A.evaluate(() => Object.keys(PG.G.players).length === 1));
  check('B puede volver a entrar', await (async () => { await join(B); await sleep(600); return await A.evaluate(() => Object.keys(PG.G.players).length === 2); })());
  console.log('errores', A.errs.concat(B.errs).slice(0, 5));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
