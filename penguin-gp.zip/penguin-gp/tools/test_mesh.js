const ctx = require('./load')(['util.js', 'tracks.js', 'fbxdata.js', 'fbx.js', 'models.js', 'trackmesh.js', 'sim.js']);
const PG = ctx.PG;
for (const def of PG.TRACKS) {
  const t0 = Date.now();
  const T = PG.buildTrack(def, {});
  const ms = Date.now() - t0;
  const bad = [];
  T.mesh.chunks.forEach(c => { const f = new Float32Array(c.buf); for (let i = 0; i < c.n * 5; i++) if (!isFinite(f[i])) { bad.push(i); break; } });
  console.log(`${def.id} ${def.name.padEnd(24)} tris=${T.mesh.tris.toFixed(0)} chunks=${T.mesh.chunks.length} mem=${(T.mesh.chunks.reduce((a, c) => a + c.buf.byteLength, 0) / 1e6).toFixed(1)}MB build=${ms}ms nonfinite=${bad.length}`);
}
PG.buildModels(PG.THEMES.day);
console.log('models', Object.keys(PG.Models).join(','));
const m = PG.penguinModel(PG.defaultCfg()); console.log('penguin parts', m.parts.map(p => p.kind + ':' + p.mesh.tris).join(' '));
for (let h = 0; h < 8; h++) for (let s = 0; s < 4; s++) for (let g = 0; g < 4; g++) for (let o = 0; o < 4; o++) PG.penguinModel({ hat: h, scarf: s, glasses: g, outfit: o });
console.log('all customization combos build OK');
