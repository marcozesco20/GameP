const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0;
function check(name, ok, extra) { console.log((ok ? 'OK   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) fails++; }
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true,
    args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const mk = async (name, quality) => {
    const ctx = await browser.newContext({ viewport: { width: 640, height: 360 } });
    const p = await ctx.newPage(); p.nm = name; p.errs = [];
    p.on('pageerror', e => p.errs.push(e.message));
    p.on('console', m => { if (m.type() === 'error' && !/404|agent-proxy/.test(m.text())) p.errs.push(m.text()); });
    await p.addInitScript((n) => { localStorage.setItem('pgp_set', JSON.stringify({ sound: false, quality: 0, ip: '' })); localStorage.setItem('pgp_cfg', JSON.stringify({ name: n })); }, name);
    await p.goto('http://localhost:8080/');
    await p.waitForSelector('#scrMain.show', { timeout: 60000 });
    return p;
  };
  const A = await mk('Ana'), B = await mk('Beto');
  // A crea sala
  await A.evaluate(() => { document.querySelector('[data-act=multi]').click(); });
  await A.waitForSelector('#scrMulti.show');
  await A.click('[data-act=tabLan]');
  await A.click('#btnHost');
  await A.waitForSelector('#scrLobby.show', { timeout: 10000 });
  check('A en lobby como host', await A.evaluate(() => PG.G.myId === PG.G.hostId), await A.evaluate(() => 'id=' + PG.G.myId));
  // B se une
  await B.evaluate(() => { document.querySelector('[data-act=multi]').click(); });
  await B.waitForSelector('#scrMulti.show');
  await B.click('[data-act=tabLan]');
  await B.fill('#inIp', 'localhost:8080');
  await B.click('[data-act=joinIp]');
  await B.waitForSelector('#scrLobby.show', { timeout: 10000 });
  await sleep(800);
  const nA = await A.evaluate(() => Object.keys(PG.G.players).length), nB = await B.evaluate(() => Object.keys(PG.G.players).length);
  check('ambos ven 2 jugadores', nA === 2 && nB === 2, `A=${nA} B=${nB}`);
  check('B no es host', await B.evaluate(() => PG.G.myId !== PG.G.hostId));
  check('A no puede iniciar hasta que B esté listo', await A.evaluate(() => document.getElementById('btnStart').disabled));
  await B.evaluate(() => document.getElementById('btnStart').click()); await sleep(500);
  check('B marcado listo y A puede iniciar', await A.evaluate(() => !document.getElementById('btnStart').disabled));
  // A elige pista 3 -> B la ve
  await A.evaluate(() => { PG.G.lobby.track = 2; PG.Net.send({ t: 'lobby', track: 2, bots: true }); });
  await sleep(500);
  check('B recibe pista elegida', await B.evaluate(() => PG.G.lobby.track === 2));
  // inicio
  await A.evaluate(() => document.getElementById('btnStart').click());
  await B.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 15000 });
  await A.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 15000 });
  const rosterA = await A.evaluate(() => PG.G.race.racers.map(r => r.id + ':' + (r.own ? 'own' : 'rem') + (r.bot ? 'B' : '')).join(','));
  const rosterB = await B.evaluate(() => PG.G.race.racers.map(r => r.id + ':' + (r.own ? 'own' : 'rem') + (r.bot ? 'B' : '')).join(','));
  console.log('roster A', rosterA); console.log('roster B', rosterB);
  check('misma pista en ambos', await A.evaluate(() => PG.G.trackIdx) === await B.evaluate(() => PG.G.trackIdx));
  check('mismo número de corredores', (await A.evaluate(() => PG.G.race.racers.length)) === (await B.evaluate(() => PG.G.race.racers.length)));
  // esperar salida y mover
  await sleep(6500);
  await A.waitForFunction(() => PG.G.me && PG.G.me.u > -3, null, { timeout: 40000 }).catch(() => {});
  await A.keyboard.down('ArrowUp'); await B.keyboard.down('ArrowUp');
  await A.evaluate(() => { window.focus(); });
  await sleep(9000);
  const st = async (P, id) => P.evaluate((id) => { const r = PG.G.race.byId[id]; return r ? { u: +r.u.toFixed(1), vf: +r.vf.toFixed(1), net: !!r.net, own: r.own } : null; }, id);
  const idA = 'p' + await A.evaluate(() => PG.G.myId), idB = 'p' + await B.evaluate(() => PG.G.myId);
  const a_in_B = await st(B, idA), b_in_A = await st(A, idB), a_in_A = await st(A, idA), b_in_B = await st(B, idB);
  console.log('A@A', JSON.stringify(a_in_A), 'A@B', JSON.stringify(a_in_B));
  console.log('B@B', JSON.stringify(b_in_B), 'B@A', JSON.stringify(b_in_A));
  check('B recibe estado de A', a_in_B && a_in_B.net && a_in_B.u > 5);
  check('A recibe estado de B', b_in_A && b_in_A.net && b_in_A.u > 5);
  check('posición remota ≈ real (A)', a_in_B && a_in_A && Math.abs(a_in_B.u - a_in_A.u) < 40, `d=${a_in_B && a_in_A ? (a_in_A.u - a_in_B.u).toFixed(1) : ''}`);
  // bots: sólo host los simula; B debe ver bots moviéndose
  const botB = await B.evaluate(() => PG.G.race.racers.filter(r => r.bot).map(r => ({ u: +r.u.toFixed(0), net: !!r.net, own: r.own })));
  check('B ve bots avanzando por red', botB.length > 0 && botB.every(b => !b.own) && botB.some(b => b.u > 5), JSON.stringify(botB.slice(0, 3)));
  // evento: A lanza ítem (bola de nieve) y B lo recibe
  await A.evaluate(() => { const r = PG.G.me; r.ability = 'trap'; PG.G.race.useAbility(r, 1); });
  await sleep(1800);
  const evB = await B.evaluate(() => PG.G.race.traps.length);
  check('B recibe trampa lanzada por A (evento)', evB > 0, 'traps=' + evB);
  await A.screenshot({ path: `${OUT}/net_A.png` }); await B.screenshot({ path: `${OUT}/net_B.png` });
  // forzar meta de ambos
  for (const P of [A, B]) await P.evaluate(() => { const r = PG.G.me, T = PG.G.T; r.u = (T.type === 'circuit' ? T.L * 3 : T.finishS - T.startS) - 5; r.lap = 3; });
  await A.waitForSelector('#scrResults.show', { timeout: 40000 }).catch(() => { });
  await B.waitForSelector('#scrResults.show', { timeout: 40000 }).catch(() => { });
  check('A muestra resultados', await A.evaluate(() => document.getElementById('scrResults').classList.contains('show')));
  check('B muestra resultados', await B.evaluate(() => document.getElementById('scrResults').classList.contains('show')));
  await A.screenshot({ path: `${OUT}/net_results.png` });
  // volver al lobby
  await A.evaluate(() => document.querySelector('[data-act=nextRace]').click());
  await sleep(800);
  check('B vuelve al lobby', await B.evaluate(() => PG.G.mode === 'menu' && document.getElementById('scrLobby').classList.contains('show')));
  check('A vuelve al lobby', await A.evaluate(() => PG.G.mode === 'menu' && document.getElementById('scrLobby').classList.contains('show')));
  // host se va -> B es host
  await A.evaluate(() => document.querySelector('#scrLobby [data-act=leave]').click());
  await sleep(800);
  check('B pasa a ser host', await B.evaluate(() => PG.G.myId === PG.G.hostId));
  check('B ve 1 jugador', await B.evaluate(() => Object.keys(PG.G.players).length === 1));
  console.log('errores A:', A.errs.slice(0, 5).join(' | ') || 'ninguno'); console.log('errores B:', B.errs.slice(0, 5).join(' | ') || 'ninguno');
  console.log(fails ? `\n${fails} FALLOS` : '\nTODO OK');
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
