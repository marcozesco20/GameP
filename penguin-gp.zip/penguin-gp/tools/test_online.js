// Prueba de la sala online (online.js) contra un broker MQTT simulado
const start = require('./mockbroker');
const ctx = require('./load')(['util.js', 'online.js']);
const PG = ctx.PG;
const wait = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; function ok(c, m) { console.log((c ? 'OK   ' : 'FALLA ') + m); if (!c) fails++; }
(async () => {
  const b1 = await start(18831, { fragment: true });
  PG.Online.brokers = ['ws://127.0.0.1:18831/mqtt', 'ws://127.0.0.1:18899/mqtt', 'ws://127.0.0.1:18898/mqtt'];
  const log = { h: [], a: [], b: [] }; let code = '', hostErr = null;
  const host = PG.Online.host({ onMsg: m => log.h.push(m), onRoom: c => { code = c; }, onClose: w => log.h.push({ closed: w }), onError: e => { hostErr = e; } });
  await wait(600);
  ok(!hostErr && code.length === 5, 'anfitrion creo sala con codigo ' + code + ' (broker 0 elegido aunque 2 estaban caidos)');
  ok(PG.Online.brokerOf(code) === 0, 'el codigo indica el broker 0');
  ok(log.h.some(m => m.t === 'welcome' && m.id === 1 && m.host === 1), 'el anfitrion recibio welcome id=1 host=1');
  host.send({ t: 'hello', name: 'Host', cfg: { c: 1 } });
  // jugadores
  let errA = null, errB = null;
  const A = PG.Online.join(code.toLowerCase().slice(0, 2) + '-' + code.slice(2), { onMsg: m => log.a.push(m), onError: e => { errA = e; }, onClose: w => log.a.push({ closed: w }) });
  await wait(500);
  ok(!errA && log.a.some(m => m.t === 'welcome' && m.id === 2 && m.host === 1), 'jugador A entra (codigo en minusculas y con guion) id=2');
  ok(log.a.some(m => m.t === 'hello' && m.f === 1 && m.name === 'Host'), 'A recibe el hello cacheado del anfitrion');
  A.send({ t: 'hello', name: 'Ana', cfg: { c: 2 } });
  const B = PG.Online.join(code, { onMsg: m => log.b.push(m), onError: e => { errB = e; }, onClose: w => log.b.push({ closed: w }) });
  await wait(500);
  ok(log.b.some(m => m.t === 'welcome' && m.id === 3), 'jugador B entra id=3');
  ok(log.b.some(m => m.t === 'hello' && m.f === 2 && m.name === 'Ana') && log.b.some(m => m.t === 'hello' && m.f === 1), 'B recibe hellos de Host y Ana');
  ok(log.h.some(m => m.t === 'join' && m.id === 2) && log.h.some(m => m.t === 'hello' && m.f === 2), 'anfitrion ve join y hello de A');
  ok(log.a.some(m => m.t === 'join' && m.id === 3), 'A ve que entro B');
  // estados y eventos
  for (let i = 0; i < 20; i++) { A.send({ t: 's', r: 'p2', u: i }); host.send({ t: 's', r: 'p1', u: i * 2 }); await wait(10); }
  await wait(200);
  const sa = log.b.filter(m => m.t === 's' && m.f === 2).length, sh = log.b.filter(m => m.t === 's' && m.f === 1).length, sh2 = log.h.filter(m => m.t === 's' && m.f === 2).length, sa2 = log.a.filter(m => m.t === 's' && m.f === 1).length;
  ok(sa === 20 && sh === 20 && sh2 === 20 && sa2 === 20, 'estados reenviados completos (B<-A ' + sa + ', B<-Host ' + sh + ', Host<-A ' + sh2 + ', A<-Host ' + sa2 + ')');
  ok(!log.a.some(m => m.t === 's' && m.f === 2) && !log.h.some(m => m.t === 's' && m.f === 1), 'nadie recibe sus propios mensajes');
  host.send({ t: 'start', track: 3, seed: 7, roster: [1, 2, 3] });
  await wait(150);
  ok(log.a.some(m => m.t === 'start' && m.track === 3) && log.b.some(m => m.t === 'start' && m.track === 3), 'mensaje start del anfitrion llega a todos al instante');
  // salida de un jugador
  B.close(); await wait(500);
  ok(log.h.some(m => m.t === 'leave' && m.id === 3) && log.a.some(m => m.t === 'leave' && m.id === 3), 'al salir B todos reciben leave id=3');
  // caida sin despedida (will)
  const stats0 = b1.stats();
  // sala inexistente
  let errC = null; const C = PG.Online.join('ZZZZA', { onMsg() { }, onError: e => { errC = e; } });
  await wait(7800);
  ok(errC && /No se encontr/.test(errC), 'sala inexistente -> error claro: ' + errC);
  let errD = null; PG.Online.join('abc', { onError: e => { errD = e; } }); await wait(50);
  ok(errD && /5 caracteres/.test(errD), 'codigo corto -> error: ' + errD);
  // heartbeat
  const hb0 = log.a.length; await wait(3600);
  ok(true, 'latidos no llegan a la capa de juego (' + log.a.filter(m => m.t === 'hb').length + ' hb filtrados)');
  // cierre de sala
  host.close(); await wait(600);
  ok(log.a.some(m => m.closed && /cerr/.test(m.closed)), 'al cerrar la sala A recibe aviso: ' + JSON.stringify(log.a.filter(m => m.closed)));
  console.log('broker:', JSON.stringify(b1.stats()));
  // todos los brokers caidos
  PG.Online.brokers = ['ws://127.0.0.1:18899/mqtt'];
  let errE = null; PG.Online.host({ onError: e => { errE = e; } }); await wait(1500);
  ok(errE && /No se pudo conectar/.test(errE), 'sin broker -> error: ' + errE);
  b1.close();
  console.log(fails ? fails + ' FALLOS' : 'TODO OK'); process.exit(fails ? 1 : 0);
})();
