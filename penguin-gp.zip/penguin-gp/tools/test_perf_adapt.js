// v4.8: la resolucion adaptativa baja de nivel con cuadros lentos, termina en 30 fps fijos y recuerda el nivel
const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async()=>{
const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox','--use-angle=swiftshader','--use-gl=angle','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({viewport:{width:480,height:270}})).newPage(); let err=0;
page.on('pageerror', e=>{err++;console.log('PAGEERROR', e.message)});
await page.addInitScript(()=>{ let clock=1000; performance.now=()=>clock; const q=[]; window.requestAnimationFrame=(cb)=>{q.push(cb);return q.length}; window.__step=(n,dt)=>{for(let i=0;i<n;i++){clock+=dt; q.splice(0).forEach(cb=>cb(clock));}}; window.__setClock=(v)=>{clock=v}; });
await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show',{timeout:60000});
await page.evaluate(()=>{PG.G.set.ava=false; PG.G.set.quality=1; PG.G.startSolo(0);});
await page.waitForFunction(()=>{ window.__step(3,16.7); return PG.G.mode==='race'&&PG.G.race&&PG.G.R; },null,{timeout:120000,polling:100});
const log=await page.evaluate(()=>{ const G=PG.G, R=G.R, o=[]; window.__step(5,16.7); window.__setClock(5000); G.goAt=5000-9000;
  // 1) cuadros de 45 ms (22 fps): debe bajar de nivel
  for(let k=0;k<30;k++){ window.__step(20,45); o.push(k+':lv'+Math.round(R.dyn*100)+(G.cap30?' CAP30':'')); if(G.cap30) break; }
  return {o:o.join(' '), dyn:R.dyn, cap:G.cap30, store:localStorage.getItem('pgp_perf')}; });
console.log(JSON.stringify(log));
// 2) con 60 fps limpios debe subir de nuevo (tras >8 s)
const up=await page.evaluate(()=>{ const G=PG.G,R=G.R; G.cap30=false; for(let k=0;k<40;k++) window.__step(60,16.7); return {dyn:R.dyn}; });
console.log('tras 40 s a 60 fps:',JSON.stringify(up));
await browser.close(); process.exit(err?1:0); })();
