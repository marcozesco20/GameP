// reparto de premios: 6 participantes, apuesta 500 -> bote 3000, comision 10 %, 50/30/20
const ctx = require('./load')(['util.js']); let fails = 0;
const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
const CH_RAKE = 0.10, SH = { 1: [1], 2: [0.65, 0.35], 3: [0.5, 0.3, 0.2] }, shares = n => n >= 5 ? SH[3] : (n >= 3 ? SH[2] : SH[1]);
const pr = (stake, n) => { const pool = Math.floor(stake * n * (1 - CH_RAKE)); return shares(n).map(s => Math.floor(pool * s)); };
ok(JSON.stringify(pr(500, 6)) === JSON.stringify([1350, 810, 540]), '6 x 500 -> 1350/810/540 ' + pr(500, 6));
ok(pr(500, 2)[0] === 900, '2 jugadores: el ganador cobra 900 (1000 menos 10 %)');
ok(pr(100, 4).length === 2, '4 participantes: pagan 2 puestos');
process.exit(fails ? 1 : 0);
