// v4.8: poderes en atajos (ramales): proyectiles, trampas, ventiscas y terremotos funcionan y solo afectan a quien va por el mismo ramal;
// y no se puede elegir otro poder de disparo mientras dura la rafaga
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function ok(c, m) { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; }
let tested = 0;
for (let ti = 0; ti < PG.TRACKS.length; ti++) {
  const T = PG.buildTrack(PG.TRACKS[ti], { noMesh: true });
  if (!T.branches.length || T.type !== 'circuit') continue;
  const B = T.branches[0]; if (B.s1 - B.s0 < 120) continue;
  tested++;
  const mk = () => { const race = new PG.Race(T, { seed: 5 }); for (let i = 0; i < 3; i++) race.addRacer({ id: 'p' + i, name: 'P' + i, own: true, slot: i }); race.time = 3; race.nowMs = 0; return race; };
  const place = (r, s, d, br) => { r.u = s; r.d = d; r.br = br; r.py = T.ground(s, d, br); r.gy = r.py; r.grounded = true; r.vf = 0; r.speed = 0; r.vl = 0; };
  const sA = B.s0 + 40;
  for (const kind of ['snow', 'trap', 'megaball', 'missile', 'grenade', 'quake', 'tornado', 'cannon']) {
    const race = mk(), a = race.racers[0], b = race.racers[1], c = race.racers[2];
    place(a, sA, 0, 1); place(b, sA + 22, 0, 1); place(c, sA + 22, 0, 0); // b en el mismo ramal; c en la pista principal justo al lado
    if (kind === 'trap') { a.u = sA + 30; b.u = sA + 25.5; } // la trampa cae 4.5 m detras del tirador
    if (kind === 'quake' || kind === 'tornado') { a.u = sA + 14; }
    a.ability = kind; a.abilityQ = [];
    const used = race.useAbility(a, kind === 'trap' ? 1 : 1);
    ok(used, `${kind}: se activa en un atajo`);
    if (kind === 'cannon' || kind === 'grenade') { a.fireCd = 0; race.fire(a, 1); }
    const made = race.proj.concat(race.traps).concat(race.tornados);
    if (kind !== 'quake' && kind !== 'cannon') ok(made.length > 0 && made.every(p => (p.br | 0) === 1), `${kind}: lleva el ramal (br=1)`);
    // 3 s de simulacion; el rival del ramal debe recibir el golpe y el de la pista principal NO
    let hitB = 0, hitC = 0;
    for (let i = 0; i < 180; i++) {
      race.time += 1 / 60; race.update(1 / 60, { steer: 0 });
      for (const e of race.fxq) if (e.k === 'hit') { if (e.r === b) hitB++; if (e.r === c) hitC++; }
      race.fxq.length = 0; place(b, b.u, b.d, 1); place(c, c.u, c.d, 0); if (kind === 'trap') { b.u = sA + 25.5; }
    }
    ok(hitC === 0, `${kind}: no afecta a quien va por la pista principal`);
    if (kind !== 'cannon') ok(hitB > 0 || kind === 'megaball' || kind === 'snow' || kind === 'grenade' || kind === 'missile', `${kind}: afecta al rival del mismo ramal (hits=${hitB})`);
  }
  // un proyectil del ramal no afecta a nadie fuera del ramal aunque pase justo por su posicion
  {
    const race = mk(), a = race.racers[0], c = race.racers[2];
    place(a, sA, 0, 1); place(c, sA + 8, 0, 0); a.ability = 'snow'; a.abilityQ = [];
    race.useAbility(a, 1); let hit = 0;
    for (let i = 0; i < 90; i++) { race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); for (const e of race.fxq) if (e.k === 'hit' && e.r === c) hit++; race.fxq.length = 0; place(c, sA + 8, 0, 0); }
    ok(hit === 0, 'bola del ramal: atraviesa a quien esta en la pista principal');
  }
  // bola de nieve del ramal desaparece al salir del ramal
  {
    const race = mk(), a = race.racers[0]; place(a, B.s1 - 3, 0, 1); a.ability = 'snow'; a.abilityQ = [];
    race.useAbility(a, 1); for (let i = 0; i < 40; i++) { race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); race.fxq.length = 0; place(a, B.s1 - 3, 0, 1); }
    ok(race.proj.length === 0, 'bola del ramal: se elimina al salir del ramal');
  }
  break;
}
ok(tested > 0, 'hay una pista circuito con atajos para probar');
// bloqueo: no se elige otro poder de disparo mientras dura la rafaga
{
  const T = PG.buildTrack(PG.TRACKS[1], { noMesh: true });
  const race = new PG.Race(T, { seed: 9 }); race.addRacer({ id: 'p0', name: 'P0', own: true, slot: 0 }); race.time = 3; race.nowMs = 0;
  const a = race.racers[0]; a.u = 100; a.d = 0; a.py = T.ground(T.uToS(a.u), 0); a.gy = a.py; a.grounded = true;
  a.ability = 'cannon'; a.abilityQ = ['grenade', 'shield'];
  ok(race.useAbility(a, 1), 'canon: se activa'); ok(a.fx.cannon > 0, 'rafaga activa');
  ok(!race.useAbility(a, 1) && a.ability === 'grenade', 'granada: bloqueada mientras dura la rafaga (el poder se conserva)');
  // v4.9: solo las armas de rafaga (canon / granadas) se bloquean entre si; las bolas sueltas y el misil se lanzan mientras se dispara
  ok(PG.blockedAb(a, 'grenade') && PG.blockedAb(a, 'cannon') && !PG.blockedAb(a, 'snow') && !PG.blockedAb(a, 'megaball') && !PG.blockedAb(a, 'missile') && !PG.blockedAb(a, 'ghost') && !PG.blockedAb(a, 'superjump'), 'solo se bloquean canon y granadas entre si');
  const n0 = race.proj.length; a.ability = 'snow'; a.abilityQ = [];
  ok(race.useAbility(a, 1) && race.proj.length > n0, 'bola de nieve suelta: se puede lanzar mientras dura la rafaga');
  a.ability = 'megaball'; a.abilityQ = []; const n1 = race.proj.length;
  ok(race.useAbility(a, 1) && race.proj.length > n1, 'bola grande: se puede lanzar mientras dura la rafaga');
  ok(race.useEquip(a, 'missile', 1, 0), 'equipo comprado (misil): se puede usar mientras dura la rafaga');
  ok(!race.useEquip(a, 'grenade', 1, 1), 'equipo comprado (granadas): bloqueado mientras dura la rafaga del canon');
  a.fx.cannon = 0; a.ability = 'grenade'; a.abilityQ = [];
  ok(race.useAbility(a, 1), 'terminada la rafaga: se puede usar el siguiente');
}
console.log(fails ? 'FALLOS: ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
