// voz por proximidad: volumen segun la distancia solo en carrera; en la sala vuelve a 1
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => PG.G.startSolo(0));
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const res = await page.evaluate(() => {
    const G = PG.G, V = PG.Voice, rs = G.race.racers, me = G.me, out = {};
    const others = rs.filter(r => r !== me).slice(0, 3);
    V.on = true; G.mp = true;
    const dists = [5, 60, 150];
    others.forEach((r, i) => { V.peers[r.id] = { id: r.id, audio: { volume: 1, muted: false }, gain: { gain: { value: 1 } }, muted: false }; r.u = me.u + dists[i]; r.d = me.d; });
    G.updateProxVoice();
    out.race = others.map(r => +V.peers[r.id].prox.toFixed(3));
    out.vol = others.map(r => +V.peers[r.id].audio.volume.toFixed(3));
    G.mode = 'lobby'; G.updateProxVoice();
    out.lobby = others.map(r => V.peers[r.id].prox);
    out.lobbyVol = others.map(r => V.peers[r.id].audio.volume);
    G.mode = 'race'; V.on = false; V.proxOn = false;
    return out;
  });
  console.log(JSON.stringify(res));
  ok(res.race[0] === 1 && res.race[1] < res.race[0] && res.race[2] < res.race[1], 'volumen baja con la distancia ' + res.race.join(' > '));
  ok(res.vol[2] === res.race[2], 'se aplica al elemento de audio');
  ok(res.lobby.every(x => x === undefined) && res.lobbyVol.every(x => x === 1), 'en la sala de espera todo suena normal');
  ok(!errs.length, 'sin errores ' + errs.join('|'));
  await browser.close(); process.exit(fails ? 1 : 0);
})();
