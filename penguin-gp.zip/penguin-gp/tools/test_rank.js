// orden de resultados estable + regla del 4.º jugador
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function ok(c, m) { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; }
const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true });
const race = new PG.Race(T, { seed: 11 });
for (let i = 0; i < 6; i++) race.addRacer({ id: 'b' + i, name: 'Bot' + i, own: true, bot: true, slot: i });
race.time = 0; race.nowMs = 0;
let t = 0, prev = [], stable = true, evs = [], endAt = -1;
while (t < 300) {
  race.time = t; race.update(1 / 60, null); t += 1 / 60;
  for (const e of race.out) evs.push(e); race.out.length = 0; race.fxq.length = 0;
  const fo = race.finishOrder;
  for (let i = 0; i < prev.length; i++) if (fo[i] !== prev[i]) stable = false;
  prev = fo.slice();
  if (race.ended && endAt < 0) endAt = t;
  if (race.racers.every(r => r.finished)) break;
}
const fo = race.finishOrder.map(r => (r && r.id) || r);
ok(stable, 'el orden de llegada nunca cambia hacia atrás: ' + fo.join(','));
ok(race.ended, 'la carrera termina al llegar el 4.º');
const real = race.racers.filter(r => r.finished && !r.dnf);
ok(real.length === 4, 'solo 4 llegan de verdad (llegaron ' + real.length + ')');
ok(race.racers.filter(r => r.dnf).length === 2, 'los otros 2 quedan como "no llegó"');
ok(evs.some(e => e.k === 'end'), 'se emite el evento de fin');
// el primero en llegar es el rank 1 en el orden final
const firstId = fo[0];
ok(race.racers.find(r => r.id === firstId).finishTime <= Math.min(...real.map(r => r.finishTime)) + 1e-6, 'el primero de la lista tiene el mejor tiempo');
// cliente (no autoritativo): adopta el orden del anfitrión aunque vea a otro pasar la meta antes
const cl = new PG.Race(T, { seed: 11 }); cl.auth = false;
for (let i = 0; i < 6; i++) cl.addRacer({ id: 'b' + i, name: 'Bot' + i, own: i === 5, bot: i === 5, slot: i });
const order = ['b2', 'b0', 'b4', 'b1'];
cl.applyEvent({ k: 'fo', o: order.slice(0, 1) }); cl.applyEvent({ k: 'fo', o: order.slice(0, 2) });
// un remoto pasado de la meta sin evento no debe adelantar al ganador
const endU = T.type === 'circuit' ? cl.laps * T.L : T.D;
cl.byId['b3'].u = endU + 5;
cl.updateRanks();
ok(cl.byId['b2'].rank === 1 && cl.byId['b0'].rank === 2, 'cliente: ganador sigue 1.º y 2.º sigue 2.º');
cl.applyEvent({ k: 'end', o: order.concat(['b3', 'b5']), n: 4 });
ok(cl.ended && cl.byId['b3'].dnf && cl.byId['b5'].dnf && !cl.byId['b2'].dnf, 'cliente: el evento end marca solo al resto como no llegó');
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
