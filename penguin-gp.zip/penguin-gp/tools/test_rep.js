const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']); const PG = ctx.PG;
const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true });
const race = new PG.Race(T, { seed: 9, diff: 1, avalanche: false });
const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
for (let i = 0; i < 5; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
let bad = 0, maxQ = 0, seqs = [];
for (let k = 0; k < 4000; k++) {
  me.rank = 1 + (k % 6); me.ability = null; me.abilityQ = me.abHist ? me.abilityQ : [];
  if (k % 3 === 0) { me.ability = null; me.abilityQ = []; }
  race.giveAbility(me, k % 2 === 0); // alterna azul/violeta
  const all = [me.ability].concat(me.abilityQ).filter(Boolean); const cnt = {}; all.forEach(a => cnt[a] = (cnt[a] || 0) + 1);
  if (Object.values(cnt).some(c => c > 2)) bad++;
  const h = me.abHist; if (h.length >= 3 && h[h.length - 1] === h[h.length - 2] && h[h.length - 2] === h[h.length - 3]) bad++;
}
console.log(bad ? 'FAIL repeticiones: ' + bad : 'OK   nunca mas de 2 iguales (cola) ni 3 seguidos', '| cajas pista0', T.boxes.length, 'cristales', T.crys.length);
