// v3.1: escudo electrico y de rebote, trampa siempre atras, un solo escudo a la vez
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk() {
  const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true });
  const race = new PG.Race(T, { seed: 3 });
  const a = race.addRacer({ id: 'a', own: true, local: true, slot: 0 }), b = race.addRacer({ id: 'b', own: true, slot: 1 });
  race.time = 0; return { T, race, a, b };
}
function place(r, u, d) { r.u = u; r.d = d; r.vf = 20; r.py = r.gy = 0; r.grounded = true; r.fx.spin = 0; r.hitCd = 0; }
function step(race, n) { for (let i = 0; i < n; i++) { race.time += 1 / 60; race.update(1 / 60, {}); race.fxq.length = 0; race.out.length = 0; } }
{ const { race, a, b } = mk(); step(race, 20);
  a.ability = 'eshield'; a.abilityQ = []; check('eshield: se activa', race.useAbility(a, 1) === true && a.fx.shield > 0 && a.shType === 1);
  a.ability = 'bshield'; check('un solo escudo: ni electrico ni rebote encima', race.useAbility(a, 1) === false);
  a.ability = 'shield'; check('un solo escudo: ni el normal encima', race.useAbility(a, 1) === false);
}
{ const { race, a, b } = mk(); step(race, 20);
  place(a, 100, 0); place(b, 100.5, 0.4); a.fx.shield = 8; a.shType = 1; a.shHp = 4; b.fx.shield = 0;
  let got = false; for (let i = 0; i < 20 && !got; i++) { race.time += 1 / 60; place(a, a.u, 0); race.update(1 / 60, {}); got = race.fxq.some(e => e.k === 'shock' || (e.k === 'hit' && e.kind === 'shock')); race.fxq.length = 0; }
  check('electrico: el que toca se electrocuta', got && b.fx.spin > 0);
}
{ const { race, a, b } = mk(); step(race, 20);
  place(a, 100, 0); place(b, 100.5, 0.4); a.fx.shield = 8; a.shType = 1; a.shHp = 4; b.fx.shield = 8; b.shType = 0; b.shHp = 4;
  for (let i = 0; i < 20; i++) { race.time += 1 / 60; place(a, a.u, 0); b.fx.shield = 8; race.update(1 / 60, {}); race.fxq.length = 0; }
  check('electrico: contra escudo normal solo lo gasta', b.fx.spin === 0 && b.shHp < 4);
}
{ const { race, a, b } = mk(); step(race, 20);
  place(b, 200, 0); b.fx.shield = 8; b.shType = 2; b.shHp = 4; const n0 = race.proj.length;
  const hit = PG.applyHit(race, b, 'snow');
  check('rebote: la bola no hace dano', hit === false && b.fx.spin === 0);
  check('rebote: sale una bola nueva con el escudo como dueno', race.proj.length === n0 + 1 && race.proj[race.proj.length - 1].owner === 'b');
  let dirs = {}; for (let i = 0; i < 40; i++) { b.bnCd = 0; b.fx.shield = 8; b.shHp = 4; PG.applyHit(race, b, 'snow'); dirs[race.proj[race.proj.length - 1].dir] = 1; }
  check('rebote: sale en ambas direcciones (tambien hacia atras)', dirs[1] && dirs[-1]);
}
{ const { race, a, b } = mk(); step(race, 20);
  place(a, 300, 0); a.fx.shield = 0; place(b, 301, 1); b.fx.shield = 8; b.shType = 2; b.shHp = 4;
  let moved = false; for (let k = 0; k < 20 && !moved; k++) { a.hitCd = 0; place(a, 300, 0); a.vl = 0; const vl0 = 0; race.push(a, 1); race.time += 1 / 60; race.update(1 / 60, {}); if (Math.abs(a.vl) > 3) moved = true; race.fxq.length = 0; race.out.length = 0; b.fx.shield = 8; b.shHp = 4; a.pushCd = 0; }
  check('rebote: el empujon vuelve al que empuja', moved);
}
{ const { race, a, b } = mk(); step(race, 20);
  a.ability = 'trap'; a.abilityQ = []; place(a, 150, 0); const u0 = a.u;
  race.useAbility(a, 1); const tr = race.traps[race.traps.length - 1];
  check('trampa: siempre detras (aim adelante)', tr && tr.u < u0);
  a.ability = 'trap'; race.useAbility(a, -1); const tr2 = race.traps[race.traps.length - 1];
  check('trampa: siempre detras (aim atras)', tr2.u < u0);
  check('trampa: no apunta', PG.canAimBack(a, 'trap') === false);
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
