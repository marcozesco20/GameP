// v3.9: reglas de choque entre campos de fuerza
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk(n, seed) {
  const T = PG.buildTrack(PG.TRACKS[0], { noMesh: true });
  const race = new PG.Race(T, { seed: seed || 5 }); const rs = [];
  for (let i = 0; i < (n || 2); i++) rs.push(race.addRacer({ id: 'r' + i, own: true, local: i === 0, slot: i }));
  race.time = 0; for (let i = 0; i < 20; i++) { race.time += 1 / 60; race.update(1 / 60, {}); race.fxq.length = 0; }
  return { T, race, rs };
}
function place(r, u, d, vf) { r.u = u; r.d = d; r.vf = vf === undefined ? 20 : vf; r.py = r.gy = 0; r.grounded = true; r.fx.spin = 0; r.hitCd = 0; r.vl = 0; }
function sh(r, t) { r.fx.shield = 8; r.shType = t; r.shHp = 4; }
function run(race, n, f) { const ev = []; for (let i = 0; i < n; i++) { if (f) f(i); race.time += 1 / 60; race.update(1 / 60, {}); for (const e of race.fxq) ev.push(e); race.fxq.length = 0; race.out.length = 0; } return ev; }
// 1) electrico vs normal: se drenan los dos mientras se tocan
{ const { race, rs: [a, b] } = mk(); place(a, 100, 0); place(b, 100.5, 0.4); sh(a, 1); sh(b, 0);
  run(race, 60, () => { place(a, 100, 0); place(b, 100.5, 0.4); a.fx.shield = 8; b.fx.shield = 8; });
  check('electrico vs normal: el normal pierde mas que el electrico', b.shHp < a.shHp && a.shHp < 4, 'a=' + a.shHp.toFixed(2) + ' b=' + b.shHp.toFixed(2));
  check('electrico vs normal: nadie queda aturdido', b.fx.spin === 0 && a.fx.spin === 0);
  run(race, 200, () => { place(a, 100, 0); place(b, 100.5, 0.4); if (a.fx.shield > 0) a.fx.shield = 8; if (b.fx.shield > 0) b.fx.shield = 8; });
  check('electrico vs normal: el normal acaba rompiendose', !(b.fx.shield > 0));
}
// 1b) sin contacto no se gastan
{ const { race, rs: [a, b] } = mk(); place(a, 100, 0); place(b, 140, 0); sh(a, 1); sh(b, 0);
  run(race, 60, () => { place(a, 100, 0); place(b, 140, 0); a.fx.shield = 8; b.fx.shield = 8; });
  check('sin tocarse no hay descarga', a.shHp === 4 && b.shHp === 4);
}
// 2) electrico vs rebote: sale un rayo; electrocuta a uno desprotegido cercano, a uno con escudo no
{ let shocked = 0, arcs = 0, trials = 40;
  for (let t = 0; t < trials; t++) {
    const { race, rs: [a, b, c] } = mk(3, 11 + t); place(a, 100, 0); place(b, 100.5, 0.4); place(c, 108, 2); sh(a, 1); sh(b, 2); c.fx.shield = 0;
    const ev = run(race, 6, () => { place(a, 100, 0); place(b, 100.5, 0.4); c.hitCd = 0; c.fx.spin = 0; if (c.u < 0) place(c, 108, 2); });
    if (ev.some(e => e.k === 'arc')) arcs++; if (c.shockT > 0 || ev.some(e => e.k === 'shock')) shocked++;
  }
  check('electrico vs rebote: sale rayo', arcs === trials, arcs + '/' + trials);
  check('electrico vs rebote: a veces electrocuta al desprotegido, a veces no', shocked > 0 && shocked < trials, shocked + '/' + trials);
}
{ const { race, rs: [a, b, c] } = mk(3); place(a, 100, 0); place(b, 100.5, 0.4); place(c, 106, 2); sh(a, 1); sh(b, 2); sh(c, 0);
  let sh0 = c.shHp, shocked = false;
  for (let t = 0; t < 30; t++) { const e = run(race, 3, () => { place(a, 100, 0); place(b, 100.5, 0.4); a.fx.shield = 8; b.fx.shield = 8; c.fx.shield = 8; place(c, 106, 2); a.elecHit = {}; }); if (c.fx.spin > 0 || c.shockT > 0) shocked = true; }
  check('rayo contra un escudo: no electrocuta', !shocked);
}
// 3) normal vs rebote: rebotan, sin aturdir ni perder velocidad
{ const { race, rs: [a, b] } = mk(); place(a, 100, 0, 25); place(b, 100.5, 0.4, 25); sh(a, 0); sh(b, 2);
  const v0 = a.vf; let maxvl = 0;
  run(race, 20, () => { a.fx.shield = 8; b.fx.shield = 8; a.hitCd = 0; b.hitCd = 0; });
  maxvl = Math.max(Math.abs(a.vl), Math.abs(b.vl));
  check('normal vs rebote: se separan (rebotan)', Math.abs(a.d - b.d) > 0.4 || maxvl > 1, 'dd=' + (a.d - b.d).toFixed(2) + ' vl=' + maxvl.toFixed(1));
  check('normal vs rebote: sin aturdir', a.fx.spin === 0 && b.fx.spin === 0);
  check('normal vs rebote: sin perder velocidad', a.vf > 24 && b.vf > 24, a.vf.toFixed(1) + ' ' + b.vf.toFixed(1));
  check('normal vs rebote: los escudos no se gastan', a.shHp === 4 && b.shHp === 4);
}
// 4) sin escudos el choque normal sigue frenando al mas rapido
{ const { race, rs: [a, b] } = mk(); place(a, 100, 0, 30); place(b, 100.4, 0.3, 10); const v0 = a.vf;
  run(race, 10, () => { a.fx.shield = 0; b.fx.shield = 0; });
  check('sin escudos: el mas rapido se frena al chocar', a.vf < v0, a.vf.toFixed(1));
}
console.log(fails ? fails + ' FALLOS' : 'TODO OK'); process.exit(fails ? 1 : 0);
