const PG_PTS_X = 500;
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 }); await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/shop_menu.png` });
  ok(await page.evaluate(() => PG.Eco.data.coins === 0), 'empiezas con 0 monedas');
  await page.click('[data-act=shop]'); await page.waitForTimeout(300);
  // sin dinero no se puede comprar
  ok(await page.evaluate(() => document.querySelector('[data-act=shopBuy][data-k=missile]').disabled), 'sin monedas el boton de comprar esta desactivado');
  ok(!(await page.evaluate(() => PG.Eco.buy('missile').ok)), 'comprar sin monedas falla');
  await page.evaluate(() => { PG.Eco.data.coins = 1500; PG.Eco.renderShop(); });
  // comprar con confirmacion
  await page.click('[data-act=shopBuy][data-k=hyper]'); await page.waitForTimeout(100);
  ok(await page.evaluate(() => PG.Eco.own('hyper') === 0), 'el primer toque solo pide confirmacion');
  await page.click('[data-act=shopBuy][data-k=hyper]'); await page.waitForTimeout(100);
  ok(await page.evaluate(() => PG.Eco.own('hyper') === 1 && PG.Eco.data.coins === 1500 - 380), 'segundo toque compra (cuesta 380)');
  for (let i = 0; i < 5; i++) await page.evaluate(() => PG.Eco.buy('hyper'));
  ok(await page.evaluate(() => PG.Eco.own('hyper') === 3), 'maximo 3 por poder (inventario)');
  ok(await page.evaluate(() => !PG.Eco.buy('hyper').ok && PG.Eco.data.coins >= 0), 'el 4º no se puede comprar y no cobra');
  await page.evaluate(() => { PG.Eco.data.coins = 1500; PG.Eco.buy('shield'); PG.Eco.buy('megaball'); PG.Eco.renderShop(); });
  await page.click('[data-act=shopEq][data-k=hyper]'); await page.click('[data-act=shopEq][data-k=shield]');
  ok(await page.evaluate(() => PG.Eco.data.load.join() === 'hyper,shield'), 'equipo inicial: 2 ranuras');
  ok(await page.evaluate(() => !PG.Eco.toggleLoad('megaball')), 'no cabe un tercero en el equipo');
  await page.waitForTimeout(200); await page.screenshot({ path: `${OUT}/shop.png` });
  await page.evaluate(() => { document.querySelector('#shopGrid').scrollTop = 0; });
  // carrera: el equipo se carga y se gasta
  await page.evaluate(() => { PG.G.nav = ['scrMain']; PG.G.startSolo(1); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race, null, { timeout: 90000 });
  const st = await page.evaluate(() => ({ ab: PG.G.me.ability, q: PG.G.me.abilityQ.join(), hy: PG.Eco.own('hyper'), sh: PG.Eco.own('shield'), load: PG.Eco.data.load.join() }));
  ok(st.ab === 'hyper' && st.q === 'shield' && st.hy === 2 && st.sh === 0, 'al empezar: habilidad ' + JSON.stringify(st));
  // combos: eventos de pirueta dan monedas
  await page.evaluate(() => { PG.G.goAt -= 8000; });
  await page.waitForTimeout(800);
  await page.evaluate(() => { const me = PG.G.me; PG.G.race.fxq.push({ k: 'trick', id: me.id, r: me, n: 1 }); PG.G.race.fxq.push({ k: 'trick', id: me.id, r: me, n: 3 }); });
  await page.waitForTimeout(3500);
  const rcj = await page.evaluate(() => JSON.stringify(PG.G.raceCoins)); console.log('rc', rcj);
  ok(await page.evaluate(() => PG.G.raceCoins.combo === 2 + 12 && PG.G.raceCoins.tricks === 4), 'combos suman monedas (1 giro=2, 3 giros=12)');
  await page.screenshot({ path: `${OUT}/shop_chip.png` });
  // meta en 2º puesto: monedas = combos + 35
  const before = await page.evaluate(() => PG.Eco.data.coins);
  await page.evaluate(() => {
    const G = PG.G, R = G.race, T = G.T, endU = T.type === 'circuit' ? R.laps * T.L : T.D;
    R.racers.forEach(r => { if (r.bot && r.slot === 1) { r.u = endU + 1; } });
  });
  await page.waitForFunction(() => PG.G.race.racers.some(r => r.bot && r.finished), null, { timeout: 20000 });
  await page.evaluate(() => { const G = PG.G, T = G.T, R = G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; G.me.u = endU + 1; if (T.type === 'circuit') G.me.lap = R.laps; });
  await page.waitForFunction(() => PG.G.resCoins, null, { timeout: 20000 });
  const rc = await page.evaluate(() => ({ rc: PG.G.resCoins, now: PG.Eco.data.coins, hist: PG.G.stats.hist.slice(-1)[0], pts: PG.G.stats.points }));
  console.log(JSON.stringify(rc));
  ok(rc.rc.rank === 2 && rc.rc.place === 35 && rc.rc.combo === 14 && rc.now - before === 49, '2º puesto: 35 + 14 de combos = +49 monedas');
  ok(rc.rc.points === (7 + 2) * PG_PTS_X, 'puntos v2.9: (7 por el 2º + 2 por giros) x500 = ' + (7 + 2) * PG_PTS_X);
  await page.waitForSelector('#scrResults.show', { timeout: 20000 });
  await page.waitForTimeout(400); await page.screenshot({ path: `${OUT}/shop_results.png` });
  console.log('errores', errs); ok(!errs.length, 'sin errores JS');
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK');
  await browser.close(); process.exit(fails ? 1 : 0);
})();
