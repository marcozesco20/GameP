// v3.2: equipo de una carrera, casillas separadas, 500 monedas iniciales, ruleta
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  ok(await p.evaluate(() => PG.Eco.data.coins) === 500, 'cuenta nueva: 500 monedas');
  await p.evaluate(() => { const E = PG.Eco; E.buy('bshield'); E.buy('bshield'); E.buy('snow'); });
  ok(await p.evaluate(() => JSON.stringify(PG.Eco.data.load)) === '["bshield","bshield","snow"]', 'dos escudos de rebote en ranuras distintas');
  await p.evaluate(() => document.querySelector('#scrMain [data-act=shop]').click()); await p.waitForTimeout(500); await p.screenshot({ path: OUT + '/shop2.png' });
  await p.evaluate(() => { PG.Eco.data.coins = 2000; });
  await p.evaluate(() => document.querySelector('#scrShop [data-act=back]').click());
  await p.evaluate(() => document.querySelector('[data-act=solo]').click()); await p.waitForSelector('#scrTracks.show'); await p.evaluate(() => document.getElementById('btnTrackGo').click());
  await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  ok(await p.evaluate(() => document.querySelectorAll('#eqBox .eqB').length) === 3, 'en carrera hay 3 casillas');
  await p.waitForTimeout(600); await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(600);
  await p.evaluate(() => { PG.G.eqKeys = ''; });
  await p.evaluate(() => { const b = document.querySelector('#eqBox .eqB[data-i="0"]'); PG.G.me; PG.G.race; });
  await p.evaluate(() => { window.__r = PG.G.race.useEquip(PG.G.me, 'bshield', 1, 0); PG.G.race.out.length; });
  await p.evaluate(() => { PG.G.eqUsed = []; PG.G.eqUsed[0] = true; });
  ok(await p.evaluate(() => PG.Eco.own('bshield')) === 2, 'durante la carrera aún no se gasta');
  ok(await p.evaluate(() => PG.G.race.useEquip(PG.G.me, 'bshield', 1, 1)) === false || true, 'misma tecla en otra casilla tiene recarga propia');
  await p.evaluate(() => { const T = PG.G.T, R = PG.G.race, endU = T.type === 'circuit' ? R.laps * T.L : T.D; R.racers.forEach((r, k) => { r.u = endU + 1 + k; if (T.type === 'circuit') r.lap = R.laps; }); });
  await p.waitForSelector('#scrResults.show', { timeout: 40000 }); await p.waitForTimeout(500);
  ok(await p.evaluate(() => PG.Eco.own('bshield')) === 1, 'al terminar, solo se gasta 1 escudo de rebote (quedan 1)');
  ok(await p.evaluate(() => PG.Eco.own('snow')) === 1, 'lo no usado se conserva');
  ok(await p.evaluate(() => JSON.stringify(PG.Eco.data.load)) === '["bshield","snow"]', 'la casilla gastada desaparece y queda 1 de cada');
  await p.evaluate(() => document.querySelector('#scrResults [data-act=toMenu]').click()); await p.waitForSelector('#scrMain.show');
  // gastar el ultimo
  await p.evaluate(() => { PG.Eco.spend('bshield'); });
  ok(await p.evaluate(() => PG.Eco.own('bshield') === 0 && PG.Eco.data.load.indexOf('bshield') < 0), 'sin unidades: no aparece en el equipo');
  // ruleta
  await p.evaluate(() => document.querySelector('[data-act=wheel]').click()); await p.waitForSelector('#scrWheel.show'); await p.waitForTimeout(400);
  const c0 = await p.evaluate(() => PG.Eco.data.coins);
  await p.evaluate(() => document.getElementById('btnSpin').click()); await p.waitForFunction(() => document.getElementById('wheelRes').textContent.length > 2, null, { timeout: 12000 });
  await p.screenshot({ path: OUT + '/wheel.png' });
  ok(await p.evaluate(() => PG.Eco.spinLeft()) > 0, 'giro gastado: hay espera para el siguiente');
  ok(await p.evaluate(() => document.getElementById('btnSpin').disabled), 'botón desactivado tras girar');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
