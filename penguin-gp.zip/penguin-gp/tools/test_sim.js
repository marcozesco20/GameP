const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG;
const only = process.argv[2] !== undefined ? +process.argv[2] : -1;
const nBots = +(process.argv[3] || 6);
for (const def of PG.TRACKS) {
  if (only >= 0 && def.id !== only) continue;
  const T = PG.buildTrack(def, { noMesh: true });
  const race = new PG.Race(T, { seed: 7 });
  for (let i = 0; i < nBots; i++) race.addRacer({ id: 'b' + i, name: 'Bot' + i, own: true, bot: true, slot: i });
  race.time = 0; race.nowMs = 0;
  const dt = 1 / 60; let t = 0, maxSpeed = 0, evs = {};
  while (t < 300) {
    race.time = t; race.update(dt, null); t += dt;
    for (const e of race.fxq) evs[e.k] = (evs[e.k] || 0) + 1; race.fxq.length = 0; race.out.length = 0;
    for (const r of race.racers) maxSpeed = Math.max(maxSpeed, r.speed);
    if (race.racers.every(r => r.finished)) break;
  }
  const fin = race.racers.map(r => r.finished ? r.finishTime.toFixed(1) : 'DNF(' + r.u.toFixed(0) + ')').join(' ');
  console.log(`${def.id} ${def.name.padEnd(24)} t=${t.toFixed(0)}s vmax=${maxSpeed.toFixed(0)} | ${fin}`);
  console.log('    caidas:', race.racers.map(r => r.falls).join(','), ' eventos:', JSON.stringify(evs));
}
