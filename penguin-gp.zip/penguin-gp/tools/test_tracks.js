const ctx = require('./load')(['util.js', 'tracks.js']);
const PG = ctx.PG;
for (const def of PG.TRACKS) {
  const t0 = Date.now();
  const T = PG.buildTrack(def, { noMesh: true });
  let minR = 1e9, minAt = 0, maxSlope = 0, minY = 1e9, maxY = -1e9;
  for (let i = 0; i < T.N; i++) { const k = Math.abs(T.cv[i]); if (k > 1e-6 && 1 / k < minR) { minR = 1 / k; minAt = i; } maxSlope = Math.max(maxSlope, Math.abs(T.sl[i])); minY = Math.min(minY, T.py[i]); maxY = Math.max(maxY, T.py[i]); }
  // auto-interseccion: muestras lejanas en distancia de pista pero cercanas en el espacio
  let minGap = 1e9, gi = 0, gj = 0;
  for (let i = 0; i < T.N; i += 3) for (let j = i + 1; j < T.N; j += 3) {
    let ds = (j - i) * T.ds; if (T.closed) ds = Math.min(ds, T.L - ds);
    if (ds < 140) continue;
    const d = Math.hypot(T.px[i] - T.px[j], T.pz[i] - T.pz[j]);
    if (d < minGap) { minGap = d; gi = i; gj = j; }
  }
  console.log(`${def.id} ${def.name.padEnd(24)} ${T.type.padEnd(7)} L=${T.L.toFixed(0)}m D=${T.D.toFixed(0)}m minRadio=${minR.toFixed(0)}m(en s=${(minAt*T.ds).toFixed(0)}) pend.max=${(maxSlope*100).toFixed(0)}% y=[${minY.toFixed(0)},${maxY.toFixed(0)}] sep.min=${minGap.toFixed(0)}m`);
  console.log(`    saltos/huecos=${T.holes.length} rampas=${T.ramps.length} obst=${T.obs.length} cajas=${T.boxes.length} pads=${T.pads.length} cristales=${T.crys.length}  (${Date.now()-t0}ms)`);
}
