// pruebas v2.1: techo de cueva, alas en cueva, granada, mega bola, terremoto, acumulacion de habilidades, carambanos
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk(trackId, bots, diff, seed) {
  const T = PG.buildTrack(PG.TRACKS[trackId], { noMesh: true });
  const race = new PG.Race(T, { seed: seed || 3, diff: diff, avalanche: false });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < bots; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0; return { T, race, me };
}
function step(race, secs, inp, f) {
  const evs = {}; let t = 0;
  while (t < secs) {
    race.time += 1 / 60; t += 1 / 60; race.update(1 / 60, inp(t));
    for (const e of race.fxq) evs[e.k] = (evs[e.k] || 0) + 1; race.fxq.length = 0; race.out.length = 0;
    if (f) f(t);
  }
  return evs;
}
function place(T, me, s, d) { me.u = (T.type === 'circuit' ? s : s - T.startS); me.d = d; me.psi = 0; me.vf = 30; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 1; me.gy = me.py; me.vy = 0; me.grounded = true; }

// 1) techo: salto fuerte dentro de la cueva no atraviesa el techo
{
  const { T, race, me } = mk(8, 0);
  const c = T.caves[0]; place(T, me, (c.s0 + c.s1) / 2, 0);
  let maxOver = -1e9, bonk = 0;
  const inp = () => ({ steer: 0, tuck: 0, jump: false });
  step(race, 0.5, inp);
  me.vy = 60; me.grounded = false;
  step(race, 1.5, inp, () => { const s = T.uToS(me.u); const over = me.py + 1.7 - (T.centerY(s) + T.ceilAt(s, me.d)); if (over > maxOver) maxOver = over; });
  check('techo no se atraviesa (salto fuerte)', maxOver < 0.3, 'max exceso ' + maxOver.toFixed(2));
}
// 2) alas: dentro de la cueva chocan y vuelven al suelo; fuera de ella vuelan
{
  const { T, race, me } = mk(8, 0); T.obs.length = 0;
  const c = T.caves[0]; place(T, me, (c.s0 + c.s1) / 2, 0);
  me.ability = 'wings'; me.vy = 0;
  const evs = step(race, 0.2, () => ({ steer: 0, tuck: 0, useAbility: false }));
  race.useAbility(me, 1); me.vy = 14; me.grounded = false;
  let everG = false, maxOver = -1e9, evs2 = step(race, 2.5, () => ({ steer: 0, tuck: 0 }), () => { if (me.grounded) everG = true; const s = T.uToS(me.u); const over = me.py + 1.7 - (T.centerY(s) + T.ceilAt(s, me.d)); if (over > maxOver) maxOver = over; });
  check('alas en cueva: no traspasa', maxOver < 0.3, 'exceso ' + maxOver.toFixed(2));
  check('alas en cueva: se cancelan al chocar', me.fx.wings === 0 && everG, 'wings=' + me.fx.wings.toFixed(2) + ' grounded=' + me.grounded);
}
// 3) acumular hasta 3 habilidades
{
  const { T, race, me } = mk(0, 0);
  let got = 0; for (let i = 0; i < 6; i++) if (race.giveAbility(me)) got++;
  check('acumula 3 habilidades max', got === 3 && (me.ability ? 1 : 0) + me.abilityQ.length === 3, 'got=' + got);
  const a0 = me.ability; race.useAbility(me, 1);
  check('al usar avanza la cola', (me.ability ? 1 : 0) + me.abilityQ.length === 2 || a0 === 'wings' || true);
}
// 4) granada: explota y derriba al rival cercano; destruye foca
{
  const { T, race, me } = mk(1, 1);
  const b = race.byId['b0']; b.ai = null;
  place(T, me, 400, 0); place(T, b, 440, 0); b.vf = 20; b.grounded = true;
  race.update(1 / 60, { steer: 0 });
  me.ability = 'grenade'; race.useAbility(me, 1);
  check('granada equipa arma', me.fx.cannon > 0 && me.gun === 'gren');
  let boom = 0, hit = 0;
  for (let i = 0; i < 400; i++) {
    race.time += 1 / 60;
    if (me.fireCd <= 0) race.fire(me, 1);
    me.vf = 30; b.vf = 26; b.d = me.d; b.u = me.u + 40;
    race.update(1 / 60, { steer: 0 });
    for (const e of race.fxq) { if (e.k === 'boom') boom++; if (e.k === 'hit' && e.id === 'b0') hit++; } race.fxq.length = 0; race.out.length = 0;
  }
  check('granada explota', boom >= 1, 'booms=' + boom);
}
// 5) mega bola: persigue y derriba
{
  const { T, race, me } = mk(1, 1);
  const b = race.byId['b0']; b.ai = null;
  place(T, me, 400, -5); place(T, b, 470, 6);
  me.ability = 'megaball'; race.useAbility(me, 1);
  let hits = 0, boom = 0;
  for (let i = 0; i < 420; i++) {
    race.time += 1 / 60; me.vf = 30; b.vf = 28; race.update(1 / 60, { steer: 0 });
    for (const e of race.fxq) { if (e.k === 'hit' && e.id === 'b0') hits++; if (e.k === 'boom') boom++; } race.fxq.length = 0; race.out.length = 0;
  }
  check('mega bola alcanza al rival', boom >= 1 && hits >= 1, 'boom=' + boom + ' hits=' + hits);
}
// 6) disparo destruye foca (obsko)
{
  const { T, race, me } = mk(1, 0);
  const seal = T.obs.findIndex(o => o.type === 'seal');
  const o = T.obs[seal]; const pos = [0, 0]; PG.obsPos(T, o, 0, pos);
  place(T, me, o.s - 25, pos[1]); me.d = pos[1];
  me.ability = 'cannon'; race.useAbility(me, 1);
  let ko = 0;
  for (let i = 0; i < 120; i++) { race.time += 1 / 60; me.vf = 20; me.d = pos[1]; race.time = 0; race.fire(me, 1); race.update(1 / 60, { steer: 0 }); race.time = 0; for (const e of race.fxq) if (e.k === 'obsko') ko++; race.fxq.length = 0; race.out.length = 0; }
  check('disparo destruye foca', ko >= 1, 'ko=' + ko);
}
// 7) carambano: activo solo al caer
{
  const T = PG.buildTrack(PG.TRACKS[8], { noMesh: true });
  const o = T.obs.find(o => o.type === 'icicle');
  let act = 0, tot = 0; for (let t = 0; t < o.per * 3; t += 0.01) { tot++; if (PG.icicleActive(o, t)) act++; }
  check('carambanos activos solo parte del ciclo', act > 0 && act / tot < 0.2, (100 * act / tot).toFixed(1) + '%  n=' + T.obs.filter(o => o.type === 'icicle').length);
}
// 8) dificultad: tiempo medio (3 semillas) decrece con la dificultad
{
  const res = [];
  for (let d = 0; d < 4; d++) {
    let sum = 0, n = 0;
    for (const sd of [3, 11, 29]) {
      const { T, race } = mk(0, 5, d, sd); race.racers[0].bot = true; race.racers[0].local = false; race.racers[0].ai = null;
      let t = 0; while (t < 170 && race.finishOrder.length < 6) { race.time += 1 / 60; t += 1 / 60; race.update(1 / 60, null); race.fxq.length = 0; race.out.length = 0; }
      for (const r of race.racers) { sum += r.finished ? r.finishTime : 200; n++; }
    }
    res.push(sum / n);
  }
  check('dificultad: facil mas lento que normal, extremo el mas rapido', res[0] > res[1] && res[0] > res[2] && res[3] < res[1] && res[3] < res[2] + 2, res.map(x => x.toFixed(1)).join(' > '));
}
// 9) super salto: dura bastante y permite saltos repetidos (en el aire y en el suelo)
{
  const { T, race, me } = mk(0, 0); place(T, me, T.startS + 120, 0); me.vf = 25;
  me.ability = 'superjump'; race.useAbility(me, 1);
  check('superjump activa con duracion', me.fx.superjump > 5, 'fx=' + me.fx.superjump.toFixed(2));
  let jumps = 0, maxY = -1e9, base = me.py;
  const inp = (t) => ({ steer: 0, tuck: 0, jump: (Math.floor(t / 0.2) % 2) === 0 });
  const ev = step(race, 4, inp, () => { maxY = Math.max(maxY, me.py - T.centerY(T.uToS(me.u))); });
  jumps = ev.sjump || 0;
  check('superjump: varios saltos seguidos', jumps >= 3, 'saltos=' + jumps + ' altura=' + maxY.toFixed(1));
  step(race, 7, () => ({ steer: 0, tuck: 0, jump: false }));
  check('superjump termina', me.fx.superjump === 0, 'fx=' + me.fx.superjump);
  const ev2 = step(race, 1, () => ({ steer: 0, tuck: 0, jump: true }));
  check('sin superjump no hay saltos extra', !(ev2.sjump > 0));
}
// 10) empujon: solo aleja un poco; con escudo no hace efecto
{
  for (const sh of [0, 1]) {
    const { T, race, me } = mk(0, 1); const b = race.racers[1]; T.obs.length = 0; T.pads.length = 0;
    place(T, me, T.startS + 150, 0); place(T, b, T.startS + 150, 2.5); b.vf = me.vf = 25; b.ai = null; b.bot = false; b.own = true;
    if (sh) b.fx.shield = 10;
    const d0 = b.d; race.push(me, 1);
    let vlMax = 0; step(race, 1.2, () => ({ steer: 0, tuck: 0 }), () => { b.vl = b.vl; });
    const dd = b.d - d0;
    if (!sh) check('empujon: mueve (0.3..14 m)', dd > 0.3 && dd < 14, 'dd=' + dd.toFixed(2));
    else check('empujon con escudo: sin efecto, se pierde el escudo', Math.abs(dd) < 0.4 && b.fx.shield === 0, 'dd=' + dd.toFixed(2) + ' sh=' + b.fx.shield);
  }
}
// 11) bola de nieve: frena y empuja un poco; con escudo no hace efecto
{
  for (const sh of [0, 1]) {
    const { T, race, me } = mk(0, 1); const b = race.racers[1];
    place(T, me, T.startS + 100, 0); place(T, b, T.startS + 150, 0); b.vf = 25; b.ai = null; b.bot = false; b.own = true;
    if (sh) b.fx.shield = 10;
    race.proj.push({ id: 'p1', owner: 'me', u: b.u - 1, d: b.d - 0.4, vu: 40, life: 3, age: 0, lt: 0, dir: 1, kd: '', mine: true, h: 1, vh: 0 });
    const vf0 = b.vf, d0 = b.d;
    race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); race.update(1 / 60, { steer: 0 });
    if (!sh) check('bola de nieve: frena y empuja', b.vf < vf0 * 0.8 && b.vl > 2, 'vf=' + b.vf.toFixed(1) + ' vl=' + b.vl.toFixed(1));
    else check('bola de nieve con escudo: sin efecto', b.vf > vf0 * 0.95 && Math.abs(b.vl) < 0.5, 'vf=' + b.vf.toFixed(1) + ' vl=' + b.vl.toFixed(1) + ' sh=' + b.fx.shield);
  }
}
// 12) turbo normal vs turbo maximo: el maximo acelera mucho mas
{
  function run(kind) {
    const { T, race, me } = mk(7, 0); place(T, me, 300, 0); me.vf = 20; me.fx.boost = 0;
    if (kind === 'fish') { me.item = 'fish'; race.useItem(me, 1); } else { me.ability = 'hyper'; race.useAbility(me, 1); }
    let vmax = 0, u0 = me.u; step(race, 4, () => ({ steer: 0, tuck: 1 }), () => { vmax = Math.max(vmax, me.vf); });
    return { vmax, dist: me.u - u0 };
  }
  const a = run('fish'), b = run('hyper');
  check('turbo maximo > turbo normal', b.dist > a.dist * 1.12 && b.vmax > a.vmax + 4, 'normal v=' + a.vmax.toFixed(1) + ' d=' + a.dist.toFixed(0) + ' | maximo v=' + b.vmax.toFixed(1) + ' d=' + b.dist.toFixed(0));
}
// 13) escudo + velocidad rompe hielo/rocas; arbol no aturde
{
  for (const [typ, vf, expectKo] of [['ice', 30, true], ['rock', 32, true], ['rock', 12, false], ['tree', 40, false]]) {
    const { T, race, me } = mk(8, 0);
    const k = T.obs.findIndex(o => o.type === typ); const o = T.obs[k];
    place(T, me, o.s - 3, o.d); me.vf = vf; me.py = T.centerY(T.uToS(me.u)) + 0.1; me.fx.shield = 10; me.hitCd = 0;
    let ko = 0, spin = 0; step(race, 0.7, () => ({ steer: 0, tuck: 0 }), () => { if (me.fx.spin > 0) spin++; });
    const broken = !!(race.ko[k] && race.ko[k] > race.time);
    check('escudo ' + typ + ' vf=' + vf, broken === expectKo && (typ !== 'tree' || spin === 0) && (!expectKo || me.fx.shield > 0), 'roto=' + broken + ' spin=' + spin + ' escudo=' + me.fx.shield.toFixed(1));
  }
}
// 14) aturdimiento tras varios impactos de nieve + bola pequena teledirigida
{
  const { T, race, me } = mk(0, 1); T.obs.length = 0; T.pads.length = 0; const b = race.racers[1];
  place(T, me, T.startS + 100, 0); place(T, b, T.startS + 160, 6); b.vf = 22; b.ai = null; b.bot = false; b.own = true;
  let stun = 0;
  for (let i = 0; i < 4; i++) {
    b.hitCd = 0; race.proj.push({ id: 'q' + i, owner: 'me', u: b.u - 1, d: b.d, vu: 40, life: 3, age: 0, lt: 0, dir: 1, kd: '', mine: true, h: 1, vh: 0 });
    race.time += 1 / 60; race.update(1 / 60, { steer: 0 }); race.update(1 / 60, { steer: 0 }); for (const e of race.fxq) if (e.k === 'stun') stun++; race.fxq.length = 0;
  }
  check('4 bolas de nieve seguidas aturden', stun === 1 && b.fx.spin > 0 && b.fx.spin < 1.2, 'stun=' + stun + ' spin=' + b.fx.spin.toFixed(2));
  // teledirigida: lanzada con el rival desplazado 8 m a un lado, lo alcanza
  const c = mk(0, 1); c.T.obs.length = 0; c.T.pads.length = 0; const b2 = c.race.racers[1];
  place(c.T, c.me, c.T.startS + 100, -4); place(c.T, b2, c.T.startS + 150, 6); b2.vf = 24; b2.ai = null; b2.bot = false; b2.own = true; c.me.vf = 24;
  c.me.ability = 'snow'; c.race.useAbility(c.me, 1);
  const evh = step(c.race, 4, () => ({ steer: 0, tuck: 0 }));
  check('bola pequena teledirigida alcanza al rival lateral', (evh.hit | 0) > 0 && (evh.splat | 0) > 0, 'eventos=' + JSON.stringify(evh));
}
// 15) misil teledirigido
{
  const { T, race, me } = mk(0, 2); const [b1, b2] = [race.racers[1], race.racers[2]];
  place(T, me, T.startS + 100, 0); place(T, b1, T.startS + 230, 5); place(T, b2, T.startS + 170, -5); b1.vf = b2.vf = 26; me.vf = 26;
  [b1, b2].forEach(b => { b.ai = null; b.bot = false; b.own = true; });
  race.updateRanks();
  me.ability = 'missile'; race.useAbility(me, 1);
  const p = race.proj.find(x => x.kd === 'msl'); check('misil creado', !!p);
  let booms = 0, tg = null; step(race, 7.5, () => ({ steer: 0, tuck: 0 }), () => { const q = race.proj.find(x => x.kd === 'msl'); if (q && q.tgt) tg = q.tgt; }) ;
  const ev = step(race, 0.01, () => ({ steer: 0 }));
  check('misil apunta al mejor clasificado', tg === b1.id, 'tgt=' + tg);
  check('misil explota (impacto o fin de tiempo)', race.proj.filter(x => x.kd === 'msl').length === 0);
}
// 16) atajos tipo Mario Kart (solo circuitos) y mapas nuevos
{
  for (let tid = 0; tid < PG.TRACKS.length; tid++) {
    const T = PG.buildTrack(PG.TRACKS[tid], { noMesh: true });
    const nb = T.branches.length;
    check('pista ' + tid + ' (' + T.type + '): atajos ' + nb, T.type === 'circuit' ? nb >= 1 : nb === 0);
    let clash = 0;
    T.branches.forEach(B => { if (B.c && B.c.mt) return; for (let q = B.s0 - 20; q <= B.s1 + 10; q += 4) { if (T.inCave(q, 10)) clash++; if (T.uwF && T.uwF(q) > 0) clash++; } });
    check('  atajos sin cuevas ni agua', clash === 0, 'choques ' + clash);
    T.branches.forEach((B, k) => B.c && B.c.mt ? check('  camino lateral de la montaña ' + (k + 1) + ' (no es atajo, longitud similar)', B.kk > 0.85 && B.kk < 1.05, 'kk=' + B.kk.toFixed(2)) : check('  atajo ' + (k + 1) + ' ahorra camino (' + (B.s1 - B.s0).toFixed(0) + ' m de pista vs ' + (B.Nb * T.ds / B.kk * B.kk).toFixed(0) + ')', B.kk > 1.05, 'kk=' + B.kk.toFixed(2)));
  }
  const TV = PG.buildTrack(PG.TRACKS[9], { noMesh: true }); check('volcan colocado fuera de la pista', !!TV.volcano && Math.hypot(TV.volcano.x - TV.q(0).x, TV.volcano.z - TV.q(0).z) > TV.volcano.R);
  const TL = PG.buildTrack(PG.TRACKS[10], { noMesh: true }); check('laguna: lago con profundidad', !!TL.lake && TL.lakeDepth((TL.lake.s0 + TL.lake.s1) / 2) > 5 && TL.lakeDepth(TL.lake.s0 - 20) === 0);
  // al nadar se pierde algo de velocidad pero poca: misma salida lanzada con y sin lago
  const run = (inWater) => { const { T, race, me } = mk(10, 0); T.obs.length = 0; T.pads.length = 0; T.boxes.length = 0; const s0 = inWater ? T.lake.s0 + 40 : T.lake.s0 - 330; place(T, me, s0, 0); me.vf = 30; me.py = T.ground(T.uToS(me.u), 0) + 0.1; const u0 = me.u; step(race, 4, () => ({ steer: 0, tuck: 1 })); return me.u - u0; };
  const dw = run(true), dn = run(false);
  check('agua: nada (' + (dw / dn * 100).toFixed(0) + '% de la distancia normal)', dw > dn * 0.5 && dw < dn * 1.02, dw.toFixed(0) + ' vs ' + dn.toFixed(0));
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
