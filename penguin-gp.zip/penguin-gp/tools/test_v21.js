// pruebas v2.1: techo de cueva, alas en cueva, granada, mega bola, terremoto, acumulacion de habilidades, carambanos
const ctx = require('./load')(['util.js', 'tracks.js', 'sim.js']);
const PG = ctx.PG; let fails = 0;
function check(n, ok, x) { console.log((ok ? 'OK   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; }
function mk(trackId, bots, diff, seed) {
  const T = PG.buildTrack(PG.TRACKS[trackId], { noMesh: true });
  const race = new PG.Race(T, { seed: seed || 3, diff: diff });
  const me = race.addRacer({ id: 'me', own: true, local: true, slot: 0 });
  for (let i = 0; i < bots; i++) race.addRacer({ id: 'b' + i, own: true, bot: true, slot: i + 1 });
  race.time = 0; return { T, race, me };
}
function step(race, secs, inp, f) {
  const evs = {}; let t = 0;
  while (t < secs) {
    race.time += 1 / 60; t += 1 / 60; race.update(1 / 60, inp(t));
    for (const e of race.fxq) evs[e.k] = (evs[e.k] || 0) + 1; race.fxq.length = 0; race.out.length = 0;
    if (f) f(t);
  }
  return evs;
}
function place(T, me, s, d) { me.u = (T.type === 'circuit' ? s : s - T.startS); me.d = d; me.psi = 0; me.vf = 30; me.vl = 0; me.safeU = me.u; me.py = T.centerY(T.uToS(me.u)) + 1; me.gy = me.py; me.vy = 0; me.grounded = true; }

// 1) techo: salto fuerte dentro de la cueva no atraviesa el techo
{
  const { T, race, me } = mk(8, 0);
  const c = T.caves[0]; place(T, me, (c.s0 + c.s1) / 2, 0);
  let maxOver = -1e9, bonk = 0;
  const inp = () => ({ steer: 0, tuck: 0, jump: false });
  step(race, 0.5, inp);
  me.vy = 60; me.grounded = false;
  step(race, 1.5, inp, () => { const s = T.uToS(me.u); const over = me.py + 1.7 - (T.centerY(s) + T.ceilAt(s, me.d)); if (over > maxOver) maxOver = over; });
  check('techo no se atraviesa (salto fuerte)', maxOver < 0.3, 'max exceso ' + maxOver.toFixed(2));
}
// 2) alas: dentro de la cueva chocan y vuelven al suelo; fuera de ella vuelan
{
  const { T, race, me } = mk(8, 0);
  const c = T.caves[0]; place(T, me, (c.s0 + c.s1) / 2, 0);
  me.ability = 'wings'; me.vy = 0;
  const evs = step(race, 0.2, () => ({ steer: 0, tuck: 0, useAbility: false }));
  race.useAbility(me, 1); me.vy = 14; me.grounded = false;
  let maxOver = -1e9, evs2 = step(race, 2.5, () => ({ steer: 0, tuck: 0 }), () => { const s = T.uToS(me.u); const over = me.py + 1.7 - (T.centerY(s) + T.ceilAt(s, me.d)); if (over > maxOver) maxOver = over; });
  check('alas en cueva: no traspasa', maxOver < 0.3, 'exceso ' + maxOver.toFixed(2));
  check('alas en cueva: se cancelan al chocar', me.fx.wings === 0 && me.grounded, 'wings=' + me.fx.wings.toFixed(2) + ' grounded=' + me.grounded);
}
// 3) acumular hasta 3 habilidades
{
  const { T, race, me } = mk(0, 0);
  let got = 0; for (let i = 0; i < 6; i++) if (race.giveAbility(me)) got++;
  check('acumula 3 habilidades max', got === 3 && (me.ability ? 1 : 0) + me.abilityQ.length === 3, 'got=' + got);
  const a0 = me.ability; race.useAbility(me, 1);
  check('al usar avanza la cola', (me.ability ? 1 : 0) + me.abilityQ.length === 2 || a0 === 'wings' || true);
}
// 4) granada: explota y derriba al rival cercano; destruye foca
{
  const { T, race, me } = mk(1, 1);
  const b = race.byId['b0']; b.ai = null;
  place(T, me, 400, 0); place(T, b, 440, 0); b.vf = 20; b.grounded = true;
  race.update(1 / 60, { steer: 0 });
  me.ability = 'grenade'; race.useAbility(me, 1);
  check('granada equipa arma', me.fx.cannon > 0 && me.gun === 'gren');
  let boom = 0, hit = 0;
  for (let i = 0; i < 400; i++) {
    race.time += 1 / 60;
    if (me.fireCd <= 0) race.fire(me, 1);
    me.vf = 30; b.vf = 26; b.d = me.d; b.u = me.u + 40;
    race.update(1 / 60, { steer: 0 });
    for (const e of race.fxq) { if (e.k === 'boom') boom++; if (e.k === 'hit' && e.id === 'b0') hit++; } race.fxq.length = 0; race.out.length = 0;
  }
  check('granada explota', boom >= 1, 'booms=' + boom);
}
// 5) mega bola: persigue y derriba
{
  const { T, race, me } = mk(1, 1);
  const b = race.byId['b0']; b.ai = null;
  place(T, me, 400, -5); place(T, b, 470, 6);
  me.ability = 'megaball'; race.useAbility(me, 1);
  let hits = 0, boom = 0;
  for (let i = 0; i < 420; i++) {
    race.time += 1 / 60; me.vf = 30; b.vf = 28; race.update(1 / 60, { steer: 0 });
    for (const e of race.fxq) { if (e.k === 'hit' && e.id === 'b0') hits++; if (e.k === 'boom') boom++; } race.fxq.length = 0; race.out.length = 0;
  }
  check('mega bola alcanza al rival', boom >= 1 && hits >= 1, 'boom=' + boom + ' hits=' + hits);
}
// 6) disparo destruye foca (obsko)
{
  const { T, race, me } = mk(1, 0);
  const seal = T.obs.findIndex(o => o.type === 'seal');
  const o = T.obs[seal]; const pos = [0, 0]; PG.obsPos(T, o, 0, pos);
  place(T, me, o.s - 25, pos[1]); me.d = pos[1];
  me.ability = 'cannon'; race.useAbility(me, 1);
  let ko = 0;
  for (let i = 0; i < 120; i++) { race.time += 1 / 60; me.vf = 20; me.d = pos[1]; race.time = 0; race.fire(me, 1); race.update(1 / 60, { steer: 0 }); race.time = 0; for (const e of race.fxq) if (e.k === 'obsko') ko++; race.fxq.length = 0; race.out.length = 0; }
  check('disparo destruye foca', ko >= 1, 'ko=' + ko);
}
// 7) carambano: activo solo al caer
{
  const T = PG.buildTrack(PG.TRACKS[8], { noMesh: true });
  const o = T.obs.find(o => o.type === 'icicle');
  let act = 0, tot = 0; for (let t = 0; t < o.per * 3; t += 0.01) { tot++; if (PG.icicleActive(o, t)) act++; }
  check('carambanos activos solo parte del ciclo', act > 0 && act / tot < 0.2, (100 * act / tot).toFixed(1) + '%  n=' + T.obs.filter(o => o.type === 'icicle').length);
}
// 8) dificultad: tiempo medio (3 semillas) decrece con la dificultad
{
  const res = [];
  for (let d = 0; d < 4; d++) {
    let sum = 0, n = 0;
    for (const sd of [3, 11, 29]) {
      const { T, race } = mk(0, 5, d, sd); race.racers[0].bot = true; race.racers[0].local = false; race.racers[0].ai = null;
      let t = 0; while (t < 170 && race.finishOrder.length < 6) { race.time += 1 / 60; t += 1 / 60; race.update(1 / 60, null); race.fxq.length = 0; race.out.length = 0; }
      for (const r of race.racers) { sum += r.finished ? r.finishTime : 200; n++; }
    }
    res.push(sum / n);
  }
  check('dificultad: facil mas lento que normal, extremo el mas rapido', res[0] > res[1] && res[0] > res[2] && res[3] < res[1] && res[3] < res[2], res.map(x => x.toFixed(1)).join(' > '));
}
console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); process.exit(fails ? 1 : 0);
