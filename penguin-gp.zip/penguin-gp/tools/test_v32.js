// v3.2: aviso de impacto, borroso, foto ampliable, escudos, campeonato 3
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
let fails = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await (await browser.newContext({ viewport: { width: 860, height: 400 }, hasTouch: true })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.evaluate(() => PG.G.startSolo(0));
  await p.waitForFunction(() => PG.G.mode === 'race' && PG.G.goAt && !PG.G.demo, null, { timeout: 90000 });
  await p.evaluate(() => { PG.G.goAt -= 8000; }); await p.waitForTimeout(1200);
  // aviso de impacto: lanzo una trampa y pongo a un rival encima
  const r1 = await p.evaluate(() => {
    const G = PG.G, R = G.race, me = G.me, v = R.racers.find(r => r !== me && !r.fell);
    me.ability = 'trap'; me.fx.shield = 0;
    R.doAbility(me, 'trap', 1);
    const tr = R.traps[R.traps.length - 1]; v.u = tr.u; v.d = tr.d; v.py = v.gy !== undefined ? v.gy : v.py; v.grounded = true; v.hitCd = 0; v.fx.shield = 0; v.fx.ghost = 0; tr.age = 2;
    return !!tr;
  });
  await p.waitForFunction(() => document.getElementById('hitNote').classList.contains('show'), null, { timeout: 8000 }).catch(() => {}); await p.waitForTimeout(450);
  ok(await p.evaluate(() => document.getElementById('hitNote').classList.contains('show') && /Le diste/.test(document.getElementById('hitNote').textContent)), 'aviso «¡Le diste a …!» al atrapar a un rival con la trampa');
  console.log(JSON.stringify(await p.evaluate(() => { const e = document.getElementById('hitNote'), c = getComputedStyle(e), b = e.getBoundingClientRect(); return { op: c.opacity, tr: c.transform, x: b.x, y: b.y, w: b.width, h: b.height, vis: c.visibility, disp: c.display, par: getComputedStyle(e.parentNode).display }; })));
  await p.screenshot({ path: OUT + '/v32_hit.png' });
  // borroso
  await p.evaluate(() => { const me = PG.G.me; me.vf = 62; me.speed = 62; });
  await p.waitForTimeout(3500);
  const bl = await p.evaluate(() => { const e = document.getElementById('blurFx'); return { d: getComputedStyle(e).display, o: +getComputedStyle(e).opacity }; });
  ok(bl.d === 'block' && bl.o > 0.2, 'visión borrosa activa a alta velocidad ' + JSON.stringify(bl));
  await p.screenshot({ path: OUT + '/v32_blur.png' });
  // foto ampliable
  await p.evaluate(() => PG.G.quitRace ? 0 : 0); await p.goto('http://localhost:8080/'); await p.waitForSelector('#scrMain.show', { timeout: 60000 });
  await p.evaluate(() => document.querySelector('#scrMain [data-act=friends]').click()); await p.waitForTimeout(500);
  await p.evaluate(() => document.getElementById('frAv').click()); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.getElementById('avBox').classList.contains('show')), 'la foto de perfil se amplía al tocarla');
  await p.screenshot({ path: OUT + '/v32_av.png' });
  ok(await p.evaluate(() => { const e = document.elementFromPoint(innerWidth / 2, innerHeight - 20); return !!(e && e.closest('#avBox')); }), 'el visor recibe toques reales (pointer-events)');
  await p.mouse.click(430, 380);
  ok(await p.evaluate(() => !document.getElementById('avBox').classList.contains('show')), 'tocar de nuevo la cierra');
  ok(errs.length === 0, 'sin errores JS ' + errs.join('|'));
  console.log(fails ? 'FALLOS ' + fails : 'TODO OK'); await browser.close(); process.exit(fails ? 1 : 0);
})();
