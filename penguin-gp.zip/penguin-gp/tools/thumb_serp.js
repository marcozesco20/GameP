const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 400 } })).newPage();
  page.on('pageerror', e => console.log('ERR', String(e))); await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(11); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === 11, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none';
    const G = PG.G, T = G.T, me = G.me; const s0 = T.startS + 2700; me.br = 0; me.u = s0 - T.startS; me.d = 0; me.psi = 0; me.vf = 35; me.vl = 0; me.safeU = me.u; me.py = T.centerY(s0, 0) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
    G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 8 - Math.random() * 14; x.d = (Math.random() - 0.5) * 14; x.br = 0; } });
    G.dbgCamFn = null;
  });
  await page.waitForTimeout(1800);
  await page.screenshot({ path: '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots/t11try.jpg', type: 'jpeg', quality: 80 });
  await browser.close();
})();
