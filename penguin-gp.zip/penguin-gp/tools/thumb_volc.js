const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 640, height: 400 } })).newPage();
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(9); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === 9, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none';
    const G = PG.G, T = G.T, me = G.me, V = T.volcano; const s = T.L - 45; me.br = 0; me.u = s; me.d = 3; me.psi = 0; me.vf = 20; me.vl = 0; me.safeU = s; me.py = T.centerY(s, 0) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
    G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 14 - Math.random() * 8; x.d = (Math.random() - 0.5) * 12; x.br = 0; } });
    G.dbgCamFn = (cam) => { const q = T.q(s, 0); cam.eye[0] = q.x - q.tx * 22 + q.rx * 6; cam.eye[1] = q.y + 6; cam.eye[2] = q.z - q.tz * 22 + q.rz * 6;
      cam.target[0] = (q.x + V.x) / 2 + q.tx * 40 * 0; cam.target[1] = q.y + 55; cam.target[2] = (q.z + V.z) / 2 - 30; cam.fov = 1.1; cam.roll = 0; };
  });
  await page.waitForTimeout(1800);
  await page.screenshot({ path: '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots/t9try.jpg', type: 'jpeg', quality: 80 });
  await browser.close();
})();
