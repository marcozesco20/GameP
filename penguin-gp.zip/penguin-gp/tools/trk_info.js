const PG = require('./load')(['util.js', 'tracks.js']).PG;
for(const d of PG.TRACKS){
  const T=PG.buildTrack(d,{noMesh:true});
  let mx=0,mn=1e9,my=-1e9,cur=0,maxc=0;
  for(let i=0;i<=T.N;i++){mx=Math.max(mx,Math.abs(T.sl[i]));mn=Math.min(mn,T.py[i]);my=Math.max(my,T.py[i]);}
  for(let i=2;i<T.N-2;i++){const c=Math.abs((T.sl[i+2]-T.sl[i-2])/(4*T.ds));maxc=Math.max(maxc,c);}
  let bad=[];
  for(const h of T.holes)for(const c of T.caves)if(h.s1>c.s0-10&&h.s0<c.s1+10)bad.push('hole@'+h.s0.toFixed(0)+' in cave '+c.s0.toFixed(0)+'-'+c.s1.toFixed(0));
  console.log(d.id,d.name.padEnd(24),'L',T.L.toFixed(0),'yrange',(my-mn).toFixed(0),'maxslope%',(mx*100).toFixed(0),'maxcurv',maxc.toFixed(4),'caves',T.caves.map(c=>((c.s1-c.s0)|0)).join(','),bad.join(';'));
}
