const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'v', offs = (process.argv[3] || '-150,-70,-20,30,150').split(',').map(Number), ref = process.argv[4] || 'c0', tid = +(process.argv[5] || 9), BR = +(process.argv[6] || 0);
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,200)); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate((t) => { PG.G.set.ava = false; PG.G.startSolo(t); }, tid);
  await page.waitForFunction((t) => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === t, tid, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; });
  console.log(await page.evaluate(() => { const T = PG.G.T; return JSON.stringify({ caves: T.caves, hall: T.hall, lake: T.lake, L: T.L, branches: T.branches.map(b => [b.s0, b.s1]) }); }));
  for (const o of offs) {
    await page.evaluate(([o, ref, BR]) => {
      const G = PG.G, T = G.T, me = G.me; G.dbgCamFn = null;
      let base = ref === 'c0' ? T.caves[0].s0 : ref === 'hall' ? T.hall.s0 : ref === 'lake' ? T.lake.s0 : +ref;
      const s = T.wrapS(base + o); me.br = BR; me.u = s - T.startS; me.d = 0; me.psi = 0; me.vf = 0.5; me.vl = 0; me.safeU = me.u; me.py = T.ground(s, 0, BR) + 0.3; me.gy = me.py; me.fx.ghost = 99; G.camInit = false;
      G.race.racers.forEach(x => { if (x !== me) { x.u = me.u - 90; x.br = BR; } });
    }, [o, ref, BR]);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/${tag}_${o}.png` });
  }
  console.log(errs.slice(0, 6)); await browser.close();
})();
