const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = '/tmp/claude-0/-home-claude/8a7a08de-a458-59e2-bd62-ee14156321e5/scratchpad/shots';
const tag = process.argv[2] || 'a';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/google/chrome/chrome', headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await (await browser.newContext({ viewport: { width: 800, height: 400 }, hasTouch: true })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,200)); });
  await page.goto('http://localhost:8080/'); await page.waitForSelector('#scrMain.show', { timeout: 60000 });
  await page.evaluate(() => { PG.G.set.ava = false; PG.G.startSolo(9); });
  await page.waitForFunction(() => PG.G.mode === 'race' && PG.G.race && PG.G.trackIdx === 9, null, { timeout: 90000 });
  await page.evaluate(() => { PG.G.goAt -= 6000; document.getElementById('hud').style.display = 'none'; const T = PG.G.T, me = PG.G.me; const s = T.volcano.sc - 600; me.u = s - T.startS; me.safeU = me.u; me.br = 0; me.d = 0; me.vf = 0.5; me.py = T.ground(s,0,0)+0.3; });
  const views = {
    front: (V) => [[V.x - V.ax * 420, V.y + 90, V.z - V.az * 420 + 0], [V.x - V.ax * 200, V.y + 20, V.z - V.az * 200], 0.9],
    front2: (V) => [[V.x - V.ax * 330 + 60, V.y + 25, V.z - V.az * 330 + 60], [V.x - V.ax * 230, V.y + 15, V.z - V.az * 230], 0.9],
    side: (V) => [[V.x + 20, V.y + 140, V.z - 520], [V.x, V.y + 90, V.z], 0.95],
    top: (V) => [[V.x - V.ax * 250, V.y + 520, V.z - V.az * 250 - 80], [V.x, V.y, V.z], 0.9],
    exit: (V) => [[V.x + V.ax * 420, V.y + 90, V.z + V.az * 420], [V.x + V.ax * 200, V.y + 20, V.z + V.az * 200], 0.9],
  };
  for (const k of Object.keys(views)) {
    await page.evaluate(([k, src]) => {
      const G = PG.G, V = G.T.volcano; const f = eval('(' + src + ')'); const [e, t, fov] = f(V);
      G.dbgCamFn = (cam) => { cam.eye[0] = e[0]; cam.eye[1] = e[1]; cam.eye[2] = e[2]; cam.target[0] = t[0]; cam.target[1] = t[1]; cam.target[2] = t[2]; cam.fov = fov; cam.roll = 0; };
    }, [k, views[k].toString()]);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/${tag}_${k}.png` });
  }
  console.log(errs.slice(0, 5)); await browser.close();
})();
