/* Audio sintetizado con WebAudio (sin archivos externos) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var A = PG.Audio = { ctx: null, on: true, master: null, slideGain: null, slideFilt: null, musicOn: true };

  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      var c = A.ctx = new AC();
      A.master = c.createGain(); A.master.gain.value = A.on ? 0.55 : 0; A.master.connect(c.destination);
      // ruido de deslizamiento
      var len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      A.noiseBuf = buf;
      var src = c.createBufferSource(); src.buffer = buf; src.loop = true;
      A.slideFilt = c.createBiquadFilter(); A.slideFilt.type = 'bandpass'; A.slideFilt.frequency.value = 900; A.slideFilt.Q.value = 0.7;
      A.slideGain = c.createGain(); A.slideGain.gain.value = 0;
      src.connect(A.slideFilt); A.slideFilt.connect(A.slideGain); A.slideGain.connect(A.master); src.start();
      // viento de ventisca
      var ws = c.createBufferSource(); ws.buffer = buf; ws.loop = true; ws.loopStart = 0.37;
      A.windFilt = c.createBiquadFilter(); A.windFilt.type = 'bandpass'; A.windFilt.frequency.value = 400; A.windFilt.Q.value = 0.6;
      A.windGain = c.createGain(); A.windGain.gain.value = 0;
      ws.connect(A.windFilt); A.windFilt.connect(A.windGain); A.windGain.connect(A.master); ws.start();
    } catch (e) { A.ctx = null; }
  };
  A.setOn = function (on) { A.on = on; if (A.master) A.master.gain.value = on ? 0.55 : 0; };
  A.slide = function (v01, onGround) {
    if (!A.ctx || !A.slideGain) return;
    var t = A.ctx.currentTime;
    A.slideGain.gain.setTargetAtTime(onGround ? Math.min(0.16, v01 * 0.18) : 0, t, 0.08);
    A.slideFilt.frequency.setTargetAtTime(500 + v01 * 1800, t, 0.1);
  };
  A.storm = function (k, t) {
    if (!A.ctx || !A.windGain) return;
    var now = A.ctx.currentTime;
    var gust = 0.75 + 0.25 * Math.sin(t * 1.3) * Math.sin(t * 0.37 + 1);
    A.windGain.gain.setTargetAtTime(k > 0.01 ? Math.min(0.3, k * 0.26 * gust) : 0, now, 0.15);
    A.windFilt.frequency.setTargetAtTime(280 + k * 520 * gust + Math.sin(t * 0.9) * 90, now, 0.2);
  };
  A.silence = function () { A.slide(0, false); A.storm(0, 0); };
  function tone(f0, f1, dur, type, vol, delay) {
    var c = A.ctx; if (!c || !A.on) return;
    var t = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.3, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(A.master); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(dur, f0, f1, vol, delay) {
    var c = A.ctx; if (!c || !A.on || !A.noiseBuf) return;
    var t = c.currentTime + (delay || 0), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = A.noiseBuf; f.type = 'bandpass'; f.Q.value = 1.2;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(50, f1), t + dur);
    g.gain.setValueAtTime(vol || 0.3, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(A.master); s.start(t); s.stop(t + dur + 0.05);
  }
  A.sfx = function (n) {
    if (!A.ctx) return;
    switch (n) {
      case 'beep': tone(520, 520, 0.18, 'square', 0.18); break;
      case 'go': tone(880, 880, 0.45, 'square', 0.2); tone(1320, 1320, 0.45, 'square', 0.12); break;
      case 'item': tone(660, 990, 0.12, 'triangle', 0.25); tone(990, 1480, 0.14, 'triangle', 0.22, 0.09); break;
      case 'ability': tone(440, 880, 0.2, 'sawtooth', 0.14); tone(660, 1320, 0.25, 'triangle', 0.2, 0.1); tone(990, 1760, 0.3, 'triangle', 0.2, 0.2); break;
      case 'boost': noise(0.6, 600, 3000, 0.35); tone(200, 600, 0.4, 'sawtooth', 0.1); break;
      case 'pad': noise(0.4, 800, 2800, 0.3); tone(300, 900, 0.3, 'square', 0.08); break;
      case 'hit': noise(0.35, 900, 120, 0.5); tone(180, 50, 0.3, 'sine', 0.5); break;
      case 'wall': noise(0.18, 700, 200, 0.3); break;
      case 'land': tone(120, 50, 0.18, 'sine', 0.4); noise(0.15, 1000, 300, 0.2); break;
      case 'fall': tone(700, 90, 0.9, 'sine', 0.3); break;
      case 'throw': noise(0.2, 1500, 500, 0.25); tone(300, 600, 0.12, 'triangle', 0.15); break;
      case 'shield': tone(500, 1000, 0.3, 'sine', 0.25); tone(750, 1500, 0.3, 'sine', 0.15, 0.05); break;
      case 'pop': noise(0.25, 2500, 400, 0.35); break;
      case 'tornado': noise(1.2, 300, 1500, 0.4); tone(120, 240, 1.0, 'sawtooth', 0.12); break;
      case 'smash': noise(0.3, 1800, 300, 0.4); tone(300, 100, 0.2, 'square', 0.12); break;
      case 'finish': tone(523, 523, 0.15, 'triangle', 0.3); tone(659, 659, 0.15, 'triangle', 0.3, 0.15); tone(784, 784, 0.15, 'triangle', 0.3, 0.3); tone(1047, 1047, 0.5, 'triangle', 0.35, 0.45); break;
      case 'click': tone(800, 600, 0.06, 'square', 0.1); break;
      case 'respawn': tone(300, 900, 0.3, 'sine', 0.2); break;
      case 'jump': tone(280, 520, 0.12, 'sine', 0.22); noise(0.1, 1200, 500, 0.12); break;
      case 'flip': tone(520, 780, 0.1, 'triangle', 0.12); break;
      case 'trick': tone(660, 990, 0.1, 'triangle', 0.25); tone(880, 1320, 0.1, 'triangle', 0.25, 0.08); tone(1175, 1760, 0.18, 'triangle', 0.28, 0.16); break;
      case 'shoot': noise(0.09, 2600, 900, 0.16); tone(900, 420, 0.07, 'square', 0.07); break;
    }
  };
})();
