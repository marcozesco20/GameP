/* v4.1: sin emojis en botones, poderes y menus. Este modulo cambia cada emoji de la interfaz por un icono vectorial propio (estilo Penguin Fort).
   Tambien entiende marcas ":ic_nombre:" en cualquier texto. El chat (mensajes, selector de emojis y stickers) conserva sus emojis: son contenido de los jugadores. */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var MAP = {
    '🎤': 'mic', '🎙': 'mic', '🔊': 'spk', '🔇': 'spkoff', '▶': 'next', '◀': 'prev', '🌐': 'globe', '📶': 'wifi', '👥': 'users', '💬': 'chat', '😊': 'smile', '⌨': 'chat',
    '🏁': 'flag', '📷': 'camera', '🪙': 'coin', '💰': 'coin', '🏆': 'trophy', '👍': 'thumb', '🎯': 'target', '⭐': 'star', '★': 'star', '🌟': 'star',
    '🥇': 'medal1', '🥈': 'medal2', '🥉': 'medal3', '⚠': 'alert', '❄': 'snow', '🚀': 'rocket', '👁': 'eye', '✔': 'tick2', '✓': 'tick2', '✅': 'tick2',
    '✕': 'cross', '✖': 'cross', '❌': 'cross', '⏱': 'clock', '⏳': 'clock', '🔒': 'lock', '🛍': 'bag', '👔': 'shirt', '🔁': 'loop', '⬇': 'down', '💔': 'cross', '🌀': 'swirl',
    '🐧': 'penguin', '🐣': 'chick', '🧊': 'cube', '⛷': 'skier', '🎿': 'skier', '🏔': 'mountain', '🧭': 'compass', '🎖': 'medalstar', '💎': 'gem', '👑': 'crown', '🔥': 'flame', '⛄': 'snowman',
    '❤': 'heart', '💙': 'heart', '🚫': 'none'
  };
  var RE = /(?:[\u{1F000}-\u{1FAFF}]|[←-⇿⌀-⏿☀-➿⬀-⯿]|▶|◀)[️‍⃣\u{1F000}-\u{1FAFF}]*|:ic_[a-z0-9_]+:/gu;
  var SKIP = 'script,style,textarea,input,[data-emoji-ok],#chatLog,#chatPick,.stkPrev,.cm,.pkGrid,.pkTabs';
  function iconHtml(n) { return '<i class="ei">' + PG.ico(n) + '</i>'; }
  function has(n) { return PG.ico && PG.ico(n).indexOf('<path') >= 0 || PG.ico(n).indexOf('<circle') >= 0 || PG.ico(n).indexOf('<rect') >= 0; }
  function nameOf(m) {
    if (m.charAt(0) === ':') return m.slice(4, -1);
    return MAP[m.replace(/[️‍]/g, '')] || MAP[m.replace(/[️‍]/g, '').charAt(0)] || null;
  }
  function fix(node) {
    var t = node.nodeValue; if (!t) return;
    RE.lastIndex = 0; if (!RE.test(t)) return;
    var p = node.parentNode; if (!p || (p.closest && p.closest(SKIP))) return;
    RE.lastIndex = 0;
    var frag = document.createDocumentFragment(), last = 0, m, any = false;
    while ((m = RE.exec(t))) {
      var n = nameOf(m[0]);
      if (!n || !has(n)) continue;
      if (m.index > last) frag.appendChild(document.createTextNode(t.slice(last, m.index)));
      var w = document.createElement('span'); w.innerHTML = iconHtml(n); frag.appendChild(w.firstChild);
      last = m.index + m[0].length; any = true;
    }
    if (!any) return;
    if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
    p.replaceChild(frag, node);
  }
  function walk(root) {
    if (root.nodeType === 3) { fix(root); return; }
    if (root.nodeType !== 1) return;
    if (root.closest && root.closest(SKIP)) return;
    var tw = document.createTreeWalker(root, 4, null), list = [], n;
    while ((n = tw.nextNode())) if (n.nodeValue && n.nodeValue.length) list.push(n);
    for (var i = 0; i < list.length; i++) fix(list[i]);
  }
  PG.deEmoji = function (root) { walk(root || document.body); };
  function start() {
    walk(document.body);
    new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var r = recs[i];
        if (r.type === 'characterData') fix(r.target);
        else for (var j = 0; j < r.addedNodes.length; j++) walk(r.addedNodes[j]);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
