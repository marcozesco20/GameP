/* Lector de los modelos FBX del usuario (ya reducidos y empaquetados en fbxdata.js) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var LUT = null;
  function b64dec(s) {
    if (!LUT) { LUT = {}; for (var i = 0; i < 64; i++) LUT[B64.charAt(i)] = i; }
    var n = s.length, pad = s.charAt(n - 1) === '=' ? (s.charAt(n - 2) === '=' ? 2 : 1) : 0;
    var out = new Uint8Array((n >> 2) * 3 - pad), o = 0;
    for (var p = 0; p < n; p += 4) {
      var a = LUT[s.charAt(p)], b = LUT[s.charAt(p + 1)], c = LUT[s.charAt(p + 2)] || 0, d = LUT[s.charAt(p + 3)] || 0;
      var v = (a << 18) | (b << 12) | (c << 6) | d;
      if (o < out.length) out[o++] = (v >> 16) & 255;
      if (o < out.length) out[o++] = (v >> 8) & 255;
      if (o < out.length) out[o++] = v & 255;
    }
    return out;
  }
  // decodifica una malla empaquetada: { V: Float32Array(xyz), T: Uint16Array(tri idx), C: Uint8Array(clase por cara), nt }
  PG.fbxMesh = function (e) {
    if (e._m) return e._m;
    var vb = b64dec(e.v), tb = b64dec(e.t), cb = b64dec(e.c);
    var q = new Int16Array(vb.buffer, vb.byteOffset, e.nv * 3), V = new Float32Array(e.nv * 3), i, k = 1 / e.q;
    for (i = 0; i < V.length; i++) V[i] = q[i] * k;
    var T = new Uint16Array(tb.buffer, tb.byteOffset, e.nt * 3);
    e._m = { V: V, T: T, C: cb, nt: e.nt };
    return e._m;
  };
  /* v4.3: subdivision de superficie (Loop) de una malla FBX: 1 nivel = 4x triangulos y silueta redondeada (menos "low poly").
     Se sueldan los vertices por posicion; los bordes abiertos / no variedad conservan su forma. k = cuanto se aplica el suavizado (0..1) */
  PG.fbxSubdiv = function (e, k) {
    if (e._sub) return e._sub;
    k = k === undefined ? 0.8 : k;
    var m = PG.fbxMesh(e), V = m.V, T = m.T, C = m.C, nt = m.nt, i, j;
    var idMap = {}, P = [], vid = new Array(V.length / 3);
    for (i = 0; i < vid.length; i++) {
      var key = Math.round(V[i * 3] * 5000) + ',' + Math.round(V[i * 3 + 1] * 5000) + ',' + Math.round(V[i * 3 + 2] * 5000);
      var id = idMap[key]; if (id === undefined) { id = P.length / 3; idMap[key] = id; P.push(V[i * 3], V[i * 3 + 1], V[i * 3 + 2]); } vid[i] = id;
    }
    var nv = P.length / 3, F = [], FC = [];
    for (i = 0; i < nt; i++) { var a = vid[T[i * 3]], b = vid[T[i * 3 + 1]], c = vid[T[i * 3 + 2]]; if (a === b || b === c || a === c) continue; F.push(a, b, c); FC.push(C[i]); }
    var nf = FC.length, edges = {}, nbr = new Array(nv), ek;
    for (i = 0; i < nv; i++) nbr[i] = [];
    function addE(a, b, opp) { var lo = a < b ? a : b, hi = a < b ? b : a; ek = lo * 70000 + hi; var E = edges[ek]; if (!E) { E = edges[ek] = { a: lo, b: hi, opp: [], mid: -1 }; nbr[lo].push(hi); nbr[hi].push(lo); } E.opp.push(opp); }
    for (i = 0; i < nf; i++) { var A = F[i * 3], B = F[i * 3 + 1], D = F[i * 3 + 2]; addE(A, B, D); addE(B, D, A); addE(D, A, B); }
    var NP = P.slice(), keys = Object.keys(edges), bnd = new Array(nv), bn = new Array(nv);
    for (i = 0; i < nv; i++) { bnd[i] = 0; bn[i] = []; }
    for (j = 0; j < keys.length; j++) { var Ed = edges[keys[j]]; if (Ed.opp.length !== 2) { bnd[Ed.a]++; bnd[Ed.b]++; bn[Ed.a].push(Ed.b); bn[Ed.b].push(Ed.a); } }
    var out = P.slice(); // nuevas posiciones: primero las pares (originales), luego un punto por arista
    for (i = 0; i < nv; i++) {
      var n = nbr[i].length, q, x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2], tx, ty, tz;
      if (bnd[i] > 0) { if (bnd[i] !== 2 || bn[i].length !== 2) continue; tx = (bn[i][0] * 0 + P[bn[i][0] * 3] + P[bn[i][1] * 3]) * 0.125 + x * 0.75; ty = (P[bn[i][0] * 3 + 1] + P[bn[i][1] * 3 + 1]) * 0.125 + y * 0.75; tz = (P[bn[i][0] * 3 + 2] + P[bn[i][1] * 3 + 2]) * 0.125 + z * 0.75; }
      else { var be = n === 3 ? 0.1875 : 0.375 / n, sx = 0, sy = 0, sz = 0; for (q = 0; q < n; q++) { sx += P[nbr[i][q] * 3]; sy += P[nbr[i][q] * 3 + 1]; sz += P[nbr[i][q] * 3 + 2]; } tx = x * (1 - n * be) + sx * be; ty = y * (1 - n * be) + sy * be; tz = z * (1 - n * be) + sz * be; }
      out[i * 3] = x + (tx - x) * k; out[i * 3 + 1] = y + (ty - y) * k; out[i * 3 + 2] = z + (tz - z) * k;
    }
    for (j = 0; j < keys.length; j++) {
      var Ee = edges[keys[j]], a2 = Ee.a * 3, b2 = Ee.b * 3, mx, my, mz;
      var mlx = (P[a2] + P[b2]) / 2, mly = (P[a2 + 1] + P[b2 + 1]) / 2, mlz = (P[a2 + 2] + P[b2 + 2]) / 2;
      if (Ee.opp.length === 2) { var c1 = Ee.opp[0] * 3, c2 = Ee.opp[1] * 3; mx = 0.375 * (P[a2] + P[b2]) + 0.125 * (P[c1] + P[c2]); my = 0.375 * (P[a2 + 1] + P[b2 + 1]) + 0.125 * (P[c1 + 1] + P[c2 + 1]); mz = 0.375 * (P[a2 + 2] + P[b2 + 2]) + 0.125 * (P[c1 + 2] + P[c2 + 2]); mx = mlx + (mx - mlx) * k; my = mly + (my - mly) * k; mz = mlz + (mz - mlz) * k; }
      else { mx = mlx; my = mly; mz = mlz; }
      Ee.mid = out.length / 3; out.push(mx, my, mz);
    }
    var T2 = [], C2 = [];
    function em(a, b) { return edges[(a < b ? a : b) * 70000 + (a < b ? b : a)].mid; }
    for (i = 0; i < nf; i++) {
      var A1 = F[i * 3], B1 = F[i * 3 + 1], D1 = F[i * 3 + 2], ab = em(A1, B1), bd = em(B1, D1), da = em(D1, A1), cc = FC[i];
      T2.push(A1, ab, da, ab, B1, bd, da, bd, D1, ab, bd, da); C2.push(cc, cc, cc, cc);
    }
    e._sub = { V: new Float32Array(out), T: new Uint32Array(T2), C: new Uint8Array(C2), nt: C2.length };
    return e._sub;
  };
  /* v4.6: reduccion de triangulos por agrupacion de vertices (rejilla de k x tamano del modelo): rocas lejanas de la pista con ~35 % de triangulos y la misma silueta */
  PG.fbxDecimate = function (e, k) {
    var key = '_dec' + k; if (e[key]) return e[key];
    var m = PG.fbxMesh(e), V = m.V, T = m.T, C = m.C, nt = m.nt, nvv = V.length / 3, i, x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
    for (i = 0; i < nvv; i++) { var x = V[i * 3], y = V[i * 3 + 1], z = V[i * 3 + 2]; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; if (z < z0) z0 = z; if (z > z1) z1 = z; }
    var g = Math.max(x1 - x0, y1 - y0, z1 - z0) * k || 1, map = {}, sum = [], cnt = [], vid = new Array(nvv);
    for (i = 0; i < nvv; i++) {
      var kk = Math.floor((V[i * 3] - x0) / g) + ',' + Math.floor((V[i * 3 + 1] - y0) / g) + ',' + Math.floor((V[i * 3 + 2] - z0) / g), id = map[kk];
      if (id === undefined) { id = cnt.length; map[kk] = id; sum.push(0, 0, 0); cnt.push(0); }
      sum[id * 3] += V[i * 3]; sum[id * 3 + 1] += V[i * 3 + 1]; sum[id * 3 + 2] += V[i * 3 + 2]; cnt[id]++; vid[i] = id;
    }
    var NV = new Float32Array(cnt.length * 3), NT = [], NC = [];
    for (i = 0; i < cnt.length; i++) { NV[i * 3] = sum[i * 3] / cnt[i]; NV[i * 3 + 1] = sum[i * 3 + 1] / cnt[i]; NV[i * 3 + 2] = sum[i * 3 + 2] / cnt[i]; }
    for (i = 0; i < nt; i++) { var a = vid[T[i * 3]], b = vid[T[i * 3 + 1]], c = vid[T[i * 3 + 2]]; if (a === b || b === c || a === c) continue; NT.push(a, b, c); NC.push(C[i]); }
    var out = { _m: { V: NV, T: new Uint16Array(NT), C: new Uint8Array(NC), nt: NC.length } };
    e[key] = out; return out;
  };
  /* Dibuja una malla FBX dentro de un MB (usa la matriz actual del MB).
     pal: color por clase [r,g,b]; jit: variacion de brillo por cara; emi: emisivo por clase (opcional) */
  PG.MB.prototype.fbx = function (entry, pal, jit, emi, orient) { // orient: punto interior [x,y,z] para orientar todas las caras hacia afuera (modelos con giro de caras mezclado)
    var m = this.subdiv ? PG.fbxSubdiv(entry) : PG.fbxMesh(entry), V = m.V, T = m.T, C = m.C, A = [0, 0, 0], B = [0, 0, 0], D = [0, 0, 0];
    var oref = this.ref, oup = this.up; this.ref = orient || null; this.up = false;
    for (var i = 0; i < m.nt; i++) {
      var a = T[i * 3] * 3, b = T[i * 3 + 1] * 3, d = T[i * 3 + 2] * 3, cl = C[i];
      A[0] = V[a]; A[1] = V[a + 1]; A[2] = V[a + 2]; B[0] = V[b]; B[1] = V[b + 1]; B[2] = V[b + 2]; D[0] = V[d]; D[1] = V[d + 1]; D[2] = V[d + 2];
      var col = pal[cl] || pal[0];
      if (jit) col = PG.shade(col, 1 + (this.rnd() - 0.5) * jit);
      this.tri(A, B, D, col, emi ? emi[cl] : undefined);
    }
    this.ref = oref; this.up = oup;
  };
})();
