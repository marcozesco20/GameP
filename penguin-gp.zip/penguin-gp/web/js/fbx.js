/* Lector de los modelos FBX del usuario (ya reducidos y empaquetados en fbxdata.js) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var LUT = null;
  function b64dec(s) {
    if (!LUT) { LUT = {}; for (var i = 0; i < 64; i++) LUT[B64.charAt(i)] = i; }
    var n = s.length, pad = s.charAt(n - 1) === '=' ? (s.charAt(n - 2) === '=' ? 2 : 1) : 0;
    var out = new Uint8Array((n >> 2) * 3 - pad), o = 0;
    for (var p = 0; p < n; p += 4) {
      var a = LUT[s.charAt(p)], b = LUT[s.charAt(p + 1)], c = LUT[s.charAt(p + 2)] || 0, d = LUT[s.charAt(p + 3)] || 0;
      var v = (a << 18) | (b << 12) | (c << 6) | d;
      if (o < out.length) out[o++] = (v >> 16) & 255;
      if (o < out.length) out[o++] = (v >> 8) & 255;
      if (o < out.length) out[o++] = v & 255;
    }
    return out;
  }
  // decodifica una malla empaquetada: { V: Float32Array(xyz), T: Uint16Array(tri idx), C: Uint8Array(clase por cara), nt }
  PG.fbxMesh = function (e) {
    if (e._m) return e._m;
    var vb = b64dec(e.v), tb = b64dec(e.t), cb = b64dec(e.c);
    var q = new Int16Array(vb.buffer, vb.byteOffset, e.nv * 3), V = new Float32Array(e.nv * 3), i, k = 1 / e.q;
    for (i = 0; i < V.length; i++) V[i] = q[i] * k;
    var T = new Uint16Array(tb.buffer, tb.byteOffset, e.nt * 3);
    e._m = { V: V, T: T, C: cb, nt: e.nt };
    return e._m;
  };
  /* Dibuja una malla FBX dentro de un MB (usa la matriz actual del MB).
     pal: color por clase [r,g,b]; jit: variacion de brillo por cara; emi: emisivo por clase (opcional) */
  PG.MB.prototype.fbx = function (entry, pal, jit, emi) {
    var m = PG.fbxMesh(entry), V = m.V, T = m.T, C = m.C, A = [0, 0, 0], B = [0, 0, 0], D = [0, 0, 0];
    var oref = this.ref, oup = this.up; this.ref = null; this.up = false;
    for (var i = 0; i < m.nt; i++) {
      var a = T[i * 3] * 3, b = T[i * 3 + 1] * 3, d = T[i * 3 + 2] * 3, cl = C[i];
      A[0] = V[a]; A[1] = V[a + 1]; A[2] = V[a + 2]; B[0] = V[b]; B[1] = V[b + 1]; B[2] = V[b + 2]; D[0] = V[d]; D[1] = V[d + 1]; D[2] = V[d + 2];
      var col = pal[cl] || pal[0];
      if (jit) col = PG.shade(col, 1 + (this.rnd() - 0.5) * jit);
      this.tri(A, B, D, col, emi ? emi[cl] : undefined);
    }
    this.ref = oref; this.up = oup;
  };
})();
