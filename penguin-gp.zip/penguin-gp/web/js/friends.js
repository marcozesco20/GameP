/* Amigos (v2.7): codigo de amigo personal, lista con estado (en linea / sala / carrera) e invitaciones a tu sala.
   Usa los mismos brokers MQTT publicos que las salas online (no hay servidor propio).
   Temas:  pgf/<codigo>/p  presencia del jugador (con retencion y mensaje de ultima voluntad "desconectado")
           pgf/<codigo>/i  buzon del jugador (solicitudes de amistad e invitaciones)
   El ultimo caracter del codigo (6 simbolos) indica en que broker vive ese jugador, igual que en las salas. */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var KEY = 'pgp_friends', HB = 10000, FRESH = 32000, ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var F = PG.Friends = {
    code: '', list: [], vis: true, seen: {}, reqs: [], invs: [], err: '', state: 'idle',
    cb: null, onInvite: null, onRequest: null, getInfo: null
  };
  var pendAdd = [], conns = {}, hbT = 0, uiT = 0, started = false, myBroker = 0, dedupe = {}, finding = false;

  function load() {
    try {
      var o = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (o && typeof o === 'object') {
        F.code = typeof o.code === 'string' && o.code.length === 6 ? o.code : '';
        F.vis = o.vis !== false;
        F.list = (Array.isArray(o.list) ? o.list : []).filter(function (f) { return f && typeof f.c === 'string' && f.c.length === 6; }).map(function (f) { return { c: f.c, n: String(f.n || '').slice(0, 12) }; }).slice(0, 60);
      }
    } catch (e) { }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify({ code: F.code, vis: F.vis, list: F.list })); } catch (e) { } }
  function changed() { if (F.cb) { try { F.cb(); } catch (e) { if (window.console) console.error(e); } } }
  function norm(c) { return String(c || '').toUpperCase().replace(/[^ABCDEFGHJKLMNPQRSTUVWXYZ23456789]/g, ''); }
  function brokerOf(code) { return Math.floor(ALPHA.indexOf(code.charAt(5)) / 8); }
  function urls() { return PG.Online.brokerList(); }
  function myInfo() { var i = F.getInfo ? F.getInfo() : null; return i || { n: 'Pingüino', s: 0 }; }
  function topicP(c) { return 'pgf/' + c + '/p'; }
  function topicI(c) { return 'pgf/' + c + '/i'; }

  load();
  F.enabled = function () { return !!F.code; };

  /* ---- conexiones (una por broker necesario) ---- */
  function conn(idx) {
    var u = urls()[idx]; if (!u) return null;
    var c = conns[idx];
    if (c && (c.mq.ready || c.connecting)) return c;
    if (c) { try { c.mq.close(true); } catch (e) { } }
    var will = (idx === myBroker && F.code) ? { topic: topicP(F.code), msg: '{"o":1}', retain: true } : null;
    c = conns[idx] = { idx: idx, mq: new PG.Online.Mqtt(u, will), connecting: true, topics: c ? c.topics : {}, retry: 0 };
    c.mq.onmessage = onMsg;
    c.mq.onclose = function () { c.connecting = false; c.mq.ready = false; if (started) setTimeout(function () { if (started) conn(idx); }, 6000); changed(); };
    c.mq.connect(function () {
      c.connecting = false;
      var t = Object.keys(c.topics); if (t.length) c.mq.subscribe(t, function () { });
      if (idx === myBroker) pulse();
      changed();
    }, function () { c.connecting = false; if (started) setTimeout(function () { if (started) conn(idx); }, 9000); changed(); }, 8000);
    return c;
  }
  function sub(idx, topic) {
    var c = conn(idx); if (!c) return;
    if (c.topics[topic]) return; c.topics[topic] = 1;
    if (c.mq.ready) c.mq.subscribe([topic], function () { });
  }
  function pub(idx, topic, obj, retain) {
    var c = conn(idx); if (!c) return false;
    var s = JSON.stringify(obj);
    if (c.mq.ready) return c.mq.publish(topic, s, retain);
    // todavia conectando: se envia en cuanto este lista (unos segundos como maximo)
    var n = 0, iv = setInterval(function () { n++; if (c.mq.ready) { clearInterval(iv); c.mq.publish(topic, s, retain); } else if (n > 24) clearInterval(iv); }, 400);
    return true;
  }

  /* ---- mensajes entrantes ---- */
  function cleanName(n) { return String(n || '').replace(/[<>&"']/g, '').slice(0, 12); }
  function onMsg(topic, msg) {
    var o; try { o = JSON.parse(msg); } catch (e) { return; }
    if (!o || typeof o !== 'object') return;
    var m = /^pgf\/([A-Z0-9]{6})\/([pi])$/.exec(topic); if (!m) return;
    var code = m[1];
    if (m[2] === 'p') {
      var f = F.list.filter(function (x) { return x.c === code; })[0]; if (!f) return;
      var nm = cleanName(o.n);
      if (o.o) F.seen[code] = { off: true, t: Date.now() };
      else { F.seen[code] = { off: false, t: Date.now(), n: nm, s: o.s | 0 }; if (nm && nm !== f.n) { f.n = nm; save(); } }
      changed();
    } else if (code === F.code) {
      var from = norm(o.f); if (from.length !== 6 || from === F.code) return;
      var id = String(o.id || '') + from; if (dedupe[id]) return; dedupe[id] = 1;
      var isFriend = F.list.some(function (x) { return x.c === from; });
      if (o.k === 'add') {
        if (isFriend || F.reqs.some(function (r) { return r.c === from; })) return;
        F.reqs.push({ c: from, n: cleanName(o.n) });
        if (F.onRequest) F.onRequest(F.reqs[F.reqs.length - 1]);
        changed();
      } else if (o.k === 'inv' && isFriend) {
        var room = norm(o.r); if (room.length !== 5) return;
        var inv = { c: from, n: cleanName(o.n) || 'Un amigo', r: room, t: Date.now() };
        F.invs.push(inv); if (F.invs.length > 8) F.invs.shift();
        if (F.onInvite) F.onInvite(inv);
        changed();
      }
    }
  }

  /* ---- presencia ---- */
  function pulse() {
    if (!F.code || !started) return;
    var c = conns[myBroker]; if (!c || !c.mq.ready) return;
    if (!F.vis) { c.mq.publish(topicP(F.code), '{"o":1}', true); return; }
    var i = myInfo();
    c.mq.publish(topicP(F.code), JSON.stringify({ n: cleanName(i.n), s: i.s | 0 }), true);
  }
  F.pulse = pulse;

  function subAll() { for (var i = 0; i < F.list.length; i++) subOne(F.list[i].c); if (F.code) sub(myBroker, topicI(F.code)); }
  function subOne(c) { var b = brokerOf(c); if (urls()[b]) sub(b, topicP(c)); }

  /* ---- arranque ---- */
  // Crea el codigo la primera vez (elige el primer broker alcanzable) y empieza a publicar la presencia
  F.start = function (done) {
    if (started) { if (done) done(); return; }
    var list = urls();
    if (F.code) { begin(); if (done) done(); return; }
    if (finding) return; finding = true; F.state = 'finding'; F.err = ''; changed();
    var i = 0;
    (function tryNext() {
      if (i >= list.length) { finding = false; F.state = 'idle'; F.err = 'No se pudo conectar. Revisa tu internet e inténtalo de nuevo.'; changed(); if (done) done(); return; }
      var idx = i++, mq = new PG.Online.Mqtt(list[idx]);
      mq.connect(function () {
        mq.close(true); finding = false;
        var s = ''; for (var k = 0; k < 5; k++) s += ALPHA.charAt(Math.floor(Math.random() * 32));
        F.code = s + ALPHA.charAt(idx * 8 + Math.floor(Math.random() * 8)); save(); begin(); if (done) done();
      }, function () { tryNext(); }, 6000);
    })();
  };
  function begin() {
    if (started) return; started = true; F.state = 'on'; F.err = '';
    myBroker = brokerOf(F.code); if (!urls()[myBroker]) myBroker = 0;
    conn(myBroker); subAll();
    pendAdd.splice(0).forEach(function (c) { if (F.isFriend(c)) sendAdd(c); });
    clearInterval(hbT); hbT = setInterval(function () { pulse(); for (var k in conns) if (!conns[k].mq.ready && !conns[k].connecting) conn(+k); }, HB);
    clearInterval(uiT); uiT = setInterval(changed, 5000);
    changed();
  }
  F.stop = function () {
    started = false; F.state = 'idle'; clearInterval(hbT); clearInterval(uiT);
    for (var k in conns) { try { var c = conns[k]; if (c.mq.ready && +k === myBroker && F.code) c.mq.publish(topicP(F.code), '{"o":1}', true); c.mq.close(true); } catch (e) { } }
    conns = {};
  };
  F.reconnect = function () { if (!started) return; for (var k in conns) if (!conns[k].mq.ready && !conns[k].connecting) conn(+k); pulse(); };

  /* ---- lista ---- */
  F.status = function (c) {
    var s = F.seen[c]; if (!s || s.off || Date.now() - s.t > FRESH) return { on: false, s: -1, n: '' };
    return { on: true, s: s.s | 0, n: s.n || '' };
  };
  F.isFriend = function (c) { return F.list.some(function (x) { return x.c === c; }); };
  // devuelve '' si todo bien o el texto del error
  F.add = function (raw, name) {
    var c = norm(raw);
    if (c.length !== 6) return 'El código de amigo tiene 6 letras o números.';
    if (c === F.code) return 'Ese es tu propio código.';
    if (F.isFriend(c)) return 'Ya es tu amigo.';
    if (F.list.length >= 60) return 'Tu lista de amigos está llena.';
    if (!urls()[brokerOf(c)]) return 'Código no válido.';
    F.list.push({ c: c, n: cleanName(name) }); save();
    F.reqs = F.reqs.filter(function (r) { return r.c !== c; });
    if (started) sendAdd(c); else pendAdd.push(c);
    changed(); return '';
  };
  function sendAdd(c) { subOne(c); var i = myInfo(); pub(brokerOf(c), topicI(c), { k: 'add', f: F.code, n: cleanName(i.n), id: Math.random().toString(36).slice(2, 8) }); }
  F.remove = function (c) { F.list = F.list.filter(function (x) { return x.c !== c; }); delete F.seen[c]; save(); changed(); };
  F.acceptReq = function (c) { var r = F.reqs.filter(function (x) { return x.c === c; })[0]; F.reqs = F.reqs.filter(function (x) { return x.c !== c; }); if (r && !F.isFriend(c)) { F.list.push({ c: c, n: r.n }); save(); if (started) subOne(c); } changed(); };
  F.ignoreReq = function (c) { F.reqs = F.reqs.filter(function (x) { return x.c !== c; }); changed(); };
  F.setVisible = function (v) { F.vis = !!v; save(); pulse(); changed(); };
  F.invite = function (c, room) {
    if (!started || !F.isFriend(c) || !room) return false;
    var i = myInfo();
    return pub(brokerOf(c), topicI(c), { k: 'inv', f: F.code, n: cleanName(i.n), r: room, id: Math.random().toString(36).slice(2, 8) });
  };
  F.dropInv = function (inv) { F.invs = F.invs.filter(function (x) { return x !== inv; }); changed(); };

  document.addEventListener('visibilitychange', function () { if (!document.hidden) F.reconnect(); });
  window.addEventListener('online', function () { F.reconnect(); });
  window.addEventListener('pagehide', function () { if (started) { var c = conns[myBroker]; try { if (c && c.mq.ready && F.code) c.mq.publish(topicP(F.code), '{"o":1}', true); } catch (e) { } } });
  F.autostart = function () { if (F.code) F.start(); };
})();
