/* Juego principal: bucle, camara, render, HUD, controles, menus y flujo multijugador */
(function () {
  'use strict';
  var PG = window.PG, G = PG.G = {}, m4 = PG.m4, clamp = PG.clamp, Net = PG.Net, Audio = PG.Audio;
  function $(id) { return document.getElementById(id); }
  var NAMES = ['Frosty', 'Rocky', 'Pebble', 'Slushy', 'Flipper', 'Waddles', 'Iggy', 'Chilly', 'Glacio', 'Copo'];
  var VERSION = 'v2.2';

  /* ---------------- almacenamiento ---------------- */
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  };
  G.cfg = PG.fixCfg(store.get('pgp_cfg', null));
  G.set = store.get('pgp_set', null) || { sound: true, quality: 1, ip: '' };
  if (G.set.music === undefined) G.set.music = true;
  if (G.set.diff === undefined) G.set.diff = 1;
  if (G.set.quality === undefined) G.set.quality = 1;
  function saveCfg() { store.set('pgp_cfg', G.cfg); }
  function saveSet() { store.set('pgp_set', G.set); }

  /* ---------------- iconos SVG ---------------- */
  var ICONS = {
    fish: '<svg viewBox="0 0 64 64"><path d="M5 32C16 15 34 12 47 25l11-9v32l-11-9C34 52 16 49 5 32z" fill="#59b9ee" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M22 22c5 6 5 14 0 20" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="16" cy="29" r="3.2" fill="#0b2740"/></svg>',
    fishoff: '<svg viewBox="0 0 64 64" opacity=".45"><path d="M5 32C16 15 34 12 47 25l11-9v32l-11-9C34 52 16 49 5 32z" fill="#9db6c8" stroke="#dbe9f3" stroke-width="3" stroke-linejoin="round"/><circle cx="16" cy="29" r="3.2" fill="#223"/></svg>',
    snow: '<svg viewBox="0 0 64 64"><circle cx="32" cy="34" r="22" fill="#f4fbff" stroke="#8fc6ea" stroke-width="3"/><circle cx="24" cy="26" r="6" fill="#fff"/><path d="M44 18l8-8M50 24l8-2" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    trap: '<svg viewBox="0 0 64 64"><path d="M32 8l22 12v24L32 56 10 44V20z" fill="#8fd6ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M10 20l22 12 22-12M32 32v24" fill="none" stroke="#fff" stroke-width="3"/></svg>',
    shield: '<svg viewBox="0 0 64 64"><path d="M32 6l22 8v16c0 14-9 24-22 28C19 54 10 44 10 30V14z" fill="#4da8ee" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M32 16v34" stroke="#fff" stroke-width="3" opacity=".6"/></svg>',
    tornado: '<svg viewBox="0 0 64 64"><g fill="none" stroke="#e9f6ff" stroke-width="5" stroke-linecap="round"><path d="M10 14h44"/><path d="M16 26h34"/><path d="M22 38h22"/><path d="M28 50h10"/></g></svg>',
    wings: '<svg viewBox="0 0 64 64"><path d="M32 40C22 38 10 28 4 14c10 2 18 6 24 14zM32 40c10-2 22-12 28-26-10 2-18 6-24 14z" fill="#bfe8ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="42" r="6" fill="#fff"/></svg>',
    grenade: '<svg viewBox="0 0 64 64"><circle cx="30" cy="38" r="19" fill="#5a8a3e" stroke="#fff" stroke-width="3"/><rect x="24" y="12" width="12" height="11" rx="3" fill="#dfe6ee" stroke="#fff" stroke-width="2"/><path d="M36 14c6-8 12-8 16-4" fill="none" stroke="#ffb12b" stroke-width="4" stroke-linecap="round"/><path d="M14 38h32" stroke="#f5c21b" stroke-width="5"/></svg>',
    megaball: '<svg viewBox="0 0 64 64"><circle cx="34" cy="32" r="22" fill="#eaf7ff" stroke="#6cc3f5" stroke-width="3"/><circle cx="27" cy="27" r="3.4" fill="#16203a"/><circle cx="41" cy="27" r="3.4" fill="#16203a"/><path d="M26 40q8 6 16 0" fill="none" stroke="#e03a4a" stroke-width="4" stroke-linecap="round"/><path d="M2 20h12M0 32h14M4 44h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    quake: '<svg viewBox="0 0 64 64"><path d="M6 44l12-8 8 10 10-18 8 12 14-6" fill="none" stroke="#ffd36a" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 56h48M16 20l4-10M32 18V6M48 20l-4-10" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></svg>',
    ghost: '<svg viewBox="0 0 64 64"><path d="M12 56V30C12 16 21 8 32 8s20 8 20 22v26l-7-6-6 6-7-6-7 6-6-6z" fill="#e8f1ff" stroke="#fff" stroke-width="3" stroke-linejoin="round" opacity=".92"/><circle cx="25" cy="30" r="4" fill="#3a4a7a"/><circle cx="39" cy="30" r="4" fill="#3a4a7a"/></svg>',
    superjump: '<svg viewBox="0 0 64 64"><path d="M32 6l16 20H38v16H26V26H16z" fill="#7be07a" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M14 50q18 10 36 0M18 58q14 5 28 0" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></svg>',
    cannon: '<svg viewBox="0 0 64 64"><rect x="8" y="26" width="34" height="14" rx="5" fill="#ff8c26" stroke="#fff" stroke-width="3"/><rect x="40" y="23" width="14" height="20" rx="4" fill="#59d8ff" stroke="#fff" stroke-width="3"/><circle cx="58" cy="33" r="3" fill="#fff"/><path d="M14 40l-4 14h14l-2-14z" fill="#fff" stroke="#8fc6ea" stroke-width="2"/></svg>'
  };

  /* ---------------- utilidades ---------------- */
  function fmtTime(t) {
    if (!(t >= 0)) t = 0;
    var m = Math.floor(t / 60), s = t - m * 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  }
  var toastTimer = 0;
  function toast(msg, ms) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, ms || 1800);
  }
  G.toast = toast;
  function cssColor(hex) { return hex; }
  function bodyColor(cfg) { return PG.PAL.body[(cfg && cfg.body) | 0] || '#222'; }

  /* ---------------- pantallas / navegacion ---------------- */
  G.screen = ''; G.nav = [];
  function show(id) {
    var list = document.querySelectorAll('.screen');
    for (var i = 0; i < list.length; i++) list[i].classList.toggle('show', list[i].id === id);
    G.screen = id;
  }
  function go(id) { if (G.screen && G.screen !== 'scrLoad' && G.screen !== id) G.nav.push(G.screen); show(id); onScreen(id); }
  function back() { var p = G.nav.pop() || 'scrMain'; show(p); onScreen(p); }
  function showLoading(txt) { $('loadTxt').textContent = txt || 'Cargando…'; show('scrLoad'); }
  function onScreen(id) {
    var hud = $('hud');
    if (id !== 'scrPause' && id !== 'scrResults') hud.classList.add('hidden');
    if (id === 'scrMain') { G.mode = 'menu'; G.camMode = 'demo'; ensureDemo(); Audio.music('ice', 0.45); }
    if (id === 'scrCustom') { G.camMode = 'preview'; buildCustomUI(); }
    else if (G.camMode === 'preview') G.camMode = 'demo';
    if (id === 'scrTracks') buildTrackGrid();
    if (id === 'scrMulti') { setupMulti(); }
    if (id === 'scrSettings') { $('chkSound').checked = G.set.sound; $('chkMusic').checked = G.set.music; markQuality(); try { $('inBroker').value = localStorage.getItem('pg_broker') || ''; } catch (e) { } }
    if (id !== 'scrMulti') Net.stopDiscovery();
  }

  /* ---------------- GPU: modelos ---------------- */
  var gm = {};
  function uploadModels() {
    var R = G.R, M = PG.Models;
    for (var k in gm) { var v = gm[k]; if (Array.isArray(v)) v.forEach(function (x) { R.free(x); }); else R.free(v); }
    gm = {};
    for (k in M) gm[k] = Array.isArray(M[k]) ? M[k].map(function (x) { return R.upload(x); }) : R.upload(M[k]);
  }
  function pengGpu(cfg) {
    var model = PG.penguinModel(cfg);
    for (var i = 0; i < model.parts.length; i++) if (!model.parts[i].gl) model.parts[i].gl = G.R.upload(model.parts[i].mesh);
    return model;
  }

  /* ---------------- carga de pista ---------------- */
  G.tracksInfo = [];
  function loadTrack(idx) {
    var R = G.R;
    if (G.tmesh) { R.free(G.tmesh); G.tmesh = null; }
    var T = G.T = PG.buildTrack(PG.TRACKS[idx], {});
    G.trackIdx = idx;
    G.tmesh = R.upload(T.mesh); T.mesh = null;
    PG.buildModels(T.theme); uploadModels();
    buildMiniMapBase();
  }
  var miniBase = null;
  function buildMiniMapBase() {
    var T = G.T, c = document.createElement('canvas'); c.width = c.height = 150;
    var x = c.getContext('2d'), th = T.thumb, pad = 14, sc = (150 - pad * 2) / Math.max(th.w, th.h);
    x.lineJoin = 'round'; x.lineCap = 'round';
    function path() { x.beginPath(); for (var i = 0; i < th.pts.length; i++) { var px = pad + th.pts[i][0] * sc, py = pad + th.pts[i][1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); } if (T.closed) x.closePath(); }
    path(); x.strokeStyle = 'rgba(0,30,60,.85)'; x.lineWidth = 9; x.stroke();
    path(); x.strokeStyle = '#bfe4ff'; x.lineWidth = 5; x.stroke();
    miniBase = { canvas: c, pad: pad, sc: sc, scale: th.sc };
  }

  /* ---------------- carrera ---------------- */
  G.race = null; G.me = null; G.goAt = 0; G.paused = false; G.mp = false;
  var particles = [], MAXP = 1400;
  var inp = { steer: 0, tuck: 0, brake: 0, useItem: false, useAbility: false, jump: false, fire: false, push: false, aim: 1, fireAim: 1 };

  function makeBotCfg(rnd) {
    var c = PG.defaultCfg();
    c.body = Math.floor(rnd() * PG.PAL.body.length); c.feet = Math.floor(rnd() * 4);
    c.hat = Math.floor(rnd() * PG.OPT.hats.length); c.hatCol = Math.floor(rnd() * PG.PAL.accent.length);
    c.scarf = Math.floor(rnd() * 4); c.scarfCol = Math.floor(rnd() * PG.PAL.accent.length);
    c.glasses = rnd() < 0.5 ? 0 : Math.floor(rnd() * 4); c.outfit = rnd() < 0.5 ? 0 : Math.floor(rnd() * 4); c.outCol = Math.floor(rnd() * PG.PAL.accent.length);
    return c;
  }
  function makeRoster(humans, wantBots, seed) {
    var rnd = PG.rng(seed ^ 0x5bd1), roster = [], i;
    for (i = 0; i < humans.length; i++) roster.push({ id: 'p' + humans[i].id, owner: humans[i].id, name: humans[i].name, cfg: humans[i].cfg, bot: false });
    var total = Math.max(roster.length, 6), nb = wantBots ? total - roster.length : 0;
    var nm = NAMES.slice(); for (i = nm.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = nm[i]; nm[i] = nm[j]; nm[j] = t; }
    for (i = 0; i < nb; i++) roster.push({ id: 'b' + (i + 1), owner: null, name: nm[i], cfg: makeBotCfg(rnd), bot: true });
    // posiciones de salida mezcladas
    var slots = []; for (i = 0; i < roster.length; i++) slots.push(i);
    for (i = slots.length - 1; i > 0; i--) { var jj = Math.floor(rnd() * (i + 1)), tt = slots[i]; slots[i] = slots[jj]; slots[jj] = tt; }
    for (i = 0; i < roster.length; i++) roster[i].slot = slots[i];
    return roster;
  }

  // inicia la carrera con los datos recibidos (o generados localmente)
  function beginRace(m, demo) {
    var after = function () {
      if (G.trackIdx !== m.track || !G.tmesh) loadTrack(m.track);
      var race = G.race = new PG.Race(G.T, { seed: m.seed, diff: m.diff === undefined ? 1 : m.diff });
      G.me = null;
      var iAmHost = !G.mp || G.myId === G.hostId;
      for (var i = 0; i < m.roster.length; i++) {
        var e = m.roster[i], mine = (!e.bot && (!G.mp ? e.owner === 'solo' : e.owner === G.myId));
        var own = demo ? true : (e.bot ? iAmHost : mine);
        var r = race.addRacer({ id: e.id, name: e.name, cfg: e.cfg, own: own, bot: e.bot || !!demo, local: mine && !demo, slot: e.slot });
        if (mine && !demo) G.me = r;
        pengGpu(e.cfg);
      }
      race.nowMs = performance.now();
      G.demo = !!demo;
      G.goAt = performance.now() + (demo ? -3000 : m.startIn);
      race.time = (performance.now() - G.goAt) / 1000;
      resetWeather(); G.fireShown = null;
      particles.length = 0; G.camInit = false; G.finishShown = false; G.lastCount = 99; G.paused = false;
      G.resultsAt = 0; G.finalShown = false; G.netAcc = 0; G.lastMsgShown = false; G.resMsg = ''; $('cheer').innerHTML = '';
      if (!demo) {
        G.mode = 'race'; G.camMode = 'race'; G.nav = [];
        show(''); $('hud').classList.remove('hidden'); buildMarkers();
        Audio.music(Audio.trackMusic(m.track), 0.5);
        $('lapBox').style.visibility = G.T.type === 'circuit' ? 'visible' : 'hidden';
        $('countdown').textContent = '';
        setHudVisibleForRace();
      }
    };
    if (demo) { after(); return; }
    showLoading('Cargando ' + PG.TRACKS[m.track].name + '…');
    setTimeout(after, 40);
  }
  function setHudVisibleForRace() { /* reservado */ }

  function ensureDemo() {
    if (G.race && G.demo) return;
    if (G.mode === 'race') return;
    var seed = (Math.random() * 1e9) | 0, rnd = PG.rng(seed), roster = [];
    for (var i = 0; i < 6; i++) roster.push({ id: 'b' + (i + 1), name: NAMES[i], cfg: makeBotCfg(rnd), bot: true, slot: i });
    G.mode = 'menu';
    beginRace({ track: 0, seed: seed, roster: roster, startIn: 0 }, true);
  }

  G.startSolo = function (idx) {
    G.mp = false; G.myId = 'solo';
    var seed = (Math.random() * 1e9) | 0;
    var roster = makeRoster([{ id: 'solo', name: G.cfg.name, cfg: G.cfg }], true, seed);
    beginRace({ track: idx, seed: seed, roster: roster, startIn: 4500, diff: G.set.diff }, false);
  };

  function quitRace(toMenu) {
    Audio.slide(0, false); Audio.storm(0, 0); jumpTouch = fireTouch = false;
    G.race = null; G.me = null; G.demo = false; G.mode = 'menu';
    if (G.mp) { Net.close(); G.mp = false; G.online = false; G.players = {}; }
    G.nav = []; $('hud').classList.add('hidden');
    ensureDemo(); go('scrMain'); G.nav = [];
  }

  /* ---------------- entrada ---------------- */
  var keys = {};
  window.addEventListener('keydown', function (e) {
    keys[e.code] = true;
    if (e.code === 'Space' || e.code.indexOf('Arrow') === 0) e.preventDefault();
    if (G.mode === 'race') {
      if (e.code === 'KeyE' || e.code === 'Enter' || e.code === 'KeyF') inp.useItem = true;
      if (e.code === 'KeyQ' || e.code === 'KeyR') inp.useAbility = true;
      if (e.code === 'KeyP' || e.code === 'KeyB' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') inp.push = true;
      if (e.code === 'Escape') pauseRace();
    }
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; });
  var joy = { id: -1, x: 0, y: 0 }, jumpTouch = false, fireTouch = false, itemAim = 0, itemAimUntil = 0, fireAim = 1;
  function setupTouch() {
    var el = $('joy'), knob = $('joyKnob');
    function upd(e) {
      var r = el.getBoundingClientRect(), R = r.width / 2;
      var dx = (e.clientX - (r.left + R)) / (R * 0.8), dy = (e.clientY - (r.top + R)) / (R * 0.8);
      var l = Math.sqrt(dx * dx + dy * dy); if (l > 1) { dx /= l; dy /= l; }
      joy.x = dx; joy.y = dy;
      knob.style.transform = 'translate(' + (dx * R * 0.55) + 'px,' + (dy * R * 0.55) + 'px)';
    }
    el.addEventListener('pointerdown', function (e) { joy.id = e.pointerId; el.setPointerCapture(e.pointerId); upd(e); e.preventDefault(); });
    el.addEventListener('pointermove', function (e) { if (e.pointerId === joy.id) { upd(e); e.preventDefault(); } });
    function rel(e) { if (e.pointerId === joy.id) { joy.id = -1; joy.x = joy.y = 0; knob.style.transform = ''; } }
    el.addEventListener('pointerup', rel); el.addEventListener('pointercancel', rel);
    function hold(id, setter) {
      var el = $(id);
      el.addEventListener('pointerdown', function (e) { setter(true); try { el.setPointerCapture(e.pointerId); } catch (x) { } el.classList.add('on'); e.preventDefault(); });
      function up() { setter(false); el.classList.remove('on'); }
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
    }
    hold('btnJump', function (v) { jumpTouch = v; });
    // arrastrar hacia abajo = apuntar hacia atras (objeto y disparo)
    var hint = $('aimHint');
    function aimDrag(id, onDown, onAim, onUp) {
      var el = $(id), st = null;
      el.addEventListener('pointerdown', function (e) {
        st = { id: e.pointerId, y0: e.clientY, aim: 1 }; try { el.setPointerCapture(e.pointerId); } catch (x) { }
        el.classList.add('on'); onDown(); hint.className = 'show'; hint.style.left = (el.getBoundingClientRect().left + el.offsetWidth / 2) + 'px'; hint.style.top = (el.getBoundingClientRect().top - 8) + 'px'; hint.dataset.aim = 'f'; e.preventDefault();
      });
      el.addEventListener('pointermove', function (e) {
        if (!st || e.pointerId !== st.id) return;
        var a = (e.clientY - st.y0) > 26 ? -1 : 1;
        if (a !== st.aim) { st.aim = a; hint.dataset.aim = a < 0 ? 'b' : 'f'; onAim(a); }
        e.preventDefault();
      });
      function up(e) { if (!st || (e && e.pointerId !== st.id)) return; var a = st.aim; st = null; el.classList.remove('on'); hint.className = ''; onUp(a); }
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', function () { if (st) { st = null; el.classList.remove('on'); hint.className = ''; onUp(1, true); } });
    }
    aimDrag('btnFire', function () { fireTouch = true; fireAim = 1; }, function (a) { fireAim = a; }, function () { fireTouch = false; fireAim = 1; });
    aimDrag('itemBox', function () { }, function () { }, function (a, cancel) { if (cancel) return; inp.useItem = true; itemAim = a; itemAimUntil = performance.now() + 200; });
    $('btnAbility').addEventListener('pointerdown', function (e) { inp.useAbility = true; $('btnAbility').classList.add('on'); setTimeout(function () { $('btnAbility').classList.remove('on'); }, 160); e.preventDefault(); });
    $('btnPush').addEventListener('pointerdown', function (e) { inp.push = true; $('btnPush').classList.add('on'); setTimeout(function () { $('btnPush').classList.remove('on'); }, 160); e.preventDefault(); });
    $('btnPause').addEventListener('pointerdown', function (e) { pauseRace(); e.preventDefault(); });
    (function () { // girar el pinguino en "Mi pinguino"
      var dg = $('pvDrag'), drag = null;
      function rot(d) { preview.manual = true; preview.rot += d; }
      dg.addEventListener('pointerdown', function (e) { if (e.target.closest('button')) return; drag = { id: e.pointerId, x: e.clientX }; try { dg.setPointerCapture(e.pointerId); } catch (x) { } e.preventDefault(); });
      dg.addEventListener('pointermove', function (e) { if (!drag || drag.id !== e.pointerId) return; rot((e.clientX - drag.x) * 0.012); drag.x = e.clientX; });
      function end(e) { if (drag && drag.id === e.pointerId) drag = null; }
      dg.addEventListener('pointerup', end); dg.addEventListener('pointercancel', end);
      $('pvL').addEventListener('click', function () { rot(-0.6); Audio.sfx('click'); });
      $('pvR').addEventListener('click', function () { rot(0.6); Audio.sfx('click'); });
      $('pvAuto').addEventListener('click', function () { preview.manual = false; Audio.sfx('click'); });
    })();
  }
  function readInput() {
    var sx = 0, tuck = 0, brake = 0;
    if (keys.ArrowLeft || keys.KeyA) sx -= 1; if (keys.ArrowRight || keys.KeyD) sx += 1;
    if (keys.ArrowUp || keys.KeyW) tuck = 1; if (keys.ArrowDown || keys.KeyS) brake = 1;
    var jx = Math.abs(joy.x) < 0.1 ? 0 : joy.x * 1.15;
    if (jx) sx = clamp(jx, -1, 1);
    if (joy.y < -0.3) tuck = Math.max(tuck, (-joy.y - 0.3) / 0.7);
    if (joy.y > 0.4) brake = Math.max(brake, (joy.y - 0.4) / 0.6);
    inp.steer = sx; inp.tuck = tuck; inp.brake = brake;
    inp.jump = !!(keys.Space || keys.KeyC || keys.KeyZ || keys.KeyJ || jumpTouch);
    inp.fire = !!(keys.KeyX || keys.KeyV || fireTouch);
    var kAim = (keys.ArrowDown || keys.KeyS || joy.y > 0.62) ? -1 : 1;
    inp.aim = performance.now() < itemAimUntil ? itemAim : kAim;
    inp.fireAim = fireTouch ? (fireAim < 0 ? -1 : kAim) : kAim;
    return inp;
  }

  /* ---------------- pausa ---------------- */
  function pauseRace() {
    if (G.mode !== 'race' || G.paused) return;
    G.paused = true; G.pauseAt = performance.now();
    $('scrPause').classList.add('show'); G.screen = 'scrPause';
  }
  function resumeRace() {
    if (!G.paused) return;
    G.paused = false; G.goAt += performance.now() - G.pauseAt;
    $('scrPause').classList.remove('show'); G.screen = '';
  }
  window.PGBack = function () {
    if (G.mode === 'race') { if (G.paused) resumeRace(); else pauseRace(); return true; }
    if (G.screen === 'scrMain') return false;
    if (G.screen === 'scrLobby') { leaveRoom(); return true; }
    if (G.screen === 'scrResults') { return true; }
    back(); return true;
  };

  /* ---------------- particulas ---------------- */
  function emitP(x, y, z, vx, vy, vz, life, size, r, g, b, a, grav) {
    if (particles.length >= MAXP) particles.shift();
    particles.push({ x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, life: life, max: life, size: size, r: r, g: g, b: b, a: a, gr: grav === undefined ? 4 : grav });
  }
  function rnd2() { return Math.random() * 2 - 1; }
  function burst(x, y, z, n, col, spd, size, life) {
    for (var i = 0; i < n; i++) emitP(x, y, z, rnd2() * spd, Math.random() * spd, rnd2() * spd, life || 0.7, size || 0.35, col[0], col[1], col[2], 1, 6);
  }
  var _w = [0, 0, 0], _w2 = [0, 0, 0];
  G.flyers = [];
  function wpos(r, out) {
    var T = G.T, q = T.q(T.uToS(r.u));
    out[0] = q.x + q.rx * r.d; out[1] = r.py; out[2] = q.z + q.rz * r.d;
    return out;
  }
  function wposUD(u, d, out) {
    var T = G.T, s = T.uToS(u), q = T.q(s);
    out[0] = q.x + q.rx * d; out[1] = T.ground(s, d); if (out[1] < -1e8) out[1] = q.y; out[2] = q.z + q.rz * d;
    return out;
  }

  /* ---------------- eventos de la simulacion ---------------- */
  var lastWall = 0;
  function handleFx(e) {
    var r = e.r, isMe = r && G.me && r === G.me, now = performance.now();
    var near = r && G.me && Math.abs(r.u - G.me.u) < 60;
    var w;
    switch (e.k) {
      case 'itemget':
        if (isMe) { Audio.sfx('item'); pickupFx('item', e.item || 'fish', r, !e.item); }
        else if (r && near) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 10, [0.6, 0.9, 1], 4, 0.3, 0.6); }
        break;
      case 'abilityget': if (isMe) { Audio.sfx('ability'); pickupFx('ability', e.ability, r, false); } else if (r && near) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [0.8, 0.5, 1], 5, 0.35, 0.7); } break;
      case 'push':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.9, w[2], e.hit ? 14 : 5, [1, 1, 1], 5, 0.4, 0.5); }
        if (isMe || near) Audio.sfx(e.hit ? 'smash' : 'throw');
        break;
      case 'shoved':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [1, 0.9, 0.5], 6, 0.4, 0.6); }
        if (isMe) { Audio.sfx('hit'); G.shake = Math.max(G.shake, 0.55); }
        break;
      case 'boost': if (isMe || near) Audio.sfx('boost'); if (isMe) G.shake = Math.max(G.shake, 0.25); break;
      case 'pad': if (isMe) { Audio.sfx('pad'); G.shake = Math.max(G.shake, 0.3); } break;
      case 'hit':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1.2, w[2], 14, [1, 1, 0.5], 6, 0.35, 0.8); }
        if (isMe) { Audio.sfx('hit'); G.shake = 0.9; } else if (near) Audio.sfx('pop');
        break;
      case 'wall': if (isMe && now - lastWall > 250) { lastWall = now; Audio.sfx('wall'); G.shake = Math.max(G.shake, 0.3); } break;
      case 'land': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.2, w[2], 8, [1, 1, 1], 5, 0.5, 0.6); } if (isMe && e.impact > 7) { Audio.sfx('land'); G.shake = Math.max(G.shake, 0.35); } break;
      case 'fall': if (isMe) { Audio.sfx('fall'); toast('¡Caíste en una grieta!', 1500); } break;
      case 'respawn': if (isMe) Audio.sfx('respawn'); break;
      case 'throw': if (isMe || near) Audio.sfx('throw'); break;
      case 'shield': if (isMe) Audio.sfx('shield'); break;
      case 'shieldpop': if (isMe || near) Audio.sfx('pop'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [0.5, 0.8, 1], 6, 0.35, 0.7); } break;
      case 'smash': if (isMe || near) Audio.sfx('smash'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 16, [1, 1, 1], 7, 0.5, 0.8); } break;
      case 'tornado': if (near || (r && r.local)) Audio.sfx('tornado'); break;
      case 'splat': if (e.u !== undefined) { w = wposUD(e.u, e.d, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 12, [1, 1, 1], 6, 0.4, 0.6); } break;
      case 'finish': if (isMe) onLocalFinish(); break;
      case 'jump': if (isMe) Audio.sfx('jump'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.2, w[2], 6, [1, 1, 1], 3, 0.4, 0.5); } break;
      case 'flip': if (isMe) Audio.sfx('flip'); break;
      case 'trick':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 22, [1, 0.85, 0.3], 8, 0.45, 0.9); burst(w[0], w[1] + 1, w[2], 12, [0.5, 0.9, 1], 7, 0.4, 0.8); }
        if (isMe) {
          Audio.sfx('trick'); G.shake = Math.max(G.shake, 0.3);
          var words = ['¡Excelente!', '¡Sigue así!', '¡Genial!'], wi2 = Math.floor(Math.random() * 3); if (wi2 === G.lastWord) wi2 = (wi2 + 1) % 3; G.lastWord = wi2;
          bigFlash(words[wi2] + (e.n > 1 ? ' ×' + e.n : ''));
        } else if (near) Audio.sfx('pop');
        break;
      case 'obsko': {
        var Tq = G.T, qk = Tq.q(e.s), gk = Tq.ground(e.s, e.d); if (gk < -1e8) gk = qk.y;
        var kx = qk.x + qk.rx * e.d, kz = qk.z + qk.rz * e.d;
        var cols = { seal: [0.55, 0.5, 0.5], rock: [0.6, 0.62, 0.7], ice: [0.7, 0.9, 1], snowman: [1, 1, 1], tree: [0.2, 0.5, 0.3], ball: [1, 1, 1] }, cc = cols[e.type] || [1, 1, 1];
        burst(kx, gk + 1.2, kz, 22, cc, 9, 0.5, 0.9); burst(kx, gk + 1.2, kz, 10, [1, 1, 1], 6, 0.4, 0.8);
        if (e.type === 'seal' || e.type === 'snowman' || e.type === 'tree') {
          var fyaw = qk.yaw, up = e.type === 'seal' ? 22 : 15;
          G.flyers.push({ type: e.type, x: kx, y: gk + 1, z: kz, vx: Math.sin(fyaw) * 14 + rnd2() * 8, vy: up + Math.random() * 6, vz: Math.cos(fyaw) * 14 + rnd2() * 8, a: e.yaw || 0, b: 0, va: rnd2() * 8, vb: 6 + Math.random() * 8, life: 2.4, sc: e.type === 'tree' ? 0.7 : 1 });
        }
        if (G.me && Math.abs(G.me.u - Tq.uToS(e.s)) < 70) Audio.sfx(e.type === 'seal' ? 'seal' : 'smash');
        break;
      }
      case 'boom': {
        var wb = wposUD(e.u, e.d, [0, 0, 0]), big = e.kd === 'mega', nb = big ? 60 : 36;
        burst(wb[0], wb[1] + 1, wb[2], nb, [1, 0.62, 0.15], big ? 18 : 13, 0.8, 0.8); burst(wb[0], wb[1] + 1, wb[2], nb / 2, [1, 0.95, 0.7], big ? 14 : 10, 0.6, 0.6);
        if (big) burst(wb[0], wb[1] + 1.5, wb[2], 40, [0.8, 0.95, 1], 16, 0.9, 1.0);
        for (var bi = 0; bi < 24; bi++) { var ba = bi / 24 * 6.2832; emitP(wb[0], wb[1] + 0.4, wb[2], Math.cos(ba) * (big ? 20 : 15), 1, Math.sin(ba) * (big ? 20 : 15), 0.5, 0.6, 1, 0.8, 0.4, 0.9, 0); }
        emitP(wb[0], wb[1] + 1.5, wb[2], 0, 0.5, 0, 0.28, big ? 9 : 6, 1, 0.75, 0.35, 0.55, 0);
        if (G.me && Math.abs(G.me.u - e.u) < 80) { Audio.sfx('boom'); G.shake = Math.max(G.shake, big ? 1.1 : 0.8 * clamp(1 - Math.abs(G.me.u - e.u) / 80, 0.2, 1)); }
        break;
      }
      case 'quake':
        if (r) {
          w = wpos(r, [0, 0, 0]);
          for (var qi = 0; qi < 40; qi++) { var qa = qi / 40 * 6.2832; emitP(w[0], w[1] + 0.3, w[2], Math.cos(qa) * 22, 2 + Math.random() * 3, Math.sin(qa) * 22, 0.8, 0.7, 0.9, 0.95, 1, 0.9, 4); }
          burst(w[0], w[1] + 1, w[2], 30, [1, 0.85, 0.4], 10, 0.5, 0.9);
          if (G.me && Math.abs(G.me.u - r.u) < 70) { Audio.sfx('quake'); G.shake = Math.max(G.shake, 1.0); }
        }
        break;
      case 'megaball': if (isMe) { toast('¡MEGA BOLA! Persigue a los de adelante', 1800); G.shake = Math.max(G.shake, 0.5); } if (isMe || near) Audio.sfx('quake'); break;
      case 'ghost': if (isMe) toast('👻 ¡Fantasma! Nada te toca', 1800); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 18, [0.9, 0.95, 1], 6, 0.4, 0.8); } break;
      case 'superjump': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.3, w[2], 24, [0.5, 1, 0.5], 9, 0.5, 0.7); } if (isMe) { Audio.sfx('boost'); G.shake = Math.max(G.shake, 0.6); toast('¡SÚPER SALTO! Toca SALTAR otra vez en el aire', 2200); } break;
      case 'sjump':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.3, w[2], 14, [0.5, 1, 0.5], 7, 0.45, 0.6); for (var si2 = 0; si2 < 14; si2++) { var sa2 = si2 / 14 * 6.2832; emitP(w[0] + Math.cos(sa2) * 0.6, w[1] + 0.1, w[2] + Math.sin(sa2) * 0.6, Math.cos(sa2) * 7, 0.5, Math.sin(sa2) * 7, 0.4, 0.35, 0.7, 1, 0.7, 0.9, 0); } }
        if (isMe) { Audio.sfx('jump'); G.shake = Math.max(G.shake, 0.25); }
        break;
      case 'wings': if (isMe) toast('¡Alas! Cuidado con los techos', 1600); break;
      case 'bonk': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1.8, w[2], 16, [0.85, 0.92, 1], 6, 0.4, 0.7); } if (isMe) { Audio.sfx('hit'); G.shake = Math.max(G.shake, 0.8); toast('¡Chocaste con el techo!', 1100); } break;
      case 'stumble': if (isMe) { Audio.sfx('wall'); toast('¡Aterrizaje torpe!', 900); } break;
      case 'cannon': if (isMe) { Audio.sfx('ability'); toast(e.gun === 'gren' ? '¡Cañón de granadas! Toca DISPARAR' : '¡Cañón de nieve! Mantén DISPARAR', 2200); } break;
      case 'shoot':
        if (r) { var fy0 = Math.sin(G.T.q(G.T.uToS(r.u)).yaw - r.psi), fz0 = Math.cos(G.T.q(G.T.uToS(r.u)).yaw - r.psi); w = wpos(r, [0, 0, 0]); burst(w[0] + fy0 * 1.4, w[1] + 1.0, w[2] + fz0 * 1.4, 4, [0.7, 0.95, 1], 3, 0.35, 0.3); }
        if (isMe || near) Audio.sfx(e.gun === 'gren' ? 'gren' : 'shoot');
        break;
    }
  }

  /* ---- animaciones espectaculares al recoger poderes ---- */
  function pickupFx(kind, key, r, mini) {
    var isAb = kind === 'ability', host = $('pickFx'), name = PG.ITEM_NAMES[key] || key;
    var w = wpos(r, [0, 0, 0]), col = isAb ? [0.78, 0.5, 1.0] : [0.4, 0.82, 1.0], i, a;
    if (mini) { var sl = $('itemSlot'); sl.classList.remove('gotpop'); void sl.offsetWidth; sl.classList.add('gotpop'); toast('¡Pez turbo listo!', 1100); burst(w[0], w[1] + 1, w[2], 12, col, 5, 0.35, 0.6); return; }
    var fl = document.createElement('div'); fl.className = 'pkFlash ' + (isAb ? 'ab' : 'it'); host.appendChild(fl);
    setTimeout(function () { fl.remove(); }, 1000);
    var box = document.createElement('div'); box.className = 'pkIcon ' + (isAb ? 'ab' : 'it');
    box.innerHTML = '<i class="rays"></i><i class="rays r2"></i><i class="ring"></i><div class="ic">' + ICONS[key] + '</div><b>' + (isAb ? '¡HABILIDAD!' : '¡NUEVO PODER!') + '</b><small>' + esc(name) + '</small>';
    host.appendChild(box);
    setTimeout(function () {
      var tg = (isAb ? $('btnAbility') : $('itemSlot')).getBoundingClientRect(), bx = box.getBoundingClientRect();
      box.style.setProperty('--dx', (tg.left + tg.width / 2 - (bx.left + bx.width / 2)) + 'px');
      box.style.setProperty('--dy', (tg.top + tg.height / 2 - (bx.top + bx.height / 2)) + 'px');
      box.classList.add('fly');
    }, 820);
    setTimeout(function () { box.remove(); var t2 = isAb ? $('btnAbility') : $('itemSlot'); t2.classList.remove('gotpop'); void t2.offsetWidth; t2.classList.add('gotpop'); }, 1300);
    // en el mundo: anillo expansivo, columna de luz y chispas
    for (i = 0; i < 36; i++) { a = i / 36 * 6.2832; emitP(w[0] + Math.cos(a) * 0.8, w[1] + 0.3, w[2] + Math.sin(a) * 0.8, Math.cos(a) * 13, 0.4, Math.sin(a) * 13, 0.55, 0.55, col[0], col[1], col[2], 0.95, 0); }
    for (i = 0; i < 26; i++) emitP(w[0] + rnd2() * 0.5, w[1] + 0.5, w[2] + rnd2() * 0.5, rnd2() * 1.5, 5 + Math.random() * 9, rnd2() * 1.5, 0.9, 0.45, 1, 1, 0.7 + Math.random() * 0.3, 0.9, 2);
    for (i = 0; i < 30; i++) { a = Math.random() * 6.2832; var sp = 4 + Math.random() * 8; emitP(w[0], w[1] + 1.1, w[2], Math.cos(a) * sp, 2 + Math.random() * 7, Math.sin(a) * sp, 0.9, 0.38, col[0] * 0.5 + 0.5, col[1] * 0.5 + 0.5, 1, 1, 7); }
    G.shake = Math.max(G.shake, isAb ? 0.7 : 0.45); G.fovKick = isAb ? 0.3 : 0.2;
  }

  var cheerT = 0;
  function banner(kind, title, sub, hold) {
    var c = $('cheer'); clearTimeout(cheerT);
    c.innerHTML = '<div class="cb ' + kind + '" style="--hold:' + (hold || 3.6) + 's"><h3>' + esc(title) + '</h3>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div>';
    cheerT = setTimeout(function () { c.innerHTML = ''; }, ((hold || 3.6) + 0.7) * 1000);
  }
  function confetti(n) {
    var cols = ['#ffd24a', '#ff5a7a', '#59c2ff', '#7be07a', '#c58bff', '#ffffff', '#ff8a1f'];
    for (var i = 0; i < n; i++) {
      var d = document.createElement('div'); d.className = 'confetti';
      d.style.left = (Math.random() * 100) + 'vw'; d.style.background = cols[i % cols.length];
      d.style.animationDuration = (2.6 + Math.random() * 2.4) + 's'; d.style.animationDelay = (Math.random() * 1.2) + 's';
      d.style.setProperty('--rot', (Math.random() > 0.5 ? 1 : -1) * (360 + Math.random() * 720) + 'deg');
      d.style.width = (7 + Math.random() * 8) + 'px'; d.style.height = (10 + Math.random() * 12) + 'px';
      document.body.appendChild(d);
      (function (el) { setTimeout(function () { el.remove(); }, 6500); })(d);
    }
  }
  G.confetti = confetti;
  var flashT = 0;
  function bigFlash(txt) {
    var b = $('bigMsg'); if (G.finishShown) return;
    b.textContent = txt; clearTimeout(flashT); flashT = setTimeout(function () { if (!G.finishShown) b.textContent = ''; }, 900);
  }
  var OK_MSGS = [['¡Gran carrera!', 'Cruzaste la meta entre los mejores.'], ['¡Muy bien!', 'Sigue así y el podio será tuyo.'], ['¡Buen trabajo!', 'Cada carrera te hace más rápido.']];
  var LAST_MSGS = [['¡Lo lograste, terminaste!', 'El último lugar también cuenta. ¡No te rindas, la próxima será mejor!'], ['¡Llegaste a la meta!', 'Lo importante es seguir intentando. ¡Tú puedes!'], ['¡Bien por terminar!', 'Los campeones también empezaron aquí. ¡Revancha!']];
  function finishMessage(rank, total) {
    if (rank === 1) return { kind: 'win', t: '🏆 ¡GANASTE! 🏆', s: '¡Eres el campeón de la pista!' };
    if (rank === 2) return { kind: 'good', t: '¡Segundo lugar!', s: '¡Casi! Un poquito más y llegas a lo más alto.' };
    if (rank === 3) return { kind: 'good', t: '¡Tercer lugar, al podio!', s: '¡Excelente carrera!' };
    if (total >= 4 && rank === total) { var l = LAST_MSGS[Math.floor(Math.random() * LAST_MSGS.length)]; return { kind: 'keep', t: l[0], s: l[1] }; }
    var o = OK_MSGS[Math.floor(Math.random() * OK_MSGS.length)]; return { kind: 'good', t: o[0], s: o[1] + ' (' + rank + 'º puesto)' };
  }
  G.finishMessage = finishMessage;
  function onLocalFinish() {
    if (G.finishShown) return;
    G.finishShown = true;
    var rank = G.me.rank, total = G.race.racers.length, m = finishMessage(rank, total);
    Audio.sfx(rank === 1 ? 'win' : (rank <= 3 ? 'cheer' : 'finish'));
    $('bigMsg').textContent = '';
    banner(m.kind, m.t, m.s, rank === 1 ? 4.4 : 3.4);
    if (rank <= 3) { confetti(rank === 1 ? 90 : 45); G.shake = Math.max(G.shake, 0.4); }
    G.resMsg = m.t.replace(/🏆/g, '').trim() + ' ' + m.s;
    G.resultsAt = performance.now() + (rank === 1 ? 5200 : 4200);
  }
  // mensaje de animo cuando ya casi todos llegaron y voy de ultimo
  function checkLastPlace() {
    var race = G.race, me = G.me, total = race.racers.length;
    if (G.lastMsgShown || !me || me.finished || total < 4 || race.time < 5) return;
    if (race.finishOrder.length >= total - 2 && me.rank === total) {
      G.lastMsgShown = true;
      banner('keep', 'Has llegado al último lugar…', '¡Pero no te rindas! Todavía puedes terminar la carrera. ¡Tú puedes!', 4.6);
      Audio.sfx('ability');
    }
  }

  /* ---------------- HUD ---------------- */
  var mk = {}, lastHud = {};
  function setTxt(id, v) { if (lastHud[id] !== v) { lastHud[id] = v; $(id).textContent = v; } }
  function setHtml(id, v) { if (lastHud[id] !== v) { lastHud[id] = v; $(id).innerHTML = v; } }
  function buildMarkers() {
    var box = $('progMarks'); box.innerHTML = ''; mk = {};
    box.style.cssText = 'position:absolute;inset:0';
    G.race.racers.forEach(function (r) {
      var d = document.createElement('div'); d.className = 'mk' + (r === G.me ? ' me' : '');
      d.style.background = bodyColor(r.cfg); d.style.color = '#fff';
      d.textContent = r.name.charAt(0).toUpperCase();
      box.appendChild(d); mk[r.id] = d;
    });
    var tg = $('tags'); tg.innerHTML = ''; G.tagEls = {};
    G.race.racers.forEach(function (r) {
      if (r === G.me) return;
      var d = document.createElement('div'); d.className = 'tag3d'; d.textContent = r.name; tg.appendChild(d); G.tagEls[r.id] = d;
    });
    lastHud = {};
  }
  function updateHud(now) {
    var race = G.race, me = G.me, T = G.T;
    if (!me) return;
    var t = Math.max(0, race.time);
    if (me.finished) t = me.finishTime;
    setTxt('timerTxt', fmtTime(t));
    var endU = T.type === 'circuit' ? race.laps * T.L : T.D;
    if (T.type === 'circuit') setHtml('lapTxt', Math.max(1, Math.min(race.laps, me.lap || 1)) + '<small>/' + race.laps + '</small>');
    setTxt('posTxt', String(me.rank)); setTxt('posOf', '/' + race.racers.length);
    setTxt('speedTxt', String(Math.round(Math.max(0, me.speed) * 3.6)));
    // barra de progreso
    race.racers.forEach(function (r) {
      var f = clamp(r.u / endU, 0, 1), el = mk[r.id];
      if (el) el.style.bottom = 'calc(10px + (100% - 20px) * ' + f.toFixed(3) + ')';
    });
    // objetos y habilidad
    var it = me.item, ab = me.ability;
    setHtml('itemIco', it ? ICONS[it] : ICONS.fishoff);
    $('itemSlot').classList.toggle('ready', !!it);
    setTxt('itemState', it ? PG.ITEM_NAMES[it].toUpperCase() : 'CARGANDO');
    $('itemChargeFill').style.width = (it ? 100 : Math.round(me.charge * 100)) + '%';
    setHtml('abilityIco', ab ? ICONS[ab] : '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="18" fill="none" stroke="#fff" stroke-width="4" stroke-dasharray="6 7" opacity=".7"/></svg>');
    setTxt('abilityName', ab ? PG.ITEM_NAMES[ab] : 'Habilidad');
    var bf = '', fxm = me.fx;
    [['superjump', 'SÚPER SALTO', PG.CFG.SJ_T, '#7be07a'], ['ghost', 'FANTASMA', 6, '#cfe0ff'], ['wings', 'ALAS', 5.5, '#bfe8ff']].forEach(function (b) {
      if (fxm[b[0]] > 0) bf += '<div class="buff"><b>' + b[1] + ' ' + fxm[b[0]].toFixed(1) + 's</b><i><u style="width:' + Math.min(100, fxm[b[0]] / b[2] * 100).toFixed(0) + '%;background:' + b[3] + '"></u></i></div>';
    });
    setHtml('buffs', bf);
    var q2 = me.abilityQ || [], qk = q2.join(',');
    setHtml('abQ', q2.map(function (a) { return '<i>' + ICONS[a] + '</i>'; }).join(''));
    $('btnAbility').classList.toggle('ready', !!ab);
    $('btnPush').classList.toggle('cool', me.pushCd > 0);
    var ww = (me.vf < -1 || Math.abs(me.psi) > 1.25) && race.time > 1 && !me.fell;
    $('wrongWay').style.display = ww ? 'block' : 'none';
    // cuenta atras
    var cd = $('countdown');
    if (race.time < 0) {
      var n = Math.ceil(-race.time);
      if (n <= 3 && n !== G.lastCount) {
        G.lastCount = n; cd.textContent = String(n); cd.classList.remove('pop'); void cd.offsetWidth; cd.classList.add('pop'); Audio.sfx('beep');
      }
    } else if (G.lastCount !== 0) {
      G.lastCount = 0; cd.textContent = '¡YA!'; cd.classList.remove('pop'); void cd.offsetWidth; cd.classList.add('pop'); Audio.sfx('go');
      setTimeout(function () { if ($('countdown').textContent === '¡YA!') $('countdown').textContent = ''; }, 900);
    }
  }
  function updateFireBtn() {
    var me = G.me, on = me && me.fx.cannon > 0, el = $('btnFire');
    if (G.fireShown !== on) { G.fireShown = on; el.style.display = on ? 'flex' : 'none'; $('btnAbility').classList.toggle('active', !!on); if (!on) { fireTouch = false; el.classList.remove('on'); } }
    if (on) $('fireFill').style.width = Math.round(me.fx.cannon / (me.gunT || PG.CFG.CANNON_T) * 100) + '%';
  }
  function drawMini() {
    var c = $('minimap'), x = c.getContext('2d');
    if (!miniBase) return;
    x.clearRect(0, 0, 150, 150); x.drawImage(miniBase.canvas, 0, 0);
    var T = G.T, bb = T.bbox, race = G.race, k = miniBase.scale * miniBase.sc;
    race.racers.forEach(function (r) {
      var w = wpos(r, _w), px = miniBase.pad + (w[0] - bb.x0) * k, py = miniBase.pad + (w[2] - bb.z0) * k;
      x.beginPath(); x.arc(px, py, r === G.me ? 5.5 : 3.6, 0, 6.3); x.fillStyle = bodyColor(r.cfg); x.fill();
      x.lineWidth = 2; x.strokeStyle = r === G.me ? '#ffb12b' : '#fff'; x.stroke();
    });
  }

  /* ---------------- camara ---------------- */
  var cam = G.cam = { eye: [0, 10, 0], target: [0, 0, 1], fov: 1.05 };
  var camYaw = 0, camY = 0, camDist = 8;
  G.shake = 0;
  var camLook = 0, camRoll = 0;
  function updateCamera(dt, now) {
    var race = G.race, T = G.T;
    if (!race) return;
    var focus = G.me;
    if (G.camMode === 'preview') return previewCam(now);
    if (!focus) { // demo: seguir al lider
        focus = race.order ? race.order[0] : race.racers[0];
    }
    if (!focus) return;
    var s = T.uToS(focus.u), q = T.q(s), w = wpos(focus, _w);
    var demo = (G.camMode === 'demo');
    var targetYaw = q.yaw - focus.psi * 0.3;
    if (!G.camInit) { camYaw = q.yaw; camY = w[1] + 3.6; camLook = w[1] + 0.9; camRoll = 0; G.camInit = true; }
    camYaw += PG.angDiff(camYaw, targetYaw) * Math.min(1, dt * 4.5);
    var spd = Math.max(0, focus.speed || 0);
    var dist = (demo ? 11 : 6.3) + spd * 0.035 + 0;
    camDist += (dist - camDist) * Math.min(1, dt * 3);
    var fy = Math.sin(camYaw), fz = Math.cos(camYaw);
    var lat = demo ? 6 + Math.sin(now * 0.0002) * 4 : 0;
    var rxn = -fz, rzn = fy; // derecha de la camara (sistema de mano derecha)
    var hgt = demo ? 4.6 : 3.1;
    var targetY = w[1] + hgt;
    camY += (targetY - camY) * Math.min(1, dt * (focus.grounded ? 7 : 3));
    var ex = w[0] - fy * camDist + rxn * lat, ez = w[2] - fz * camDist + rzn * lat, ey = camY;
    // en las cuevas la camara no sigue al pinguino hasta la pared curva (atravesaria la roca)
    var dcamT = focus.d;
    if (!demo && T.caveF) {
      var cfk = T.caveF(s);
      if (cfk > 0) {
        var dcam = clamp(focus.d, -7.0, 7.0), dsh = (dcam - focus.d) * cfk;
        ex += q.rx * dsh; ez += q.rz * dsh; dcamT = focus.d + dsh;
      }
    }
    // la camara nunca baja del suelo (ni sube del techo) en SU posicion, no en la del pinguino:
    // en bajadas empinadas el terreno de atras esta mas alto que el pinguino
    if (!demo) {
      var sc1 = s - camDist * 0.8, sc2 = s - camDist * 1.15, gc = -1e9, g1, k2;
      for (k2 = 0; k2 < 2; k2++) {
        var sx = k2 ? sc2 : sc1;
        g1 = T.ground(sx, dcamT); if (g1 < -1e8) g1 = T.centerY(sx);
        if (g1 > gc) gc = g1;
      }
      var minCam = gc + (T.caveF && T.caveF(s) > 0 ? 2.3 : 1.7);
      if (ey < minCam) ey = minCam;
      if (T.ceilAt) {
        var ce = Math.min(T.ceilAt(sc1, dcamT), T.ceilAt(sc2, dcamT), T.ceilAt(s, dcamT));
        if (ce < 1e8) { var maxCam = T.centerY(s - camDist * 0.8) + ce - 1.6; if (ey > maxCam) ey = Math.max(maxCam, minCam); }
      }
    }
    // la camara no baja del suelo local
    var gy = T.hgt ? T.centerY(s) : 0;
    if (ey < gy + 1.2) ey = gy + 1.2;
    var sh = G.shake; G.shake = Math.max(0, G.shake - dt * 2.5);
    if (focus.fx.boost > 0 || focus.fx.pad > 0 || focus.holdBoost) sh = Math.max(sh, 0.18);
    if (sh > 0) { ex += rnd2() * sh * 0.25; ey += rnd2() * sh * 0.2; ez += rnd2() * sh * 0.25; }
    cam.eye[0] = ex; cam.eye[1] = ey; cam.eye[2] = ez;
    cam.target[0] = w[0] + fy * 12; cam.target[2] = w[2] + fz * 12;
    // mira hacia donde baja/sube la pista (sensacion de montana rusa) y se inclina en las curvas
    var tyT = w[1] + 0.9 + (focus.grounded ? q.sl * 7 : Math.max(-6, Math.min(4, (focus.vy || 0) * 0.35)));
    camLook += (tyT - camLook) * Math.min(1, dt * 6);
    cam.target[1] = camLook;
    var rollT = demo ? 0 : Math.max(-0.14, Math.min(0.14, (focus.steerVis || 0) * 0.055 + (focus.vl || 0) * 0.0035 + PG.angDiff(camYaw, q.yaw) * 0.0));
    camRoll += (rollT - camRoll) * Math.min(1, dt * 4);
    cam.roll = camRoll;
    var boosting = focus.fx.boost > 0 || focus.fx.pad > 0 || focus.holdBoost;
    var tf = 1.04 + Math.min(0.2, spd * 0.0035) + (boosting ? 0.08 : 0);
    G.fovKick = (G.fovKick || 0) * Math.max(0, 1 - dt * 3.5);
    tf += G.fovKick;
    cam.fov += (tf - cam.fov) * Math.min(1, dt * 5);
  }
  var preview = { yaw: 0.6, manual: false, rot: 0 };
  function previewCam(now) {
    var T = G.T, q = T.q(T.startS + 6), baseX = q.x, baseZ = q.z, baseY = q.y;
    var yaw = q.yaw;
    var fy = Math.sin(yaw), fz = Math.cos(yaw), rxn = -fz, rzn = fy;
    cam.eye[0] = baseX; cam.eye[1] = baseY + 2.2; cam.eye[2] = baseZ;
    var tgt = [baseX + fy * 8, baseY + 1.2, baseZ + fz * 8];
    cam.target[0] = tgt[0]; cam.target[1] = tgt[1]; cam.target[2] = tgt[2];
    cam.fov = 0.9; cam.roll = 0;
    preview.pos = [baseX + fy * 6.2 + rxn * 0 , baseY + 0.9, baseZ + fz * 6.2];
    // desplazar a la izquierda de la pantalla
    var asp = G.R.aspect, off = (asp > 1 ? 1.5 : 0.3) * 1.0;
    preview.pos[0] += rxn * (-off * 1.9); preview.pos[2] += rzn * (-off * 1.9);
    preview.yawBase = yaw;
  }

  /* ---------------- render ---------------- */
  var _m1 = m4.create(), _m2 = m4.create(), _m3 = m4.create();
  function drawPenguinAt(cfg, x, y, z, yaw, pitch, roll, sc, t, anim) {
    var R = G.R, model = pengGpu(cfg);
    var pv = anim.pv || 0;
    m4.trs(_m1, x, y + pv * sc, z, yaw, pitch, roll, sc, sc, sc);
    if (pv) { _m1[12] -= _m1[4] * pv; _m1[13] -= _m1[5] * pv; _m1[14] -= _m1[6] * pv; }
    var speedK = anim.speed || 0, hold = !!anim.extra;
    for (var i = 0; i < model.parts.length; i++) {
      var p = model.parts[i], M = _m1;
      if (p.kind !== 'body') {
        var ay = 0, ax = 0, az = 0;
        if (p.kind === 'flipR') { az = 0.10 + Math.sin(t * 8) * 0.10 * (0.4 + speedK) + (anim.wings ? Math.sin(t * 20) * 0.7 : 0) + anim.steer * 0.35; ay = 0.22; if (hold) { az = 1.05 + Math.sin(t * 9) * 0.03; ay = -0.55; } }
        else if (p.kind === 'flipL') { az = -(0.10 + Math.sin(t * 8 + 1) * 0.10 * (0.4 + speedK) + (anim.wings ? Math.sin(t * 20) * 0.7 : 0)) + anim.steer * 0.35; ay = -0.22; if (hold) { az = -1.05 - Math.sin(t * 9) * 0.03; ay = 0.55; } }
        else { ax = 0.15 + speedK * 0.5 + Math.sin(t * 11 + p.pivot[0] * 9) * 0.12 * (0.4 + speedK); ay = -anim.steer * 0.5 + Math.sin(t * 9) * 0.22 * speedK; }
        if (anim.push) { // empujon: la aleta del lado del rival se lanza hacia adelante
          var pk = Math.sin(3.1416 * (1 - clamp(anim.pushT / 0.38, 0, 1)));
          if (p.kind === 'flipL' && anim.push > 0) { ay = 1.15 * pk; az = -0.25 * pk; }
          else if (p.kind === 'flipR' && anim.push < 0) { ay = -1.15 * pk; az = 0.25 * pk; }
        }
        m4.trs(_m2, p.pivot[0], p.pivot[1], p.pivot[2], ay, ax, az, 1, 1, 1);
        M = m4.mul(_m3, _m1, _m2);
      }
      R.draw(p.gl, M, anim.tint, anim.alpha || 1);
    }
    if (anim.extra) {
      if (anim.extraYaw) { m4.trs(_m2, 0, 0, 0, anim.extraYaw, 0, 0, 1, 1, 1); R.draw(anim.extra, m4.mul(_m3, _m1, _m2), null, anim.alpha || 1); }
      else R.draw(anim.extra, _m1, null, anim.alpha || 1);
    }
  }
  function drawRacer(r, now, t) {
    var R = G.R, T = G.T, s = T.uToS(r.u), q = T.q(s);
    var x = q.x + q.rx * r.d, z = q.z + q.rz * r.d, y = r.py;
    var palpha = 1;
    if (r.fx.ghost > 0) palpha = r === G.me ? 0.55 : 0.32;
    // un pinguino que queda entre la camara y el mio (o pegado a la camara) se vuelve casi transparente
    if (G.me && r !== G.me && G.camMode === 'race') {
      var mw = wpos(G.me, _w2), ex = cam.eye[0], ey = cam.eye[1], ez = cam.eye[2];
      var vx = mw[0] - ex, vy = mw[1] + 1 - ey, vz = mw[2] - ez, L2 = vx * vx + vy * vy + vz * vz;
      var px = x - ex, py = y + 1 - ey, pz = z - ez, tt = L2 > 0 ? (px * vx + py * vy + pz * vz) / L2 : 0;
      var dx = px - vx * tt, dy = py - vy * tt, dz = pz - vz * tt, perp2 = dx * dx + dy * dy + dz * dz, eye2 = px * px + py * py + pz * pz;
      if ((tt > -0.15 && tt < 1.02 && perp2 < 2.9 * 2.9) || eye2 < 4.2 * 4.2) palpha = Math.min(palpha, 0.16);
    }
    var yaw = q.yaw - r.psi + (r.fx.spin > 0 ? r.spinAng : 0);
    var pt = r.grounded ? -Math.atan(q.sl) : -Math.atan2(r.vy, Math.max(8, r.vf)) * 0.9;
    r.pv = r.pv === undefined ? pt : r.pv + (pt - r.pv) * 0.25;
    var roll = r.steerVis * 0.5 + (r.bankRoll || 0) + (r.fx.push > 0 ? (r.pushDir || 1) * Math.sin(3.1416 * (1 - r.fx.push / 0.38)) * 0.32 : 0), pvot = 0;
    var pitchDraw = r.pv;
    if (r.flipping && r.flipAcc > 0) {
      var fa = r.flipAcc * r.flipDir; pvot = 0.32;
      if (r.flipMode === 1) pitchDraw = r.pv + fa; else roll += fa;
    }
    var gs = 1.5;
    r.gsv = r.gsv === undefined ? gs : r.gsv + (gs - r.gsv) * 0.1;
    var sp = clamp(Math.abs(r.vf) / 40, 0, 1);
    drawPenguinAt(r.cfg, x, y + (r.grounded ? Math.sin(t * 13 + r.slot) * 0.015 * sp * r.gsv : 0), z, yaw, pitchDraw, roll, r.gsv, t + r.slot,
      { speed: sp, steer: r.steerVis, wings: r.fx.wings > 0, tint: null, alpha: palpha, pv: pvot, extra: r.fx.cannon > 0 ? (r.gun === 'gren' ? gm.cannon2 : gm.cannon) : null, extraYaw: (1 - (r.aimV === undefined ? 1 : r.aimV)) * 1.5708, push: r.fx.push > 0 ? (r.pushDir || 1) : 0, pushT: r.fx.push });
    // sombra
    if (!r.fell) {
      var gy = r.gy !== undefined ? r.gy : y;
      if (gy > -1e8) {
        m4.trs(_m2, x, gy + 0.07, z, q.yaw, -Math.atan(q.sl), 0, r.gsv * 1.45 * (1 + (y - gy) * 0.05), 1, r.gsv * 1.35);
        R.draw(gm.shadow, _m2, null, clamp(0.45 - (y - gy) * 0.06, 0.12, 0.45) * (palpha < 0.5 ? 0.15 : 1));
      }
    }
    if (r.fx.shield > 0) { m4.trs(_m2, x, y + 0.6 * r.gsv, z, yaw, 0, 0, r.gsv, r.gsv, r.gsv); R.draw(gm.shield, _m2, null, 0.35); }
    // particulas
    if (r.grounded && Math.abs(r.vf) > 10 && !r.fell && particles.length < MAXP - 20) {
      var fy = Math.sin(q.yaw - r.psi), fz = Math.cos(q.yaw - r.psi);
      emitP(x - fy * 0.9 * r.gsv + rnd2() * 0.3, y + 0.15, z - fz * 0.9 * r.gsv + rnd2() * 0.3, rnd2() * 1.2 - fy * 2, 0.6 + Math.random() * 1.2, rnd2() * 1.2 - fz * 2, 0.55, 0.3 + sp * 0.25, 1, 1, 1, 0.8, 3);
      if (r.fx.boost > 0 || r.fx.pad > 0 || r.holdBoost) emitP(x - fy * 1.3, y + 0.5, z - fz * 1.3, -fy * 6 + rnd2(), 0.5 + Math.random(), -fz * 6 + rnd2(), 0.4, 0.55, 1, 0.55 + Math.random() * 0.3, 0.1, 0.9, 0);
    }
    if (r.fx.superjump > 0 && particles.length < MAXP - 5) emitP(x + rnd2() * 0.7, y + 0.1, z + rnd2() * 0.7, rnd2() * 0.5, 1.2 + Math.random(), rnd2() * 0.5, 0.5, 0.3, 0.6, 1, 0.6, 0.85, 0);
    if (r.fx.wings > 0 && particles.length < MAXP - 5) emitP(x + rnd2() * 0.6, y + 0.8, z + rnd2() * 0.6, rnd2(), 0.5, rnd2(), 0.7, 0.35, 0.7, 0.95, 1, 0.9, 0);
  }

  /* ---- espectadores: el mismo pinguino de los corredores, de pie, cada uno con su propia animacion ---- */
  var NSPEC = 10, specSet = null, _sm = new Float32Array(16), _sm2 = new Float32Array(16), _sm3 = new Float32Array(16);
  function specSetup() {
    if (specSet) return specSet;
    var rnd = PG.rng(4242), R = G.R; specSet = [];
    for (var i = 0; i < NSPEC; i++) {
      var cfg = PG.fixCfg(makeBotCfg(rnd)); cfg.hat = 1 + Math.floor(rnd() * 7); cfg.scarf = Math.floor(rnd() * 4);
      var model = PG.spectatorModel(cfg);
      model.parts.forEach(function (pt) { if (!pt.gl) pt.gl = R.upload(pt.mesh); });
      specSet.push({ model: model, lite: R.upload(PG.spectatorLite(cfg)) });
    }
    return specSet;
  }
  function drawSpectators(now, t) {
    var T = G.T, specs = T.specs; if (!specs || !specs.length) return;
    var R = G.R, set = specSetup(), eye = cam.eye, tg = cam.target;
    var fx = tg[0] - eye[0], fy = tg[1] - eye[1], fz = tg[2] - eye[2], fl = Math.sqrt(fx * fx + fy * fy + fz * fz) || 1; fx /= fl; fy /= fl; fz /= fl;
    var race = G.race, rp = [], i, k;
    for (i = 0; i < race.racers.length; i++) { var rr = race.racers[i]; wpos(rr, _w); rp.push(_w[0], _w[1], _w[2]); }
    var drawn = 0;
    for (i = 0; i < specs.length; i++) {
      var sp = specs[i], dx = sp.x - eye[0], dy = sp.y - eye[1], dz = sp.z - eye[2], d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > 170 * 170) continue;
      var dot = dx * fx + dy * fy + dz * fz; if (dot < -3) continue;
      if (dot > 0 && d2 > 16 * 16) { var pr = d2 - dot * dot; if (pr > (dot * 1.25) * (dot * 1.25) + 25) continue; } // fuera del cono de vision
      var near = d2 < 34 * 34, v = set[sp.k % NSPEC], ty = sp.k % 6, ph = sp.k * 1.713, exc = 0;
      for (k = 0; k < rp.length; k += 3) { var ex = rp[k] - sp.x, ez = rp[k + 2] - sp.z; if (ex * ex + ez * ez < 45 * 45) { exc = 1; break; } }
      var tt = t * (1 + 0.5 * exc + (sp.k % 5) * 0.06) + ph, bounce = 0, aR = 0.3, aL = 0.3, roll = 0, yawO = Math.sin(t * 0.6 + ph) * 0.3;
      if (ty === 0) { aR = 1.9 + 0.5 * Math.sin(tt * 7); aL = 1.9 + 0.5 * Math.sin(tt * 7 + 1.5); bounce = Math.abs(Math.sin(tt * 5)) * 0.2; }
      else if (ty === 1) { aR = 1.7 + 0.6 * Math.sin(tt * 9); aL = -1.0; roll = Math.sin(tt * 2) * 0.07; }
      else if (ty === 2) { bounce = Math.max(0, Math.sin(tt * 4.2)) * 0.75; aR = aL = 1.6 + 0.3 * Math.sin(tt * 8); }
      else if (ty === 3) { aR = aL = -0.8 + Math.sin(tt * 12) * 0.35; bounce = Math.abs(Math.sin(tt * 6)) * 0.07; }
      else if (ty === 4) { roll = Math.sin(tt * 1.8) * 0.16; aR = 0.4 + 0.5 * Math.sin(tt * 1.8); aL = 0.4 + 0.5 * Math.sin(tt * 1.8 + 3.1); yawO *= 1.6; }
      else { aR = 0.5 + 1.2 * Math.max(0, Math.sin(tt * 5)); aL = 0.5 + 1.2 * Math.max(0, Math.sin(tt * 5 + 3.14)); bounce = Math.abs(Math.sin(tt * 5)) * 0.1; }
      if (exc) bounce *= 1.4;
      var sc = 2.1 + (sp.k % 3) * 0.08;
      m4.trs(_sm, sp.x, sp.y + bounce, sp.z, sp.yaw + yawO, 0, roll, sc, sc, sc);
      drawn++;
      if (!near) { R.draw(v.lite, _sm, null, 1); continue; }
      var parts = v.model.parts;
      for (k = 0; k < parts.length; k++) {
        var pt = parts[k], M = _sm;
        if (pt.kind === 'flipR') { m4.trs(_sm2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, aR, 1, 1, 1); M = m4.mul(_sm3, _sm, _sm2); }
        else if (pt.kind === 'flipL') { m4.trs(_sm2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, -aL, 1, 1, 1); M = m4.mul(_sm3, _sm, _sm2); }
        R.draw(pt.gl, M, null, 1);
      }
    }
    G.specDrawn = drawn;
  }

  function drawWorld(now, dt) {
    var R = G.R, T = G.T, race = G.race, t = now / 1000;
    var focus = G.me || (race.order && race.order[0]) || race.racers[0];
    var camS = focus ? T.uToS(focus.u) : 0;
    R.draw(G.tmesh, null, null, 1);
    function vis(s) { var d = T.dS(camS, s); return d > -50 && d < 330; }
    var i, k, w = _w;
    // esferas luminosas: objetos (azul) y habilidades (violeta). Las partes translucidas se dibujan al final.
    var orbs = G.orbs; orbs.length = 0; G.halos.length = 0;
    for (k = 0; k < T.boxes.length; k++) {
      var B = T.boxes[k]; if (!vis(B.s) || race.boxT[k] > race.time) continue;
      var q = T.q(B.s), gy = T.ground(B.s, B.d); if (gy < -1e8) continue;
      var since = race.time - (race.boxT[k] || 0), ap = since > 0 && since < 0.6 ? 0.25 + since * 1.25 : 1;
      var bx = q.x + q.rx * B.d, bz = q.z + q.rz * B.d, by = gy + 1.75 + Math.sin(t * 2.5 + k) * 0.22;
      m4.trs(_m2, bx, by, bz, q.yaw + Math.sin(t * 1.3 + k) * 0.5, 0, 0, ap, ap, ap); R.draw(gm.orbItem, _m2, null, 1);
      m4.trs(_m2, bx, by, bz, t * 1.9 + k, 0, 0, ap, ap, ap); R.draw(gm.orbRingI, _m2, null, 1);
      orbs.push(0, bx, by, bz, ap, gy, t + k);
      G.halos.push(bx, by, bz, 4.2 * ap * (1 + Math.sin(t * 3 + k) * 0.08), 0.4, 0.85, 1.0, 0.5);
    }
    for (k = 0; k < T.crys.length; k++) {
      var Cr = T.crys[k]; if (!vis(Cr.s) || race.crysT[k] > race.time) continue;
      var qc = T.q(Cr.s), gc = T.ground(Cr.s, Cr.d); if (gc < -1e8) continue;
      var sinceC = race.time - (race.crysT[k] || 0), apC = sinceC > 0 && sinceC < 0.8 ? 0.25 + sinceC * 0.94 : 1;
      var cx = qc.x + qc.rx * Cr.d, cz = qc.z + qc.rz * Cr.d, cy = gc + 2.2 + Math.sin(t * 2 + k) * 0.3;
      m4.trs(_m2, cx, cy, cz, qc.yaw + Math.sin(t * 1.1 + k) * 0.5, 0, 0, apC, apC, apC); R.draw(gm.orbAbil, _m2, null, 1);
      m4.trs(_m2, cx, cy, cz, -t * 1.4 + k, 0, 0, apC, apC, apC); R.draw(gm.orbRingA, _m2, null, 1);
      orbs.push(1, cx, cy, cz, apC, gc, t + k);
      G.halos.push(cx, cy, cz, 6.2 * apC * (1 + Math.sin(t * 2.6 + k) * 0.08), 0.85, 0.55, 1.0, 0.55);
    }
    // obstaculos
    var pos = [0, 0];
    for (k = 0; k < T.obs.length; k++) {
      var o = T.obs[k]; if (!vis(o.s)) continue;
      if (race.ko[k] && race.ko[k] > race.time) continue;
      PG.obsPos(T, o, race.time, pos);
      var qo = T.q(pos[0]), go = T.ground(pos[0], pos[1]); if (go < -1e8) continue;
      var ox = qo.x + qo.rx * pos[1], oz = qo.z + qo.rz * pos[1];
      if (o.type === 'rock') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.rock[Math.floor(o.var * 3) % 3], _m2, null, 1); }
      else if (o.type === 'ice') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.ice, _m2, null, 1); }
      else if (o.type === 'snowman') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.snowman, _m2, null, 1); }
      else if (o.type === 'seal') {
        var dir = Math.cos(race.time * o.w + o.ph) > 0 ? 1 : -1;
        m4.trs(_m2, ox, go, oz, qo.yaw + dir * Math.PI / 2, 0, Math.sin(race.time * 6) * 0.08, 1, 1, 1); R.draw(gm.seal, _m2, null, 1);
      } else if (o.type === 'ball') {
        m4.trs(_m2, ox, go + 1.7, oz, qo.yaw, race.time * 3 + o.ph, 0, 1, 1, 1); R.draw(gm.ball, _m2, null, 1);
      } else if (o.type === 'tree') {
        var tsc = 0.9 + (o.var || 0) * 0.35; m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, tsc, tsc, tsc); R.draw(gm.tree, _m2, null, 1);
      } else if (o.type === 'icicle') {
        var ist = PG.icicleState(o, race.time), hy = T.centerY(pos[0]) + T.ceilAt(pos[0], pos[1]) + 0.6, shk = 0, iy = hy, isy = 1;
        if (ist.ph === 4) continue;
        if (ist.ph === 1) {
          shk = Math.sin(t * 70) * 0.16 * (0.4 + ist.f);
          m4.trs(_m2, ox, go + 0.05, oz, t * 2, 0, 0, 1 + ist.f * 0.2, 1, 1 + ist.f * 0.2); R.draw(gm.warn, _m2, null, 0.35 + 0.35 * Math.abs(Math.sin(t * 14)));
        } else if (ist.ph === 2) {
          iy = hy + (go + 5.2 - hy) * ist.f * ist.f;
          m4.trs(_m2, ox, go + 0.05, oz, 0, 0, 0, 1.2, 1, 1.2); R.draw(gm.warn, _m2, null, 0.8);
        } else if (ist.ph === 3) {
          iy = go + 5.2 * (1 - ist.f * 0.65); isy = 0.35 + (1 - ist.f) * 0.65;
          if (o._shat !== Math.floor((race.time + o.ph) / o.per)) { o._shat = Math.floor((race.time + o.ph) / o.per); burst(ox, go + 0.6, oz, 18, [0.8, 0.95, 1], 9, 0.45, 0.9); if (G.me && Math.abs(G.me.u - o.s) < 80) Audio.sfx('pop'); }
        }
        m4.trs(_m2, ox + shk, iy, oz, o.yaw, 0, 0, 1, isy, 1); R.draw(gm.icicle, _m2, null, ist.ph === 3 ? clamp(1 - (ist.f - 0.6) * 2.5, 0.2, 1) : 1);
      }
    }
    // trampas y proyectiles
    for (k = 0; k < race.traps.length; k++) {
      var tr = race.traps[k]; wposUD(tr.u, tr.d, w);
      m4.trs(_m2, w[0], w[1] + 0.1, w[2], t * 1.5, 0, 0, 1, 1, 1); R.draw(gm.trap, _m2, null, 1);
    }
    for (k = 0; k < race.proj.length; k++) {
      var pj = race.proj[k]; wposUD(pj.u, pj.d, w);
      if (pj.kd === 'gren') {
        m4.trs(_m2, w[0], w[1] + Math.max(0.4, pj.h), w[2], t * 9, t * 14, 0, 1, 1, 1); R.draw(gm.grenade, _m2, null, 1);
        if (particles.length < MAXP - 3) emitP(w[0], w[1] + pj.h + 0.5, w[2], rnd2(), rnd2() + 1, rnd2(), 0.35, 0.3, 1, 0.6 + Math.random() * 0.3, 0.15, 0.9, 0);
        continue;
      }
      if (pj.kd === 'mega') {
        var msc = 1 + Math.sin(t * 20) * 0.03;
        m4.trs(_m2, w[0], w[1] + 2.3, w[2], G.T.q(G.T.uToS(pj.u)).yaw + (pj.dir < 0 ? Math.PI : 0), -t * 6 * (pj.dir || 1), 0, msc, msc, msc); R.draw(gm.megaball, _m2, null, 1);
        G.halos.push(w[0], w[1] + 2.3, w[2], 8, 0.7, 0.9, 1, 0.35);
        if (particles.length < MAXP - 6) { for (var mq = 0; mq < 3; mq++) emitP(w[0] + rnd2() * 1.5, w[1] + 1 + Math.random() * 2.5, w[2] + rnd2() * 1.5, rnd2() * 2, Math.random() * 2, rnd2() * 2, 0.6, 0.7, 0.9, 0.97, 1, 0.8, 1); }
        continue;
      }
      var psz = pj.lt ? 0.55 : 1;
      m4.trs(_m2, w[0], w[1] + 0.9, w[2], 0, t * 12, 0, psz, psz, psz); R.draw(gm.snowball, _m2, pj.lt ? [0.7, 0.95, 1.0] : null, 1);
      if (particles.length < MAXP - 3) emitP(w[0], w[1] + 0.9, w[2], rnd2(), rnd2(), rnd2(), 0.35, pj.lt ? 0.22 : 0.3, pj.lt ? 0.6 : 1, 1, 1, 0.7, 0);
    }
    // objetos destruidos que salen volando (focas, etc.)
    var fl = G.flyers;
    for (k = fl.length - 1; k >= 0; k--) {
      var f = fl[k]; f.life -= dt; if (f.life <= 0) { fl.splice(k, 1); continue; }
      f.vy -= 22 * dt; f.x += f.vx * dt; f.y += f.vy * dt; f.z += f.vz * dt; f.a += f.va * dt; f.b += f.vb * dt;
      var fm = f.type === 'rock' ? gm.rock[0] : gm[f.type]; if (!fm) continue;
      var fs = f.sc * clamp(f.life * 2, 0.01, 1);
      m4.trs(_m2, f.x, f.y, f.z, f.a, f.b, 0, fs, fs, fs); R.draw(fm, _m2, null, 1);
      if (particles.length < MAXP - 2 && Math.random() < 0.5) emitP(f.x, f.y, f.z, rnd2(), rnd2(), rnd2(), 0.4, 0.3, 1, 1, 1, 0.7, 0);
    }
    // ventiscas
    for (k = 0; k < race.tornados.length; k++) {
      var tn = race.tornados[k]; wposUD(tn.u + tn.t * 26, tn.d, w);
      var sc = 0.6 + tn.t * 0.6, al = clamp(1 - tn.t / tn.life, 0, 1) * 0.55;
      m4.trs(_m2, w[0], w[1], w[2], tn.t * 9, 0, 0, sc, sc, sc); R.draw(gm.tornado, _m2, null, al);
    }
    drawSpectators(now, t);
    // pinguinos (lejanos primero no importa: sin transparencia)
    for (i = 0; i < race.racers.length; i++) drawRacer(race.racers[i], now, t);
    // partes translucidas de las esferas (cascaron, luz en el suelo)
    for (i = 0; i < orbs.length; i += 7) {
      var isA = orbs[i] === 1, ox2 = orbs[i + 1], oy2 = orbs[i + 2], oz2 = orbs[i + 3], oa = orbs[i + 4], og = orbs[i + 5], ot = orbs[i + 6];
      m4.trs(_m2, ox2, og, oz2, ot * 0.6, 0, 0, oa, oa, oa); R.draw(isA ? gm.glowA : gm.glowI, _m2, null, 0.17 + Math.sin(ot * 3) * 0.04);
      m4.trs(_m2, ox2, oy2, oz2, 0, 0, 0, oa, oa, oa); R.draw(isA ? gm.orbShellA : gm.orbShellI, _m2, null, 0.26 + Math.sin(ot * 4) * 0.05);
    }
  }

  function drawParticles(dt) {
    var R = G.R, arr = R.partArr, n = 0, i;
    for (i = particles.length - 1; i >= 0; i--) {
      var p = particles[i]; p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.vy -= p.gr * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    }
    for (i = 0; i < particles.length && n < R.partCap; i++) {
      var q = particles[i], o = n * 8, f = q.life / q.max;
      arr[o] = q.x; arr[o + 1] = q.y; arr[o + 2] = q.z; arr[o + 3] = q.size * (0.6 + 0.6 * f);
      arr[o + 4] = q.r; arr[o + 5] = q.g; arr[o + 6] = q.b; arr[o + 7] = q.a * Math.min(1, f * 1.8);
      n++;
    }
    var hl = G.halos;
    for (i = 0; i + 7 < hl.length && n < R.partCap; i += 8) {
      var o2 = n * 8; arr[o2] = hl[i]; arr[o2 + 1] = hl[i + 1]; arr[o2 + 2] = hl[i + 2]; arr[o2 + 3] = hl[i + 3];
      arr[o2 + 4] = hl[i + 4]; arr[o2 + 5] = hl[i + 5]; arr[o2 + 6] = hl[i + 6]; arr[o2 + 7] = hl[i + 7]; n++;
    }
    R.drawParticles(arr, n);
  }

  var tagVec = [0, 0, 0];
  function updateTags() {
    var R = G.R, race = G.race, me = G.me, vp = R.vp, W = window.innerWidth, H = window.innerHeight;
    race.racers.forEach(function (r) {
      var el = G.tagEls && G.tagEls[r.id]; if (!el) return;
      var w = wpos(r, tagVec), x = w[0], y = w[1] + 2.4, z = w[2];
      var cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12], cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13], cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15];
      var d = me ? Math.abs(r.u - me.u) : 0;
      if (cw <= 1 || d > 90 || r.fell) { el.style.display = 'none'; return; }
      el.style.display = 'block'; el.style.left = ((cx / cw * 0.5 + 0.5) * W).toFixed(0) + 'px'; el.style.top = ((1 - (cy / cw * 0.5 + 0.5)) * H).toFixed(0) + 'px';
      el.style.opacity = clamp(1.4 - d / 90, 0.3, 1);
    });
  }

  function renderPreview(now) {
    var t = now / 1000, p = preview.pos; if (!p) return;
    preview.yaw += 0.012;
    var yaw = preview.manual ? preview.yawBase + Math.PI + preview.rot : preview.yawBase + Math.PI + 0.5 + Math.sin(t * 0.7) * 0.9;
    if (!preview.manual) preview.rot = 0.5 + Math.sin(t * 0.7) * 0.9;
    drawPenguinAt(G.cfg, p[0], p[1] + Math.sin(t * 2) * 0.05 + (G.dbgFlip ? 1.2 : 0), p[2], G.dbgYaw !== undefined ? G.dbgYaw : yaw, 0.06 + (G.dbgFlip || 0), 0, 1.9, t, { speed: 0.6, steer: Math.sin(t) * 0.4, wings: false, extra: G.dbgCannon ? gm.cannon : null, pv: G.dbgFlip ? 0.32 : 0 });
    m4.trs(_m2, p[0], p[1] - 0.05, p[2], 0, 0, 0, 2.2, 1, 2.8); G.R.draw(gm.shadow, _m2, null, 0.3);
  }

  /* ---------------- clima: ventiscas ocasionales ---------------- */
  var wx = G.wx = { k: 0, on: false, t: 0, next: 18, dur: 0, dir: 0 };
  function resetWeather() { wx.k = 0; wx.on = false; wx.t = 0; wx.next = (G.T && G.T.themeName === 'storm') ? 6 : 14 + Math.random() * 12; }
  function updateWeather(dt, now) {
    var storm = G.T.themeName === 'storm', racing = G.mode === 'race' && !G.paused && G.race && G.race.time > 0;
    if (racing) {
      wx.t += dt;
      if (!wx.on) {
        if (wx.t > wx.next) { wx.on = true; wx.t = 0; wx.dur = 8 + Math.random() * 6; wx.dir = Math.random() * 6.283; toast('❄ ¡Se acerca una ventisca!', 1800); }
      } else if (wx.t > wx.dur) { wx.on = false; wx.t = 0; wx.next = storm ? 9 + Math.random() * 9 : 24 + Math.random() * 26; }
    } else if (G.mode !== 'race') { wx.on = false; }
    var tgt = (G.mode === 'race' || G.camMode === 'race') ? Math.max(storm ? 0.3 : 0, wx.on ? 1 : 0) : 0;
    wx.k += (tgt - wx.k) * Math.min(1, dt * (tgt > wx.k ? 0.8 : 0.5));
    if (wx.k < 0.002) wx.k = 0;
    wx.gust = wx.k * (0.85 + 0.15 * Math.sin(now * 0.0017) * Math.sin(now * 0.0041));
    G.R.stormK = wx.gust;
    var fx = $('stormFx'); if (fx) fx.style.opacity = (wx.gust * 0.42).toFixed(3);
    Audio.storm(G.paused ? 0 : wx.gust, now / 1000);
  }

  /* ---------------- sensacion de velocidad: lineas radiales y vineta ---------------- */
  var sfx = { cv: null, ctx: null, w: 0, h: 0 };
  function drawSpeedFx(dt, now) {
    var cv = sfx.cv || (sfx.cv = $('speedFx')); if (!cv) return;
    var W = window.innerWidth, H = window.innerHeight;
    if (sfx.w !== W || sfx.h !== H) { cv.width = Math.max(64, W >> 1); cv.height = Math.max(64, H >> 1); sfx.w = W; sfx.h = H; sfx.ctx = cv.getContext('2d'); }
    var x = sfx.ctx, w = cv.width, h = cv.height, me = G.me;
    x.clearRect(0, 0, w, h);
    if (!me || G.mode !== 'race' || G.paused) { $('vignette').style.opacity = 0; return; }
    var kmh = me.speed * 3.6, boost = (me.fx.boost > 0 || me.fx.pad > 0) ? 0.4 : 0, down = clamp(-(G.T.q(G.T.uToS(me.u)).sl) * 2.2, 0, 0.5);
    var k = clamp((kmh - 85) / 90 + boost + down, 0, 1.25);
    $('vignette').style.opacity = clamp(k * 0.75, 0, 0.9).toFixed(2);
    if (k < 0.03) return;
    var cx = w * 0.5, cy = h * 0.46, diag = Math.sqrt(w * w + h * h) * 0.5, n = Math.floor(10 + 34 * k), i;
    x.lineCap = 'round';
    for (i = 0; i < n; i++) {
      var a = Math.random() * 6.2832, r0 = diag * (0.32 + Math.random() * 0.4), len = diag * (0.08 + Math.random() * 0.22) * (0.5 + k * 0.7);
      var al = (0.10 + Math.random() * 0.32) * Math.min(1, k * 1.3);
      x.strokeStyle = 'rgba(' + (boost ? '255,235,190' : '235,248,255') + ',' + al.toFixed(2) + ')';
      x.lineWidth = 1 + Math.random() * 2.2;
      x.beginPath(); x.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); x.lineTo(cx + Math.cos(a) * (r0 + len), cy + Math.sin(a) * (r0 + len)); x.stroke();
    }
  }

  /* ---------------- resolucion adaptativa ---------------- */
  var perf = { ema: 16.7, n: 0, lastDown: 0, lastUp: 0, last: 0 };
  function perfTick(now) {
    var d = now - perf.last; perf.last = now;
    if (d <= 0 || d > 200) return;
    perf.n++; if (perf.n < 40) return;
    perf.ema += (d - perf.ema) * 0.06;
    var R = G.R;
    if (perf.ema > 26 && R.dyn > 0.5 && now - perf.lastDown > 1500) {
      R.dyn = Math.max(0.5, R.dyn * 0.87); perf.lastDown = now; perf.ema = 20; R.resize(G.set.quality);
    } else if (perf.ema < 17.6 && R.dyn < 1 && now - perf.lastDown > 20000 && now - perf.lastUp > 6000) {
      R.dyn = Math.min(1, R.dyn * 1.07); perf.lastUp = now; R.resize(G.set.quality);
    }
  }

  /* ---------------- bucle principal ---------------- */
  G.orbs = []; G.halos = [];
  G.last = 0; G.frames = 0; var acc = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.05, (now - (G.last || now)) / 1000); G.last = now;
    if (!G.R || !G.T) return;
    G.frames++;
    if (G.frames % 20 === 1) G.R.resize(G.set.quality);
    perfTick(now);
    var race = G.race;
    if (race && !G.paused) {
      var input = G.mode === 'race' ? readInput() : null;
      race.time = (now - G.goAt) / 1000; race.nowMs = now;
      acc += dt;
      var steps = 0;
      while (acc >= 1 / 60 && steps < 5) {
        race.update(1 / 60, input);
        if (input) { input.useItem = false; input.useAbility = false; input.push = false; }
        acc -= 1 / 60; steps++;
        for (var q = 0; q < race.fxq.length; q++) handleFx(race.fxq[q]);
        race.fxq.length = 0;
      }
      if (acc > 0.1) acc = 0;
      if (G.mp && G.mode === 'race') netTick(dt, now);
      else race.out.length = 0;
      if (G.mode === 'demo' || G.demo) { // reiniciar demo cuando todos terminan
        if (race.racers.every(function (r) { return r.finished; })) { G.race = null; ensureDemoRestart(); }
      }
    }
    race = G.race;
    if (!race) { return; }
    updateCamera(dt, now);
    var th = G.T.theme;
    updateWeather(dt, now);
    var fo = G.me || (race.order && race.order[0]) || race.racers[0];
    var inCv = fo && G.T.inCave && G.T.inCave(G.T.uToS(fo.u), -3) ? 1 : 0;
    G.caveK = (G.caveK || 0) + (inCv - (G.caveK || 0)) * Math.min(1, dt * 3.5);
    G.R.caveK = G.caveK;
    G.R.begin(th, cam, now / 1000);
    drawWorld(now, dt);
    if (G.camMode === 'preview') renderPreview(now);
    drawParticles(dt);
    var wk = wx.gust, wsp = G.T.themeName === 'storm' ? 14 : 2;
    G.R.drawSnow(now / 1000, (th.flakes + wk * 2.4) * (1 - 0.9 * (G.caveK || 0)), [wsp + wk * 24 * Math.cos(wx.dir), 3.2 + wk * 5, 1 + wk * 24 * Math.sin(wx.dir)]);
    if (G.mode === 'race' && G.me) {
      updateHud(now); updateTags(); if (G.frames % 3 === 0) drawMini();
      if (G.paused) Audio.slide(0, false); else Audio.slide(clamp(G.me.speed / 40, 0, 1.3), G.me.grounded && !G.me.fell);
      updateFireBtn(); drawSpeedFx(dt, now); checkLastPlace();
      if (G.resultsAt && now > G.resultsAt && !G.paused) { G.resultsAt = 0; showResults(); }
      if (G.screen === 'scrResults') refreshResults();
    } else { Audio.slide(0, false); if (sfx.ctx) sfx.ctx.clearRect(0, 0, sfx.cv.width, sfx.cv.height); }
  }
  function ensureDemoRestart() { G.demo = false; if (G.mode !== 'race') ensureDemo(); }

  /* ---------------- resultados ---------------- */
  function showResults() {
    G.screen = 'scrResults';
    $('scrResults').classList.add('show');
    var host = !G.mp || G.myId === G.hostId;
    $('btnNext').textContent = G.mp ? 'Volver a la sala' : 'Siguiente pista';
    $('btnNext').style.display = (host || !G.mp) ? '' : 'none';
    refreshResults();
  }
  function refreshResults() {
    var race = G.race; if (!race) return;
    var arr = race.racers.slice().sort(function (a, b) {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1; if (b.finished) return 1; return b.u - a.u;
    });
    var html = '', allDone = true;
    arr.forEach(function (r, i) {
      if (!r.finished) allDone = false;
      html += '<div class="rrow' + (r === G.me ? ' me' : '') + '"><span class="pos">' + (i + 1) + '</span><span class="dot" style="background:' + bodyColor(r.cfg) + '"></span><span>' + esc(r.name) + '</span><span class="tm">' + (r.finished ? fmtTime(r.finishTime) : 'en carrera…') + '</span></div>';
    });
    if (G.lastResHtml !== html) { G.lastResHtml = html; $('resList').innerHTML = html; }
    $('resTitle').textContent = allDone ? 'Resultados finales' : 'Resultados (en vivo)';
    $('resMsg').textContent = G.resMsg || '';
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------------- red: bucle y mensajes ---------------- */
  var netLast = 0;
  function netTick(dt, now) {
    var race = G.race;
    if (now - netLast >= 50) {
      netLast = now;
      for (var i = 0; i < race.racers.length; i++) {
        var r = race.racers[i]; if (!r.own || r.fell && false) continue;
        var x = 0, f = r.fx;
        if (f.boost > 0 || f.pad > 0) x |= 1; if (f.spin > 0) x |= 2; if (f.shield > 0) x |= 4; if (f.push > 0) x |= 512;
        if (f.wings > 0) x |= 16; if (r.fell) x |= 32; if (r.grounded) x |= 64; if (f.ghost > 0) x |= 128; if (f.cannon > 0) x |= 256; if (f.cannon > 0 && r.gun === 'gren') x |= 1024; if (f.superjump > 0) x |= 2048;
        Net.send({ t: 's', r: r.id, u: +r.u.toFixed(2), d: +r.d.toFixed(2), p: +r.psi.toFixed(3), v: +r.vf.toFixed(1), l: +r.vl.toFixed(1), y: +r.py.toFixed(2), x: x, n: r.lap, st: +r.steerVis.toFixed(2), fm: r.flipping ? r.flipMode * r.flipDir : 0, fl: +r.flipAcc.toFixed(2) });
      }
    }
    if (race.out.length) { Net.send({ t: 'e', ev: race.out.slice() }); race.out.length = 0; }
  }
  G.players = {};
  G.lobby = { track: 0, bots: true, diff: 1 };
  function sendLobby() { Net.send({ t: 'lobby', track: G.lobby.track, bots: G.lobby.bots, diff: G.lobby.diff }); }

  function onNetMsg(m) {
    var race = G.race;
    switch (m.t) {
      case 'welcome':
        G.myId = m.id; G.hostId = m.host; G.players = {}; G.players[m.id] = { id: m.id, name: G.cfg.name, cfg: G.cfg };
        Net.send({ t: 'hello', name: G.cfg.name, cfg: G.cfg, ver: VERSION });
        G.roomIp = m.ip || G.roomIp || ''; if (m.code) G.roomCode = m.code;
        go('scrLobby'); renderLobby();
        break;
      case 'hello':
        G.players[m.f] = { id: m.f, name: String(m.name || 'Jugador').slice(0, 12), cfg: PG.fixCfg(m.cfg) };
        if (m.ver !== VERSION && !G.verWarned) { G.verWarned = true; toast('Otro jugador usa otra versión del juego (' + (m.ver || 'antigua') + '). Instalen la misma APK.', 4500); }
        if (G.myId === G.hostId) sendLobby();
        renderLobby();
        break;
      case 'leave':
        delete G.players[m.id];
        if (G.mode === 'race' && race) { race.removeRacer('p' + m.id); if (G.tagEls && G.tagEls['p' + m.id]) { G.tagEls['p' + m.id].remove(); delete G.tagEls['p' + m.id]; } if (mk['p' + m.id]) { mk['p' + m.id].remove(); delete mk['p' + m.id]; } toast('Un jugador salió'); }
        renderLobby();
        break;
      case 'host':
        G.hostId = m.id; renderLobby();
        if (G.mode === 'race' && race && G.myId === G.hostId) race.racers.forEach(function (r) { if (r.bot) r.own = true; });
        break;
      case 'lobby': G.lobby.track = m.track | 0; G.lobby.bots = !!m.bots; if (m.diff !== undefined) G.lobby.diff = m.diff | 0; renderLobby(); break;
      case 'start': G.mp = true; beginRace(m, false); break;
      case 'back':
        G.race = null; G.me = null; G.mode = 'menu'; $('hud').classList.add('hidden'); G.camMode = 'demo'; G.nav = []; ensureDemo(); go('scrLobby'); G.nav = ['scrMain']; renderLobby();
        break;
      case 's':
        if (race && G.mode === 'race') { var r = race.byId[m.r]; if (r && !r.own) r.net = { u: m.u, d: m.d, psi: m.p, vf: m.v, vl: m.l, y: m.y, x: m.x | 0, lap: m.n, st: m.st, fm: m.fm | 0, fl: m.fl || 0, t: performance.now() }; }
        break;
      case 'e':
        if (race && m.ev) for (var i = 0; i < m.ev.length; i++) race.applyEvent(m.ev[i]);
        break;
    }
  }
  Net.on.msg = onNetMsg;
  Net.on.hosted = function (h) { G.roomIp = h.ip || ''; Net.connect('127.0.0.1:' + Net.PORT); };
  Net.on.open = function () { };
  Net.on.room = function (code) { G.roomCode = code; };
  Net.on.close = function (why) {
    if (G.mp || G.screen === 'scrLobby') { toast(typeof why === 'string' && why.length > 3 && why !== 'cerrada' ? why : 'Se perdió la conexión', 3000); G.online = false; G.mp = false; if (G.mode === 'race') { quitRace(true); } else { G.nav = []; go('scrMain'); } }
  };
  Net.on.error = function (msg) {
    if (G.online) {
      G.mp = false; G.online = false;
      var on = $(Net.role === 'host' ? 'onlHostNote' : 'onlJoinNote'); if (on) { on.textContent = String(msg || 'No se pudo conectar'); on.className = 'note err'; }
      var bh = $('btnHostOnline'); if (bh) bh.disabled = false;
      return;
    }
    var n = $('joinNote'); if (n) { n.textContent = 'No se pudo conectar: ' + (msg || ''); n.className = 'note err'; }
    var h = $('hostNote'); if (h && Net.role === 'host') { h.textContent = String(msg || ''); h.className = 'note err'; }
  };
  var rooms = [];
  Net.on.rooms = function (list) { rooms = list || []; renderRooms(); };

  function showTab(lan) {
    $('panNet').style.display = lan ? 'none' : ''; $('panLan').style.display = lan ? '' : 'none';
    $('tabNet').classList.toggle('sel', !lan); $('tabLan').classList.toggle('sel', lan);
    if (lan) { renderRooms(); Net.startDiscovery(); } else Net.stopDiscovery();
  }
  function hostOnline() {
    var n = $('onlHostNote'); n.className = 'note'; n.textContent = 'Creando sala en internet…'; $('btnHostOnline').disabled = true;
    G.mp = true; G.online = true; G.roomCode = '';
    Net.hostOnline();
  }
  function joinOnline() {
    var code = PG.Online.normCode($('inCode').value), n = $('onlJoinNote');
    if (code.length !== 5) { n.textContent = 'El código tiene 5 letras o números'; n.className = 'note err'; return; }
    G.set.code = code; saveSet();
    n.className = 'note'; n.textContent = 'Buscando la sala ' + code + '…';
    G.mp = true; G.online = true; G.roomCode = code;
    Net.joinOnline(code);
  }
  function shareCode() {
    var txt = 'Únete a mi carrera de pingüinos en Penguin Slippery. Código de sala: ' + (G.roomCode || '');
    try { if (navigator.share) { navigator.share({ text: txt }); return; } } catch (e) { }
    try { if (navigator.clipboard) { navigator.clipboard.writeText(G.roomCode || ''); toast('Código copiado'); return; } } catch (e) { }
    toast('Código: ' + (G.roomCode || ''));
  }
  function setupMulti() {
    var native = Net.native;
    $('onlHostNote').textContent = ''; $('onlHostNote').className = 'note'; $('onlJoinNote').textContent = ''; $('onlJoinNote').className = 'note'; $('btnHostOnline').disabled = false;
    $('inCode').value = G.set.code || '';
    showTab(false);
    $('hostNote').className = 'note';
    $('hostNote').textContent = native ? 'Tu IP: ' + (Net.localIp() || '(conéctate al WiFi)') : 'En el navegador: ejecuta server/server.js en un PC y abre su dirección.';
    $('joinNote').textContent = ''; $('joinNote').className = 'note';
    $('inIp').value = G.set.ip || '';
  }
  function renderRooms() {
    var el = $('roomList'); if (!el) return;
    if (!rooms.length) { el.innerHTML = '<p class="note">' + (Net.native ? 'Buscando salas en tu red…' : 'La búsqueda automática solo funciona en la app.') + '</p>'; return; }
    el.innerHTML = rooms.map(function (r) { return '<div class="room" data-ip="' + esc(r.ip) + '"><span>' + esc(r.name) + '<br><small>' + esc(r.ip) + ' · ' + (r.players | 0) + ' jugador(es)</small></span><span>Unirse ›</span></div>'; }).join('');
  }
  function hostRoom() {
    $('hostNote').className = 'note'; $('hostNote').textContent = 'Creando sala…';
    G.mp = true; G.online = false; Net.role = 'host';
    if (Net.native) Net.host(G.cfg.name);
    else Net.connect(location.host);
  }
  function joinRoom(ip) {
    ip = String(ip || '').trim(); if (!ip) { $('joinNote').textContent = 'Escribe la IP del anfitrión'; $('joinNote').className = 'note err'; return; }
    G.set.ip = ip; saveSet(); G.mp = true; G.online = false; Net.role = 'client'; G.roomIp = ip;
    $('joinNote').className = 'note'; $('joinNote').textContent = 'Conectando a ' + ip + '…';
    Net.connect(ip);
  }
  function leaveRoom() { Net.close(); G.mp = false; G.online = false; G.players = {}; G.nav = []; go('scrMain'); }
  function renderLobby() {
    var host = G.myId === G.hostId, ids = Object.keys(G.players).map(Number).sort(function (a, b) { return a - b; });
    $('playerList').innerHTML = ids.map(function (id) {
      var p = G.players[id];
      return '<div class="prow"><span class="dot" style="background:' + bodyColor(p.cfg) + '"></span><span class="' + (id === G.myId ? 'me' : '') + '">' + esc(p.name) + (id === G.myId ? ' (tú)' : '') + '</span>' + (id === G.hostId ? '<span class="host">Anfitrión</span>' : '') + '</div>';
    }).join('');
    $('lobbyRole').textContent = host ? 'Eres el anfitrión' : 'Esperando al anfitrión';
    $('lobbyTrack').textContent = PG.TRACKS[G.lobby.track].name + ' · ' + (PG.TRACKS[G.lobby.track].type === 'circuit' ? '3 vueltas' : 'Bajada A→B');
    $('btnLobbyTrack').style.display = host ? '' : 'none';
    $('btnStart').style.display = host ? '' : 'none';
    $('chkBots').disabled = !host; $('chkBots').checked = !!G.lobby.bots;
    renderDiff('segDiffLobby', G.lobby.diff, host);
    var on = !!G.online;
    $('roomLbl').textContent = on ? 'Código de sala' : 'IP de la sala'; $('roomIp').className = on ? 'code' : ''; $('btnShare').style.display = on ? '' : 'none';
    $('roomIp').textContent = on ? (G.roomCode || '—') : (G.roomIp || (Net.native ? (Net.localIp() || '—') : location.host || '—'));
    $('lobbyNote').textContent = host ? (ids.length < 2 ? (on ? 'Pasa este código a tus amigos: pueden estar en cualquier red.' : 'Comparte tu IP con los demás jugadores (mismo WiFi).') : ids.length + ' jugadores conectados.') : 'El anfitrión elegirá la pista.';
  }
  function hostStart() {
    var humans = Object.keys(G.players).map(Number).sort(function (a, b) { return a - b; }).map(function (id) { return G.players[id]; });
    var seed = (Math.random() * 1e9) | 0, roster = makeRoster(humans, G.lobby.bots, seed);
    var m = { t: 'start', track: G.lobby.track, seed: seed, startIn: 5000, roster: roster, diff: G.lobby.diff };
    Net.send(m); G.mp = true; beginRace(m, false);
  }

  /* ---------------- selector de pistas ---------------- */
  G.trackMode = 'solo'; G.selTrack = 0;
  function buildTrackGrid() {
    var grid = $('trackGrid'); grid.innerHTML = '';
    G.tracksInfo.forEach(function (ti, i) {
      var d = document.createElement('div'); d.className = 'tcard' + (i === G.selTrack ? ' sel' : ''); d.dataset.i = i;
      d.innerHTML = '<span class="num">' + (i + 1) + '</span><canvas width="300" height="190"></canvas><div class="tn">' + esc(ti.name) + '</div><div class="tt">' + (ti.type === 'circuit' ? '3 vueltas' : 'Bajada A→B') + ' · ' + Math.round(ti.len) + ' m</div>';
      grid.appendChild(d); drawThumb(d.querySelector('canvas'), ti);
    });
    $('btnTrackGo').textContent = G.trackMode === 'solo' ? '¡A correr!' : 'Elegir esta pista';
    $('diffSolo').style.display = G.trackMode === 'solo' ? '' : 'none'; renderDiff('segDiffSolo', G.set.diff, true);
    $('tracksTitle').textContent = 'Elige la pista';
    updTrackInfo();
  }
  var DIFF_DESC = ['Bots lentos y torpes', 'Bots equilibrados', 'Bots rápidos y agresivos', 'Bots casi perfectos'];
  function renderDiff(id, val, enabled) {
    var el = $(id); if (!el) return;
    el.innerHTML = PG.DIFFS.map(function (n, i) { return '<button data-d="' + i + '" class="' + (i === val ? 'sel' : '') + '"' + (enabled ? '' : ' disabled') + '>' + n + '</button>'; }).join('');
    el.title = DIFF_DESC[val] || '';
  }
  function updTrackInfo() { var d = PG.TRACKS[G.selTrack]; $('trackInfo').textContent = d.name + ' — ' + d.blurb; }
  function drawThumb(cv, ti) {
    var x = cv.getContext('2d'), th = ti.thumb, W = cv.width, H = cv.height, pad = 22, sc = Math.min((W - pad * 2) / th.w, (H - pad * 2) / th.h);
    var ox = (W - th.w * sc) / 2, oy = (H - th.h * sc) / 2;
    var theme = PG.THEMES[ti.theme], g = x.createLinearGradient(0, 0, 0, H);
    function c3(c, k) { return 'rgb(' + Math.round(c[0] * 255 * k) + ',' + Math.round(c[1] * 255 * k) + ',' + Math.round(c[2] * 255 * k) + ')'; }
    g.addColorStop(0, c3(theme.top, 1)); g.addColorStop(1, c3(theme.hor, 1));
    x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.lineJoin = 'round'; x.lineCap = 'round';
    function path() { x.beginPath(); th.pts.forEach(function (p, i) { var px = ox + p[0] * sc, py = oy + p[1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); if (ti.type === 'circuit') x.closePath(); }
    path(); x.strokeStyle = 'rgba(0,25,50,.7)'; x.lineWidth = 12; x.stroke();
    path(); x.strokeStyle = c3(theme.snow, 0.98); x.lineWidth = 8; x.stroke();
    path(); x.strokeStyle = c3(theme.ice, 1); x.lineWidth = 4; x.stroke();
    var p0 = th.pts[0], pl = th.pts[th.pts.length - 1];
    x.fillStyle = '#4cd964'; x.beginPath(); x.arc(ox + p0[0] * sc, oy + p0[1] * sc, 6, 0, 6.3); x.fill();
    if (ti.type === 'sprint') { x.fillStyle = '#ff5a4a'; x.beginPath(); x.arc(ox + pl[0] * sc, oy + pl[1] * sc, 6, 0, 6.3); x.fill(); }
  }

  /* ---------------- personalizacion ---------------- */
  function swatches(id, list, key, onPick) {
    var el = $(id); el.innerHTML = '';
    list.forEach(function (c, i) {
      var b = document.createElement('button'); b.style.background = c; b.className = G.cfg[key] === i ? 'sel' : '';
      b.addEventListener('click', function () { G.cfg[key] = i; saveCfg(); Audio.sfx('click'); buildCustomUI(); });
      el.appendChild(b);
    });
  }
  function chips(id, list, key) {
    var el = $(id); el.innerHTML = '';
    list.forEach(function (name, i) {
      var b = document.createElement('button'); b.textContent = name; b.className = G.cfg[key] === i ? 'sel' : '';
      b.addEventListener('click', function () { G.cfg[key] = i; saveCfg(); Audio.sfx('click'); buildCustomUI(); });
      el.appendChild(b);
    });
  }
  function buildCustomUI() {
    var nm = $('inName'); if (document.activeElement !== nm) nm.value = G.cfg.name;
    swatches('swBody', PG.PAL.body, 'body'); swatches('swFeet', PG.PAL.feet, 'feet');
    chips('chHat', PG.OPT.hats, 'hat'); swatches('swHat', PG.PAL.accent, 'hatCol');
    chips('chScarf', PG.OPT.scarves, 'scarf'); swatches('swScarf', PG.PAL.accent, 'scarfCol');
    chips('chGlasses', PG.OPT.glasses, 'glasses'); chips('chOutfit', PG.OPT.outfits, 'outfit'); swatches('swOut', PG.PAL.accent, 'outCol');
    $('swHat').style.display = G.cfg.hat ? '' : 'none'; $('swScarf').style.display = G.cfg.scarf ? '' : 'none'; $('swOut').style.display = G.cfg.outfit ? '' : 'none';
  }

  function markQuality() {
    var bs = $('segQuality').querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('sel', +bs[i].dataset.q === G.set.quality);
  }

  /* ---------------- acciones de UI ---------------- */
  var actions = {
    solo: function () { G.trackMode = 'solo'; go('scrTracks'); },
    multi: function () { go('scrMulti'); },
    custom: function () { go('scrCustom'); },
    settings: function () { go('scrSettings'); },
    back: function () { back(); },
    trackGo: function () {
      if (G.trackMode === 'solo') G.startSolo(G.selTrack);
      else { G.lobby.track = G.selTrack; sendLobby(); back(); renderLobby(); }
    },
    randomPeng: function () { var c = makeBotCfg(Math.random); c.name = G.cfg.name; G.cfg = PG.fixCfg(c); saveCfg(); buildCustomUI(); },
    hostRoom: hostRoom,
    joinIp: function () { joinRoom($('inIp').value); },
    tabNet: function () { showTab(false); },
    tabLan: function () { showTab(true); },
    hostOnline: hostOnline,
    joinCode: joinOnline,
    shareCode: shareCode,
    leave: leaveRoom,
    lobbyTrack: function () { G.trackMode = 'lobby'; G.selTrack = G.lobby.track; go('scrTracks'); },
    startRace: hostStart,
    nextRace: function () {
      if (G.mp) { if (G.myId === G.hostId) { Net.send({ t: 'back' }); onNetMsg({ t: 'back' }); } return; }
      var next = (G.trackIdx + 1) % PG.TRACKS.length; G.selTrack = next; $('scrResults').classList.remove('show'); G.startSolo(next);
    },
    toMenu: function () { $('scrResults').classList.remove('show'); quitRace(true); },
    resume: resumeRace,
    quitRace: function () { $('scrPause').classList.remove('show'); G.paused = false; quitRace(true); }
  };
  function bindUI() {
    $('screens').addEventListener('click', function (e) {
      Audio.init();
      var t = e.target.closest ? e.target.closest('[data-act]') : null;
      if (t) { Audio.sfx('click'); var a = actions[t.dataset.act]; if (a) a(); return; }
      var card = e.target.closest ? e.target.closest('.tcard') : null;
      if (card) { G.selTrack = +card.dataset.i; var cs = document.querySelectorAll('.tcard'); for (var i = 0; i < cs.length; i++) cs[i].classList.toggle('sel', i === G.selTrack); updTrackInfo(); Audio.sfx('click'); return; }
      var room = e.target.closest ? e.target.closest('.room') : null;
      if (room) { joinRoom(room.dataset.ip); }
    });
    document.addEventListener('pointerdown', function () { Audio.init(); Audio.retry(); }, { once: false, passive: true });
    $('inName').addEventListener('input', function (e) { G.cfg.name = e.target.value.slice(0, 12) || 'Pingu'; saveCfg(); });
    $('chkBots').addEventListener('change', function (e) { G.lobby.bots = e.target.checked; sendLobby(); });
    $('inBroker').addEventListener('change', function (e) {
      var v = String(e.target.value || '').trim();
      try { if (v) localStorage.setItem('pg_broker', v); else localStorage.removeItem('pg_broker'); } catch (er) { }
      toast(v ? 'Servidor online guardado' : 'Usando servidores públicos');
    });
    $('screens').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.segDiff button') : null; if (!b || b.disabled) return;
      var d = +b.dataset.d, id = b.parentNode.id; Audio.sfx('click');
      if (id === 'segDiffSolo') { G.set.diff = d; saveSet(); renderDiff(id, d, true); }
      else { G.lobby.diff = d; G.set.diff = d; saveSet(); sendLobby(); renderDiff(id, d, true); }
    });
    $('chkMusic').addEventListener('change', function (e) { G.set.music = e.target.checked; Audio.setMusicOn(G.set.music); saveSet(); });
    document.addEventListener('visibilitychange', function () { Audio.pauseAll(document.hidden); });
    $('chkSound').addEventListener('change', function (e) { G.set.sound = e.target.checked; Audio.setOn(G.set.sound); saveSet(); });
    $('segQuality').addEventListener('click', function (e) { var q = e.target.dataset && e.target.dataset.q; if (q !== undefined) { G.set.quality = +q; saveSet(); markQuality(); G.R.resize(G.set.quality); } });
    window.addEventListener('resize', function () { if (G.R) G.R.resize(G.set.quality); });
    setupTouch();
  }

  /* ---------------- arranque ---------------- */
  function boot() {
    $('verTxt').textContent = VERSION + (Net.native ? ' · app' : ' · web');
    Audio.on = G.set.sound; Audio.musicOn = G.set.music;
    G.lobby.diff = G.set.diff;
    bindUI();
    showLoading('Preparando el hielo…');
    setTimeout(function () {
      try {
        G.R = new PG.Renderer($('gl')); G.R.resize(G.set.quality);
        PG.TRACKS.forEach(function (d) {
          var T = PG.buildTrack(d, { noMesh: true });
          G.tracksInfo.push({ name: d.name, type: d.type, theme: d.theme, len: T.type === 'circuit' ? T.L : T.D, thumb: T.thumb });
        });
        loadTrack(0);
        G.camMode = 'demo'; G.mode = 'menu';
        ensureDemo();
        G.nav = []; requestAnimationFrame(frame);
        runIntro();
      } catch (err) {
        $('loadTxt').textContent = 'Error: ' + (err && err.message ? err.message : err);
        if (window.console) console.error(err);
      }
    }, 60);
  }
  function runIntro() {
    var el = $('scrIntro'), done = false;
    show('scrIntro'); G.screen = 'scrIntro';
    function fin() {
      if (done) return; done = true; el.classList.add('out');
      setTimeout(function () { el.classList.remove('out'); G.nav = []; show('scrMain'); onScreen('scrMain'); }, 550);
    }
    el.addEventListener('click', fin); setTimeout(fin, 3300);
  }
  G.boot = boot;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
