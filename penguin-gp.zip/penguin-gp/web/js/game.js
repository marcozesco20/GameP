/* Juego principal: bucle, camara, render, HUD, controles, menus y flujo multijugador */
(function () {
  'use strict';
  var PG = window.PG, G = PG.G = {}, m4 = PG.m4, clamp = PG.clamp, Net = PG.Net, Audio = PG.Audio;
  function $(id) { return document.getElementById(id); }
  var NAMES = ['Frosty', 'Rocky', 'Pebble', 'Slushy', 'Flipper', 'Waddles', 'Iggy', 'Chilly', 'Glacio', 'Copo'];
  var VERSION = 'v3.5';

  /* ---------------- almacenamiento ---------------- */
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  };
  G.cfg = PG.fixCfg(store.get('pgp_cfg', null));
  G.set = store.get('pgp_set', null) || { sound: true, quality: 1, ip: '' };
  if (G.set.music === undefined) G.set.music = true;
  if (G.set.diff === undefined) G.set.diff = 1;
  if (G.set.quality === undefined) G.set.quality = 1;
  function saveCfg() { store.set('pgp_cfg', G.cfg); }
  function saveSet() { store.set('pgp_set', G.set); }
  /* ---- progresion: partidas, victorias, derrotas y mejores tiempos ---- */
  function blankStats() { return { games: 0, wins: 0, podiums: 0, elim: 0, best: {}, tracks: {}, points: 0, coins: 0, stars: 0, tricks: 0, hist: [], places: [0, 0, 0, 0, 0, 0], recent: [] }; }
  G.stats = store.get('pgp_stats', null) || blankStats();
  (function () { var d = blankStats(); for (var k in d) if (G.stats[k] === undefined) G.stats[k] = d[k]; })();
  // v2.9: los puntos ahora valen x500 (cada nivel pide 100 000): se convierten una sola vez los que ya tenias
  if (G.stats.pv !== 2) { G.stats.points = Math.round((G.stats.points | 0) * 500); (G.stats.hist || []).forEach(function (h) { h.p = Math.round((h.p | 0) * 500); }); G.stats.pv = 2; store.set('pgp_stats', G.stats); }
  function saveStats() { store.set('pgp_stats', G.stats); }
  // kind: 'finish' | 'dead'. rw = {coins, points, tricks}. Devuelve {record:bool, best:segundos}
  function recordRace(kind, rank, time, trackIdx, total, rw) {
    var S = G.stats, tr = S.tracks[trackIdx] || (S.tracks[trackIdx] = { g: 0, w: 0 }), out = { record: false, best: 0 };
    rw = rw || { coins: 0, points: 0, tricks: 0 };
    S.games++; tr.g++; S.points += rw.points | 0; S.coins += rw.coins | 0; S.tricks += rw.tricks | 0; S.stars = (S.stars | 0) + (rw.stars | 0);
    if (kind === 'dead') S.elim++;
    else {
      if (rank === 1 && total > 1) { S.wins++; tr.w++; }
      if (rank <= 3 && total > 3) S.podiums++;
      S.places[Math.min(5, Math.max(0, rank - 1))]++;
      var b = S.best[trackIdx];
      if (time > 0 && (!b || time < b)) { out.record = !!b; S.best[trackIdx] = +time.toFixed(2); }
      out.best = S.best[trackIdx] || 0;
      if (time > 0) { S.recent = S.recent || []; S.recent.push({ t: trackIdx, s: +time.toFixed(2), r: rank, n: total }); if (S.recent.length > 3) S.recent.shift(); }
    }
    S.hist.push({ r: kind === 'dead' ? 0 : rank, t: trackIdx, p: rw.points | 0, c: rw.coins | 0, s: rw.stars | 0 }); if (S.hist.length > 20) S.hist.shift();
    saveStats();
    return out;
  }
  G.recordRace = recordRace;

  /* ---------------- iconos SVG ---------------- */
  var EQ_SHORT = { snow: 'Bola', trap: 'Trampa', shield: 'Escudo', eshield: 'Eléctrico', bshield: 'Rebote', hyper: 'T. máx', missile: 'Misil', tornado: 'Ventisca', wings: 'Alas', cannon: 'Cañón', grenade: 'Granada', megaball: 'Mega', quake: 'Sismo', ghost: 'Fantasma', superjump: 'Salto' };
  var ICONS = {
    fish: '<svg viewBox="0 0 64 64"><path d="M32 4c9 8 12 20 10 34H22C20 24 23 12 32 4z" fill="#f3f7ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="22" r="5" fill="#4da8ee" stroke="#1a4a72" stroke-width="2"/><path d="M22 38l-9 10 10-2zM42 38l9 10-10-2z" fill="#ff5a3c" stroke="#fff" stroke-width="2.5" stroke-linejoin="round"/><path d="M26 42h12l-3 10h-6z" fill="#ffb02e"/><path d="M29 52h6l-3 9z" fill="#ff5a3c"/></svg>',
    fishoff: '<svg viewBox="0 0 64 64" opacity=".45"><path d="M32 4c9 8 12 20 10 34H22C20 24 23 12 32 4z" fill="#f3f7ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="22" r="5" fill="#4da8ee" stroke="#1a4a72" stroke-width="2"/><path d="M22 38l-9 10 10-2zM42 38l9 10-10-2z" fill="#ff5a3c" stroke="#fff" stroke-width="2.5" stroke-linejoin="round"/><path d="M26 42h12l-3 10h-6z" fill="#ffb02e"/><path d="M29 52h6l-3 9z" fill="#ff5a3c"/></svg>',
    hyper: '<svg viewBox="0 0 64 64"><path d="M30 2c9 7 13 19 11 31H19C17 21 21 9 30 2z" fill="#ffd36a" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="30" cy="19" r="5" fill="#ff5a3c" stroke="#fff" stroke-width="2"/><path d="M19 33l-9 10 10-2zM41 33l9 10-10-2z" fill="#ff5a3c" stroke="#fff" stroke-width="2.5" stroke-linejoin="round"/><path d="M22 36h16l-3 12h-10z" fill="#ff8c26"/><path d="M24 48h12l-6 14z" fill="#ff3c3c"/><path d="M50 8l4 6M56 16l-5 2M52 26l6 1" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    missile: '<svg viewBox="0 0 64 64"><g transform="rotate(-35 32 32)"><rect x="10" y="25" width="34" height="14" rx="7" fill="#e0252b" stroke="#fff" stroke-width="3"/><path d="M44 25l12 7-12 7z" fill="#f5f5fa" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M12 25l-6-8h10zM12 39l-6 8h10z" fill="#33406a" stroke="#fff" stroke-width="2.5" stroke-linejoin="round"/><path d="M10 28l-8 4 8 4z" fill="#ffb02e"/></g><circle cx="50" cy="12" r="6" fill="none" stroke="#ff4a4a" stroke-width="3"/></svg>',
    snow: '<svg viewBox="0 0 64 64"><circle cx="32" cy="34" r="22" fill="#f4fbff" stroke="#8fc6ea" stroke-width="3"/><circle cx="24" cy="26" r="6" fill="#fff"/><path d="M44 18l8-8M50 24l8-2" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    trap: '<svg viewBox="0 0 64 64"><path d="M32 8l22 12v24L32 56 10 44V20z" fill="#8fd6ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M10 20l22 12 22-12M32 32v24" fill="none" stroke="#fff" stroke-width="3"/></svg>',
    shield: '<svg viewBox="0 0 64 64"><path d="M32 6l22 8v16c0 14-9 24-22 28C19 54 10 44 10 30V14z" fill="#4da8ee" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M32 16v34" stroke="#fff" stroke-width="3" opacity=".6"/></svg>',
    eshield: '<svg viewBox="0 0 64 64"><path d="M32 6l22 8v16c0 14-9 24-22 28C19 54 10 44 10 30V14z" fill="#ffd23a" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M35 14L23 33h8l-3 17 13-21h-8z" fill="#fff" stroke="#b86f00" stroke-width="1.5" stroke-linejoin="round"/></svg>',
    bshield: '<svg viewBox="0 0 64 64"><path d="M32 6l22 8v16c0 14-9 24-22 28C19 54 10 44 10 30V14z" fill="#e24fc4" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M20 32a12 12 0 0 1 20-8M44 32a12 12 0 0 1-20 8" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M42 18v8h-8M22 46v-8h8" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    tornado: '<svg viewBox="0 0 64 64"><g fill="none" stroke="#e9f6ff" stroke-width="5" stroke-linecap="round"><path d="M10 14h44"/><path d="M16 26h34"/><path d="M22 38h22"/><path d="M28 50h10"/></g></svg>',
    wings: '<svg viewBox="0 0 64 64"><path d="M32 40C22 38 10 28 4 14c10 2 18 6 24 14zM32 40c10-2 22-12 28-26-10 2-18 6-24 14z" fill="#bfe8ff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="42" r="6" fill="#fff"/></svg>',
    grenade: '<svg viewBox="0 0 64 64"><circle cx="30" cy="38" r="19" fill="#5a8a3e" stroke="#fff" stroke-width="3"/><rect x="24" y="12" width="12" height="11" rx="3" fill="#dfe6ee" stroke="#fff" stroke-width="2"/><path d="M36 14c6-8 12-8 16-4" fill="none" stroke="#ffb12b" stroke-width="4" stroke-linecap="round"/><path d="M14 38h32" stroke="#f5c21b" stroke-width="5"/></svg>',
    megaball: '<svg viewBox="0 0 64 64"><circle cx="34" cy="32" r="22" fill="#eaf7ff" stroke="#6cc3f5" stroke-width="3"/><circle cx="27" cy="27" r="3.4" fill="#16203a"/><circle cx="41" cy="27" r="3.4" fill="#16203a"/><path d="M26 40q8 6 16 0" fill="none" stroke="#e03a4a" stroke-width="4" stroke-linecap="round"/><path d="M2 20h12M0 32h14M4 44h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    quake: '<svg viewBox="0 0 64 64"><path d="M6 44l12-8 8 10 10-18 8 12 14-6" fill="none" stroke="#ffd36a" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 56h48M16 20l4-10M32 18V6M48 20l-4-10" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></svg>',
    ghost: '<svg viewBox="0 0 64 64"><path d="M12 56V30C12 16 21 8 32 8s20 8 20 22v26l-7-6-6 6-7-6-7 6-6-6z" fill="#e8f1ff" stroke="#fff" stroke-width="3" stroke-linejoin="round" opacity=".92"/><circle cx="25" cy="30" r="4" fill="#3a4a7a"/><circle cx="39" cy="30" r="4" fill="#3a4a7a"/></svg>',
    superjump: '<svg viewBox="0 0 64 64"><path d="M32 6l16 20H38v16H26V26H16z" fill="#7be07a" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M14 50q18 10 36 0M18 58q14 5 28 0" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></svg>',
    cannon: '<svg viewBox="0 0 64 64"><rect x="8" y="26" width="34" height="14" rx="5" fill="#ff8c26" stroke="#fff" stroke-width="3"/><rect x="40" y="23" width="14" height="20" rx="4" fill="#59d8ff" stroke="#fff" stroke-width="3"/><circle cx="58" cy="33" r="3" fill="#fff"/><path d="M14 40l-4 14h14l-2-14z" fill="#fff" stroke="#8fc6ea" stroke-width="2"/></svg>'
  };

  /* ---------------- utilidades ---------------- */
  function fmtTime(t) {
    if (!(t >= 0)) t = 0;
    var m = Math.floor(t / 60), s = t - m * 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  }
  var toastTimer = 0;
  function toast(msg, ms) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, ms || 1800);
  }
  G.toast = toast;
  function cssColor(hex) { return hex; }
  function bodyColor(cfg) { return PG.PAL.body[(cfg && cfg.body) | 0] || '#222'; }

  /* ---------------- pantallas / navegacion ---------------- */
  G.screen = ''; G.nav = [];
  function show(id) {
    var list = document.querySelectorAll('.screen');
    for (var i = 0; i < list.length; i++) list[i].classList.toggle('show', list[i].id === id);
    G.screen = id;
  }
  function go(id) { if (G.screen && G.screen !== 'scrLoad' && G.screen !== id) G.nav.push(G.screen); show(id); onScreen(id); }
  function back() { var p = G.nav.pop() || 'scrMain'; show(p); onScreen(p); }
  function showLoading(txt) { $('loadTxt').textContent = txt || 'Cargando…'; show('scrLoad'); }
  function onScreen(id) {
    var hud = $('hud');
    if (id !== 'scrPause' && id !== 'scrResults') hud.classList.add('hidden');
    if (id === 'scrMain') { G.mode = 'menu'; G.camMode = 'demo'; ensureDemo(); Audio.music('ice', 0.45); }
    if (id === 'scrCustom') { G.camMode = 'preview'; preview.manual = false; if (!G.cfgSnap) G.cfgSnap = JSON.stringify(G.cfg); buildCustomUI(); }
    else if (id === 'scrStats') { G.camMode = 'preview'; preview.manual = false; }
    else if (G.camMode === 'preview') G.camMode = 'demo';
    if (id === 'scrTracks') buildTrackGrid();
    if (id === 'scrStats') renderStats();
    if (PG.Eco && PG.Eco.onScreen) PG.Eco.onScreen(id);
    if (id === 'scrFriends') { var nt = $('frNote'); nt.textContent = ''; nt.className = 'note'; delete nt.dataset.own; Fr.start(); renderFriends(); }
    if (Fr.enabled()) Fr.pulse();
    if (id === 'scrMulti') { setupMulti(); }
    if (id === 'scrSettings') { $('chkSound').checked = G.set.sound; $('chkMusic').checked = G.set.music; $('chkAva').checked = G.set.ava !== false; $('chkBlur').checked = G.set.blurFx !== false; markQuality(); try { $('inBroker').value = localStorage.getItem('pg_broker') || ''; $('inTurn').value = localStorage.getItem('pg_turn') || ''; } catch (e) { } }
    if (id !== 'scrMulti') Net.stopDiscovery();
  }

  /* ---------------- GPU: modelos ---------------- */
  var gm = {};
  function uploadModels() {
    var R = G.R, M = PG.Models;
    for (var k in gm) { var v = gm[k]; if (Array.isArray(v)) v.forEach(function (x) { R.free(x); }); else R.free(v); }
    gm = {};
    for (k in M) gm[k] = Array.isArray(M[k]) ? M[k].map(function (x) { return R.upload(x); }) : R.upload(M[k]);
  }
  function pengGpu(cfg) {
    var model = PG.penguinModel(cfg);
    for (var i = 0; i < model.parts.length; i++) if (!model.parts[i].gl) model.parts[i].gl = G.R.upload(model.parts[i].mesh);
    return model;
  }

  /* ---------------- carga de pista ---------------- */
  G.tracksInfo = [];
  function loadTrack(idx) {
    var R = G.R;
    if (G.tmesh) { R.free(G.tmesh); G.tmesh = null; }
    var T = G.T = PG.buildTrack(PG.TRACKS[idx], {});
    G.trackIdx = idx; G.uwK = 0;
    if (G.tpads) { G.tpads.forEach(function (m) { R.free(m); }); G.tpads = null; }
    if (G.twater) { R.free(G.twater); G.twater = null; } if (G.tfish) { R.free(G.tfish); G.tfish = null; }
    G.tmesh = R.upload(T.mesh); T.mesh = null;
    if (T.padMeshes) { G.tpads = T.padMeshes.map(function (m) { return R.upload(m); }); T.padMeshes = null; }
    if (T.waterMesh) { G.twater = R.upload(T.waterMesh); G.tfish = R.upload(T.fishMesh); T.waterMesh = T.fishMesh = null; }
    PG.buildModels(T.theme); uploadModels();
    buildMiniMapBase();
  }
  var miniBase = null;
  function buildMiniMapBase() {
    var T = G.T, c = document.createElement('canvas'); c.width = c.height = 150;
    var x = c.getContext('2d'), th = T.thumb, pad = 14, sc = (150 - pad * 2) / Math.max(th.w, th.h);
    x.lineJoin = 'round'; x.lineCap = 'round';
    function path() { x.beginPath(); for (var i = 0; i < th.pts.length; i++) { var px = pad + th.pts[i][0] * sc, py = pad + th.pts[i][1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); } if (T.closed) x.closePath(); }
    function bpath(bp) { x.beginPath(); for (var i = 0; i < bp.length; i++) { var px = pad + bp[i][0] * sc, py = pad + bp[i][1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); } }
    path(); x.strokeStyle = 'rgba(0,30,60,.85)'; x.lineWidth = 9; x.stroke();
    path(); x.strokeStyle = '#bfe4ff'; x.lineWidth = 5; x.stroke();
    (th.br || []).forEach(function (bp) { bpath(bp); x.strokeStyle = 'rgba(0,30,60,.8)'; x.lineWidth = 6; x.stroke(); bpath(bp); x.strokeStyle = '#ffb347'; x.lineWidth = 3; x.stroke(); });
    miniBase = { canvas: c, pad: pad, sc: sc, scale: th.sc };
  }

  /* ---------------- carrera ---------------- */
  G.race = null; G.me = null; G.goAt = 0; G.paused = false; G.mp = false;
  var particles = [], MAXP = 2400;
  var inp = { steer: 0, tuck: 0, brake: 0, useItem: false, useAbility: false, jump: false, fire: false, push: false, aim: 1, fireAim: 1 };

  function makeBotCfg(rnd) {
    var c = PG.defaultCfg();
    c.body = Math.floor(rnd() * PG.PAL.body.length); c.feet = Math.floor(rnd() * 4);
    c.hat = Math.floor(rnd() * PG.OPT.hats.length); c.hatCol = Math.floor(rnd() * PG.PAL.accent.length);
    c.scarf = Math.floor(rnd() * PG.OPT.scarves.length); c.scarfCol = Math.floor(rnd() * PG.PAL.accent.length);
    c.glasses = rnd() < 0.5 ? 0 : Math.floor(rnd() * PG.OPT.glasses.length); c.outfit = rnd() < 0.5 ? 0 : Math.floor(rnd() * PG.OPT.outfits.length); c.outCol = Math.floor(rnd() * PG.PAL.accent.length);
    return c;
  }
  function makeRoster(humans, wantBots, seed, identSeed, nbFixed) { // identSeed: los bots de un campeonato conservan nombre y aspecto; nbFixed: cantidad fija de bots
    var rnd = PG.rng((identSeed === undefined ? seed : identSeed) ^ 0x5bd1), roster = [], i;
    for (i = 0; i < humans.length; i++) roster.push({ id: 'p' + humans[i].id, owner: humans[i].id, name: humans[i].name, cfg: humans[i].cfg, bot: false });
    var total = Math.max(roster.length, 6), nb = nbFixed !== undefined ? nbFixed : (wantBots ? total - roster.length : 0);
    var nm = NAMES.slice(); for (i = nm.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = nm[i]; nm[i] = nm[j]; nm[j] = t; }
    for (i = 0; i < nb; i++) roster.push({ id: 'b' + (i + 1), owner: null, name: nm[i], cfg: makeBotCfg(rnd), bot: true });
    // posiciones de salida mezcladas
    var slots = [], rs = PG.rng(seed ^ 0x77aa); for (i = 0; i < roster.length; i++) slots.push(i);
    for (i = slots.length - 1; i > 0; i--) { var jj = Math.floor(rs() * (i + 1)), tt = slots[i]; slots[i] = slots[jj]; slots[jj] = tt; }
    for (i = 0; i < roster.length; i++) roster[i].slot = slots[i];
    return roster;
  }

  // inicia la carrera con los datos recibidos (o generados localmente)
  function beginRace(m, demo) {
    var after = function () {
      if (G.trackIdx !== m.track || !G.tmesh) loadTrack(m.track);
      if (!demo) { if (m.champ) champOnStart(m); else { flushChampEquip(); G.champ = null; } }
      var race = G.race = new PG.Race(G.T, { seed: m.seed, diff: m.diff === undefined ? 1 : m.diff, avalanche: m.ava !== false && !demo, avForce: !!G.dbgAva });
      G.me = null; if (G.mp && !demo) G.ready = {};
      var iAmHost = !G.mp || G.myId === G.hostId;
      for (var i = 0; i < m.roster.length; i++) {
        var e = m.roster[i], mine = (!e.bot && (!G.mp ? e.owner === 'solo' : e.owner === G.myId));
        var own = demo ? true : (e.bot ? iAmHost : mine);
        var r = race.addRacer({ id: e.id, name: e.name, cfg: e.cfg, own: own, bot: e.bot || !!demo, local: mine && !demo, slot: e.slot });
        if (mine && !demo) G.me = r;
        pengGpu(e.cfg);
      }
      race.nowMs = performance.now(); race.auth = iAmHost;
      G.demo = !!demo;
      G.goAt = performance.now() + (demo ? -3000 : m.startIn);
      race.time = (performance.now() - G.goAt) / 1000;
      resetWeather(); G.fireShown = null;
      particles.length = 0; G.camInit = false; G.finishShown = false; G.lastCount = 99; G.paused = false;
      G.deadShown = false; G.lookTouch = G.lookKey = false; G.lb = 0; G.resRec = ''; G.avWarned = false; G.specId = null; $('hud').classList.remove('spec'); G.avK = 0; G.camFocus = null;
      G.raceCoins = { combo: 0, tricks: 0, best: 0 }; G.resCoins = null; G.coinsBanked = false; G.lastStarN = -1; updCoinChip(false); updStarChip();
      spendEquip(); G.eq = (G.me && !demo) ? PG.Eco.loadout() : []; G.eqUsed = []; G.eqSpent = false; G.eqKeys = ''; // v3.0: el equipo comprado tiene sus propias casillas en la carrera
      G.resultsAt = 0; G.finalShown = false; G.netAcc = 0; G.lastMsgShown = false; G.resMsg = ''; $('cheer').innerHTML = '';
      if (!demo) {
        G.mode = 'race'; G.camMode = 'race'; G.nav = []; updVoiceHud(); try { PG.Friends.pulse(); } catch (e) { } try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (e) { }
        show(''); $('hud').classList.remove('hidden'); buildMarkers();
        if (G.champ) toast(G.champ.n === 1 ? '💰 Carrera con apuesta — ' + PG.TRACKS[m.track].name : '🏆 Campeonato · Carrera ' + (G.champ.idx + 1) + ' de ' + chN() + ' — ' + PG.TRACKS[m.track].name, 3600);
        $('btnPause').style.display = G.mp ? 'none' : ''; // v3.1: no hay pausa en multijugador
        Audio.music(Audio.nextMusic(m.track), 0.5, true); // v3.1: la musica empieza de cero en cada carrera y varia
        $('lapBox').style.visibility = G.T.type === 'circuit' ? 'visible' : 'hidden';
        $('countdown').textContent = '';
        setHudVisibleForRace();
      }
    };
    if (demo) { after(); return; }
    showLoading('Cargando ' + PG.TRACKS[m.track].name + '…');
    setTimeout(after, 40);
  }
  function setHudVisibleForRace() { /* reservado */ }

  function ensureDemo() {
    if (G.race && G.demo) return;
    if (G.mode === 'race') return;
    var seed = (Math.random() * 1e9) | 0, rnd = PG.rng(seed), roster = [];
    for (var i = 0; i < 6; i++) roster.push({ id: 'b' + (i + 1), name: NAMES[i], cfg: makeBotCfg(rnd), bot: true, slot: i });
    G.mode = 'menu';
    beginRace({ track: 0, seed: seed, roster: roster, startIn: 0 }, true);
  }

  G.startSolo = function (idx) {
    G.mp = false; G.myId = 'solo';
    var seed = (Math.random() * 1e9) | 0;
    var roster = makeRoster([{ id: 'solo', name: G.cfg.name, cfg: G.cfg }], true, seed);
    beginRace({ track: idx, seed: seed, roster: roster, startIn: 4500, diff: G.set.diff, ava: G.set.ava !== false }, false);
  };

  // v3.2: el equipo comprado se gasta al terminar la carrera: cada casilla usada gasta 1 unidad
  // v3.3: en un campeonato (3 o 5 carreras) los poderes usados NO se gastan carrera a carrera: se recuerdan y se gastan todos al terminar el campeonato (o al abandonarlo)
  function spendEquip() {
    if (G.eqSpent || !G.eq) return; G.eqSpent = true;
    var used = G.eqUsed || []; G.eqUsed = [];
    if (G.champ && G.champ.n > 1) { G.champUse = G.champUse || []; used.forEach(function (u, i) { if (u && G.eq[i]) G.champUse[i] = G.eq[i]; }); return; }
    used.forEach(function (u, i) { if (u && G.eq[i]) PG.Eco.spend(G.eq[i]); });
  }
  function flushChampEquip() { var u = G.champUse || []; G.champUse = []; u.forEach(function (k) { if (k) PG.Eco.spend(k); }); }
  G.flushChampEquip = flushChampEquip;
  function quitRace(toMenu) {
    spendEquip(); flushChampEquip();
    G.champ = null; // v3.1: abandonar la carrera = abandonar el campeonato
    Audio.slide(0, false); Audio.storm(0, 0); jumpTouch = fireTouch = false;
    G.race = null; G.me = null; G.demo = false; G.mode = 'menu';
    if (G.mp) { Voice.leave(true); Net.close(); G.mp = false; G.online = false; G.players = {}; }
    G.nav = []; $('hud').classList.add('hidden');
    ensureDemo(); go('scrMain'); G.nav = [];
  }

  /* ---------------- entrada ---------------- */
  var keys = {};
  window.addEventListener('keydown', function (e) {
    var tg = e.target && e.target.tagName; if (tg === 'TEXTAREA' || (tg === 'INPUT' && e.target.type !== 'checkbox')) return; // escribiendo (chat, nombre...)
    keys[e.code] = true; if (e.code.indexOf('Digit') === 0) keys['q' + e.code] = true; // las teclas 1-3 se recuerdan hasta el siguiente cuadro (un toque muy corto no se pierde)
    if (e.code === 'Space' || e.code.indexOf('Arrow') === 0) e.preventDefault();
    if (G.mode === 'race') {
      if (e.code === 'KeyV' || e.code === 'KeyZ') G.lookKey = true;
      if (e.code === 'KeyE' || e.code === 'Enter' || e.code === 'KeyF') inp.useItem = true;
      if (e.code === 'KeyQ' || e.code === 'KeyR') inp.useAbility = true;
      if (e.code === 'KeyT' || e.code === 'Tab') { selAbility(-1); e.preventDefault(); }
      if (e.code === 'KeyP' || e.code === 'KeyB' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') inp.push = true;
      if (e.code === 'Escape') pauseRace();
    }
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; if (e.code === 'KeyV' || e.code === 'KeyZ') G.lookKey = false; });
  var joy = { id: -1, x: 0, y: 0 }, jumpTouch = false, fireTouch = false, itemAim = 0, itemAimUntil = 0, fireAim = 1;
  function setupTouch() {
    var el = $('joy'), knob = $('joyKnob');
    function upd(e) {
      var r = el.getBoundingClientRect(), R = r.width / 2;
      var dx = (e.clientX - (r.left + R)) / (R * 0.8), dy = (e.clientY - (r.top + R)) / (R * 0.8);
      var l = Math.sqrt(dx * dx + dy * dy); if (l > 1) { dx /= l; dy /= l; }
      joy.x = dx; joy.y = dy;
      knob.style.transform = 'translate(' + (dx * R * 0.55) + 'px,' + (dy * R * 0.55) + 'px)';
    }
    el.addEventListener('pointerdown', function (e) { joy.id = e.pointerId; el.setPointerCapture(e.pointerId); upd(e); e.preventDefault(); });
    el.addEventListener('pointermove', function (e) { if (e.pointerId === joy.id) { upd(e); e.preventDefault(); } });
    function rel(e) { if (e.pointerId === joy.id) { joy.id = -1; joy.x = joy.y = 0; knob.style.transform = ''; } }
    el.addEventListener('pointerup', rel); el.addEventListener('pointercancel', rel);
    function hold(id, setter) {
      var el = $(id);
      el.addEventListener('pointerdown', function (e) { setter(true); try { el.setPointerCapture(e.pointerId); } catch (x) { } el.classList.add('on'); e.preventDefault(); });
      function up() { setter(false); el.classList.remove('on'); }
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
    }
    hold('btnJump', function (v) { jumpTouch = v; });
    hold('btnLook', function (v) { G.lookTouch = v; });
    // arrastrar hacia abajo = apuntar hacia atras (objeto y disparo)
    var hint = $('aimHint');
    function aimDrag(id, onDown, onAim, onUp, can) {
      var el = typeof id === 'string' ? $(id) : id, st = null;
      el.addEventListener('pointerdown', function (e) {
        var ca = can ? can() : true; // v3.0: solo los poderes que se lanzan muestran «adelante / atrás»
        st = { id: e.pointerId, y0: e.clientY, aim: 1, can: ca }; try { el.setPointerCapture(e.pointerId); } catch (x) { }
        el.classList.add('on'); onDown(); if (!ca) { e.preventDefault(); return; } hint.className = 'show'; hint.style.left = (el.getBoundingClientRect().left + el.offsetWidth / 2) + 'px'; hint.style.top = (el.getBoundingClientRect().top - 8) + 'px'; hint.dataset.aim = 'f'; e.preventDefault();
      });
      el.addEventListener('pointermove', function (e) {
        if (!st || e.pointerId !== st.id || !st.can) return;
        var a = (e.clientY - st.y0) > 26 ? -1 : 1;
        if (a !== st.aim) { st.aim = a; hint.dataset.aim = a < 0 ? 'b' : 'f'; onAim(a); }
        e.preventDefault();
      });
      function up(e) { if (!st || (e && e.pointerId !== st.id)) return; var a = st.aim; st = null; el.classList.remove('on'); hint.className = ''; onUp(a); }
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', function () { if (st) { st = null; el.classList.remove('on'); hint.className = ''; onUp(1, true); } });
    }
    aimDrag('btnFire', function () { fireTouch = true; fireAim = 1; }, function (a) { fireAim = a; }, function () { fireTouch = false; fireAim = 1; });
    $('itemBox').addEventListener('pointerdown', function (e) { inp.useItem = true; $('itemSlot').classList.add('on'); setTimeout(function () { $('itemSlot').classList.remove('on'); }, 160); e.preventDefault(); });
    // habilidad: toca = usar hacia adelante; desliza hacia abajo = usar hacia atras (bola de nieve, trampa, etc.)
    aimDrag('btnAbility', function () { }, function () { }, function (a, cancel) { if (cancel) return; inp.useAbility = true; itemAim = a; itemAimUntil = performance.now() + 200; }, function () { return !!(G.me && G.me.ability && PG.canAimBack(G.me, G.me.ability)); });
    // v3.0: casillas del equipo comprado (se crean al empezar la carrera)
    G.bindEq = function (el) {
      var k = el.dataset.k;
      aimDrag(el, function () { }, function () { }, function (a, cancel) { if (cancel) return; inp.eqUse = { k: k, i: el.dataset.i | 0, aim: a }; }, function () { return !!(G.me && PG.canAimBack(G.me, k)); });
    };
    $('btnPush').addEventListener('pointerdown', function (e) { inp.push = true; $('btnPush').classList.add('on'); setTimeout(function () { $('btnPush').classList.remove('on'); }, 160); e.preventDefault(); });
    $('abQ').addEventListener('pointerdown', function (e) { // tocar un circulo pequeño = lanzar ese poder primero (no activa el boton)
      var i = e.target.closest ? e.target.closest('i') : null; e.stopPropagation(); e.preventDefault(); if (!i) return;
      selAbility([].indexOf.call($('abQ').children, i));
    });
    $('btnPause').addEventListener('pointerdown', function (e) { pauseRace(); e.preventDefault(); });
    $('specPrev').addEventListener('click', function () { specStep(-1); Audio.sfx('click'); });
    $('specNext').addEventListener('click', function () { specStep(1); Audio.sfx('click'); });
    $('specRes').addEventListener('click', function () { Audio.sfx('click'); showResults(); });
    $('specExit').addEventListener('click', function () { Audio.sfx('click'); quitRace(true); });
    (function () { // girar el pinguino (en "Mi pingüino" y en "Mi progreso"): arrastrar con el dedo o con botones
      function rot(d) { preview.manual = true; preview.rot += d; }
      function attach(dg) {
        var drag = null;
        dg.addEventListener('pointerdown', function (e) { if (e.target.closest('button')) return; drag = { id: e.pointerId, x: e.clientX }; try { dg.setPointerCapture(e.pointerId); } catch (x) { } e.preventDefault(); });
        dg.addEventListener('pointermove', function (e) { if (!drag || drag.id !== e.pointerId) return; rot((e.clientX - drag.x) * 0.012); drag.x = e.clientX; });
        function end(e) { if (drag && drag.id === e.pointerId) drag = null; }
        dg.addEventListener('pointerup', end); dg.addEventListener('pointercancel', end);
      }
      attach($('pvDrag')); attach($('pvDrag2'));
      $('pvL').addEventListener('click', function () { rot(-0.6); Audio.sfx('click'); });
      $('pvR').addEventListener('click', function () { rot(0.6); Audio.sfx('click'); });
      $('pvAuto').addEventListener('click', function () { preview.manual = false; Audio.sfx('click'); });
    })();
  }
  // v3.2.1: elegir qué poder se lanza primero: tocar un círculo pequeño lo pasa al botón principal (el principal ocupa su lugar). Tecla T: rota la cola.
  function selAbility(idx) {
    var me = G.me; if (!me || G.mode !== 'race' || !me.abilityQ || !me.ability) return false;
    if (idx < 0) { me.abilityQ.push(me.ability); me.ability = me.abilityQ.shift(); }
    else { if (idx >= me.abilityQ.length) return false; var t = me.ability; me.ability = me.abilityQ[idx]; me.abilityQ[idx] = t; }
    Audio.sfx('click'); G.abPick = performance.now();
    var b = $('btnAbility'); b.classList.remove('gotpop'); void b.offsetWidth; b.classList.add('gotpop');
    return true;
  }
  G.selAbility = selAbility;
  function readInput() {
    var sx = 0, tuck = 0, brake = 0;
    if (keys.ArrowLeft || keys.KeyA) sx -= 1; if (keys.ArrowRight || keys.KeyD) sx += 1;
    if (keys.ArrowUp || keys.KeyW) tuck = 1; if (keys.ArrowDown || keys.KeyS) brake = 1;
    var jx = Math.abs(joy.x) < 0.1 ? 0 : joy.x * 1.15;
    if (jx) sx = clamp(jx, -1, 1);
    if (joy.y < -0.3) tuck = Math.max(tuck, (-joy.y - 0.3) / 0.7);
    if (joy.y > 0.4) brake = Math.max(brake, (joy.y - 0.4) / 0.6);
    inp.steer = sx; inp.tuck = tuck; inp.brake = brake;
    if (G.dbgInp) { inp.steer = G.dbgInp.steer || 0; inp.tuck = G.dbgInp.tuck || 0; inp.brake = 0; }
    for (var ei = 0; ei < 3; ei++) { var ek = 'qDigit' + (ei + 1); if (keys[ek]) { keys[ek] = false; var eqn = (G.eq || [])[ei]; if (eqn) inp.eqUse = { k: eqn, i: ei, aim: (keys.ArrowDown || keys.KeyS) ? -1 : 1 }; } }
    inp.jump = !!(keys.Space || keys.KeyC || keys.KeyZ || keys.KeyJ || jumpTouch);
    inp.fire = !!(keys.KeyX || keys.KeyV || fireTouch);
    var kAim = (keys.ArrowDown || keys.KeyS || joy.y > 0.62) ? -1 : 1;
    inp.aim = performance.now() < itemAimUntil ? itemAim : kAim;
    inp.fireAim = fireTouch ? (fireAim < 0 ? -1 : kAim) : kAim;
    return inp;
  }

  /* ---------------- pausa ---------------- */
  function pauseRace() { if (G.syncSet) G.syncSet(); updVoiceHud();
    if (G.mode !== 'race' || G.paused || G.mp) return; // v3.1: sin pausa en multijugador
    G.paused = true; G.pauseAt = performance.now();
    $('scrPause').classList.add('show'); G.screen = 'scrPause';
  }
  function resumeRace() {
    if (!G.paused) return;
    G.paused = false; G.goAt += performance.now() - G.pauseAt;
    $('scrPause').classList.remove('show'); G.screen = '';
  }
  window.PGBack = function () {
    if (G.mode === 'race') { if (G.paused) resumeRace(); else if (!G.mp) pauseRace(); return true; }
    if (G.screen === 'scrMain') return false;
    if (G.screen === 'scrLobby') { leaveRoom(); return true; }
    if (G.screen === 'scrResults') { return true; }
    back(); return true;
  };

  /* ---------------- particulas ---------------- */
  function emitP(x, y, z, vx, vy, vz, life, size, r, g, b, a, grav) {
    if (particles.length >= MAXP) particles.shift();
    particles.push({ x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, life: life, max: life, size: size, r: r, g: g, b: b, a: a, gr: grav === undefined ? 4 : grav });
  }
  function rnd2() { return Math.random() * 2 - 1; }
  function burst(x, y, z, n, col, spd, size, life) {
    for (var i = 0; i < n; i++) emitP(x, y, z, rnd2() * spd, Math.random() * spd, rnd2() * spd, life || 0.7, size || 0.35, col[0], col[1], col[2], 1, 6);
  }
  var _w = [0, 0, 0], _w2 = [0, 0, 0];
  G.flyers = [];
  function wpos(r, out) {
    var T = G.T, q = T.q(T.uToS(r.u), r.br);
    out[0] = q.x + q.rx * r.d; out[1] = r.py; out[2] = q.z + q.rz * r.d;
    return out;
  }
  function wposUD(u, d, out) {
    var T = G.T, s = T.uToS(u), q = T.q(s);
    out[0] = q.x + q.rx * d; out[1] = T.ground(s, d); if (out[1] < -1e8) out[1] = q.y; out[2] = q.z + q.rz * d;
    return out;
  }

  /* ---------------- eventos de la simulacion ---------------- */
  var lastWall = 0;
  function handleFx(e) {
    var r = e.r, isMe = r && G.me && r === G.me, now = performance.now();
    var near = r && G.me && Math.abs(r.u - G.me.u) < 60;
    var w;
    switch (e.k) {
      case 'itemget':
        if (isMe) { Audio.sfx('item'); pickupFx('item', e.item || 'fish', r, !e.item); }
        else if (r && near) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 10, [0.6, 0.9, 1], 4, 0.3, 0.6); }
        break;
      case 'abilityget': if (isMe) { Audio.sfx(PG.COMMON.indexOf(e.ability) >= 0 ? 'item' : 'ability'); pickupFx(PG.COMMON.indexOf(e.ability) >= 0 ? 'item' : 'ability', e.ability, r, false); } else if (r && near) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [0.8, 0.5, 1], 5, 0.35, 0.7); } break;
      case 'push':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.9, w[2], e.hit ? 14 : 5, [1, 1, 1], 5, 0.4, 0.5); }
        if (isMe || near) Audio.sfx(e.hit ? 'smash' : 'throw');
        break;
      case 'shoved':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [1, 0.9, 0.5], 6, 0.4, 0.6); }
        if (isMe) { Audio.sfx('hit'); G.shake = Math.max(G.shake, 0.55); }
        break;
      case 'boost': if (isMe || near) Audio.sfx('boost'); if (isMe) { G.shake = Math.max(G.shake, e.hyper ? 0.7 : 0.25); if (e.hyper) G.fovKick = Math.max(G.fovKick || 0, 0.35); } if (e.hyper && r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.8, w[2], 30, [1, 0.7, 0.2], 10, 0.6, 0.8); } break;
      case 'stun': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 2.6, w[2], 16, [1, 0.95, 0.4], 5, 0.7, 0.9); } if (isMe) { Audio.sfx('hit'); G.shake = Math.max(G.shake, 0.6); } break;
      case 'missile': if (isMe || near) Audio.sfx('throw'); if (isMe) G.shake = Math.max(G.shake, 0.4); break;
      case 'pad': if (isMe) { Audio.sfx('pad'); G.shake = Math.max(G.shake, 0.3); } break;
      case 'hit':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1.2, w[2], 14, [1, 1, 0.5], 6, 0.35, 0.8); }
        if (isMe) { Audio.sfx('hit'); G.shake = 0.9; } else if (near) Audio.sfx('pop');
        break;
      case 'wall': if (isMe && now - lastWall > 250) { lastWall = now; Audio.sfx('wall'); G.shake = Math.max(G.shake, 0.3); } break;
      case 'land': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.2, w[2], 8, [1, 1, 1], 5, 0.5, 0.6); } if (isMe && e.impact > 7) { Audio.sfx('land'); G.shake = Math.max(G.shake, 0.35); } break;
      case 'fall': if (isMe) Audio.sfx('fall'); break;
      case 'respawn': if (isMe) Audio.sfx('respawn'); break;
      case 'throw': if (isMe || near) Audio.sfx('throw'); break;
      case 'shield': if (isMe) Audio.sfx('shield'); break;
      case 'dealt': if (G.me && e.by === G.me.id && r) hitNote(r.name || 'rival', e.kind); break;
      case 'eqused': if (isMe) { (G.eqUsed = G.eqUsed || [])[e.i | 0] = true; G.eqKeys = ''; } break;
      case 'zap': if (isMe || near) Audio.sfx('pop'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [1, 0.9, 0.25], 7, 0.25, 0.45); } break;
      case 'shock': if (isMe || near) Audio.sfx('hit'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 18, [1, 0.95, 0.45], 8, 0.22, 0.6); } break;
      case 'bounce': if (isMe || near) Audio.sfx('pop'); if (r) { w = wpos(r, [0, 0, 0]); r.shFlash = 0.35; burst(w[0], w[1] + 1, w[2], 10, [1, 0.5, 0.95], 6, 0.25, 0.45); } break;
      case 'shieldhit': if (isMe || near) Audio.sfx('pop'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 8, [0.5, 0.85, 1], 4, 0.3, 0.55); r.shFlash = 0.35; } break;
      case 'shieldpop': if (isMe || near) Audio.sfx('pop'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [0.5, 0.8, 1], 6, 0.35, 0.7); } break;
      case 'smash': if (isMe || near) Audio.sfx('smash'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 16, [1, 1, 1], 7, 0.5, 0.8); } break;
      case 'tornado': if (near || (r && r.local)) Audio.sfx('tornado'); break;
      case 'splat': if (e.u !== undefined) { w = wposUD(e.u, e.d, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 12, [1, 1, 1], 6, 0.4, 0.6); } break;
      case 'finish': if (isMe) { if (G.mp) setTimeout(function () { if (G.race && G.me) onLocalFinish(); }, 450); else onLocalFinish(); } break;
      case 'jump': if (isMe) Audio.sfx('jump'); if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.2, w[2], 6, [1, 1, 1], 3, 0.4, 0.5); } break;
      case 'flip': if (isMe) Audio.sfx('flip'); break;
      case 'trick':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 22, [1, 0.85, 0.3], 8, 0.45, 0.9); burst(w[0], w[1] + 1, w[2], 12, [0.5, 0.9, 1], 7, 0.4, 0.8); }
        if (isMe) {
          Audio.sfx('trick'); G.shake = Math.max(G.shake, 0.3);
          var cc = PG.Eco.comboCoins(e.n); G.raceCoins.combo += cc; G.raceCoins.tricks += e.n; G.raceCoins.best = Math.max(G.raceCoins.best, e.n); updCoinChip(true);
          var words = ['¡Excelente!', '¡Sigue así!', '¡Genial!'], wi2 = Math.floor(Math.random() * 3); if (wi2 === G.lastWord) wi2 = (wi2 + 1) % 3; G.lastWord = wi2;
          bigFlash(words[wi2] + (e.n > 1 ? ' ×' + e.n : ''));
        } else if (near) Audio.sfx('pop');
        break;
      case 'obsko': {
        var Tq = G.T, qk = Tq.q(e.s, e.br), gk = Tq.ground(e.s, e.d, e.br); if (gk < -1e8) gk = qk.y;
        var kx = qk.x + qk.rx * e.d, kz = qk.z + qk.rz * e.d;
        var cols = { seal: [0.55, 0.5, 0.5], rock: [0.6, 0.62, 0.7], ice: [0.7, 0.9, 1], snowman: [1, 1, 1], tree: [0.2, 0.5, 0.3], ball: [1, 1, 1] }, cc = cols[e.type] || [1, 1, 1];
        burst(kx, gk + 1.2, kz, 22, cc, 9, 0.5, 0.9); burst(kx, gk + 1.2, kz, 10, [1, 1, 1], 6, 0.4, 0.8);
        if (e.type === 'seal' || e.type === 'snowman' || e.type === 'tree') {
          var fyaw = qk.yaw, up = e.type === 'seal' ? 22 : 15;
          G.flyers.push({ type: e.type, x: kx, y: gk + 1, z: kz, vx: Math.sin(fyaw) * 14 + rnd2() * 8, vy: up + Math.random() * 6, vz: Math.cos(fyaw) * 14 + rnd2() * 8, a: e.yaw || 0, b: 0, va: rnd2() * 8, vb: 6 + Math.random() * 8, life: 2.4, sc: e.type === 'tree' ? 0.7 : 1 });
        }
        if (G.me && Math.abs(G.me.u - Tq.uToS(e.s)) < 70) Audio.sfx(e.type === 'seal' ? 'seal' : 'smash');
        break;
      }
      case 'boom': {
        var wb = wposUD(e.u, e.d, [0, 0, 0]), big = e.kd === 'mega', nb = big ? 60 : 36;
        burst(wb[0], wb[1] + 1, wb[2], nb, [1, 0.62, 0.15], big ? 18 : 13, 0.8, 0.8); burst(wb[0], wb[1] + 1, wb[2], nb / 2, [1, 0.95, 0.7], big ? 14 : 10, 0.6, 0.6);
        if (big) burst(wb[0], wb[1] + 1.5, wb[2], 40, [0.8, 0.95, 1], 16, 0.9, 1.0);
        for (var bi = 0; bi < 24; bi++) { var ba = bi / 24 * 6.2832; emitP(wb[0], wb[1] + 0.4, wb[2], Math.cos(ba) * (big ? 20 : 15), 1, Math.sin(ba) * (big ? 20 : 15), 0.5, 0.6, 1, 0.8, 0.4, 0.9, 0); }
        emitP(wb[0], wb[1] + 1.5, wb[2], 0, 0.5, 0, 0.28, big ? 9 : 6, 1, 0.75, 0.35, 0.55, 0);
        if (G.me && Math.abs(G.me.u - e.u) < 80) { Audio.sfx('boom'); G.shake = Math.max(G.shake, big ? 1.1 : 0.8 * clamp(1 - Math.abs(G.me.u - e.u) / 80, 0.2, 1)); }
        break;
      }
      case 'quake':
        if (r) {
          w = wpos(r, [0, 0, 0]);
          for (var qi = 0; qi < 40; qi++) { var qa = qi / 40 * 6.2832; emitP(w[0], w[1] + 0.3, w[2], Math.cos(qa) * 22, 2 + Math.random() * 3, Math.sin(qa) * 22, 0.8, 0.7, 0.9, 0.95, 1, 0.9, 4); }
          burst(w[0], w[1] + 1, w[2], 30, [1, 0.85, 0.4], 10, 0.5, 0.9);
          if (G.me && Math.abs(G.me.u - r.u) < 70) { Audio.sfx('quake'); G.shake = Math.max(G.shake, 1.0); }
        }
        break;
      case 'megaball': if (isMe) { G.shake = Math.max(G.shake, 0.5); } if (isMe || near) Audio.sfx('quake'); break;
      case 'ghost': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 18, [0.9, 0.95, 1], 6, 0.4, 0.8); } break;
      case 'superjump': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.3, w[2], 24, [0.5, 1, 0.5], 9, 0.5, 0.7); } if (isMe) { Audio.sfx('boost'); G.shake = Math.max(G.shake, 0.6); toast('¡SÚPER SALTO! Toca SALTAR otra vez en el aire', 2200); } break;
      case 'sjump':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.3, w[2], 14, [0.5, 1, 0.5], 7, 0.45, 0.6); for (var si2 = 0; si2 < 14; si2++) { var sa2 = si2 / 14 * 6.2832; emitP(w[0] + Math.cos(sa2) * 0.6, w[1] + 0.1, w[2] + Math.sin(sa2) * 0.6, Math.cos(sa2) * 7, 0.5, Math.sin(sa2) * 7, 0.4, 0.35, 0.7, 1, 0.7, 0.9, 0); } }
        if (isMe) { Audio.sfx('jump'); G.shake = Math.max(G.shake, 0.25); }
        break;
      case 'wings': break;
      case 'ceil': if (r && e.on) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 18, [0.85, 0.95, 1], 7, 0.45, 0.8); if (isMe || near) Audio.sfx('pad'); if (isMe) G.shake = Math.max(G.shake, 0.4); } break;
      case 'righted': if (r && (isMe || near)) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 0.6, w[2], 10, [1, 1, 1], 4, 0.35, 0.5); Audio.sfx('flip'); } break;
      case 'bonk': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1.8, w[2], 16, [0.85, 0.92, 1], 6, 0.4, 0.7); } if (isMe) { Audio.sfx('hit'); G.shake = Math.max(G.shake, 0.8); } break;
      case 'engulf':
        if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1.2, w[2], 40, [1, 1, 1], 11, 0.9, 1.0); }
        if (isMe) onLocalDead(); else if (near) Audio.sfx('quake');
        break;
      case 'treebump': if (r) { w = wpos(r, [0, 0, 0]); burst(w[0], w[1] + 1, w[2], 14, [0.9, 1, 0.9], 5, 0.4, 0.6); } if (isMe) { Audio.sfx('wall'); G.shake = Math.max(G.shake, 0.4); } break;
      case 'stumble': if (isMe) { Audio.sfx('wall');  } break;
      case 'cannon': if (isMe) { Audio.sfx('ability'); toast(e.gun === 'gren' ? '¡Cañón de granadas! Toca DISPARAR' : '¡Cañón de nieve! Mantén DISPARAR', 2200); } break;
      case 'shoot':
        if (r) { var fy0 = Math.sin(G.T.q(G.T.uToS(r.u), r.br).yaw - r.psi), fz0 = Math.cos(G.T.q(G.T.uToS(r.u), r.br).yaw - r.psi); w = wpos(r, [0, 0, 0]); burst(w[0] + fy0 * 1.4, w[1] + 1.0, w[2] + fz0 * 1.4, 4, [0.7, 0.95, 1], 3, 0.35, 0.3); }
        if (isMe || near) Audio.sfx(e.gun === 'gren' ? 'gren' : 'shoot');
        break;
    }
  }

  /* ---- animaciones espectaculares al recoger poderes ---- */
  function pickupFx(kind, key, r, mini) {
    var isAb = kind === 'ability', host = $('pickFx'), name = PG.ITEM_NAMES[key] || key;
    var w = wpos(r, [0, 0, 0]), col = isAb ? [0.78, 0.5, 1.0] : [0.4, 0.82, 1.0], i, a;
    if (mini) { var sl = $('itemSlot'); sl.classList.remove('gotpop'); void sl.offsetWidth; sl.classList.add('gotpop'); burst(w[0], w[1] + 1, w[2], 12, col, 5, 0.35, 0.6); return; }
    var fl = document.createElement('div'); fl.className = 'pkFlash ' + (isAb ? 'ab' : 'it'); host.appendChild(fl);
    setTimeout(function () { fl.remove(); }, 1000);
    var box = document.createElement('div'); box.className = 'pkIcon ' + (isAb ? 'ab' : 'it');
    box.innerHTML = '<i class="rays"></i><i class="rays r2"></i><i class="ring"></i><div class="ic">' + ICONS[key] + '</div><b>' + (isAb ? '¡HABILIDAD!' : '¡NUEVO PODER!') + '</b><small>' + esc(name) + '</small>';
    host.appendChild(box);
    setTimeout(function () {
      var tg = $('btnAbility').getBoundingClientRect(), bx = box.getBoundingClientRect();
      box.style.setProperty('--dx', (tg.left + tg.width / 2 - (bx.left + bx.width / 2)) + 'px');
      box.style.setProperty('--dy', (tg.top + tg.height / 2 - (bx.top + bx.height / 2)) + 'px');
      box.classList.add('fly');
    }, 820);
    setTimeout(function () { box.remove(); var t2 = $('btnAbility'); t2.classList.remove('gotpop'); void t2.offsetWidth; t2.classList.add('gotpop'); }, 1300);
    // en el mundo: anillo expansivo, columna de luz y chispas
    for (i = 0; i < 36; i++) { a = i / 36 * 6.2832; emitP(w[0] + Math.cos(a) * 0.8, w[1] + 0.3, w[2] + Math.sin(a) * 0.8, Math.cos(a) * 13, 0.4, Math.sin(a) * 13, 0.55, 0.55, col[0], col[1], col[2], 0.95, 0); }
    for (i = 0; i < 26; i++) emitP(w[0] + rnd2() * 0.5, w[1] + 0.5, w[2] + rnd2() * 0.5, rnd2() * 1.5, 5 + Math.random() * 9, rnd2() * 1.5, 0.9, 0.45, 1, 1, 0.7 + Math.random() * 0.3, 0.9, 2);
    for (i = 0; i < 30; i++) { a = Math.random() * 6.2832; var sp = 4 + Math.random() * 8; emitP(w[0], w[1] + 1.1, w[2], Math.cos(a) * sp, 2 + Math.random() * 7, Math.sin(a) * sp, 0.9, 0.38, col[0] * 0.5 + 0.5, col[1] * 0.5 + 0.5, 1, 1, 7); }
    G.shake = Math.max(G.shake, isAb ? 0.7 : 0.45); G.fovKick = isAb ? 0.3 : 0.2;
  }

  // v3.2: aviso discreto (esquina izquierda, no tapa la pantalla) cuando tu poder o trampa le da a alguien
  var HIT_TXT = { snow: 'Bola de nieve', pellet: 'Cañón', trap: 'Trampa', missile: '¡Misil!', mega: '¡Mega bola!', boom: 'Explosión', tornado: 'Ventisca', shock: 'Descarga', push: 'Empujón', speed: 'Embestida' }, hitNoteT = 0, hitStreak = 0, hitLast = 0;
  function hitNote(name, kind) {
    var el = $('hitNote'); if (!el) return; var now = performance.now();
    hitStreak = now - hitLast < 4000 ? hitStreak + 1 : 1; hitLast = now;
    el.innerHTML = '<i>🎯</i><span><b>¡Le diste a ' + esc(name) + '!</b><small>' + (HIT_TXT[kind] || 'Impacto') + (hitStreak > 1 ? ' · x' + hitStreak : '') + '</small></span>';
    el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
    Audio.sfx('ding'); clearTimeout(hitNoteT); hitNoteT = setTimeout(function () { el.classList.remove('show'); }, 1900);
  }
  var cheerT = 0;
  function banner(kind, title, sub, hold) {
    var c = $('cheer'); clearTimeout(cheerT);
    c.innerHTML = '<div class="cb ' + kind + '" style="--hold:' + (hold || 3.6) + 's"><h3>' + esc(title) + '</h3>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div>';
    cheerT = setTimeout(function () { c.innerHTML = ''; }, ((hold || 3.6) + 0.7) * 1000);
  }
  function confetti(n) {
    var cols = ['#ffd24a', '#ff5a7a', '#59c2ff', '#7be07a', '#c58bff', '#ffffff', '#ff8a1f'];
    for (var i = 0; i < n; i++) {
      var d = document.createElement('div'); d.className = 'confetti';
      d.style.left = (Math.random() * 100) + 'vw'; d.style.background = cols[i % cols.length];
      d.style.animationDuration = (2.6 + Math.random() * 2.4) + 's'; d.style.animationDelay = (Math.random() * 1.2) + 's';
      d.style.setProperty('--rot', (Math.random() > 0.5 ? 1 : -1) * (360 + Math.random() * 720) + 'deg');
      d.style.width = (7 + Math.random() * 8) + 'px'; d.style.height = (10 + Math.random() * 12) + 'px';
      document.body.appendChild(d);
      (function (el) { setTimeout(function () { el.remove(); }, 6500); })(d);
    }
  }
  G.confetti = confetti;
  var flashT = 0;
  G.raceCoins = { combo: 0, tricks: 0, best: 0 };
  // contadores de la carrera: monedas (las tuyas + las de combos de esta carrera) y estrellas segun tu rendimiento
  function updCoinChip(pop) {
    var c = $('coinChip'); if (!c) return;
    var base = PG.Eco && PG.Eco.data ? PG.Eco.data.coins : 0, v = base + (G.coinsBanked ? 0 : G.raceCoins.combo);
    c.innerHTML = PG.ico('coin') + '<b>' + v + '</b>';
    if (pop) { c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }
  }
  function updStarChip() {
    var c = $('starChip'), me = G.me; if (!c || !me || !G.race) return;
    var n = me.dead ? 0 : (G.resCoins ? G.resCoins.stars : PG.Eco.starsFor(me.rank || 0, G.race.racers.length, G.raceCoins.tricks, { falls: me.falls | 0, hurt: me.hurt | 0 }));
    if (G.lastStarN !== n) { G.lastStarN = n; c.innerHTML = PG.ico('star') + '<b>' + n + '/5</b>'; c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }
  }
  function bigFlash(txt) {
    var b = $('bigMsg'); if (G.finishShown) return;
    b.textContent = txt; clearTimeout(flashT); flashT = setTimeout(function () { if (!G.finishShown) b.textContent = ''; }, 900);
  }
  var OK_MSGS = [['¡Gran carrera!', 'Cruzaste la meta entre los mejores.'], ['¡Muy bien!', 'Sigue así y el podio será tuyo.'], ['¡Buen trabajo!', 'Cada carrera te hace más rápido.']];
  var LAST_MSGS = [['¡Lo lograste, terminaste!', 'El último lugar también cuenta. ¡No te rindas, la próxima será mejor!'], ['¡Llegaste a la meta!', 'Lo importante es seguir intentando. ¡Tú puedes!'], ['¡Bien por terminar!', 'Los campeones también empezaron aquí. ¡Revancha!']];
  function finishMessage(rank, total) {
    if (rank === 1) return { kind: 'win', t: '🏆 ¡GANASTE! 🏆', s: '¡Eres el campeón de la pista!' };
    if (rank === 2) return { kind: 'good', t: '¡Segundo lugar!', s: '¡Casi! Un poquito más y llegas a lo más alto.' };
    if (rank === 3) return { kind: 'good', t: '¡Tercer lugar, al podio!', s: '¡Excelente carrera!' };
    if (total >= 4 && rank === total) { var l = LAST_MSGS[Math.floor(Math.random() * LAST_MSGS.length)]; return { kind: 'keep', t: l[0], s: l[1] }; }
    var o = OK_MSGS[Math.floor(Math.random() * OK_MSGS.length)]; return { kind: 'good', t: o[0], s: o[1] + ' (' + rank + 'º puesto)' };
  }
  G.finishMessage = finishMessage;
  G.go = go; G.esc = esc; G.store = store; G.ICONS = ICONS; G.fmtTime = fmtTime; G.bodyColor = bodyColor; G.$ = $;
  function onLocalFinish() {
    if (G.finishShown) return;
    G.finishShown = true;
    var rank = G.me.rank, total = G.race.racers.length, m = finishMessage(rank, total);
    Audio.sfx(rank === 1 ? 'win' : (rank <= 3 ? 'cheer' : 'finish'));
    $('bigMsg').textContent = '';
    banner(m.kind, m.t, m.s, rank === 1 ? 4.4 : 3.4);
    if (rank <= 3) { confetti(rank === 1 ? 90 : 45); G.shake = Math.max(G.shake, 0.4); }
    G.resMsg = m.t.replace(/🏆/g, '').trim() + ' ' + m.s;
    if (!G.demo) {
      var rcx = G.raceCoins, me0 = G.me, wt = 0;
      G.race.racers.forEach(function (q) { if (q !== me0 && q.finishTime > 0 && (!wt || q.finishTime < wt)) wt = q.finishTime; });
      rcx.falls = me0.falls | 0; rcx.hurt = me0.hurt | 0; rcx.gap = (rank > 1 && wt > 0 && me0.finishTime > 0) ? Math.max(0, (me0.finishTime - wt) / wt) : 0;
      var rw = rewardFor(rank, total, rcx);
      G.resCoins = rw; G.coinsBanked = true; G.resAnimAt = 0;
      var rr = recordRace('finish', rank, G.me.finishTime, G.trackIdx, total, rw);
      G.resRec = rr.record ? '⭐ ¡Nuevo récord en esta pista: ' + fmtTime(rr.best) + '!' : '';
    }
    G.resultsAt = performance.now() + (rank === 1 ? 5200 : 4200);
  }
  /* ---- eliminado por la avalancha: mensaje inmediato y modo espectador ---- */
  function onLocalDead() {
    if (G.deadShown) return;
    G.deadShown = true; G.finishShown = true;
    Audio.sfx('lose'); G.shake = Math.max(G.shake, 1.2);
    $('bigMsg').textContent = '';
    banner('lose', '¡PERDISTE!', 'Te alcanzó la avalancha', 4.2);
    G.resMsg = 'Te alcanzó la avalancha.'; G.resRec = '';
    if (!G.demo) { var rw2 = rewardFor(0, G.race.racers.length, G.raceCoins); G.resCoins = rw2; G.coinsBanked = true; G.resAnimAt = 0; recordRace('dead', 0, 0, G.trackIdx, G.race.racers.length, rw2); }
    $('hud').classList.add('spec'); $('alerts').innerHTML = ''; lastHud.alerts = '';
    $('specExit').textContent = G.mp ? 'Salir de la sala' : 'Salir';
    G.specId = null; G.camInit = false;
  }
  /* ---- llego el 4.o jugador a la meta: los que faltan pierden y salen los resultados ---- */
  function onLocalLost() {
    if (G.finishShown) return;
    G.finishShown = true; G.deadShown = true;
    Audio.sfx('lose'); G.shake = Math.max(G.shake, 0.8);
    $('bigMsg').textContent = '';
    banner('lose', '¡PERDISTE!', 'El penúltimo jugador ya llegó a la meta', 3.4);
    G.resMsg = 'Perdiste: todos los demás llegaron a la meta antes que tú.'; G.resRec = '';
    if (!G.demo) { var rw3 = rewardFor(0, G.race.racers.length, G.raceCoins); G.resCoins = rw3; G.coinsBanked = true; G.resAnimAt = 0; recordRace('dead', 0, 0, G.trackIdx, G.race.racers.length, rw3); }
    G.resultsAt = performance.now() + 2800;
  }
  function specList() { return G.race.racers.filter(function (r) { return !r.dead; }); }
  function specFocus() {
    var race = G.race, cur = G.specId && race.byId[G.specId];
    if (!cur || cur.dead) {
      var pick = null, l = specList();
      for (var i = 0; i < l.length; i++) { if (!l[i].finished && (!pick || l[i].rank < pick.rank)) pick = l[i]; }
      if (!pick) pick = l[0] || race.racers[0];
      G.specId = pick.id; cur = pick;
    }
    return cur;
  }
  function specStep(d) {
    var l = specList(); if (!l.length) return;
    var i = l.indexOf(G.race.byId[G.specId]); i = (i + d + l.length) % l.length; G.specId = l[i].id; G.camInit = false;
  }
  // mensaje de animo cuando ya casi todos llegaron y voy de ultimo
  function checkLastPlace() {
    var race = G.race, me = G.me, total = race.racers.length;
    if (G.lastMsgShown || !me || me.finished || total < 4 || race.time < 5) return;
    if (race.finishOrder.length >= total - 2 && me.rank === total) {
      G.lastMsgShown = true;
      banner('keep', 'Has llegado al último lugar…', '¡Pero no te rindas! Todavía puedes terminar la carrera. ¡Tú puedes!', 4.6);
      Audio.sfx('ability');
    }
  }

  /* ---------------- HUD ---------------- */
  var mk = {}, lastHud = {};
  function setTxt(id, v) { if (lastHud[id] !== v) { lastHud[id] = v; $(id).textContent = v; } }
  function setHtml(id, v) { if (lastHud[id] !== v) { lastHud[id] = v; $(id).innerHTML = v; } }
  function buildMarkers() {
    var box = $('progMarks'); box.innerHTML = ''; mk = {};
    box.style.cssText = 'position:absolute;inset:0';
    G.race.racers.forEach(function (r) {
      var d = document.createElement('div'); d.className = 'mk' + (r === G.me ? ' me' : '');
      d.style.background = bodyColor(r.cfg); d.style.color = '#fff';
      d.textContent = r.name.charAt(0).toUpperCase();
      box.appendChild(d); mk[r.id] = d;
    });
    var tg = $('tags'); tg.innerHTML = ''; G.tagEls = {};
    G.race.racers.forEach(function (r) {
      if (r === G.me) return;
      var d = document.createElement('div'); d.className = 'tag3d'; d.textContent = r.name; tg.appendChild(d); G.tagEls[r.id] = d;
    });
    lastHud = {};
  }
  function alertsHtml(race, me) {
    var h = '', t = race.time;
    if (me.dead || me.finished) return '';
    var ph = race.avPhase(t);
    if (ph === 1) h += '<div class="al near">⚠ ¡AVALANCHA! <b>' + Math.max(0, Math.ceil(race.av.tGo - t)) + '</b></div>';
    else if (ph === 2) {
      var dist = me.u - race.avFront(t);
      if (dist > -5 && dist < 900) { var cl = dist < 45 ? ' danger' : (dist < 110 ? ' near' : ''); h += '<div class="al' + cl + '">❄ AVALANCHA <b>' + Math.max(0, Math.round(dist)) + '</b> m</div>'; }
    }
    var best = 1e9;
    for (var i = 0; i < race.proj.length; i++) { var p = race.proj[i]; if (p.kd === 'msl' && p.tgt === me.id && p.owner !== me.id) { var dm = (me.u - p.u) * (p.dir || 1); if (dm > -4 && dm < best) best = dm; } }
    if (best < 400) { var cm = best < 60 ? ' danger' : (best < 140 ? ' near' : ''); h += '<div class="al' + cm + '">🚀 MISIL <b>' + Math.max(0, Math.round(best)) + '</b> m</div>'; }
    return h;
  }
  function updateHud(now) {
    var race = G.race, me = G.me, T = G.T;
    if (!me) return;
    if (me.dead) {
      var sf = G.camFocus; setTxt('specTxt', '👁 Mirando a: ' + (sf ? sf.name : '—') + (race.racers.every(function (r) { return r.finished; }) ? ' · carrera terminada' : ''));
      setHtml('alerts', '');
    } else { if (race.av && !G.avWarned && race.avPhase(race.time) >= 1) { G.avWarned = true; Audio.sfx('avwarn'); } setHtml('alerts', alertsHtml(race, me)); }
    var t = Math.max(0, race.time);
    if (me.finished) t = me.finishTime;
    setTxt('timerTxt', fmtTime(t));
    var endU = T.type === 'circuit' ? race.laps * T.L : T.D;
    if (T.type === 'circuit') setHtml('lapTxt', Math.max(1, Math.min(race.laps, me.lap || 1)) + '<small>/' + race.laps + '</small>');
    setTxt('posTxt', String(me.rank)); setTxt('posOf', '/' + race.racers.length);
    updCoinChip(false); updStarChip();
    setTxt('speedTxt', String(Math.round(Math.max(0, me.speed) * 3.6))); $('speedFill').style.width = Math.min(100, Math.max(0, me.speed) * 3.6 / 170 * 100).toFixed(0) + '%';
    // barra de progreso
    race.racers.forEach(function (r) {
      var f = clamp(r.u / endU, 0, 1), el = mk[r.id];
      if (el) el.style.bottom = 'calc(10px + (100% - 20px) * ' + f.toFixed(3) + ')';
    });
    // objetos y habilidad
    var it = me.item, ab = me.ability;
    setHtml('itemIco', it ? ICONS[it] : ICONS.fishoff);
    $('itemSlot').classList.toggle('ready', !!it);
    setTxt('itemState', it ? 'TURBO' : 'CARGANDO');
    $('itemChargeFill').style.width = (it ? 100 : Math.round(me.charge * 100)) + '%'; $('itemSlot').style.setProperty('--ch', it ? 100 : Math.round(me.charge * 100));
    setHtml('abilityIco', ab ? ICONS[ab] : '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="18" fill="none" stroke="#fff" stroke-width="4" stroke-dasharray="6 7" opacity=".7"/></svg>');
    setTxt('abilityName', ab ? PG.ITEM_NAMES[ab] : 'Habilidad');
    var bf = '', fxm = me.fx;
    [['shield', me.shType === 1 ? 'ESCUDO ELÉCTRICO' : (me.shType === 2 ? 'ESCUDO DE REBOTE' : 'ESCUDO'), 10, me.shType === 1 ? '#ffd23a' : (me.shType === 2 ? '#e24fc4' : '#4da8ee')], ['superjump', 'SÚPER SALTO', PG.CFG.SJ_T, '#7be07a'], ['ghost', 'FANTASMA', 6, '#cfe0ff'], ['wings', 'ALAS', 5.5, '#bfe8ff']].forEach(function (b) {
      if (fxm[b[0]] > 0) bf += '<div class="buff"><b>' + b[1] + ' ' + fxm[b[0]].toFixed(1) + 's</b><i><u style="width:' + Math.min(100, fxm[b[0]] / b[2] * 100).toFixed(0) + '%;background:' + b[3] + '"></u></i></div>';
    });
    setHtml('buffs', bf);
    // v3.0: casillas del equipo comprado (cada una con su recarga lenta y su contador de unidades)
    var eqNow = G.eq || [], eqs = eqNow.join(',') + '|' + (G.eqUsed || []).map(function (u) { return u ? 1 : 0; }).join('');
    if (G.eqKeys !== eqs) {
      G.eqKeys = eqs;
      var eb = $('eqBox');
      eb.innerHTML = eqNow.map(function (k, i) { return '<button class="eqB' + ((G.eqUsed || [])[i] ? ' used' : '') + '" data-k="' + k + '" data-i="' + i + '" aria-label="' + PG.ITEM_NAMES[k] + '"><span class="ic">' + ICONS[k] + '</span><em class="cd"></em><small>' + (EQ_SHORT[k] || PG.ITEM_NAMES[k]) + '</small></button>'; }).join('');
      [].forEach.call(eb.children, function (b) { G.bindEq(b); });
    }
    [].forEach.call($('eqBox').children, function (b) {
      var k = b.dataset.k, cdv = (me.eqCd && me.eqCd[k + '#' + b.dataset.i]) || 0, tot = PG.EQ_CD[k] || 30;
      b.style.setProperty('--cd', (cdv / tot * 100).toFixed(0) + '%');
      b.classList.toggle('cool', cdv > 0); b.classList.toggle('blk', (k === 'shield' || k === 'eshield' || k === 'bshield') && me.fx.shield > 0);
    });
    var q2 = me.abilityQ || [], qk = q2.join(',');
    setHtml('abQ', q2.map(function (a) { return '<i>' + ICONS[a] + '</i>'; }).join(''));
    $('btnAbility').classList.toggle('ready', !!ab);
    $('btnPush').classList.toggle('cool', me.pushCd > 0);
    var ww = (me.vf < -1 || Math.abs(me.psi) > 1.25) && race.time > 1 && !me.fell;
    $('wrongWay').style.display = ww ? 'block' : 'none';
    // cuenta atras
    var cd = $('countdown');
    if (race.time < 0) {
      var n = Math.ceil(-race.time);
      if (n <= 3 && n !== G.lastCount) {
        G.lastCount = n; cd.textContent = String(n); cd.classList.remove('pop'); void cd.offsetWidth; cd.classList.add('pop'); Audio.sfx('beep');
      }
    } else if (G.lastCount !== 0) {
      G.lastCount = 0; cd.textContent = '¡YA!'; cd.classList.remove('pop'); void cd.offsetWidth; cd.classList.add('pop'); Audio.sfx('go');
      setTimeout(function () { if ($('countdown').textContent === '¡YA!') $('countdown').textContent = ''; }, 900);
    }
  }
  function updateFireBtn() {
    var me = G.me, on = me && me.fx.cannon > 0, el = $('btnFire');
    if (G.fireShown !== on) { G.fireShown = on; el.style.display = on ? 'flex' : 'none'; $('btnAbility').classList.toggle('active', !!on); if (!on) { fireTouch = false; el.classList.remove('on'); } }
    if (on) $('fireFill').style.width = Math.round(me.fx.cannon / (me.gunT || PG.CFG.CANNON_T) * 100) + '%';
  }
  function drawMini() {
    var c = $('minimap'), x = c.getContext('2d');
    if (!miniBase) return;
    x.clearRect(0, 0, 150, 150); x.drawImage(miniBase.canvas, 0, 0);
    var T = G.T, bb = T.bbox, race = G.race, k = miniBase.scale * miniBase.sc;
    race.racers.forEach(function (r) {
      var w = wpos(r, _w), px = miniBase.pad + (w[0] - bb.x0) * k, py = miniBase.pad + (w[2] - bb.z0) * k;
      x.beginPath(); x.arc(px, py, r === G.me ? 5.5 : 3.6, 0, 6.3); x.fillStyle = bodyColor(r.cfg); x.fill();
      x.lineWidth = 2; x.strokeStyle = r === G.me ? '#ffb12b' : '#fff'; x.stroke();
    });
  }

  /* ---------------- camara ---------------- */
  var cam = G.cam = { eye: [0, 10, 0], target: [0, 0, 1], fov: 1.05 };
  var camYaw = 0, camY = 0, camDist = 8;
  G.shake = 0;
  var camLook = 0, camRoll = 0, camBank = 0, camCeil = 0;
  function updateCamera(dt, now) {
    var race = G.race, T = G.T;
    if (!race) return;
    var focus = G.me;
    if (focus && focus.dead) focus = specFocus();
    if (G.camMode === 'preview') return previewCam(now);
    if (G.dbgCamFn) return G.dbgCamFn(cam, focus);
    if (!focus) { // demo: seguir al lider
        focus = race.order ? race.order[0] : race.racers[0];
    }
    if (!focus) return;
    if (G.camFocus !== focus) { G.camFocus = focus; if (G.me && G.me.dead) G.camInit = false; }
    var fbr = focus.br | 0, s = T.uToS(focus.u), q = T.q(s, fbr), w = wpos(focus, _w);
    var demo = (G.camMode === 'demo');
    var targetYaw = q.yaw - focus.psi * 0.3;
    if (!G.camInit) { camYaw = q.yaw; camY = w[1] + 3.6; camLook = w[1] + 0.9; camRoll = 0; camBank = 0; camCeil = 0; G.camInit = true; }
    camYaw += PG.angDiff(camYaw, targetYaw) * Math.min(1, dt * 4.5);
    var spd = Math.max(0, focus.speed || 0);
    var dist = (demo ? 11 : 6.3) + spd * 0.035 + 0;
    camDist += (dist - camDist) * Math.min(1, dt * 3);
    var fy = Math.sin(camYaw), fz = Math.cos(camYaw);
    var lat = demo ? 6 + Math.sin(now * 0.0002) * 4 : 0;
    var rxn = -fz, rzn = fy; // derecha de la camara (sistema de mano derecha)
    // techo de las cuevas: la camara pasa por debajo del pinguino (que va boca abajo) y gira con el
    camCeil += ((demo ? 0 : (focus.ceilK || 0)) - camCeil) * Math.min(1, dt * 9);
    var ceE = camCeil * camCeil * (3 - 2 * camCeil), ceS = 1 - 2 * ceE;
    var hgt = (demo ? 4.6 : 3.1) * ceS;
    var targetY = w[1] + hgt;
    camY += (targetY - camY) * Math.min(1, dt * (focus.grounded ? 7 : 3));
    var ex = w[0] - fy * camDist + rxn * lat, ez = w[2] - fz * camDist + rzn * lat, ey = camY;
    // en las cuevas la camara no sigue al pinguino hasta la pared curva (atravesaria la roca)
    var dcamT = focus.d;
    if (!demo && T.caveF) {
      var cfk = T.caveF(s, fbr);
      if (cfk > 0) {
        var dcam = clamp(focus.d, -7.0, 7.0), dsh = (dcam - focus.d) * cfk;
        ex += q.rx * dsh; ez += q.rz * dsh; dcamT = focus.d + dsh;
      }
    }
    // la camara nunca baja del suelo (ni sube del techo) en SU posicion, no en la del pinguino:
    // en bajadas empinadas el terreno de atras esta mas alto que el pinguino
    if (!demo) {
      var sc1 = s - camDist * 0.8, sc2 = s - camDist * 1.15, gc = -1e9, g1, k2;
      for (k2 = 0; k2 < 2; k2++) {
        var sx = k2 ? sc2 : sc1;
        g1 = T.ground(sx, dcamT, fbr); if (g1 < -1e8) g1 = T.centerY(sx, fbr);
        if (g1 > gc) gc = g1;
      }
      var minCam = gc + (T.caveF && T.caveF(s, fbr) > 0 ? 2.3 : 1.7);
      if (ey < minCam) ey = minCam;
      if (T.ceilAt) {
        var ce = Math.min(T.ceilAt(sc1, dcamT, fbr), T.ceilAt(sc2, dcamT, fbr), T.ceilAt(s, dcamT, fbr));
        if (ce < 1e8) { var maxCam = T.centerY(s - camDist * 0.8, fbr) + ce - 1.6; if (ey > maxCam) ey = Math.max(maxCam, minCam); }
      }
    }
    // la camara no baja del suelo local
    var gy = T.hgt ? T.centerY(s, fbr) : 0;
    if (ey < gy + 1.2) ey = gy + 1.2;
    var sh = G.shake; G.shake = Math.max(0, G.shake - dt * 2.5);
    if (focus.fx.boost > 0 || focus.fx.pad > 0 || focus.holdBoost) sh = Math.max(sh, 0.18);
    if (sh > 0) { ex += rnd2() * sh * 0.25; ey += rnd2() * sh * 0.2; ez += rnd2() * sh * 0.25; }
    cam.eye[0] = ex; cam.eye[1] = ey; cam.eye[2] = ez;
    cam.target[0] = w[0] + fy * 12; cam.target[2] = w[2] + fz * 12;
    // mira hacia donde baja/sube la pista (sensacion de montana rusa) y se inclina en las curvas
    var tyT = w[1] + (0.9 + (focus.grounded ? q.sl * 7 : Math.max(-6, Math.min(4, (focus.vy || 0) * 0.35)))) * ceS;
    camLook += (tyT - camLook) * Math.min(1, dt * 6);
    cam.target[1] = camLook;
    // mirar atras (mientras se mantiene el boton): la camara pasa delante del pinguino y mira hacia atras
    var lbT = (!demo && (G.lookTouch || G.lookKey) && !(G.me && G.me.dead)) ? 1 : 0;
    G.lb = (G.lb || 0) + (lbT - (G.lb || 0)) * Math.min(1, dt * 11);
    var lbk = 0;
    if (G.lb > 0.01) {
      var sF = s + camDist * 0.95, gF = T.ground(sF, dcamT, fbr); if (gF < -1e8) gF = T.centerY(sF, fbr);
      var ry = Math.max(camY, gF + (T.caveF && T.caveF(s, fbr) > 0 ? 2.3 : 1.7));
      if (T.ceilAt) { var ceB = T.ceilAt(sF, dcamT, fbr); if (ceB < 1e8) { var mxB = T.centerY(sF, fbr) + ceB - 1.6; if (ry > mxB) ry = Math.max(mxB, gF + 1.7); } }
      lbk = G.lb * G.lb * (3 - 2 * G.lb);
      cam.eye[0] += (w[0] + fy * camDist * 0.95 - cam.eye[0]) * lbk; cam.eye[1] += (ry - cam.eye[1]) * lbk; cam.eye[2] += (w[2] + fz * camDist * 0.95 - cam.eye[2]) * lbk;
      cam.target[0] += (w[0] - fy * 12 - cam.target[0]) * lbk; cam.target[1] += (w[1] + 1.2 - cam.target[1]) * lbk; cam.target[2] += (w[2] - fz * 12 - cam.target[2]) * lbk;
    }
    var rollT = demo ? 0 : Math.max(-0.14, Math.min(0.14, (focus.steerVis || 0) * 0.055 + (focus.vl || 0) * 0.0035 + PG.angDiff(camYaw, q.yaw) * 0.0)) * ceS;
    camRoll += (rollT - camRoll) * Math.min(1, dt * 4);
    // en las paredes curvas de las cuevas la camara se inclina junto con el pingüino (el suelo pasa a ser la pared)
    camBank += ((demo ? 0 : (focus.bankRoll || 0) * (0.92 + 0.08 * ceE)) - camBank) * Math.min(1, dt * (5 + 5 * ceE));
    cam.roll = (camRoll + camBank) * (1 - lbk);
    var boosting = focus.fx.boost > 0 || focus.fx.pad > 0 || focus.holdBoost;
    var tf = 1.04 + Math.min(0.2, spd * 0.0035) + (boosting ? 0.08 : 0);
    G.fovKick = (G.fovKick || 0) * Math.max(0, 1 - dt * 3.5);
    tf += G.fovKick;
    cam.fov += (tf - cam.fov) * Math.min(1, dt * 5);
  }
  var preview = { yaw: 0.6, manual: false, rot: 0 };
  function previewCam(now) {
    var T = G.T, q = T.q(T.startS + 6), baseX = q.x, baseZ = q.z, baseY = q.y;
    var yaw = q.yaw;
    var fy = Math.sin(yaw), fz = Math.cos(yaw), rxn = -fz, rzn = fy;
    // el suelo donde se para el pingüino (la pista sube o baja delante de la cámara: antes quedaba medio enterrado)
    var asp = G.R.aspect, off = (asp > 1 ? 1.5 : 0.3) * 1.0;
    var px = baseX + fy * 6.2 + rxn * (-off * 1.9), pz = baseZ + fz * 6.2 + rzn * (-off * 1.9);
    var gy = T.ground(T.startS + 6 + 6.2, -off * 1.9); if (!(gy > -1e8)) gy = baseY;
    preview.gy = gy;
    baseY = gy;
    cam.eye[0] = baseX; cam.eye[1] = baseY + 2.2; cam.eye[2] = baseZ;
    var tgt = [baseX + fy * 8, baseY + 1.2, baseZ + fz * 8];
    cam.target[0] = tgt[0]; cam.target[1] = tgt[1]; cam.target[2] = tgt[2];
    cam.fov = 0.9; cam.roll = 0;
    preview.pos = [px, baseY + 0.9, pz];
    preview.yawBase = yaw;
  }

  /* ---------------- render ---------------- */
  var _m1 = m4.create(), _m2 = m4.create(), _m3 = m4.create();
  function drawPenguinAt(cfg, x, y, z, yaw, pitch, roll, sc, t, anim) {
    var R = G.R, model = pengGpu(cfg);
    var pv = anim.pv || 0;
    m4.trs(_m1, x, y + pv * sc, z, yaw, pitch, roll, sc, sc, sc);
    if (pv) { _m1[12] -= _m1[4] * pv; _m1[13] -= _m1[5] * pv; _m1[14] -= _m1[6] * pv; }
    var speedK = anim.speed || 0, hold = !!anim.extra;
    for (var i = 0; i < model.parts.length; i++) {
      var p = model.parts[i], M = _m1;
      if (p.kind !== 'body') {
        var ay = 0, ax = 0, az = 0;
        if (p.kind === 'flipR') { az = 0.10 + Math.sin(t * 8) * 0.10 * (0.4 + speedK) + (anim.wings ? Math.sin(t * 20) * 0.7 : 0) + anim.steer * 0.35; ay = 0.22; if (hold) { az = 1.05 + Math.sin(t * 9) * 0.03; ay = -0.55; } }
        else if (p.kind === 'flipL') { az = -(0.10 + Math.sin(t * 8 + 1) * 0.10 * (0.4 + speedK) + (anim.wings ? Math.sin(t * 20) * 0.7 : 0)) + anim.steer * 0.35; ay = -0.22; if (hold) { az = -1.05 - Math.sin(t * 9) * 0.03; ay = 0.55; } }
        else { ax = 0.15 + speedK * 0.5 + Math.sin(t * 11 + p.pivot[0] * 9) * 0.12 * (0.4 + speedK); ay = -anim.steer * 0.5 + Math.sin(t * 9) * 0.22 * speedK; }
        if (anim.swim) { // v2.7: nadando en la laguna: las aletas bracean (vaiven grande y rapido) y la cola patalea
          var swc = Math.sin(t * 8.5), swd = Math.cos(t * 8.5);
          if (p.kind === 'flipR') { az = 0.55 + 0.85 * swc + anim.steer * 0.3; ay = 0.30 + 0.45 * swd; }
          else if (p.kind === 'flipL') { az = -(0.55 + 0.85 * swc) + anim.steer * 0.3; ay = -(0.30 + 0.45 * swd); }
          else { ax = 0.3 + Math.sin(t * 8.5 + 1.2) * 0.4; ay = Math.sin(t * 4.2) * 0.18; }
        }
        if (anim.push) { // empujon: la aleta del lado del rival se lanza hacia adelante
          var pk = Math.sin(3.1416 * (1 - clamp(anim.pushT / 0.38, 0, 1)));
          if (p.kind === 'flipL' && anim.push > 0) { ay = 1.15 * pk; az = -0.25 * pk; }
          else if (p.kind === 'flipR' && anim.push < 0) { ay = -1.15 * pk; az = 0.25 * pk; }
        }
        m4.trs(_m2, p.pivot[0], p.pivot[1], p.pivot[2], ay, ax, az, 1, 1, 1);
        M = m4.mul(_m3, _m1, _m2);
      }
      R.draw(p.gl, M, anim.tint, anim.alpha || 1);
    }
    if (anim.extra) {
      if (anim.extraYaw) { m4.trs(_m2, 0, 0, 0, anim.extraYaw, 0, 0, 1, 1, 1); R.draw(anim.extra, m4.mul(_m3, _m1, _m2), null, anim.alpha || 1); }
      else R.draw(anim.extra, _m1, null, anim.alpha || 1);
    }
  }
  function lagoonSplash(r, x, y, z, into, q) { // salpicadura al entrar en el agua / al salir (y al caer de un salto)
    var n = into ? 34 : 16, i, fy = Math.sin(q.yaw), fz = Math.cos(q.yaw), sp0 = into ? 1 : 0.55;
    for (i = 0; i < n && particles.length < MAXP - 6; i++) {
      var a = Math.random() * 6.283, rr = Math.random() * 1.2;
      emitP(x + Math.cos(a) * rr, y + 0.1, z + Math.sin(a) * rr, Math.cos(a) * (2 + Math.random() * 4) * sp0 + fy * 4, (4 + Math.random() * 7) * sp0, Math.sin(a) * (2 + Math.random() * 4) * sp0 + fz * 4, 0.9 + Math.random() * 0.4, 0.55 + Math.random() * 0.5, 0.82, 0.94, 1, 0.9, 16);
    }
    for (i = 0; i < 14 && particles.length < MAXP - 2; i++) { // anillo de ondas
      var b = 6.283 * i / 14;
      emitP(x + Math.cos(b) * 0.8, y + 0.08, z + Math.sin(b) * 0.8, Math.cos(b) * (4.5 + (into ? 2 : 0)), 0, Math.sin(b) * (4.5 + (into ? 2 : 0)), 1.1, 0.9, 0.7, 0.9, 1, 0.55, 0);
    }
    if (r === (G.camFocus || G.me) && !G.paused) Audio.sfx(into ? 'splash' : 'splashOut');
  }
  function drawRacer(r, now, t) {
    if (r.dead) return;
    var R = G.R, T = G.T, s = T.uToS(r.u), q = T.q(s, r.br);
    var x = q.x + q.rx * r.d, z = q.z + q.rz * r.d, y = r.py;
    var palpha = 1;
    if (r.fx.ghost > 0) palpha = r === G.me ? 0.55 : 0.32;
    // un pinguino que queda entre la camara y el mio (o pegado a la camara) se vuelve casi transparente
    var cf = G.camFocus || G.me;
    if (cf && r !== cf && G.camMode === 'race') {
      var mw = wpos(cf, _w2), ex = cam.eye[0], ey = cam.eye[1], ez = cam.eye[2];
      var vx = mw[0] - ex, vy = mw[1] + 1 - ey, vz = mw[2] - ez, L2 = vx * vx + vy * vy + vz * vz;
      var px = x - ex, py = y + 1 - ey, pz = z - ez, tt = L2 > 0 ? (px * vx + py * vy + pz * vz) / L2 : 0;
      var dx = px - vx * tt, dy = py - vy * tt, dz = pz - vz * tt, perp2 = dx * dx + dy * dy + dz * dz, eye2 = px * px + py * py + pz * pz;
      if ((tt > -0.15 && tt < 1.02 && perp2 < 2.9 * 2.9) || eye2 < 4.2 * 4.2) palpha = Math.min(palpha, 0.16);
    }
    var yaw = q.yaw - r.psi + (r.yawOff || 0) + (r.fx.spin > 0 ? r.spinAng : 0);
    // v2.7: laguna. Se detecta por posicion (sirve igual para los rivales online): sobre la superficie del agua se nada
    var swim = !!(T.lake && !r.br && !r.fell && T.lakeDepth(s) > 0.6 && Math.abs(r.py - T.lake.y) < 0.9);
    if (swim !== !!r.wasSwim) {
      if (r.wasSwim !== undefined) lagoonSplash(r, x, T.lake.y, z, swim, q);
      if (swim && r.wasSwim !== undefined) { r.swDip = 0.05; r.swDv = 3.4 + Math.min(4, Math.abs(r.vf) * 0.07) + Math.min(4, Math.max(0, -(r.vy || 0)) * 0.25); } // v2.8: al entrar se hunde un poco y vuelve a flotar
      r.wasSwim = swim;
    }
    if (swim) {
      var dtS = Math.min(0.05, G.dtLast || 0.016), dp = r.swDip || 0, dv = r.swDv || 0;
      dv += (-30 * dp - 5.2 * dv) * dtS; dp += dv * dtS; if (dp < -0.12) { dp = -0.12; dv = Math.max(0, dv); } if (dp > 1.5) { dp = 1.5; dv = Math.min(0, dv); }
      r.swDip = dp; r.swDv = dv;
      // v3.0: se nada BAJO la superficie, a media agua y sin tocar el fondo (en la orilla, donde hay poca agua, va subiendo hasta asomar)
      var floorY = T.centerY(s, 0), wdep = Math.max(0, T.lake.y - floorY), sub = Math.min(2.4, Math.max(0.35, wdep * 0.42));
      var yT = T.lake.y - sub - dp + Math.sin(t * 1.9 + r.slot * 1.3) * 0.16 + Math.sin(t * 5.3 + r.slot) * 0.05;
      yT = Math.max(yT, floorY + 0.9); yT = Math.min(yT, T.lake.y - 0.25);
      r.swY = r.swY === undefined ? yT : r.swY + (yT - r.swY) * Math.min(1, (G.dtLast || 0.016) * 4);
      y = r.swY;
      if (dp > 0.35 && particles.length < MAXP - 4 && Math.random() < 0.5 && !G.paused) emitP(x + rnd2() * 0.5, y + 0.4, z + rnd2() * 0.5, rnd2() * 0.3, 1.2 + Math.random() * 1.4, rnd2() * 0.3, 0.8, 0.28, 0.85, 0.96, 1, 0.65, -0.2);
    } else { r.swDip = 0; r.swDv = 0; }
    if (!swim) r.swY = undefined;
    var pt = swim ? Math.sin(t * 2.1 + r.slot) * 0.1 - Math.atan(q.sl) * 0.5 : (r.grounded ? -Math.atan(q.sl) : -Math.atan2(r.vy, Math.max(8, r.vf)) * 0.9);
    r.pv = r.pv === undefined ? pt : r.pv + (pt - r.pv) * 0.25;
    var roll = r.steerVis * 0.5 + (swim ? Math.sin(t * 1.7 + r.slot * 2) * 0.09 : 0) + (r.bankRoll || 0) + (r.fx.push > 0 ? (r.pushDir || 1) * Math.sin(3.1416 * (1 - r.fx.push / 0.38)) * 0.32 : 0), pvot = 0;
    var pitchDraw = r.pv;
    if (r.flipping && r.flipAcc > 0) {
      var fa = r.flipAcc * r.flipDir; pvot = 0.32;
      if (r.flipMode === 1) pitchDraw = r.pv + fa; else roll += fa;
    }
    if (r.rightA) { // v2.7: aterrizo boca arriba: se endereza solo con un giro rapido
      r.rightA *= Math.exp(-Math.min(0.05, G.dtLast || 0.016) * 9); if (Math.abs(r.rightA) < 0.03) r.rightA = 0;
      if (r.rightMode === 1) pitchDraw += r.rightA; else roll += r.rightA;
      pvot = 0.32;
    }
    var gs = 1.5;
    r.gsv = r.gsv === undefined ? gs : r.gsv + (gs - r.gsv) * 0.1;
    var sp = clamp(Math.abs(r.vf) / 40, 0, 1);
    drawPenguinAt(r.cfg, x, y + (r.grounded ? Math.sin(t * 13 + r.slot) * 0.015 * sp * r.gsv : 0), z, yaw, pitchDraw, roll, r.gsv, t + r.slot,
      { speed: sp, steer: r.steerVis, swim: swim, wings: r.fx.wings > 0, tint: null, alpha: palpha, pv: pvot, extra: r.fx.cannon > 0 ? (r.gun === 'gren' ? gm.cannon2 : gm.cannon) : null, extraYaw: (1 - (r.aimV === undefined ? 1 : r.aimV)) * 1.5708, push: r.fx.push > 0 ? (r.pushDir || 1) : 0, pushT: r.fx.push });
    // estela y espuma al nadar
    if (swim && particles.length < MAXP - 14 && !G.paused) {
      var wy_ = Math.sin(q.yaw - r.psi), wz_ = Math.cos(q.yaw - r.psi), wl = Math.max(0.3, sp);
      emitP(x - wy_ * 1.1 + rnd2() * 0.8, y + 0.5, z - wz_ * 1.1 + rnd2() * 0.8, rnd2() * 0.5 - wy_ * 1.5, 0.9 + Math.random() * 1.4, rnd2() * 0.5 - wz_ * 1.5, 0.9, 0.5 + wl * 0.4, 0.88, 0.96, 1, 0.6, 1.2);
      if (Math.random() < 0.6) { var sdw = Math.random() < 0.5 ? -1 : 1; emitP(x - wy_ * 0.4 - wz_ * sdw * 0.9, T.lake.y + 0.1, z - wz_ * 0.4 + wy_ * sdw * 0.9, -wz_ * sdw * (2 + wl * 2.5) - wy_ * 2, 0.4 + Math.random() * 0.8, wy_ * sdw * (2 + wl * 2.5) - wz_ * 2, 0.7, 0.42, 1, 1, 1, 0.7, 4); }
    }
    // sombra
    if (!r.fell && !swim) {
      var gy = r.gy !== undefined ? r.gy : y;
      if (gy > -1e8) {
        m4.trs(_m2, x, gy + 0.07, z, q.yaw, -Math.atan(q.sl), 0, r.gsv * 1.45 * (1 + (y - gy) * 0.05), 1, r.gsv * 1.35);
        R.draw(gm.shadow, _m2, null, clamp(0.45 - (y - gy) * 0.06, 0.12, 0.45) * (palpha < 0.5 ? 0.15 : 1));
      }
    }
    if (r.fx.shield > 0) {
      var sty = r.shType | 0, shp = (r.shHp !== undefined ? 0.2 + Math.min(4, r.shHp) * 0.04 : 0.35), fl2 = r.shFlash > 0 ? 0.35 * r.shFlash / 0.35 : 0;
      if (r.shFlash > 0) r.shFlash -= G.dtLast || 0.016;
      var gs = r.gsv, tn = null, al = shp + fl2, ph2 = t * 1000 * 0.001, sx = gs, sy = gs, sz = gs;
      if (sty === 1) { // electrico: amarillo, titila y suelta chispas
        tn = [2.3, 1.15, 0.04]; al = (shp + 0.05 + 0.14 * Math.abs(Math.sin(ph2 * 31 + (r.id.length || 1))) * (Math.sin(ph2 * 13) > 0 ? 1 : 0.4)) * 0.6 + fl2;
        if (particles.length < MAXP - 24 && Math.random() < 0.55) { var ea = Math.random() * 6.28, ey = (Math.random() - 0.1) * 1.7; burst(x + Math.cos(ea) * 1.3 * gs, y + 0.6 + ey, z + Math.sin(ea) * 1.3 * gs, 3, [1, 0.95, 0.35], 3.8, 0.34, 0.26); }
      } else if (sty === 2) { // rebote: magenta que late (como una pompa elastica)
        tn = [1.55, 0.55, 1.45]; var pu = Math.sin(ph2 * 9); sx = gs * (1 + 0.07 * pu); sy = gs * (1 - 0.07 * pu); sz = gs * (1 + 0.05 * pu); al = shp + 0.08 + fl2;
      }
      m4.trs(_m2, x, y + 0.6 * gs, z, yaw + (sty === 1 ? ph2 * 6 : 0), 0, 0, sx, sy, sz); R.shieldFx(gm.shield, _m2, sty, Math.max(0.55, Math.min(1.5, (shp + fl2) / 0.4)), tn, Math.min(0.8, al));
      // v3.2: paneles de cristal, aros y animaciones propias de cada escudo
      // (v3.2.1: se quitaron los paneles de cuadritos; el escudo es una esfera suave con aros, franja y rayos)
      if (sty === 0) { // normal: franja de luz que sube y baja
        var bt = (Math.sin(ph2 * 2.4) * 0.5 + 0.5), bw = Math.sqrt(Math.max(0.02, 1 - Math.pow(bt * 2 - 1, 2) * 0.96));
        m4.trs(_m2, x, y + (0.1 + bt * 1.15) * gs, z, yaw, 0, 0, gs * 1.3 * bw, gs, gs * 1.55 * bw); R.draw(gm.shieldBand, _m2, [0.9, 1.4, 1.8], R.gloss ? 0.16 : 0.5);
      } else if (sty === 1) { // electrico: rayos que saltan por la superficie (cambian de sitio ~16 veces por segundo)
        var fk = Math.floor(ph2 * 16), nb2 = R.gloss ? 5 : 3;
        for (var bk = 0; bk < nb2; bk++) {
          var bh = Math.sin(fk * 12.9898 + bk * 78.233 + (r.id.length || 1)) * 43758.5453, bf = bh - Math.floor(bh);
          m4.trs(_m2, x, y + 0.6 * gs, z, bf * 6.283, (bk % 3 === 1 ? 0.9 : (bk % 3 === 2 ? 2.3 : 0)) * (bf > 0.5 ? 1 : -1) + (bf - 0.5) * 1.2, (bk - 1) * 1.1, gs, gs, gs);
          R.draw(gm.bolts[(fk + bk * 2) % gm.bolts.length], _m2, [1.4, 1.4, 1.0], 0.55 + 0.4 * ((fk + bk) & 1));
        }
        if (!R.gloss) { m4.trs(_m2, x, y + 0.6 * gs, z, -ph2 * 5, 0, 0, gs, gs, gs); R.draw(gm.shieldRing, _m2, [1.5, 1.4, 0.5], 0.45 + 0.35 * Math.abs(Math.sin(ph2 * 31))); }
      } else { // rebote: dos aros que giran y se ondulan; al recibir un golpe se expanden
        var wob = 1 + 0.06 * Math.sin(ph2 * 9);
        if (!R.gloss) {
        m4.trs(_m2, x, y + 0.6 * gs, z, ph2 * 3.1, 0, 0, gs * wob, gs / wob, gs * wob); R.draw(gm.shieldRing, _m2, [1.6, 0.6, 1.4], 0.75);
        m4.trs(_m2, x, y + 0.6 * gs, z, -ph2 * 2.3, 1.5708, 0.6, gs / wob, gs * wob, gs * wob); R.draw(gm.shieldRing, _m2, [0.6, 1.6, 1.7], 0.7);
        }
        if (particles.length < MAXP - 10 && Math.random() < 0.25) { var ba = Math.random() * 6.28; burst(x + Math.cos(ba) * 1.4 * gs, y + 0.4 + Math.random() * 1.1, z + Math.sin(ba) * 1.4 * gs, 1, [1, 0.5, 0.95], 1.2, 0.3, 0.5); }
      }
      if (sty === 1 && !R.gloss) { m4.trs(_m2, x, y + 0.6 * gs, z, -ph2 * 9, 0, 0, gs * 1.1, gs * 1.1, gs * 1.1); R.draw(gm.shield, _m2, [2.6, 2.0, 0.6], 0.1 + 0.12 * Math.abs(Math.sin(ph2 * 47))); }
      if (sty === 2 && r.shFlash > 0) { var rs = 1.1 + (0.35 - r.shFlash) * 1.6; m4.trs(_m2, x, y + 0.6 * gs, z, yaw, 0, 0, gs * rs, gs * rs, gs * rs); R.shieldFx(gm.shield, _m2, 2, Math.min(1.2, r.shFlash * 3), [1.9, 0.8, 1.7], Math.min(0.5, r.shFlash)); }
    }
    // particulas
    if (r.grounded && Math.abs(r.vf) > 10 && !r.fell && particles.length < MAXP - 20) {
      var fy = Math.sin(q.yaw - r.psi), fz = Math.cos(q.yaw - r.psi);
      var cs = Math.abs(r.bankRoll || 0) > 2 ? -1 : 1; // pegado al techo: la nieve cae hacia abajo
      emitP(x - fy * 0.9 * r.gsv + rnd2() * 0.3, y + 0.15 * cs, z - fz * 0.9 * r.gsv + rnd2() * 0.3, rnd2() * 1.2 - fy * 2, (0.6 + Math.random() * 1.2) * cs, rnd2() * 1.2 - fz * 2, 0.55, 0.3 + sp * 0.25, 1, 1, 1, 0.8, 3);
      if (r.fx.boost > 0 || r.fx.pad > 0 || r.holdBoost) emitP(x - fy * 1.3, y + 0.5, z - fz * 1.3, -fy * 6 + rnd2(), 0.5 + Math.random(), -fz * 6 + rnd2(), 0.4, 0.55, 1, 0.55 + Math.random() * 0.3, 0.1, 0.9, 0);
    }
    if (r.fx.superjump > 0 && particles.length < MAXP - 5) emitP(x + rnd2() * 0.7, y + 0.1, z + rnd2() * 0.7, rnd2() * 0.5, 1.2 + Math.random(), rnd2() * 0.5, 0.5, 0.3, 0.6, 1, 0.6, 0.85, 0);
    if (r.fx.wings > 0 && particles.length < MAXP - 5) emitP(x + rnd2() * 0.6, y + 0.8, z + rnd2() * 0.6, rnd2(), 0.5, rnd2(), 0.7, 0.35, 0.7, 0.95, 1, 0.9, 0);
  }

  /* ---- espectadores: el mismo pinguino de los corredores, de pie, cada uno con su propia animacion ---- */
  var NSPEC = 10, specSet = null, _sm = new Float32Array(16), _sm2 = new Float32Array(16), _sm3 = new Float32Array(16);
  function specSetup() {
    if (specSet) return specSet;
    var rnd = PG.rng(4242), R = G.R; specSet = [];
    for (var i = 0; i < NSPEC; i++) {
      var cfg = PG.fixCfg(makeBotCfg(rnd)); cfg.hat = 1 + Math.floor(rnd() * 7); cfg.scarf = Math.floor(rnd() * 4);
      var model = PG.spectatorModel(cfg);
      model.parts.forEach(function (pt) { if (!pt.gl) pt.gl = R.upload(pt.mesh); });
      specSet.push({ model: model, lite: R.upload(PG.spectatorLite(cfg)) });
    }
    return specSet;
  }
  function drawSpectators(now, t) {
    var T = G.T, specs = T.specs; if (!specs || !specs.length) return;
    var R = G.R, set = specSetup(), eye = cam.eye, tg = cam.target;
    var fx = tg[0] - eye[0], fy = tg[1] - eye[1], fz = tg[2] - eye[2], fl = Math.sqrt(fx * fx + fy * fy + fz * fz) || 1; fx /= fl; fy /= fl; fz /= fl;
    var race = G.race, rp = [], i, k;
    for (i = 0; i < race.racers.length; i++) { var rr = race.racers[i]; wpos(rr, _w); rp.push(_w[0], _w[1], _w[2]); }
    var drawn = 0;
    for (i = 0; i < specs.length; i++) {
      var sp = specs[i], dx = sp.x - eye[0], dy = sp.y - eye[1], dz = sp.z - eye[2], d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > 170 * 170) continue;
      var dot = dx * fx + dy * fy + dz * fz; if (dot < -3) continue;
      if (dot > 0 && d2 > 16 * 16) { var pr = d2 - dot * dot; if (pr > (dot * 1.25) * (dot * 1.25) + 25) continue; } // fuera del cono de vision
      var near = d2 < 34 * 34, v = set[sp.k % NSPEC], ty = sp.k % 6, ph = sp.k * 1.713, exc = 0;
      for (k = 0; k < rp.length; k += 3) { var ex = rp[k] - sp.x, ez = rp[k + 2] - sp.z; if (ex * ex + ez * ez < 45 * 45) { exc = 1; break; } }
      var tt = t * (1 + 0.5 * exc + (sp.k % 5) * 0.06) + ph, bounce = 0, aR = 0.3, aL = 0.3, roll = 0, yawO = Math.sin(t * 0.6 + ph) * 0.3;
      if (ty === 0) { aR = 1.9 + 0.5 * Math.sin(tt * 7); aL = 1.9 + 0.5 * Math.sin(tt * 7 + 1.5); bounce = Math.abs(Math.sin(tt * 5)) * 0.2; }
      else if (ty === 1) { aR = 1.7 + 0.6 * Math.sin(tt * 9); aL = -1.0; roll = Math.sin(tt * 2) * 0.07; }
      else if (ty === 2) { bounce = Math.max(0, Math.sin(tt * 4.2)) * 0.75; aR = aL = 1.6 + 0.3 * Math.sin(tt * 8); }
      else if (ty === 3) { aR = aL = -0.8 + Math.sin(tt * 12) * 0.35; bounce = Math.abs(Math.sin(tt * 6)) * 0.07; }
      else if (ty === 4) { roll = Math.sin(tt * 1.8) * 0.16; aR = 0.4 + 0.5 * Math.sin(tt * 1.8); aL = 0.4 + 0.5 * Math.sin(tt * 1.8 + 3.1); yawO *= 1.6; }
      else { aR = 0.5 + 1.2 * Math.max(0, Math.sin(tt * 5)); aL = 0.5 + 1.2 * Math.max(0, Math.sin(tt * 5 + 3.14)); bounce = Math.abs(Math.sin(tt * 5)) * 0.1; }
      if (exc) bounce *= 1.4;
      var sc = 2.1 + (sp.k % 3) * 0.08;
      m4.trs(_sm, sp.x, sp.y + bounce, sp.z, sp.yaw + yawO, near ? PG.STAND_TILT : 0, roll, sc, sc, sc);
      drawn++;
      if (!near) { R.draw(v.lite, _sm, null, 1); continue; }
      var parts = v.model.parts;
      for (k = 0; k < parts.length; k++) {
        var pt = parts[k], M = _sm;
        if (pt.kind === 'flipR') { m4.trs(_sm2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, aR, 1, 1, 1); M = m4.mul(_sm3, _sm, _sm2); }
        else if (pt.kind === 'flipL') { m4.trs(_sm2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, -aL, 1, 1, 1); M = m4.mul(_sm3, _sm, _sm2); }
        R.draw(pt.gl, M, null, 1);
      }
    }
    G.specDrawn = drawn;
  }

  /* ---- avalancha: muro de nieve que avanza por la pista ---- */
  function drawAvalanche(now, t) {
    var race = G.race, av = race.av, T = G.T, R = G.R, w = _w; G.avK = 0;
    if (!av) return;
    var ph = race.avPhase(race.time), cf = G.camFocus || G.me; if (!cf) return;
    if (ph === 1) { G.avK = 0.3 + 0.25 * Math.sin(t * 25); return; }
    if (ph !== 2) return;
    var uF = race.avFront(race.time), endU = T.type === 'circuit' ? race.laps * T.L : T.D;
    var dist = cf.u - uF; G.avK = clamp(1 - dist / 240, 0, 0.95);
    if (uF > endU + 60) return; // ya paso la meta
    if (dist < -330 || dist > 300) return; // fuera de la vista
    // sombra oscura sobre la pista por delante del frente (la nube tapa el sol) + rafagas de nieve que se adelantan
    if (dist > -10 && dist < 150) {
      var shW = T.W + 8, sc, sr;
      for (sr = 0; sr < 7; sr++) {
        var su = uF + 6 + sr * 15, sa = 0.5 * (1 - sr / 7.5);
        for (sc = 0; sc < 4; sc++) {
          wposUD(su, -shW / 2 + (sc + 0.5) * shW / 4, w);
          m4.trs(_m2, w[0], w[1] + 0.22, w[2], 0, 0, 0, 15, 1, 15); R.draw(gm.shadow, _m2, null, sa);
        }
      }
    }
    var c, row, W = T.W + 6, n = 8;
    for (row = 0; row < 4; row++) {
      for (c = 0; c < n; c++) {
        var jit = Math.sin(c * 12.9 + row * 7.1) * 0.5, d = -W / 2 + (c + 0.5 + jit * 0.5) * W / n;
        var rad = (7 + 3 * (0.5 + 0.5 * Math.sin(t * 2.6 + c * 1.9 + row * 2.3))) * (1.1 - row * 0.1);
        var u = uF - 1 - row * 6.5 - (Math.sin(c * 3.7) + 1) * 2.2;
        wposUD(u, d, w);
        var bob = Math.abs(Math.sin(t * 3.2 + c * 1.3 + row)) * 1.4;
        m4.trs(_m2, w[0], w[1] + rad * 0.75 + bob, w[2], c * 1.7 + row, -t * 2.4 + c, t * 0.9, rad, rad * 0.9, rad); R.draw(gm.avBall, _m2, null, 1);
      }
    }
    // nube de polvo de nieve que se levanta delante del muro y rueda hacia adelante
    var qa = T.q(T.uToS(uF)), fx = qa.tx, fz = qa.tz, adt = Math.min(0.05, G.dtLast || 0.016), nrm = clamp(1 - dist / 150, 0, 1);
    if (particles.length < MAXP - 40) {
      var nc = Math.round(10 + 26 * nrm);
      for (c = 0; c < nc; c++) {
        wposUD(uF + 4 + Math.random() * 10, (Math.random() - 0.5) * W * 1.15, w);
        var sp = 10 + Math.random() * 22, hh = Math.random() * 15, big = Math.random() < 0.35;
        emitP(w[0], w[1] + 0.5 + hh, w[2], fx * sp + rnd2() * 4, 1 + Math.random() * 6, fz * sp + rnd2() * 4, 1.3 + Math.random() * 0.9, big ? 5 + Math.random() * 5 : 2 + Math.random() * 2.2, 0.96, 0.98, 1, big ? 0.55 : 0.8, 1.5);
      }
    }
    // la nieve que levanta el frente se adelanta mucho: rafagas que pasan zumbando junto a la camara (se ven venir desde lejos)
    var far = clamp(1 - dist / 300, 0, 1);
    if (far > 0.04 && dist > -15 && particles.length < MAXP - 60) {
      var ce = cam.eye, nq = Math.round((3 + 46 * far * far + 8 * far) * (adt / 0.016));
      var cq = T.q(T.uToS(cf.u)), cfx = cq.tx, cfz = cq.tz, crx = cq.rx, crz = cq.rz;
      for (c = 0; c < nq; c++) {
        var ahead = -12 + Math.random() * 70, side = (Math.random() - 0.5) * 24, yy = ce[1] - 2.5 + Math.random() * 10, spd = 26 + Math.random() * 30 + 40 * far;
        emitP(ce[0] + cfx * ahead + crx * side, yy, ce[2] + cfz * ahead + crz * side, cfx * spd, rnd2() * 2, cfz * spd, 0.55 + Math.random() * 0.6, 0.5 + Math.random() * 1.8, 1, 1, 1, 0.85, 0);
      }
      // nubes de nieve grandes que avanzan por la pista por delante del frente (la "sombra blanca" que se acerca)
      var nb = Math.round((1 + 5 * far) * (adt / 0.016));
      for (c = 0; c < nb; c++) {
        wposUD(uF + 14 + Math.random() * Math.max(30, Math.min(dist, 200)), (Math.random() - 0.5) * W * 1.1, w);
        var sp2 = 22 + Math.random() * 18;
        emitP(w[0], w[1] + 1 + Math.random() * 9, w[2], fx * sp2, 1 + Math.random() * 3, fz * sp2, 1.2 + Math.random() * 0.8, 6 + Math.random() * 7, 0.9, 0.94, 1, 0.38, 0);
      }
    }
    if (dist >= 0 && dist < 60) G.shake = Math.max(G.shake, 0.25 * (1 - dist / 60));
  }

  function drawWorld(now, dt) {
    var R = G.R, T = G.T, race = G.race, t = now / 1000;
    var focus = G.camFocus || G.me || (race.order && race.order[0]) || race.racers[0];
    var camS = focus ? T.uToS(focus.u) : 0;
    R.draw(G.tmesh, null, null, 1);
    if (G.tpads) R.draw(G.tpads[G.dbgPadFrame !== undefined ? G.dbgPadFrame : Math.floor(performance.now() / 95) % G.tpads.length], null, null, 1); // v2.9: flechas de neon de los turbos (animadas)
    function vis(s) { var d = T.dS(camS, s); return d > -50 && d < 330; }
    var i, k, w = _w;
    // esferas luminosas: objetos (azul) y habilidades (violeta). Las partes translucidas se dibujan al final.
    var orbs = G.orbs; orbs.length = 0; G.halos.length = 0;
    for (k = 0; k < T.boxes.length; k++) {
      var B = T.boxes[k]; if (!vis(B.s) || race.boxT[k] > race.time) continue;
      var q = T.q(B.s, B.br), gy = T.ground(B.s, B.d, B.br); if (gy < -1e8) continue;
      var since = race.time - (race.boxT[k] || 0), ap = since > 0 && since < 0.6 ? 0.25 + since * 1.25 : 1;
      var bx = q.x + q.rx * B.d, bz = q.z + q.rz * B.d, by = gy + 1.75 + Math.sin(t * 2.5 + k) * 0.22;
      m4.trs(_m2, bx, by, bz, q.yaw + Math.sin(t * 1.3 + k) * 0.5, 0, 0, ap, ap, ap); R.draw(gm.orbItem, _m2, null, 1);
      m4.trs(_m2, bx, by, bz, t * 1.9 + k, 0, 0, ap, ap, ap); R.draw(gm.orbRingI, _m2, null, 1);
      orbs.push(0, bx, by, bz, ap, gy, t + k);
      G.halos.push(bx, by, bz, 4.2 * ap * (1 + Math.sin(t * 3 + k) * 0.08), 0.4, 0.85, 1.0, 0.5);
    }
    for (k = 0; k < T.crys.length; k++) {
      var Cr = T.crys[k]; if (!vis(Cr.s) || race.crysT[k] > race.time) continue;
      var qc = T.q(Cr.s, Cr.br), gc = Cr.ceil ? T.centerY(Cr.s) + T.ceilAt(Cr.s, Cr.d) - 4.6 : T.ground(Cr.s, Cr.d, Cr.br); if (gc < -1e8) continue; // v3.2.1: los del techo cuelgan del techo de la cueva
      var sinceC = race.time - (race.crysT[k] || 0), apC = sinceC > 0 && sinceC < 0.8 ? 0.25 + sinceC * 0.94 : 1;
      var cx = qc.x + qc.rx * Cr.d, cz = qc.z + qc.rz * Cr.d, cy = gc + 2.2 + Math.sin(t * 2 + k) * 0.3;
      m4.trs(_m2, cx, cy, cz, qc.yaw + Math.sin(t * 1.1 + k) * 0.5, 0, 0, apC, apC, apC); R.draw(gm.orbAbil, _m2, null, 1);
      m4.trs(_m2, cx, cy, cz, -t * 1.4 + k, 0, 0, apC, apC, apC); R.draw(gm.orbRingA, _m2, null, 1);
      orbs.push(1, cx, cy, cz, apC, gc, t + k);
      G.halos.push(cx, cy, cz, 6.2 * apC * (1 + Math.sin(t * 2.6 + k) * 0.08), 0.85, 0.55, 1.0, 0.55);
    }
    // obstaculos
    var pos = [0, 0];
    for (k = 0; k < T.obs.length; k++) {
      var o = T.obs[k]; if (!vis(o.s)) continue;
      if (race.ko[k] && race.ko[k] > race.time) continue;
      PG.obsPos(T, o, race.time, pos);
      var qo = T.q(pos[0], o.br), go = T.ground(pos[0], pos[1], o.br); if (go < -1e8) continue;
      var ox = qo.x + qo.rx * pos[1], oz = qo.z + qo.rz * pos[1];
      if (o.type === 'rock') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.rock[Math.floor(o.var * 3) % 3], _m2, null, 1); }
      else if (o.type === 'ice') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.ice, _m2, null, 1); }
      else if (o.type === 'snowman') { m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, 1, 1, 1); R.draw(gm.snowman, _m2, null, 1); }
      else if (o.type === 'seal') {
        var dir = Math.cos(race.time * o.w + o.ph) > 0 ? 1 : -1;
        m4.trs(_m2, ox, go, oz, qo.yaw + dir * Math.PI / 2, 0, Math.sin(race.time * 6) * 0.08, 1, 1, 1); R.draw(gm.seal, _m2, null, 1);
      } else if (o.type === 'ball') {
        m4.trs(_m2, ox, go + 1.7, oz, qo.yaw, race.time * 3 + o.ph, 0, 1, 1, 1); R.draw(gm.ball, _m2, null, 1);
      } else if (o.type === 'tree') {
        var tsc = 0.9 + (o.var || 0) * 0.35; m4.trs(_m2, ox, go - 0.1, oz, o.yaw, 0, 0, tsc, tsc, tsc); R.draw(gm.tree, _m2, null, 1);
      } else if (o.type === 'icicle') {
        var ist = PG.icicleState(o, race.time), hy = T.centerY(pos[0]) + T.ceilAt(pos[0], pos[1]) + 0.6, shk = 0, iy = hy, isy = 1;
        if (ist.ph === 4) continue;
        if (ist.ph === 1) {
          shk = Math.sin(t * 70) * 0.16 * (0.4 + ist.f);
          m4.trs(_m2, ox, go + 0.05, oz, t * 2, 0, 0, 1 + ist.f * 0.2, 1, 1 + ist.f * 0.2); R.draw(gm.warn, _m2, null, 0.35 + 0.35 * Math.abs(Math.sin(t * 14)));
        } else if (ist.ph === 2) {
          iy = hy + (go + 5.2 - hy) * ist.f * ist.f;
          m4.trs(_m2, ox, go + 0.05, oz, 0, 0, 0, 1.2, 1, 1.2); R.draw(gm.warn, _m2, null, 0.8);
        } else if (ist.ph === 3) {
          iy = go + 5.2 * (1 - ist.f * 0.65); isy = 0.35 + (1 - ist.f) * 0.65;
          if (o._shat !== Math.floor((race.time + o.ph) / o.per)) { o._shat = Math.floor((race.time + o.ph) / o.per); burst(ox, go + 0.6, oz, 18, [0.8, 0.95, 1], 9, 0.45, 0.9); if (G.me && Math.abs(G.me.u - o.s) < 80) Audio.sfx('pop'); }
        }
        m4.trs(_m2, ox + shk, iy, oz, o.yaw, 0, 0, 1, isy, 1); R.draw(gm.icicle, _m2, null, ist.ph === 3 ? clamp(1 - (ist.f - 0.6) * 2.5, 0.2, 1) : 1);
      }
    }
    // trampas y proyectiles
    for (k = 0; k < race.traps.length; k++) {
      var tr = race.traps[k]; wposUD(tr.u, tr.d, w);
      var tsc = (tr.age < 0.35 ? tr.age / 0.35 : 1) * (1.3 + 0.03 * Math.sin(t * 5 + k)); m4.trs(_m2, w[0], w[1] + 0.02, w[2], k * 1.9 + 0.6, 0, 0, tsc, tsc, tsc); R.draw(gm.trap, _m2, null, 1);
    }
    for (k = 0; k < race.proj.length; k++) {
      var pj = race.proj[k]; wposUD(pj.u, pj.d, w);
      if (pj.kd === 'gren') {
        m4.trs(_m2, w[0], w[1] + Math.max(0.4, pj.h), w[2], t * 9, t * 14, 0, 1, 1, 1); R.draw(gm.grenade, _m2, null, 1);
        if (particles.length < MAXP - 3) emitP(w[0], w[1] + pj.h + 0.5, w[2], rnd2(), rnd2() + 1, rnd2(), 0.35, 0.3, 1, 0.6 + Math.random() * 0.3, 0.15, 0.9, 0);
        continue;
      }
      if (pj.kd === 'mega') {
        var msc = 1 + Math.sin(t * 20) * 0.03;
        m4.trs(_m2, w[0], w[1] + 2.3, w[2], G.T.q(G.T.uToS(pj.u)).yaw + (pj.dir < 0 ? Math.PI : 0), -t * 6 * (pj.dir || 1), 0, msc, msc, msc); R.draw(gm.megaball, _m2, null, 1);
        G.halos.push(w[0], w[1] + 2.3, w[2], 8, 0.7, 0.9, 1, 0.35);
        if (particles.length < MAXP - 6) { for (var mq = 0; mq < 3; mq++) emitP(w[0] + rnd2() * 1.5, w[1] + 1 + Math.random() * 2.5, w[2] + rnd2() * 1.5, rnd2() * 2, Math.random() * 2, rnd2() * 2, 0.6, 0.7, 0.9, 0.97, 1, 0.8, 1); }
        continue;
      }
      if (pj.kd === 'msl') {
        var qy = G.T.q(G.T.uToS(pj.u)).yaw + (pj.dir < 0 ? Math.PI : 0), mdr = pj.dir < 0 ? -1 : 1;
        m4.trs(_m2, w[0], w[1] + 1.6, w[2], qy, 0, t * 6, 1.25, 1.25, 1.25); R.draw(gm.missile, _m2, null, 1);
        G.halos.push(w[0], w[1] + 1.6, w[2], 5.5, 1, 0.6, 0.2, 0.4);
        if (particles.length < MAXP - 6) { for (var mq2 = 0; mq2 < 3; mq2++) emitP(w[0] - Math.sin(qy) * 2.2 + rnd2() * 0.4, w[1] + 1.6 + rnd2() * 0.4, w[2] - Math.cos(qy) * 2.2 + rnd2() * 0.4, rnd2() * 2, rnd2() * 2, rnd2() * 2, 0.7, 0.7, 1, 0.65, 0.2, 0.85, 1); }
        continue;
      }
      var psz = pj.lt ? 0.55 : 1;
      m4.trs(_m2, w[0], w[1] + 0.9, w[2], 0, t * 12, 0, psz, psz, psz); R.draw(gm.snowball, _m2, pj.lt ? [0.7, 0.95, 1.0] : null, 1);
      if (particles.length < MAXP - 3) emitP(w[0], w[1] + 0.9, w[2], rnd2(), rnd2(), rnd2(), 0.35, pj.lt ? 0.22 : 0.3, pj.lt ? 0.6 : 1, 1, 1, 0.7, 0);
    }
    // objetos destruidos que salen volando (focas, etc.)
    var fl = G.flyers;
    for (k = fl.length - 1; k >= 0; k--) {
      var f = fl[k]; f.life -= dt; if (f.life <= 0) { fl.splice(k, 1); continue; }
      f.vy -= 22 * dt; f.x += f.vx * dt; f.y += f.vy * dt; f.z += f.vz * dt; f.a += f.va * dt; f.b += f.vb * dt;
      var fm = f.type === 'rock' ? gm.rock[0] : gm[f.type]; if (!fm) continue;
      var fs = f.sc * clamp(f.life * 2, 0.01, 1);
      m4.trs(_m2, f.x, f.y, f.z, f.a, f.b, 0, fs, fs, fs); R.draw(fm, _m2, null, 1);
      if (particles.length < MAXP - 2 && Math.random() < 0.5) emitP(f.x, f.y, f.z, rnd2(), rnd2(), rnd2(), 0.4, 0.3, 1, 1, 1, 0.7, 0);
    }
    // ventiscas
    for (k = 0; k < race.tornados.length; k++) {
      var tn = race.tornados[k]; wposUD(tn.u + tn.t * 26, tn.d, w);
      var sc = 0.6 + tn.t * 0.6, al = clamp(1 - tn.t / tn.life, 0, 1) * 0.55;
      m4.trs(_m2, w[0], w[1], w[2], tn.t * 9, 0, 0, sc, sc, sc); R.draw(gm.tornado, _m2, null, al);
    }
    drawSpectators(now, t);
    G.dtLast = dt; drawAvalanche(now, t);
    // pinguinos (lejanos primero no importa: sin transparencia)
    if (G.camMode !== 'preview') for (i = 0; i < race.racers.length; i++) drawRacer(race.racers[i], now, t);
    // partes translucidas de las esferas (cascaron, luz en el suelo)
    for (i = 0; i < orbs.length; i += 7) {
      var isA = orbs[i] === 1, ox2 = orbs[i + 1], oy2 = orbs[i + 2], oz2 = orbs[i + 3], oa = orbs[i + 4], og = orbs[i + 5], ot = orbs[i + 6];
      m4.trs(_m2, ox2, og, oz2, ot * 0.6, 0, 0, oa, oa, oa); R.draw(isA ? gm.glowA : gm.glowI, _m2, null, 0.17 + Math.sin(ot * 3) * 0.04);
      m4.trs(_m2, ox2, oy2, oz2, 0, 0, 0, oa, oa, oa); R.draw(isA ? gm.orbShellA : gm.orbShellI, _m2, null, 0.26 + Math.sin(ot * 4) * 0.05);
    }
    if (G.twater) drawLagoon(t, camS);
  }

  var FISH_TINT = [[1, 1, 1], [0.55, 0.85, 1.2], [1.2, 0.7, 0.9]];
  function drawLagoon(t, camS) {
    var T = G.T, R = G.R, i;
    if (G.tfish) for (i = 0; i < T.fish.length; i++) {
      var f = T.fish[i], ds = T.dS(camS, f.s); if (ds < -60 || ds > 260) continue;
      var ph = t * 0.45 * f.sp + f.ph, s = f.s + 14 * Math.sin(ph), q = T.q(s, 0), dd = f.d + 7 * Math.sin(t * 0.3 * f.sp + f.ph * 2);
      var dir = Math.cos(ph) >= 0 ? 1 : -1, yw = Math.atan2(q.tx * dir, q.tz * dir) + Math.sin(t * 5 * f.sp + f.ph) * 0.12;
      m4.trs(_m2, q.x + q.rx * dd, q.y + f.y + Math.sin(t * 1.3 + f.ph) * 0.6, q.z + q.rz * dd, yw, 0, 0, f.sc, f.sc, f.sc);
      R.draw(G.tfish, _m2, FISH_TINT[f.t], 1);
    }
    // v2.8: desde fuera el agua se ve azul y bien marcada; una vez dentro se vuelve transparente
    var Lk = T.lake, kIn = Lk ? Math.max(0, Math.min(1, (camS - (Lk.s0 - 4)) / 22)) * Math.max(0, Math.min(1, (Lk.s1 + 4 - camS) / 22)) : 0;
    R.draw(G.twater, null, [0.94 + Math.sin(t * 1.3) * 0.05, 1, 1.02 + Math.sin(t * 1.7 + 1) * 0.05], 0.62 - 0.38 * kIn);
  }

  function drawParticles(dt) {
    var R = G.R, arr = R.partArr, n = 0, i;
    for (i = particles.length - 1; i >= 0; i--) {
      var p = particles[i]; p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.vy -= p.gr * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    }
    for (i = 0; i < particles.length && n < R.partCap; i++) {
      var q = particles[i], o = n * 8, f = q.life / q.max;
      arr[o] = q.x; arr[o + 1] = q.y; arr[o + 2] = q.z; arr[o + 3] = q.size * (0.6 + 0.6 * f);
      arr[o + 4] = q.r; arr[o + 5] = q.g; arr[o + 6] = q.b; arr[o + 7] = q.a * Math.min(1, f * 1.8);
      n++;
    }
    var hl = G.halos;
    for (i = 0; i + 7 < hl.length && n < R.partCap; i += 8) {
      var o2 = n * 8; arr[o2] = hl[i]; arr[o2 + 1] = hl[i + 1]; arr[o2 + 2] = hl[i + 2]; arr[o2 + 3] = hl[i + 3];
      arr[o2 + 4] = hl[i + 4]; arr[o2 + 5] = hl[i + 5]; arr[o2 + 6] = hl[i + 6]; arr[o2 + 7] = hl[i + 7]; n++;
    }
    var vh = G.volcHalo;
    if (vh) for (i = 0; i + 7 < vh.length && n < R.partCap; i += 8) { var o3 = n * 8; for (var kk = 0; kk < 8; kk++) arr[o3 + kk] = vh[i + kk]; n++; }
    R.drawParticles(arr, n);
  }

  function updateVolcano(dt, now) {
    var T = G.T, V = T && T.volcano; G.volcHalo = null;
    if (!V || G.paused) return;
    var cx = cam.eye[0] - V.x, cz = cam.eye[2] - V.z;
    if (cx * cx + cz * cz > 900 * 900) return;
    var top = V.y + V.H - 7, t = now / 1000, pul = 1 + Math.sin(t * 2.1) * 0.12;
    G.volcHalo = [V.x, top - 8, V.z, 70 * pul, 1.0, 0.45, 0.1, 0.5, V.x, top + 20, V.z, 140 * pul, 1.0, 0.3, 0.08, 0.22];
    var hg = T.hallGlow; // v2.7: camara interior del volcan: halos de lava, brasas y humo del volcan interior
    if (hg && cx * cx + cz * cz < 150 * 150) {
      G.volcHalo.push(hg.x, hg.y - 4, hg.z, 46 * pul, 1.0, 0.45, 0.1, 0.55, hg.x, hg.y + 12, hg.z, 90 * pul, 1.0, 0.32, 0.08, 0.25, hg.x2, hg.y2 + 6, hg.z2, 60 * pul, 1.0, 0.5, 0.15, 0.4);
      G.hallAcc = (G.hallAcc || 0) + dt;
      while (G.hallAcc > 0.12) {
        G.hallAcc -= 0.12;
        emitP(hg.x + rnd2() * 5, hg.y, hg.z + rnd2() * 5, rnd2() * 3, 7 + Math.random() * 6, rnd2() * 3, 4.5, 9 + Math.random() * 6, 0.22, 0.18, 0.18, 0.5, -0.3);
        emitP(cam.eye[0] + rnd2() * 28, cam.eye[1] - 3 + Math.random() * 14, cam.eye[2] + rnd2() * 28, rnd2() * 1.2, 2 + Math.random() * 3, rnd2() * 1.2, 3.5, 0.45, 1, 0.55, 0.15, 0.9, -0.6);
      }
    }
    G.volcAcc = (G.volcAcc || 0) + dt;
    while (G.volcAcc > 0.1) {
      G.volcAcc -= 0.1;
      var a = Math.random() * 6.283, rr = Math.random() * V.R * 0.1;
      emitP(V.x + Math.cos(a) * rr, top, V.z + Math.sin(a) * rr, Math.cos(a) * 3, 16 + Math.random() * 10, Math.sin(a) * 3 + 2, 7, 26 + Math.random() * 16, 0.2, 0.15, 0.14, 0.55, -0.4);
      if (Math.random() < 0.7) emitP(V.x + rnd2() * 10, top, V.z + rnd2() * 10, rnd2() * 14, 40 + Math.random() * 30, rnd2() * 14, 3.5, 2.2, 1, 0.5, 0.12, 1, 14);
    }
  }

  var tagVec = [0, 0, 0];
  function updateTags() {
    var R = G.R, race = G.race, me = G.me, vp = R.vp, W = window.innerWidth, H = window.innerHeight;
    race.racers.forEach(function (r) {
      var el = G.tagEls && G.tagEls[r.id]; if (!el) return;
      var w = wpos(r, tagVec), x = w[0], y = w[1] + 2.4, z = w[2];
      var cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12], cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13], cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15];
      var fcs = G.camFocus || me, d = fcs ? Math.abs(r.u - fcs.u) : 0;
      if (cw <= 1 || d > 90 || r.fell || r.dead) { el.style.display = 'none'; return; }
      el.style.display = 'block'; el.style.left = ((cx / cw * 0.5 + 0.5) * W).toFixed(0) + 'px'; el.style.top = ((1 - (cy / cw * 0.5 + 0.5)) * H).toFixed(0) + 'px';
      el.style.opacity = clamp(1.4 - d / 90, 0.3, 1);
    });
  }

  // pinguino de pie (el modelo de los espectadores, con aletas animables) para "Mi pingüino" y "Mi progreso"
  function drawStandingPenguin(cfg, x, y, z, yaw, sc, t) {
    var R = G.R, key = JSON.stringify(cfg), k;
    if (!G.standCache || G.standCache.key !== key) G.standCache = { key: key, model: PG.spectatorModel(PG.fixCfg(cfg)) }; // se reconstruye solo si cambia el diseño
    var model = G.standCache.model;
    for (k = 0; k < model.parts.length; k++) if (!model.parts[k].gl) model.parts[k].gl = R.upload(model.parts[k].mesh);
    m4.trs(_m1, x, y, z, yaw, PG.STAND_TILT, 0, sc, sc, sc);
    // pose normal de pie: aletas caídas a los costados con un leve vaivén (al respirar); en Mi progreso a veces saluda con la aleta derecha
    var sw = -(1.22 + Math.sin(t * 1.6) * 0.035), waving = (G.screen === 'scrStats' && Math.sin(t * 0.9) > 0.8), wave = waving ? 1.55 + Math.sin(t * 12) * 0.35 : sw;
    for (k = 0; k < model.parts.length; k++) {
      var pt = model.parts[k], M = _m1;
      if (pt.kind === 'flipR') { m4.trs(_m2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, wave, 1, 1, 1); M = m4.mul(_m3, _m1, _m2); }
      else if (pt.kind === 'flipL') { m4.trs(_m2, pt.pivot[0], pt.pivot[1], pt.pivot[2], 0, 0, -sw, 1, 1, 1); M = m4.mul(_m3, _m1, _m2); }
      R.draw(pt.gl, M, null, 1);
    }
  }
  function renderPreview(now) {
    var t = now / 1000, p = preview.pos; if (!p) return;
    var yaw = preview.manual ? preview.yawBase + Math.PI + preview.rot : preview.yawBase + Math.PI + 0.5 + Math.sin(t * 0.7) * 0.9;
    if (!preview.manual) preview.rot = 0.5 + Math.sin(t * 0.7) * 0.9;
    if (G.dbgStandYaw !== undefined) yaw = G.dbgStandYaw;
    var bob = Math.sin(t * 1.6) * 0.012, gnd = p[1] - 0.9; // gnd = suelo de la pista (la camara apunta 0.9 m por encima)
    if (G.dbgFlip || G.dbgCannon || G.dbgYaw !== undefined) { // depuracion: pose de deslizamiento
      drawPenguinAt(G.cfg, p[0], p[1] + Math.sin(t * 2) * 0.05 + (G.dbgFlip ? 1.2 : 0), p[2], G.dbgYaw !== undefined ? G.dbgYaw : yaw, 0.06 + (G.dbgFlip || 0), 0, 1.9, t, { speed: 0.6, steer: Math.sin(t) * 0.4, wings: false, extra: G.dbgCannon ? gm.cannon : null, pv: G.dbgFlip ? 0.32 : 0 });
    } else drawStandingPenguin(G.cfg, p[0], gnd + 0.03 + bob, p[2], yaw, G.screen === 'scrStats' ? 1.9 : 2.0, t);
    m4.trs(_m2, p[0], gnd + 0.06, p[2], 0, 0, 0, 1.3, 1, 1.3); G.R.draw(gm.shadow, _m2, null, 0.4);
  }

  /* ---------------- clima: ventiscas ocasionales ---------------- */
  var wx = G.wx = { k: 0, on: false, t: 0, next: 18, dur: 0, dir: 0 };
  function resetWeather() { wx.k = 0; wx.on = false; wx.t = 0; wx.next = (G.T && G.T.themeName === 'storm') ? 6 : 14 + Math.random() * 12; }
  function updateWeather(dt, now) {
    var storm = G.T.themeName === 'storm', racing = G.mode === 'race' && !G.paused && G.race && G.race.time > 0;
    if (racing) {
      wx.t += dt;
      if (!wx.on) {
        if (wx.t > wx.next) { wx.on = true; wx.t = 0; wx.dur = 8 + Math.random() * 6; wx.dir = Math.random() * 6.283; }
      } else if (wx.t > wx.dur) { wx.on = false; wx.t = 0; wx.next = storm ? 9 + Math.random() * 9 : 24 + Math.random() * 26; }
    } else if (G.mode !== 'race') { wx.on = false; }
    var tgt = (G.mode === 'race' || G.camMode === 'race') ? Math.max(storm ? 0.3 : 0, wx.on ? 1 : 0) : 0;
    wx.k += (tgt - wx.k) * Math.min(1, dt * (tgt > wx.k ? 0.8 : 0.5));
    if (wx.k < 0.002) wx.k = 0;
    wx.gust = wx.k * (0.85 + 0.15 * Math.sin(now * 0.0017) * Math.sin(now * 0.0041));
    // sombra de la avalancha: el cielo se vuelve gris-azulado y la luz baja cuando se acerca (aunque venga por detras)
    var avSh = 0;
    if (G.mode === 'race' && G.race && G.race.av && G.race.avPhase(G.race.time) === 2) {
      var cfA = G.camFocus || G.me;
      if (cfA) { var dA = cfA.u - G.race.avFront(G.race.time); avSh = clamp(1 - dA / 300, 0, 1); avSh = avSh * avSh * (3 - 2 * avSh); }
    }
    G.avShade = (G.avShade || 0) + (avSh - (G.avShade || 0)) * Math.min(1, dt * 4);
    G.R.stormK = Math.max(wx.gust, G.avShade * 0.9);
    var fx = $('stormFx'); if (fx) fx.style.opacity = (wx.gust * 0.42).toFixed(3);
    Audio.storm(G.paused ? 0 : Math.max(wx.gust, G.avK || 0), now / 1000);
  }

  /* ---------------- sensacion de velocidad: lineas radiales y vineta ---------------- */
  var sfx = { cv: null, ctx: null, w: 0, h: 0 };
  function drawSpeedFx(dt, now) {
    var cv = sfx.cv || (sfx.cv = $('speedFx')); if (!cv) return;
    var W = window.innerWidth, H = window.innerHeight;
    if (sfx.w !== W || sfx.h !== H) { cv.width = Math.max(64, W >> 1); cv.height = Math.max(64, H >> 1); sfx.w = W; sfx.h = H; sfx.ctx = cv.getContext('2d'); }
    var x = sfx.ctx, w = cv.width, h = cv.height, me = G.me;
    x.clearRect(0, 0, w, h);
    if (!me || G.mode !== 'race' || G.paused) { $('vignette').style.opacity = 0; sfx.bk = 0; if (sfx.bkOn) { sfx.bkOn = false; $('blurFx').style.display = 'none'; } return; }
    // v3.2: vision borrosa en los bordes a velocidades muy altas; baja al frenar (es solo visual: no toca los controles)
    var bkT = clamp((me.speed * 3.6 - 125) / 65, 0, 1) * (G.set.blurFx === false ? 0 : 1); sfx.bk = (sfx.bk || 0) + (bkT - (sfx.bk || 0)) * Math.min(1, dt * (bkT > sfx.bk ? 2.2 : 3.2));
    var bkOn = sfx.bk > 0.02; if (bkOn !== sfx.bkOn) { sfx.bkOn = bkOn; $('blurFx').style.display = bkOn ? 'block' : 'none'; }
    if (bkOn) $('blurFx').style.opacity = sfx.bk.toFixed(2);
    var kmh = me.speed * 3.6, boost = (me.fx.boost > 0 || me.fx.pad > 0) ? 0.4 : 0, down = clamp(-(G.T.q(G.T.uToS(me.u), me.br).sl) * 2.2, 0, 0.5);
    var cvk = G.caveK || 0, k = clamp((kmh - 85) / 90 + boost + down + cvk * clamp((kmh - 30) / 70, 0, 0.55), 0, 1.25);
    $('vignette').style.opacity = clamp(k * 0.75, 0, 0.9).toFixed(2);
    if (k < 0.03) return;
    var cx = w * 0.5, cy = h * 0.46, diag = Math.sqrt(w * w + h * h) * 0.5, n = Math.floor(10 + 34 * k), i;
    x.lineCap = 'round';
    for (i = 0; i < n; i++) {
      var a = Math.random() * 6.2832, r0 = diag * (0.32 + Math.random() * 0.4), len = diag * (0.08 + Math.random() * 0.22) * (0.5 + k * 0.7);
      var al = (0.10 + Math.random() * 0.32) * Math.min(1, k * 1.3);
      x.strokeStyle = 'rgba(' + (boost ? '255,235,190' : '235,248,255') + ',' + al.toFixed(2) + ')';
      x.lineWidth = 1 + Math.random() * 2.2;
      x.beginPath(); x.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); x.lineTo(cx + Math.cos(a) * (r0 + len), cy + Math.sin(a) * (r0 + len)); x.stroke();
    }
    // v3.4: haces de fibras curvas de viento (como estelas de aire con chispas), mas visibles dentro de las cuevas
    if (G.set.quality !== 0) {
      var nb = Math.floor(3 + 7 * k * (1 + cvk * 0.6)), bi, fi, tone = boost ? '255,226,170' : '215,240,255';
      x.lineWidth = 1;
      for (bi = 0; bi < nb; bi++) {
        var ba = Math.random() * 6.2832, br0 = diag * (0.30 + Math.random() * 0.34), bl = diag * (0.22 + Math.random() * 0.34) * (0.6 + k * 0.6), sw = (Math.random() - 0.5) * 0.9, fl = 4 + ((Math.random() * 4) | 0);
        for (fi = 0; fi < fl; fi++) {
          var off = (fi - fl / 2) * (1.6 + Math.random() * 1.4), aa = ba + off * 0.004, ra = br0 + Math.random() * 10;
          var sx0 = cx + Math.cos(aa) * ra, sy0 = cy + Math.sin(aa) * ra, ex = cx + Math.cos(aa + sw * 0.18) * (ra + bl), ey = cy + Math.sin(aa + sw * 0.18) * (ra + bl);
          var mx = (sx0 + ex) / 2 + Math.cos(aa + 1.5708) * sw * bl * 0.35 + off, my = (sy0 + ey) / 2 + Math.sin(aa + 1.5708) * sw * bl * 0.35;
          x.strokeStyle = 'rgba(' + tone + ',' + ((0.18 + Math.random() * 0.4) * Math.min(1, k * 1.2)).toFixed(2) + ')';
          x.beginPath(); x.moveTo(sx0, sy0); x.quadraticCurveTo(mx, my, ex, ey); x.stroke();
        }
        if (Math.random() < 0.7) { x.fillStyle = 'rgba(' + tone + ',0.8)'; x.fillRect(cx + Math.cos(ba) * (br0 + bl * Math.random()), cy + Math.sin(ba) * (br0 + bl * Math.random()), 1.6, 1.6); }
      }
    }
  }

  /* ---------------- resolucion adaptativa ---------------- */
  var perf = { ema: 16.7, n: 0, lastDown: 0, lastUp: 0, last: 0 };
  function perfTick(now) {
    var d = now - perf.last; perf.last = now;
    if (d <= 0 || d > 200) return;
    perf.n++; if (perf.n < 40) return;
    perf.ema += (d - perf.ema) * 0.06;
    var R = G.R;
    if (perf.ema > 26 && R.dyn > 0.5 && now - perf.lastDown > 1500) {
      R.dyn = Math.max(0.5, R.dyn * 0.87); perf.lastDown = now; perf.ema = 20; R.resize(G.set.quality);
    } else if (perf.ema < 17.6 && R.dyn < 1 && now - perf.lastDown > 20000 && now - perf.lastUp > 6000) {
      R.dyn = Math.min(1, R.dyn * 1.07); perf.lastUp = now; R.resize(G.set.quality);
    }
  }

  /* ---------------- bucle principal ---------------- */
  G.orbs = []; G.halos = [];
  G.last = 0; G.frames = 0; var acc = 0;
  // v2.7: voz por proximidad: solo dentro de la carrera, el volumen de cada jugador baja con la distancia en pista (en la sala de espera suena todo normal)
  function updateProxVoice() {
    var V = PG.Voice;
    if (!V || (!V.on && !V.proxOn)) return;
    var ref = G.camFocus || G.me;
    if (G.mode !== 'race' || !G.mp || !G.race || !ref) { V.resetProx(); return; }
    var T = G.T, L = T.type === 'circuit' ? T.L * 1 : 0, rs = G.race.racers, i, r, du, dd, k, dist;
    for (i = 0; i < rs.length; i++) {
      r = rs[i]; if (r === G.me || !V.peers[r.id]) continue;
      du = r.u - ref.u; if (L) du = ((du + L / 2) % L + L) % L - L / 2;
      dd = (r.d - ref.d) * 1.0; dist = Math.sqrt(du * du + dd * dd);
      k = dist < 14 ? 1 : Math.max(0, 1 - (dist - 14) / 230); k = k * k;
      V.setProx(r.id, k);
    }
  }
  G.updateProxVoice = updateProxVoice;
  function frame(now) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.05, (now - (G.last || now)) / 1000); G.last = now;
    if (!G.R || !G.T) return;
    G.frames++;
    if (G.frames % 6 === 0) updateProxVoice();
    if (G.frames % 20 === 1) G.R.resize(G.set.quality);
    perfTick(now);
    var race = G.race;
    if (race && !G.paused) {
      var input = G.mode === 'race' ? readInput() : null;
      race.time = (now - G.goAt) / 1000; race.nowMs = now;
      acc += dt;
      var steps = 0;
      while (acc >= 1 / 60 && steps < 5) {
        race.update(1 / 60, input);
        if (input) { input.useItem = false; input.useAbility = false; input.push = false; }
        acc -= 1 / 60; steps++;
        for (var q = 0; q < race.fxq.length; q++) handleFx(race.fxq[q]);
        race.fxq.length = 0;
      }
      if (acc > 0.1) acc = 0;
      if (G.mp && G.mode === 'race') netTick(dt, now);
      else race.out.length = 0;
      if (G.mode === 'demo' || G.demo) { // reiniciar demo cuando todos terminan
        if (race.racers.every(function (r) { return r.finished; })) { G.race = null; ensureDemoRestart(); }
      }
    }
    race = G.race;
    if (!race) { return; }
    updateCamera(dt, now);
    var th = G.T.theme;
    updateWeather(dt, now);
    updateVolcano(dt, now);
    var fo = G.me || (race.order && race.order[0]) || race.racers[0];
    var inCv = fo && G.T.inCave && (fo.br ? G.T.inCave(G.T.uToS(fo.u), -3, fo.br) : G.T.inCave(G.T.uToS(fo.u), -3)) ? 1 : (fo && !fo.br && G.T.inHall && G.T.inHall(G.T.uToS(fo.u), -3) ? 0.7 : 0);
    if (G.camMode === 'preview') inCv = 0; // v3.1: en Mi pingüino / Mi progreso la camara esta fija en la salida: la luz de cueva del corredor del fondo oscurecia toda la pantalla
    G.caveK = (G.caveK || 0) + (inCv - (G.caveK || 0)) * Math.min(1, dt * 3.5);
    G.R.caveK = G.caveK; G.R.caveTint = G.T.volcano ? 1 : 0; // volcan: dentro de la montana la luz y la niebla son rojizas
    var inUw = 0;
    if (fo && G.T.uwF) { var sUw = G.T.uToS(fo.u); if (G.T.uwF(sUw) > 0 && cam.eye[1] < G.T.centerY(sUw, 0) + G.T.uwH) inUw = 1; }
    G.uwK = (G.uwK || 0) + (inUw - (G.uwK || 0)) * Math.min(1, dt * 5);
    G.R.uwK = G.uwK;
    if (G.uwK > 0.35 && particles.length < MAXP - 6 && !G.paused) { var uwR = Math.random(); if (uwR < dt * 14) emitP(cam.eye[0] + rnd2() * 14, cam.eye[1] - 2 + rnd2() * 4, cam.eye[2] + rnd2() * 14, rnd2() * 0.4, 2.5 + Math.random() * 2, rnd2() * 0.4, 3, 0.35 + Math.random() * 0.4, 0.8, 0.95, 1, 0.55, -0.3); }
    G.R.begin(th, cam, now / 1000);
    drawWorld(now, dt);
    var avo = $('avFx'); if (avo) { var av2 = G.mode === 'race' ? Math.max(0, (G.avK || 0) - 0.15) : 0; if (G.lastAvO !== av2) { G.lastAvO = av2; avo.style.opacity = av2.toFixed(2); } }
    if (G.camMode === 'preview') renderPreview(now);
    drawParticles(dt);
    var wk = wx.gust, wsp = G.T.themeName === 'storm' ? 14 : 2;
    G.R.drawSnow(now / 1000, (th.flakes + wk * 2.4) * (1 - 0.9 * (G.caveK || 0)), [wsp + wk * 24 * Math.cos(wx.dir), 3.2 + wk * 5, 1 + wk * 24 * Math.sin(wx.dir)]);
    G.R.finish();
    if (G.mode === 'race' && G.me) {
      updateHud(now); updateTags(); if (G.frames % 3 === 0) drawMini();
      if (G.paused) Audio.slide(0, false); else Audio.slide(clamp(G.me.speed / 40, 0, 1.3), G.me.grounded && !G.me.fell);
      updateFireBtn(); drawSpeedFx(dt, now); checkLastPlace();
      if (G.me.dnf && !G.finishShown) onLocalLost();
      if (G.champ && !G.mp && !G.race.ended && (G.me.finished || G.me.dead)) G.race.endRace(); // v3.2: campeonato en solitario: sin esperar al ultimo; el resto se ordena por posicion
      if (G.me.dead && !G.resultsAt && G.screen !== 'scrResults' && G.race.racers.every(function (r) { return r.finished; })) G.resultsAt = now + 2500;
      if (G.resultsAt && now > G.resultsAt && !G.paused) { G.resultsAt = 0; showResults(); }
      if (G.screen === 'scrResults') refreshResults();
    } else { Audio.slide(0, false); if (sfx.ctx) sfx.ctx.clearRect(0, 0, sfx.cv.width, sfx.cv.height); }
  }
  function ensureDemoRestart() { G.demo = false; if (G.mode !== 'race') ensureDemo(); }

  /* ---------------- resultados ---------------- */
  function showResults() {
    spendEquip();
    G.screen = 'scrResults'; Audio.music(null); // v3.1: al terminar la carrera la musica se apaga (cada carrera arranca la suya)
    $('scrResults').classList.add('show');
    var host = !G.mp || G.myId === G.hostId;
    $('btnNext').textContent = G.mp ? 'Siguiente carrera' : 'Siguiente pista';
    // v2.9: en multijugador, al terminar todos hay una cuenta atras para volver a la sala; se puede marcar «listo» desde aqui o salir
    $('btnNext').style.display = G.mp ? 'none' : '';
    $('btnRepeat').style.display = G.mp ? 'none' : '';
    $('btnResReady').style.display = (G.mp && !host) ? '' : 'none';
    $('btnResLobby').style.display = (G.mp && host) ? '' : 'none';
    $('resWait').style.display = 'none';
    if (G.champ) { $('btnRepeat').style.display = 'none'; $('btnResReady').style.display = 'none'; $('btnResLobby').style.display = 'none'; $('btnNext').style.display = 'none'; }
    $('champStand').innerHTML = ''; G.lastChHtml = '';
    $('scrResults').classList.toggle('champ', !!G.champ);
    G.resCdAt = 0; G.resBackSent = false; G.resCdShort = false; $('resCd').textContent = '';
    refreshResults();
  }
  function refreshResults() {
    var race = G.race; if (!race) return;
    var arr = race.racers.slice().sort(function (a, b) { return a.rank - b.rank; });
    var html = '', allDone = true;
    arr.forEach(function (r, i) {
      if (!r.finished) allDone = false;
      var pm = G.mp && /^p(\d+)$/.exec(String(r.id)), rdyTag = pm && +pm[1] !== G.hostId && G.ready[+pm[1]] ? '<span class="rdy">✔ listo</span>' : '';
      html += '<div class="rrow' + (r === G.me ? ' me' : '') + '"><span class="pos">' + (i + 1) + '</span><span class="dot" style="background:' + bodyColor(r.cfg) + '"></span><span>' + esc(r.name) + rdyTag + '</span><span class="tm">' + (r.dead ? '❄ eliminado' : (r.dnf ? 'no llegó' : (r.finished ? fmtTime(r.finishTime) : 'en carrera…'))) + '</span></div>';
    });
    if (G.lastResHtml !== html) { G.lastResHtml = html; $('resList').innerHTML = html; }
    $('resTitle').textContent = allDone ? 'Resultados finales' : 'Resultados (en vivo)';
    if (G.champ) champResults(allDone); else if (G.mp) resCountdown(allDone);
    $('resMsg').textContent = G.resMsg || ''; $('resRec').textContent = G.resRec || '';
    var rc = G.resCoins, rch = '';
    if (rc) {
      var stH = ''; for (var si = 0; si < 5; si++) stH += '<i class="' + (si < rc.stars ? 'on' : '') + '" style="animation-delay:' + (0.25 + si * 0.28).toFixed(2) + 's">★</i>';
      rch = '<div class="rcBox"><div class="rcStars">' + stH + '</div><div class="rcCoins">🪙 <b id="coinNum">0</b></div></div>';
    }
    if (G.lastRc !== rch) { G.lastRc = rch; $('resCoins').innerHTML = rch; G.resAnimAt = performance.now(); }
    if (rc && $('coinNum')) { // el contador de monedas sube de 0 al total
      var kk = Math.min(1, (performance.now() - (G.resAnimAt || 0) - 500) / 1100); if (kk < 0) kk = 0;
      $('coinNum').textContent = '+' + Math.round(rc.coins * (1 - Math.pow(1 - kk, 3)));
    }
  }
  function resCountdown(allDone) {
    var now = performance.now(), host = G.myId === G.hostId, cd = $('resCd');
    var rb = $('btnResReady'); if (rb) { var im = !!G.ready[G.myId]; rb.textContent = im ? '✔ ¡Listo! (toca para cancelar)' : '👍 ¡Estoy listo!'; rb.classList.toggle('ready', im); }
    if (!allDone) { G.resCdAt = 0; cd.textContent = 'Esperando a que terminen los demás…'; return; }
    if (!G.resCdAt) G.resCdAt = now + 15000;
    var others = Object.keys(G.players).map(Number).filter(function (i) { return i !== G.hostId; });
    if (!G.resCdShort && others.length && allReady() === 0 && G.resCdAt - now > 3000) { G.resCdShort = true; G.resCdAt = now + 3000; } // todos listos: se adelanta
    var left = Math.max(0, Math.ceil((G.resCdAt - now) / 1000));
    cd.textContent = '⏱ Volviendo a la sala en ' + left + ' s';
    if (now >= G.resCdAt && !G.resBackSent && (host || now >= G.resCdAt + 5000)) { // si el anfitrion no avisa en 5 s, cada uno vuelve por su cuenta
      G.resBackSent = true;
      if (host) Net.send({ t: 'back' });
      onNetMsg({ t: 'back' });
    }
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------------- red: bucle y mensajes ---------------- */
  var netLast = 0;
  function netTick(dt, now) {
    var race = G.race;
    if (now - netLast >= 50) {
      netLast = now;
      for (var i = 0; i < race.racers.length; i++) {
        var r = race.racers[i]; if (!r.own || r.fell && false) continue;
        var x = 0, f = r.fx;
        if (f.boost > 0 || f.pad > 0) x |= 1; if (f.spin > 0) x |= 2; if (f.shield > 0) x |= 4; if (f.shield > 0 && r.shType === 1) x |= 8192; if (f.shield > 0 && r.shType === 2) x |= 16384; if (f.push > 0) x |= 512;
        if (f.wings > 0) x |= 16; if (r.fell) x |= 32; if (r.grounded) x |= 64; if (f.ghost > 0) x |= 128; if (f.cannon > 0) x |= 256; if (f.cannon > 0 && r.gun === 'gren') x |= 1024; if (f.superjump > 0) x |= 2048;
        Net.send({ t: 's', r: r.id, b: r.br | 0, u: +r.u.toFixed(2), d: +r.d.toFixed(2), p: +r.psi.toFixed(3), v: +r.vf.toFixed(1), l: +r.vl.toFixed(1), y: +r.py.toFixed(2), x: x, n: r.lap, st: +r.steerVis.toFixed(2), fm: r.flipping ? r.flipMode * r.flipDir : 0, fl: +r.flipAcc.toFixed(2) });
      }
    }
    if (race.out.length) { Net.send({ t: 'e', ev: race.out.slice() }); race.out.length = 0; }
  }
  G.players = {}; G.ready = {};
  G.pid = store.get('pgp_pid', null) || (function () { var v = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); store.set('pgp_pid', v); return v; })();
  G.lobby = { track: 0, bots: true, diff: 1 };

  /* ==================== v3.1: CAMPEONATO (5 carreras, puntos, apuestas con bote) ==================== */
  var CH_PTS = [10, 7, 5, 3, 2, 1], CH_STAKES = [50, 100, 250, 500, 1000, 2500, 5000], CH_SHARE = { 1: [1], 2: [0.65, 0.35], 3: [0.55, 0.30, 0.15] };
  G.champSet = { on: false, n: 5, bets: false, stake: 100, pick: [] }; G.champSolo = 0; G.champ = null; G.champPick = [];
  function chN() { return G.champ ? G.champ.n : 5; }
  // v3.2: pistas elegidas por el anfitrion (en orden) y, las que falten, al azar sin repetir
  function chTracks(seed, n, pick) {
    var rnd = PG.rng(seed ^ 0x7c3), ids = [], i, out = [];
    (pick || []).forEach(function (t) { if (out.length < n && t >= 0 && t < PG.TRACKS.length && out.indexOf(t) < 0) out.push(t); });
    for (i = 0; i < PG.TRACKS.length; i++) if (out.indexOf(i) < 0) ids.push(i);
    for (i = ids.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
    return out.concat(ids).slice(0, n);
  }
  function chMeta(idx) { var c = G.champ; return { seed: c.seed, n: c.n, tracks: c.tracks, idx: idx, bets: c.bets ? 1 : 0, stake: c.stake, h0: c.h0, nb: c.nb, mp: c.mp ? 1 : 0 }; }
  function chMyRid() { return G.mp ? 'p' + G.myId : 'psolo'; }
  function champOnStart(m) {
    var cm = m.champ;
    if (!G.champ || G.champ.seed !== cm.seed) {
      flushChampEquip();
      var cn1 = cm.n === 3 ? 3 : (cm.n === 1 ? 1 : 5); // v3.3: n=1 = carrera rapida con apuesta
      G.champ = { seed: cm.seed, n: cn1, tracks: cm.tracks.slice(0, cn1), idx: cm.idx | 0, bets: !!cm.bets, stake: cm.stake | 0, h0: cm.h0 | 0, nb: cm.nb | 0, mp: !!cm.mp, rows: {}, rc: {}, rec: {}, paid: false, prize: 0 };
      if (G.champ.bets && G.champ.stake > 0) PG.Eco.bet(G.champ.stake); // la apuesta se paga al empezar el campeonato
    }
    var c = G.champ; c.idx = cm.idx | 0;
    m.roster.forEach(function (e) { if (!c.rows[e.id]) c.rows[e.id] = { id: e.id, name: e.name, cfg: e.cfg, human: !e.bot, pts: 0, wins: 0, pod: 0, ranks: [], times: [], out: false }; });
  }
  function chPot() { var c = G.champ, p = c.bets ? c.stake * c.h0 : 0, k, id; if (c.bets) for (k in c.rc) for (id in c.rc[k]) p += c.rc[k][id]; return p; }
  // ordenados: mas puntos, luego mas victorias, luego mejor suma de puestos
  function chSorted(onlyHumans) {
    var c = G.champ, a = Object.keys(c.rows).map(function (k) { return c.rows[k]; });
    if (onlyHumans) a = a.filter(function (r) { return r.human && !r.out; });
    function rs(r) { var s = 0; for (var i = 0; i < chN(); i++) s += r.ranks[i] || 9; return s; }
    return a.sort(function (x, y) { return (y.pts - x.pts) || (y.wins - x.wins) || (rs(x) - rs(y)); });
  }
  function chPrizes() {
    var c = G.champ, out = {}; if (!c.bets) return out;
    var hs = chSorted(true), sh = CH_SHARE[Math.min(3, hs.length)] || [], pot = chPot();
    hs.forEach(function (r, i) { if (sh[i]) out[r.id] = Math.floor(pot * sh[i]); });
    return out;
  }
  function champRecord() {
    var c = G.champ, race = G.race; if (!c || !race || c.rec[c.idx]) return; c.rec[c.idx] = 1;
    var arr = race.racers.slice().sort(function (a, b) { return a.rank - b.rank; }), seen = {};
    arr.forEach(function (r, i) {
      var row = c.rows[r.id]; if (!row) return; seen[r.id] = 1;
      row.pts += CH_PTS[i] || 0; row.ranks[c.idx] = i + 1; row.times[c.idx] = (r.finished && !r.dnf && !r.dead && r.finishTime > 0) ? r.finishTime : 0;
      if (i === 0) row.wins++; if (i < 3) row.pod++;
    });
    Object.keys(c.rows).forEach(function (k) { if (!seen[k]) c.rows[k].ranks[c.idx] = 0; });
  }
  function champCoins(coins) { // con apuestas, las monedas ganadas en la carrera van al bote
    var c = G.champ; if (!c || !c.bets) return;
    (c.rc[c.idx] = c.rc[c.idx] || {})[chMyRid()] = coins | 0;
    if (c.mp) Net.send({ t: 'cc', i: c.idx, id: chMyRid(), c: coins | 0 });
  }
  function rewardFor(rank, total, rc) {
    var bank = !!(G.champ && G.champ.bets), rw = PG.Eco.finishReward(rank, total, rc, bank);
    if (bank) champCoins(rw.coins);
    return rw;
  }
  function medal(n) { return n === 1 ? '🥇' : (n === 2 ? '🥈' : (n === 3 ? '🥉' : (n > 0 ? String(n) : '–'))); }
  function champStandHtml(compact) {
    var c = G.champ, rows = chSorted(false), me = chMyRid(), h = '<table class="chT"><thead><tr><th>#</th><th>Jugador</th><th>Pts</th>';
    for (var i = 0; i < c.n; i++) h += '<th class="r' + (i === c.idx ? ' cur' : '') + '">' + (i + 1) + '</th>';
    h += '</tr></thead><tbody>';
    rows.forEach(function (r, k) {
      h += '<tr class="' + (r.id === me ? 'me' : '') + (r.out ? ' out' : '') + '"><td>' + (k + 1) + '</td><td><span class="dot" style="background:' + bodyColor(r.cfg) + '"></span>' + esc(r.name) + (r.out ? ' <i>(se retiró)</i>' : '') + '</td><td><b>' + r.pts + '</b></td>';
      for (var j = 0; j < c.n; j++) h += '<td class="r">' + (c.rec[j] ? medal(r.ranks[j]) : '') + '</td>';
      h += '</tr>';
    });
    h += '</tbody></table>';
    if (c.bets) h += '<p class="chPot">Bote: 🪙 <b>' + chPot() + '</b> · se reparte entre los 3 primeros jugadores</p>';
    return h;
  }
  // resultados de una carrera del campeonato: tabla, cuenta atras y paso a la siguiente
  function champResults(allDone) {
    var c = G.champ, now = performance.now(), host = !c.mp || G.myId === G.hostId, last = c.idx >= c.n - 1, cd = $('resCd');
    if (!allDone) { G.resCdAt = 0; cd.textContent = 'Esperando a que terminen los demás…'; return; }
    champRecord();
    var hh = champStandHtml(true); if (G.lastChHtml !== hh) { G.lastChHtml = hh; $('champStand').innerHTML = hh; }
    $('btnNext').textContent = last ? (c.n === 1 ? '💰 Ver premios' : '🏆 Ver el campeonato') : 'Siguiente carrera (' + (c.idx + 2) + '/' + c.n + ')';
    $('btnNext').style.display = (host || last) ? '' : 'none';
    $('resWait').style.display = (!host && !last) ? '' : 'none'; $('resWait').textContent = 'Esperando al anfitrión…';
    if (!G.resCdAt) G.resCdAt = now + (last ? 9000 : 14000);
    var left = Math.max(0, Math.ceil((G.resCdAt - now) / 1000));
    cd.textContent = last ? (c.n === 1 ? '💰 Premios en ' : '🏆 Resultados del campeonato en ') + left + ' s' : '⏱ Siguiente carrera (' + (c.idx + 2) + '/' + c.n + ') en ' + left + ' s';
    if (now >= G.resCdAt && !G.resBackSent && (host || last)) { G.resBackSent = true; champAdvance(); }
  }
  function champAdvance() {
    var c = G.champ; if (!c) return;
    if (c.idx >= c.n - 1) { showChampFinal(); return; }
    if (c.mp && G.myId !== G.hostId) return;
    var i = c.idx + 1, seed = (Math.random() * 1e9) | 0, humans;
    if (c.mp) humans = Object.keys(G.players).map(Number).sort(function (a, b) { return a - b; }).filter(function (id) { var r = c.rows['p' + id]; return r && !r.out; }).map(function (id) { return G.players[id]; });
    else humans = [{ id: 'solo', name: G.cfg.name, cfg: G.cfg }];
    var roster = makeRoster(humans, c.nb > 0, seed, c.seed, c.nb);
    var m = { t: 'start', track: c.tracks[i], seed: seed, startIn: c.mp ? 5000 : 4500, roster: roster, diff: c.mp ? G.lobby.diff : G.set.diff, ava: G.set.ava !== false, champ: chMeta(i) };
    $('scrResults').classList.remove('show'); G.lastChHtml = '';
    if (c.mp) { Net.send(m); G.mp = true; }
    beginRace(m, false);
  }
  function champStartFirst(humans, mp) { // anfitrion o jugador solo: crea el campeonato y lanza la carrera 1
    var seed = (Math.random() * 1e9) | 0, nb = G.lobby && mp ? (G.lobby.bots ? Math.max(0, 6 - humans.length) : 0) : 5, n = mp ? (G.champSet.on ? (G.champSet.n === 3 ? 3 : 5) : 1) : (G.champSolo === 3 ? 3 : 5);
    var meta = { seed: seed, n: n, tracks: chTracks(seed, n, n === 1 && mp ? [G.lobby.track] : G.champPick), idx: 0, bets: mp && G.champSet.bets ? 1 : 0, stake: mp && G.champSet.bets ? G.champSet.stake : 0, h0: humans.length, nb: nb, mp: mp ? 1 : 0 };
    var roster = makeRoster(humans, nb > 0, seed ^ 0x1234, seed, nb);
    var m = { t: 'start', track: meta.tracks[0], seed: (Math.random() * 1e9) | 0, startIn: mp ? 5000 : 4500, roster: roster, diff: mp ? G.lobby.diff : G.set.diff, ava: G.set.ava !== false, champ: meta };
    G.champ = null; G.lastChHtml = '';
    if (mp) { Net.send(m); G.mp = true; } else { G.mp = false; G.myId = 'solo'; }
    beginRace(m, false);
  }
  function showChampFinal() {
    var c = G.champ; if (!c) return;
    spendEquip(); flushChampEquip(); // fin del campeonato: ahora si se gastan los poderes usados
    champRecord();
    var rows = chSorted(false), pr = chPrizes(), me = chMyRid(), win = rows[0], myRow = c.rows[me], myPrize = pr[me] || 0;
    if (c.bets && !c.paid) { c.paid = true; c.prize = myPrize; if (myPrize > 0) PG.Eco.payout(myPrize); }
    Audio.sfx(myRow && rows[0] === myRow ? 'win' : 'finish');
    var h = '<div class="chWin"><span class="cup">🏆</span><b>' + esc(win.name) + '</b><small>' + win.pts + ' puntos · ' + win.wins + (win.wins === 1 ? ' victoria' : ' victorias') + '</small></div>';
    h += '<div class="chCards">';
    h += '<div class="chCard"><small>Tu puesto</small><b>' + (rows.indexOf(myRow) + 1 || '–') + '.º</b></div>';
    h += '<div class="chCard"><small>Tus puntos</small><b>' + (myRow ? myRow.pts : 0) + '</b></div>';
    h += '<div class="chCard"><small>Victorias</small><b>' + (myRow ? myRow.wins : 0) + '</b></div>';
    h += '<div class="chCard"><small>Podios</small><b>' + (myRow ? myRow.pod : 0) + '</b></div>';
    if (c.bets) { h += '<div class="chCard"><small>Bote</small><b>🪙 ' + chPot() + '</b></div>'; h += '<div class="chCard ' + (myPrize > 0 ? 'gold' : '') + '"><small>Tu premio</small><b>' + (myPrize > 0 ? '+🪙 ' + myPrize : '0') + '</b></div>'; }
    h += '</div>';
    // tabla completa con puesto de cada carrera, victorias, podios y premio
    h += '<table class="chT big"><thead><tr><th>#</th><th>Jugador</th><th>Pts</th>';
    for (var i = 0; i < c.n; i++) h += '<th class="r">C' + (i + 1) + '</th>';
    h += '<th class="r">🥇</th><th class="r">Podios</th>' + (c.bets ? '<th class="r">Premio</th>' : '') + '</tr></thead><tbody>';
    rows.forEach(function (r, k) {
      h += '<tr class="' + (r.id === me ? 'me' : '') + (r.out ? ' out' : '') + '"><td>' + (k + 1) + '</td><td><span class="dot" style="background:' + bodyColor(r.cfg) + '"></span>' + esc(r.name) + (r.out ? ' <i>(se retiró)</i>' : '') + '</td><td><b>' + r.pts + '</b></td>';
      for (var j = 0; j < c.n; j++) h += '<td class="r">' + medal(r.ranks[j]) + '</td>';
      h += '<td class="r">' + r.wins + '</td><td class="r">' + r.pod + '</td>' + (c.bets ? '<td class="r">' + (pr[r.id] ? '🪙 ' + pr[r.id] : '–') + '</td>' : '') + '</tr>';
    });
    h += '</tbody></table><h3 class="chH">Carreras</h3><div class="chTracks">';
    for (var t = 0; t < c.n; t++) {
      var wr = rows.slice().sort(function (a, b) { return (a.ranks[t] || 99) - (b.ranks[t] || 99); })[0], tm = wr && wr.times[t] ? ' · ' + fmtTime(wr.times[t]) : '';
      h += '<div class="chTr"><b>' + (t + 1) + '</b><span>' + esc(PG.TRACKS[c.tracks[t]].name) + '</span><em>' + (wr && wr.ranks[t] === 1 ? '🥇 ' + esc(wr.name) + tm : '–') + '</em></div>';
    }
    h += '</div>';
    if (c.bets) h += '<p class="note">Con apuestas: cada jugador puso 🪙 ' + c.stake + ' y las monedas ganadas en las carreras se sumaron al bote. Reparto entre jugadores: 1.º, 2.º y 3.º; del 4.º en adelante no se gana nada.</p>';
    $('chTitle').textContent = c.n === 1 ? 'Carrera con apuesta · resultados' : 'Campeonato · resultados'; $('chBody').innerHTML = h;
    $('btnChampDone').textContent = 'Volver a la sala'; $('btnChampDone').style.display = G.mp ? '' : 'none';
    $('scrResults').classList.remove('show'); G.nav = []; go('scrChamp'); G.nav = [];
  }
  function champAgain() { // v3.2: revancha: otro campeonato eligiendo mapas
    var wasMp = G.mp, n = G.champ ? G.champ.n : 5; G.champ = null; G.champPick = []; $('scrChamp').classList.remove('show');
    if (wasMp) { G.champSet.on = true; G.champSet.pick = []; onNetMsg({ t: 'back' }); return; }
    quitRace(true); G.trackMode = 'solo'; G.champSolo = n; G.selTrack = 0; go('scrTracks');
  }
  function champDone() {
    var wasMp = G.mp; G.champ = null; $('scrChamp').classList.remove('show');
    if (wasMp) { onNetMsg({ t: 'back' }); } else quitRace(true);
  }
  function renderChampBox(host) {
    var s = G.champSet;
    $('segModeLobby').innerHTML = [['r', 'Carrera'], ['m', 'Mini · 3'], ['c', 'Campeonato · 5']].map(function (o) { return '<button data-m="' + o[0] + '" class="' + ((o[0] === 'r' ? !s.on : (s.on && (o[0] === 'm') === (s.n === 3))) ? 'sel' : '') + '"' + (host ? '' : ' disabled') + '>' + o[1] + '</button>'; }).join('');
    $('champOpts').style.display = '';
    $('chkBets').checked = !!s.bets; $('chkBets').disabled = !host;
    $('stakeRow').style.display = s.bets ? '' : 'none';
    $('stakeRow').innerHTML = CH_STAKES.map(function (v) { return '<button data-st="' + v + '" class="' + (v === s.stake ? 'sel' : '') + '"' + (host ? '' : ' disabled') + '>🪙' + v + '</button>'; }).join('');
    $('champNote').textContent = !s.on ? (s.bets ? 'Carrera con apuesta: cada jugador pone 🪙' + s.stake + '. El bote (apuestas + monedas ganadas) lo reparten los 3 primeros.' : '') : s.on ? (s.bets ? 'Cada jugador apuesta 🪙' + s.stake + '. El bote (apuestas + monedas ganadas) lo reparten los 3 primeros; quien se vaya queda fuera.' : 'Sin apuestas: ' + s.n + ' carreras seguidas; gana quien sume más puntos.') + ' Mapas elegidos: ' + ((s.pick || []).length || 'al azar') + '.' : '';
  }
  function champSetChange() { G.ready = {}; if (G.myId === G.hostId) sendReady(); sendLobby(); renderLobby(); }
  function sendLobby() { Net.send({ t: 'lobby', track: G.lobby.track, bots: G.lobby.bots, diff: G.lobby.diff, champ: (G.champSet.on || G.champSet.bets) ? { b: G.champSet.bets ? 1 : 0, s: G.champSet.stake | 0, n: G.champSet.on ? (G.champSet.n === 3 ? 3 : 5) : 1, p: (G.champPick || []).slice(0, 5) } : 0 }); }

  function dropPlayer(id, silent) {
    Voice.peerLeft(id); delete G.players[id]; delete G.ready[id];
    if (!silent && G.myId === G.hostId) sendReady();
    if (G.mode === 'race' && G.race && !silent) { /* el resto lo gestiona 'leave' */ }
  }
  // el anfitrion reparte quien esta listo (los demas solo avisan al anfitrion)
  function sendReady() { Net.send({ t: 'rdy', ids: Object.keys(G.ready).map(Number).filter(function (i) { return G.players[i]; }) }); }
  function allReady() {
    var ids = Object.keys(G.players).map(Number), n = 0;
    for (var i = 0; i < ids.length; i++) if (ids[i] !== G.hostId && !G.ready[ids[i]]) n++;
    return n;
  }
  function onNetMsg(m) {
    var race = G.race;
    switch (m.t) {
      case 'welcome':
        G.myId = m.id; G.hostId = m.host; G.players = {}; G.ready = {}; G.players[m.id] = { id: m.id, name: G.cfg.name, cfg: G.cfg, pid: G.pid };
        Net.send({ t: 'hello', name: G.cfg.name, cfg: G.cfg, ver: VERSION, pid: G.pid });
        G.roomIp = m.ip || G.roomIp || ''; if (m.code) G.roomCode = m.code;
        G.chat = []; chatUnread = 0; lobbyTab = 'p';
        Voice.leave(true); Voice.init(function (o) { Net.send(o); }, m.id, onVoiceChange);
        go('scrLobby'); renderLobby();
        break;
      case 'hello':
        var pidIn = String(m.pid || '').slice(0, 30);
        // mismo dispositivo que ya estaba en la sala (salio y volvio a entrar): se quita la entrada vieja para no verlo dos veces
        if (pidIn) {
          if (pidIn === G.pid && m.f !== G.myId) break; // eco de mi propia sesion anterior
          Object.keys(G.players).forEach(function (oid) { if (+oid !== m.f && G.players[oid].pid === pidIn) dropPlayer(+oid, true); });
        }
        var isNew = !G.players[m.f];
        G.players[m.f] = { id: m.f, name: String(m.name || 'Jugador').slice(0, 12), cfg: PG.fixCfg(m.cfg), pid: pidIn };
        if (isNew) chatSys(G.players[m.f].name + ' entró a la sala');
        if (m.ver !== VERSION && !G.verWarned) { G.verWarned = true; toast('Otro jugador usa otra versión del juego (' + (m.ver || 'antigua') + '). Instalen la misma APK.', 4500); }
        if (G.myId === G.hostId) { sendLobby(); sendReady(); }
        renderLobby();
        break;
      case 'leave':
        if (G.champ && G.champ.rows['p' + m.id]) { G.champ.rows['p' + m.id].out = true; toast('Un jugador abandonó y queda fuera del campeonato', 3000); }
        if (G.players[m.id]) chatSys(G.players[m.id].name + ' salió');
        dropPlayer(m.id, false);
        if (G.mode === 'race' && race) { race.removeRacer('p' + m.id); if (G.tagEls && G.tagEls['p' + m.id]) { G.tagEls['p' + m.id].remove(); delete G.tagEls['p' + m.id]; } if (mk['p' + m.id]) { mk['p' + m.id].remove(); delete mk['p' + m.id]; } toast('Un jugador salió'); }
        renderLobby(); if (G.myId === G.hostId) sendReady();
        break;
      case 'host':
        G.hostId = m.id; renderLobby();
        if (G.mode === 'race' && race && G.myId === G.hostId) { race.auth = true; race.racers.forEach(function (r) { if (r.bot) r.own = true; }); }
        break;
      case 'lobby': G.lobby.track = m.track | 0; G.lobby.bots = !!m.bots; if (m.diff !== undefined) G.lobby.diff = m.diff | 0; G.champSet.on = !!m.champ && m.champ.n !== 1; G.champSet.bets = !!(m.champ && m.champ.b); if (m.champ) { G.champSet.stake = m.champ.s | 0; if (m.champ.n !== 1) G.champSet.n = m.champ.n === 3 ? 3 : 5; G.champSet.pick = (m.champ.p || []).slice(0, 5); } renderLobby(); break;
      case 'cc': if (G.champ && G.champ.bets && m.id && m.i === (m.i | 0)) { (G.champ.rc[m.i] = G.champ.rc[m.i] || {})[String(m.id).slice(0, 12)] = Math.max(0, Math.min(5000, m.c | 0)); } break;
      case 'chat': if (G.players[m.f]) addChat(m.f, String(m.text || '').slice(0, 160), m.st); break;
      case 'ready': if (G.myId === G.hostId && G.players[m.f]) { if (m.v) G.ready[m.f] = true; else delete G.ready[m.f]; sendReady(); renderLobby(); } break;
      case 'rdy': if (m.f === G.hostId) { G.ready = {}; (m.ids || []).forEach(function (i) { G.ready[i] = true; }); renderLobby(); } break;
      case 'kick': if (m.f === G.hostId && m.to === G.myId) { toast('El anfitrión te sacó de la sala', 3500); leaveRoom(); } break;
      case 'vjoin': case 'vleave': case 'va': Voice.onMsg(m); break;
      case 'vhere': case 'rtc': if (m.to === G.myId) Voice.onMsg(m); break;
      case 'start':
        if (m.champ && !(m.roster || []).some(function (e) { return !e.bot && e.owner === G.myId; })) { toast('Hay un campeonato en curso: espera en la sala a que termine', 3500); break; }
        G.mp = true; beginRace(m, false); break;
      case 'back':
        if (G.myId === G.hostId) sendReady(); // los «listo» marcados en la pantalla de resultados se conservan
        G.race = null; G.me = null; G.mode = 'menu'; updVoiceHud(); $('hud').classList.add('hidden'); G.camMode = 'demo'; G.nav = []; ensureDemo(); go('scrLobby'); G.nav = ['scrMain']; renderLobby();
        break;
      case 's':
        if (race && G.mode === 'race') { var r = race.byId[m.r]; if (r && !r.own) r.net = { br: m.b | 0, u: m.u, d: m.d, psi: m.p, vf: m.v, vl: m.l, y: m.y, x: m.x | 0, lap: m.n, st: m.st, fm: m.fm | 0, fl: m.fl || 0, t: performance.now() }; }
        break;
      case 'e':
        if (race && m.ev) for (var i = 0; i < m.ev.length; i++) race.applyEvent(m.ev[i]);
        break;
    }
  }
  Net.on.msg = onNetMsg; G.onNetMsg = onNetMsg; G.renderLobby = renderLobby; G.showResults = showResults;
  Net.on.hosted = function (h) { G.roomIp = h.ip || ''; Net.connect('127.0.0.1:' + Net.PORT); };
  Net.on.open = function () { };
  Net.on.room = function (code) { G.roomCode = code; };
  Net.on.close = function (why) {
    Voice.leave(true);
    if (G.mp || G.screen === 'scrLobby') { toast(typeof why === 'string' && why.length > 3 && why !== 'cerrada' ? why : 'Se perdió la conexión', 3000); G.online = false; G.mp = false; if (G.mode === 'race') { quitRace(true); } else { G.nav = []; go('scrMain'); } }
  };
  Net.on.error = function (msg) {
    if (G.online) {
      G.mp = false; G.online = false;
      if (G.screen !== 'scrMulti') toast(String(msg || 'No se pudo entrar a la sala'), 3200);
      var on = $(Net.role === 'host' ? 'onlHostNote' : 'onlJoinNote'); if (on) { on.textContent = String(msg || 'No se pudo conectar'); on.className = 'note err'; }
      var bh = $('btnHostOnline'); if (bh) bh.disabled = false;
      return;
    }
    var n = $('joinNote'); if (n) { n.textContent = 'No se pudo conectar: ' + (msg || ''); n.className = 'note err'; }
    var h = $('hostNote'); if (h && Net.role === 'host') { h.textContent = String(msg || ''); h.className = 'note err'; }
  };
  var rooms = [];
  Net.on.rooms = function (list) { rooms = list || []; renderRooms(); };

  function showTab(lan) {
    $('panNet').style.display = lan ? 'none' : ''; $('panLan').style.display = lan ? '' : 'none';
    $('tabNet').classList.toggle('sel', !lan); $('tabLan').classList.toggle('sel', lan);
    if (lan) { renderRooms(); Net.startDiscovery(); } else Net.stopDiscovery();
  }
  function hostOnline() {
    var n = $('onlHostNote'); n.className = 'note'; n.textContent = 'Creando sala en internet…'; $('btnHostOnline').disabled = true;
    G.mp = true; G.online = true; G.roomCode = '';
    Net.hostOnline();
  }
  function joinOnline() {
    var code = PG.Online.normCode($('inCode').value), n = $('onlJoinNote');
    if (code.length !== 5) { n.textContent = 'El código tiene 5 letras o números'; n.className = 'note err'; return; }
    G.set.code = code; saveSet();
    n.className = 'note'; n.textContent = 'Buscando la sala ' + code + '…';
    G.mp = true; G.online = true; G.roomCode = code;
    Net.joinOnline(code);
  }
  function shareCode() {
    var txt = 'Únete a mi carrera de pingüinos en Penguin Slippery. Código de sala: ' + (G.roomCode || '');
    try { if (navigator.share) { navigator.share({ text: txt }); return; } } catch (e) { }
    try { if (navigator.clipboard) { navigator.clipboard.writeText(G.roomCode || ''); toast('Código copiado'); return; } } catch (e) { }
    toast('Código: ' + (G.roomCode || ''));
  }
  function setupMulti() {
    var native = Net.native;
    $('onlHostNote').textContent = ''; $('onlHostNote').className = 'note'; $('onlJoinNote').textContent = ''; $('onlJoinNote').className = 'note'; $('btnHostOnline').disabled = false;
    $('inCode').value = G.set.code || '';
    showTab(false);
    $('hostNote').className = 'note';
    $('hostNote').textContent = native ? 'Tu IP: ' + (Net.localIp() || '(conéctate al WiFi)') : 'En el navegador: ejecuta server/server.js en un PC y abre su dirección.';
    $('joinNote').textContent = ''; $('joinNote').className = 'note';
    $('inIp').value = G.set.ip || '';
  }
  function renderRooms() {
    var el = $('roomList'); if (!el) return;
    if (!rooms.length) { el.innerHTML = '<p class="note">' + (Net.native ? 'Buscando salas en tu red…' : 'La búsqueda automática solo funciona en la app.') + '</p>'; return; }
    el.innerHTML = rooms.map(function (r) { return '<div class="room" data-ip="' + esc(r.ip) + '"><span>' + esc(r.name) + '<br><small>' + esc(r.ip) + ' · ' + (r.players | 0) + ' jugador(es)</small></span><span>Unirse ›</span></div>'; }).join('');
  }
  function hostRoom() {
    $('hostNote').className = 'note'; $('hostNote').textContent = 'Creando sala…';
    G.mp = true; G.online = false; Net.role = 'host';
    if (Net.native) Net.host(G.cfg.name);
    else Net.connect(location.host);
  }
  function joinRoom(ip) {
    ip = String(ip || '').trim(); if (!ip) { $('joinNote').textContent = 'Escribe la IP del anfitrión'; $('joinNote').className = 'note err'; return; }
    G.set.ip = ip; saveSet(); G.mp = true; G.online = false; Net.role = 'client'; G.roomIp = ip;
    $('joinNote').className = 'note'; $('joinNote').textContent = 'Conectando a ' + ip + '…';
    Net.connect(ip);
  }
  function leaveRoom() { flushChampEquip(); G.champ = null; Voice.leave(true); Net.close(); G.mp = false; G.online = false; G.players = {}; G.nav = []; go('scrMain'); }
  var lobbyTab = 'p', chatUnread = 0, chatLast = 0, Voice = PG.Voice;
  G.chat = [];
  function setLobbyTab(t) {
    lobbyTab = t; if (t === 'c') chatUnread = 0;
    $('lTabP').classList.toggle('sel', t === 'p'); $('lTabC').classList.toggle('sel', t === 'c');
    $('lPanP').style.display = t === 'p' ? '' : 'none'; $('lPanC').style.display = t === 'c' ? '' : 'none'; $('lPanC').parentNode.classList.toggle('chatMode', t === 'c');
    setChatDot();
    if (t === 'c') { renderChat(); }
  }
  function setChatDot() { var d = $('chatDot'); if (!d) return; d.textContent = chatUnread > 9 ? '9+' : String(chatUnread); d.style.display = chatUnread ? 'block' : 'none'; }
  function addChat(id, text, st) {
    var p = G.players[id], sk = st ? PG.Eco.stickerOf(st) : null; if (st && !sk) return;
    G.chat.push({ id: id, name: id === G.myId ? 'Tú' : (p ? p.name : 'Jugador'), text: text, me: id === G.myId, stk: sk });
    if (G.chat.length > 80) G.chat.shift();
    var viewing = G.screen === 'scrLobby' && lobbyTab === 'c';
    if (id !== G.myId && !viewing) { chatUnread++; Audio.sfx('pop'); if (G.screen === 'scrLobby') toast('💬 ' + (p ? p.name : 'Jugador') + ': ' + (sk ? sk.e + ' ' + sk.t : text).slice(0, 40), 1800); }
    if (G.screen === 'scrLobby') { renderChat(); setChatDot(); }
  }
  function chatSys(text) {
    G.chat.push({ sys: true, text: text }); if (G.chat.length > 80) G.chat.shift();
    if (G.screen === 'scrLobby' && lobbyTab === 'c') renderChat();
  }
  function renderChat() {
    var el = $('chatLog'); if (!el) return;
    el.innerHTML = G.chat.length ? G.chat.map(function (c) {
      if (c.sys) return '<div class="cm sys">' + esc(c.text) + '</div>';
      if (c.stk) return '<div class="cm st' + (c.me ? ' me' : '') + '"><b>' + esc(c.name) + ':</b><span class="stkMsg" style="background:' + c.stk.pack.col + '"><span class="se">' + c.stk.e + '</span><small>' + esc(c.stk.t) + '</small></span></div>';
      return '<div class="cm' + (c.me ? ' me' : '') + '"><b>' + esc(c.name) + ':</b> ' + esc(c.text) + '</div>';
    }).join('') : '<div class="cm sys">Escribe algo para saludar a los demás jugadores 👋</div>';
    el.scrollTop = el.scrollHeight;
  }
  function sendSticker(code) {
    var a = String(code).split(':'), sk = PG.Eco.stickerOf(code), now = Date.now();
    if (!sk) return;
    if (!PG.Eco.hasPack(a[0])) { toast('Desbloquea el paquete «' + sk.pack.name + '» para usar este sticker', 2200); return; }
    if (now - chatLast < 600) return; chatLast = now;
    Net.send({ t: 'chat', text: '', st: code }); addChat(G.myId, '', code);
  }
  function renderPicker() {
    var el = $('chatPick'); if (!el) return;
    el.style.display = G.pickOpen ? '' : 'none'; $('btnEmoji').textContent = G.pickOpen ? '⌨️' : '😊';
    if (!G.pickOpen) return;
    var E = PG.Eco, tab = G.pickTab || 'emo', h = '<div class="pkTabs"><button data-act="pkTab" data-t="emo" class="' + (tab === 'emo' ? 'sel' : '') + '">😀 Emojis</button>';
    E.PACKS.forEach(function (pk) { h += '<button data-act="pkTab" data-t="' + pk.id + '" class="' + (tab === pk.id ? 'sel' : '') + '">' + (E.hasPack(pk.id) ? '' : '🔒 ') + esc(pk.name) + '</button>'; });
    h += '</div>';
    if (tab === 'emo') h += '<div class="emo">' + E.EMOJIS.map(function (e) { return '<button data-act="pkEmoji" data-e="' + e + '">' + e + '</button>'; }).join('') + '</div>';
    else {
      var pk = E.pack(tab) || E.PACKS[0], own = E.hasPack(pk.id);
      if (!own) h += '<div class="buyRow"><span>🪙 ' + E.data.coins + '</span><button class="btn small primary" data-act="pkBuy" data-p="' + pk.id + '">Comprar paquete 🪙' + pk.price + '</button></div>';
      h += '<div class="stk' + (own ? '' : ' lock') + '">' + pk.st.map(function (x, i) { return '<button data-act="pkSt" data-id="' + pk.id + ':' + i + '" style="background:' + pk.col + '"><span class="se">' + x[0] + '</span><small>' + esc(x[1]) + '</small></button>'; }).join('') + '</div>';
    }
    el.innerHTML = h;
  }
  function sendChat() {
    var inp = $('chatInput'), t = String(inp.value || '').replace(/\s+/g, ' ').trim().slice(0, 140), now = Date.now();
    if (!t || now - chatLast < 600) return;
    chatLast = now; inp.value = '';
    Net.send({ t: 'chat', text: t }); addChat(G.myId, t);
  }
  /* ---- voz: barra de controles y estado de cada jugador ---- */
  function onVoiceChange() {
    if (G.screen === 'scrLobby') { renderVoiceBar(); renderPlayers(); }
    updVoiceHud();
  }
  function renderVoiceBar() {
    var el = $('voiceBar'), h;
    if (!Voice.supported()) h = '<span class="vnote">Este dispositivo no admite chat de voz.</span>';
    else if (Voice.joining) h = '<span class="vnote">Pidiendo permiso del micrófono…</span>';
    else if (!Voice.on) h = '<button class="btn small vbtn" data-act="vJoin">🎙 Activar chat de voz</button><span class="vnote">Habla con los demás con el micrófono.</span>';
    else h = '<button class="btn small vbtn ' + (Voice.mic ? 'on' : 'off') + '" data-act="vMic">' + (Voice.mic ? '🎤 Mi micro: ON' : '🔇 Mi micro: silenciado') + '</button>' +
      '<button class="btn small vbtn ' + (Voice.deaf ? 'off' : 'on') + '" data-act="vDeaf">' + (Voice.deaf ? '🔇 No oigo a nadie' : '🔊 Oigo a todos') + '</button>' +
      '<button class="btn small ghost" data-act="vLeave">Salir de voz</button>';
    if (Voice.err) h += '<div class="vnote err">' + esc(Voice.err) + '</div>';
    if (G.vbarHtml !== h) { G.vbarHtml = h; el.innerHTML = h; }
  }
  function renderPlayers() {
    var ids = Object.keys(G.players).map(Number).sort(function (a, b) { return a - b; });
    var html = ids.map(function (id) {
      var p = G.players[id], me = id === G.myId, vi = '';
      if (Voice.on || (Voice.peers[id] && Voice.peers[id].voice)) {
        if (me) { vi = Voice.on ? '<span class="vi ' + (Voice.mic ? (Voice.speakingMe ? 'talk' : 'on') : 'off') + '">' + (Voice.mic ? '🎤' : '🔇') + '</span>' : ''; }
        else {
          var st = Voice.stateOf(id), pe = Voice.peers[id];
          if (st !== 'off') vi = '<span class="vi ' + (pe && pe.muted ? 'off' : (pe && pe.speaking ? 'talk' : (st === 'ok' ? 'on' : 'wait'))) + '">' + (st === 'fail' ? '⚠' : (st === 'wait' ? '…' : (pe && pe.muted ? '🔇' : '🔊'))) + '</span>' +
            (Voice.on ? '<button class="vm" data-act="vPeer" data-id="' + id + '" aria-label="Silenciar">' + (pe && pe.muted ? 'Quitar silencio' : 'Silenciar') + '</button>' : '');
        }
      }
      var isHost = id === G.hostId, imHost = G.myId === G.hostId, rd = isHost || G.ready[id];
      var badge = isHost ? '<span class="host">Anfitrión</span>' : '<span class="rdy' + (rd ? '' : ' no') + '">' + (rd ? '✔ Listo' : 'No listo') + '</span>';
      var kick = (imHost && !me) ? '<button class="kick' + (G.kickArm === id ? ' arm' : '') + '" data-act="kick" data-id="' + id + '">' + (G.kickArm === id ? '¿Seguro?' : 'Expulsar') + '</button>' : '';
      return '<div class="prow"><span class="dot" style="background:' + bodyColor(p.cfg) + '"></span><span class="pn ' + (me ? 'me' : '') + '">' + esc(p.name) + (me ? ' (tú)' : '') + '</span>' + vi + badge + kick + '</div>';
    }).join('');
    if (G.plHtml !== html) { G.plHtml = html; $('playerList').innerHTML = html; }
    $('lTabP').textContent = '👥 Jugadores (' + ids.length + ')';
  }
  function updVoiceHud() {
    var b = $('btnMic'); if (!b) return;
    b.style.display = (Voice.on && G.mode === 'race') ? '' : 'none';
    b.textContent = Voice.mic ? '🎤' : '🔇'; b.classList.toggle('talk', !!Voice.speakingMe); b.classList.toggle('muted', !Voice.mic);
    var pv = $('pauseVoice'); if (pv) { pv.style.display = Voice.on ? '' : 'none'; $('pvMic').textContent = Voice.mic ? '🎤 Mi micro: ON' : '🔇 Mi micro: OFF'; $('pvDeaf').textContent = Voice.deaf ? '🔇 No oigo' : '🔊 Oigo a todos'; }
  }
  function renderLobby() {
    var host = G.myId === G.hostId, ids = Object.keys(G.players).map(Number);
    renderPlayers(); renderVoiceBar();
    $('lobbyRole').textContent = host ? 'Eres el anfitrión' : 'Esperando al anfitrión';
    $('lobbyImg').src = 'img/tracks/t' + G.lobby.track + '.jpg';
    $('lobbyTrack').textContent = PG.TRACKS[G.lobby.track].name + ' · ' + (PG.TRACKS[G.lobby.track].type === 'circuit' ? '3 vueltas' : 'Bajada A→B');
    renderChampBox(host);
    $('btnLobbyTrack').style.display = host ? '' : 'none'; $('btnLobbyTrack').textContent = G.champSet.on ? 'Elegir mapas' : 'Cambiar pista';
    if (G.champSet.on) $('lobbyTrack').textContent = '🏆 ' + (G.champSet.n === 3 ? 'Mini campeonato · 3' : 'Campeonato · 5') + ' carreras';
    var bs = $('btnStart'), pend = allReady(), imReady = !!G.ready[G.myId];
    if (host) { bs.disabled = pend > 0; bs.classList.toggle('wait', pend > 0); bs.classList.remove('ready'); bs.textContent = pend > 0 ? '⏳ Faltan ' + pend + ' por estar listos' : '🏁 ¡INICIAR CARRERA!'; }
    else { bs.disabled = false; bs.classList.remove('wait'); bs.classList.toggle('ready', imReady); bs.textContent = imReady ? '✔ ¡Listo! (toca para cancelar)' : '👍 ¡Estoy listo!'; }
    $('chkBots').disabled = !host; $('chkBots').checked = !!G.lobby.bots;
    renderDiff('segDiffLobby', G.lobby.diff, host);
    var on = !!G.online;
    $('roomLbl').textContent = on ? 'Código de sala' : 'IP de la sala'; $('roomIp').className = on ? 'code' : ''; $('btnShare').style.display = on ? '' : 'none';
    $('roomIp').textContent = on ? (G.roomCode || '—') : (G.roomIp || (Net.native ? (Net.localIp() || '—') : location.host || '—'));
    $('lobbyNote').textContent = host ? (ids.length < 2 ? (on ? 'Pasa el código a tus amigos (cualquier red).' : 'Comparte tu IP (mismo WiFi).') : (pend > 0 ? 'Todos deben marcar «Estoy listo» para poder empezar.' : 'Todos listos: ¡puedes empezar!')) : 'Marca «Estoy listo». El anfitrión elegirá la pista y empezará la carrera.';
    setLobbyTab(lobbyTab);
  }
  function hostStart() {
    if (allReady() > 0) { toast('Faltan jugadores por marcar «Estoy listo»', 2200); return; }
    var humans = Object.keys(G.players).map(Number).sort(function (a, b) { return a - b; }).map(function (id) { return G.players[id]; });
    if (G.champSet.on || G.champSet.bets) { // v3.1: campeonato (v3.3: o carrera rapida con apuesta = campeonato de 1 carrera)
      if (G.champSet.bets && !PG.Eco.canBet(G.champSet.stake)) { toast('Necesitas 🪙' + G.champSet.stake + ' para esta apuesta', 3000); return; }
      champStartFirst(humans, true); return;
    }
    var seed = (Math.random() * 1e9) | 0, roster = makeRoster(humans, G.lobby.bots, seed);
    var m = { t: 'start', track: G.lobby.track, seed: seed, startIn: 5000, roster: roster, diff: G.lobby.diff, ava: G.set.ava !== false };
    Net.send(m); G.mp = true; beginRace(m, false);
  }

  /* ---------------- selector de pistas ---------------- */
  G.trackMode = 'solo'; G.selTrack = 0;
  function buildTrackGrid() {
    var grid = $('trackGrid'), dots = $('carDots'); grid.innerHTML = ''; dots.innerHTML = '';
    G.tracksInfo.forEach(function (ti, i) {
      var d = document.createElement('div'); d.className = 'tcard' + (i === G.selTrack ? ' sel' : ''); d.dataset.i = i;
      d.innerHTML = '<span class="num">' + (i + 1) + '</span><div class="th"><img src="img/tracks/t' + i + '.jpg" alt="" draggable="false" onerror="this.style.display=\'none\'"><canvas class="mini" width="200" height="146"></canvas></div><div class="tcap"><div class="tn">' + esc(ti.name) + '</div><div class="tt">' + (ti.type === 'circuit' ? '🔁 3 vueltas' : '⬇️ Bajada A→B') + ' · ' + Math.round(ti.len) + ' m</div></div>';
      grid.appendChild(d); drawThumb(d.querySelector('canvas'), ti, true);
      var dt = document.createElement('button'); dt.className = 'dot'; dt.dataset.i = i; dt.setAttribute('aria-label', 'Mapa ' + (i + 1)); dots.appendChild(dt);
    });
    $('btnTrackGo').textContent = G.trackMode === 'solo' ? '¡A correr!' : 'Elegir esta pista';
    $('diffSolo').style.display = G.trackMode === 'solo' ? '' : 'none'; renderDiff('segDiffSolo', G.set.diff, true);
    $('modeSolo').style.display = ''; renderModeSolo();
    $('tracksTitle').textContent = 'Elige la pista';
    updTrackInfo(); markPicks();
    carCenter(G.selTrack, true); setTimeout(function () { carCenter(G.selTrack, true); }, 60); setTimeout(function () { carCenter(G.selTrack, true); }, 300);
  }
  /* v3.4: carrusel de mapas (desliza con el dedo, flechas, puntos o teclado) */
  var carLock = 0;
  function carCenter(i, instant) {
    var grid = $('trackGrid'), c = grid && grid.children[i]; if (!c) return;
    var x = c.offsetLeft - (grid.clientWidth - c.offsetWidth) / 2; carLock = Date.now() + (instant ? 120 : 450);
    if (instant || !grid.scrollTo) grid.scrollLeft = x; else grid.scrollTo({ left: x, behavior: 'smooth' });
    carMark(i);
  }
  var carCur = 0;
  function carMark(mid) { carCur = mid; [].forEach.call(document.querySelectorAll('#trackGrid .tcard'), function (c, k) { c.classList.toggle('mid', k === mid); }); [].forEach.call(document.querySelectorAll('#carDots .dot'), function (c, k) { c.classList.toggle('on', k === mid); }); }
  function carNearest() {
    var grid = $('trackGrid'), mid = grid.scrollLeft + grid.clientWidth / 2, best = 0, bd = 1e9;
    [].forEach.call(grid.children, function (c, k) { var d = Math.abs(c.offsetLeft + c.offsetWidth / 2 - mid); if (d < bd) { bd = d; best = k; } });
    return best;
  }
  function carStep(dir) { var n = G.tracksInfo.length, cur = Date.now() < carLock ? carCur : carNearest(), nx = Math.max(0, Math.min(n - 1, cur + dir)); carSel(nx); carCenter(nx); Audio.sfx('click'); }
  function carSel(i) { // el mapa del centro es el elegido (en campeonato solo se enfoca; se marca con un toque)
    carMark(i); if (!champCtx() && G.selTrack !== i) { G.selTrack = i; markPicks(); updTrackInfo(); }
  }
  function carInit() {
    var grid = $('trackGrid'), tk = 0;
    grid.addEventListener('scroll', function () { if (tk) return; tk = requestAnimationFrame(function () { tk = 0; if (Date.now() < carLock) { carMark(carNearest()); return; } carSel(carNearest()); }); }, { passive: true });
    $('carPrev').addEventListener('click', function () { carStep(-1); }); $('carNext').addEventListener('click', function () { carStep(1); });
    $('carDots').addEventListener('click', function (e) { var d = e.target.closest ? e.target.closest('.dot') : null; if (!d) return; var i = +d.dataset.i; carSel(i); carCenter(i); Audio.sfx('click'); });
    document.addEventListener('keydown', function (e) { if (G.screen !== 'scrTracks') return; if (e.key === 'ArrowLeft') { carStep(-1); e.preventDefault(); } else if (e.key === 'ArrowRight') { carStep(1); e.preventDefault(); } });
  }
  G.carInit = carInit;
  var MODE_INFO = [
    ['r', '🏁', 'Carrera', '1 carrera', 'Una sola carrera. Ganas monedas según tu puesto y los poderes que uses se gastan al momento.'],
    ['m', '🥈', 'Mini campeonato', '3 carreras', '3 carreras seguidas con puntos 10-7-5-3-2-1. Tus poderes comprados se gastan solo al terminar las 3.'],
    ['c', '🏆', 'Campeonato', '5 carreras', '5 carreras en mapas distintos. Gana quien más puntos sume. Tus poderes se gastan solo al final del campeonato.']
  ];
  function modeSel(o) { if (G.trackMode === 'solo') return o[0] === 'r' ? !G.champSolo : (G.champSolo === (o[0] === 'm' ? 3 : 5)); var on = G.champSet.on; return o[0] === 'r' ? !on : (on && G.champSet.n === (o[0] === 'm' ? 3 : 5)); }
  function renderModeSolo() {
    var dis = G.trackMode !== 'solo' && G.myId !== G.hostId, cur = MODE_INFO[0];
    $('segModeSolo').innerHTML = MODE_INFO.map(function (o) {
      var sel = modeSel(o); if (sel) cur = o;
      return '<button data-m="' + o[0] + '" class="mcard' + (sel ? ' sel' : '') + '"' + (dis ? ' disabled' : '') + '><i>' + o[1] + '</i><span class="mt"><b>' + o[2] + '</b><small>' + o[3] + '</small></span></button>';
    }).join('');
    $('modeDesc').textContent = cur[4] + (G.trackMode === 'solo' ? '' : (cur[0] === 'r' ? '' : ' Con apuestas opcionales.'));
    $('modeTitle').textContent = G.trackMode === 'solo' ? 'Modo de juego' : 'Modo de la sala' + (G.myId === G.hostId ? '' : ' (lo elige el anfitrión)');
    if (G.trackMode === 'solo') {
      $('btnTrackGo').textContent = G.champSolo ? '¡Empezar campeonato!' : '¡A correr!';
    }
    updTrackInfo();
  }
  var DIFF_DESC = ['Bots lentos y torpes', 'Bots equilibrados', 'Bots rápidos y agresivos', 'Bots casi perfectos'];
  function renderDiff(id, val, enabled) {
    var el = $(id); if (!el) return;
    el.innerHTML = PG.DIFFS.map(function (n, i) { return '<button data-d="' + i + '" class="' + (i === val ? 'sel' : '') + '"' + (enabled ? '' : ' disabled') + '>' + n + '</button>'; }).join('');
    el.title = DIFF_DESC[val] || '';
  }
  // v3.2: en modo campeonato la rejilla elige varios mapas (en orden); los que falten se sortean
  function champCtx() { return (G.trackMode === 'solo' && G.champSolo) ? G.champSolo : (G.trackMode === 'lobby' && G.champSet.on ? (G.champSet.n === 3 ? 3 : 5) : 0); }
  function markPicks() {
    var n = champCtx(); [].forEach.call(document.querySelectorAll('.tcard'), function (c, i) {
      var k = G.champPick.indexOf(i); c.classList.toggle('sel', n ? k >= 0 : i === G.selTrack);
      var b = c.querySelector('.num'); if (b) b.textContent = n && k >= 0 ? '✔ ' + (k + 1) : (i + 1);
    });
  }
  function updTrackInfo() {
    var n = champCtx();
    if (n) { $('trackInfo').textContent = '🏆 ' + (n === 3 ? 'Mini campeonato' : 'Campeonato') + ' de ' + n + ' carreras. Toca los mapas que quieras (' + G.champPick.length + '/' + n + '); los que falten se sortean. Puntos 10-7-5-3-2-1.' + (G.trackMode === 'lobby' ? '' : ' Sin apuestas.'); if (G.trackMode === 'lobby') $('btnTrackGo').textContent = 'Listo'; return; }
    var d = PG.TRACKS[G.selTrack]; $('trackInfo').textContent = d.name + ' — ' + d.blurb;
  }
  function drawThumb(cv, ti, mini) {
    var x = cv.getContext('2d'), th = ti.thumb, W = cv.width, H = cv.height, pad = 22, sc = Math.min((W - pad * 2) / th.w, (H - pad * 2) / th.h);
    var ox = (W - th.w * sc) / 2, oy = (H - th.h * sc) / 2;
    var theme = PG.THEMES[ti.theme], g = x.createLinearGradient(0, 0, 0, H);
    function c3(c, k) { return 'rgb(' + Math.round(c[0] * 255 * k) + ',' + Math.round(c[1] * 255 * k) + ',' + Math.round(c[2] * 255 * k) + ')'; }
    g.addColorStop(0, c3(theme.top, 1)); g.addColorStop(1, c3(theme.hor, 1));
    if (mini) { x.fillStyle = 'rgba(8,24,42,.62)'; x.fillRect(0, 0, W, H); } else { x.fillStyle = g; x.fillRect(0, 0, W, H); }
    x.lineJoin = 'round'; x.lineCap = 'round';
    function path() { x.beginPath(); th.pts.forEach(function (p, i) { var px = ox + p[0] * sc, py = oy + p[1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); if (ti.type === 'circuit') x.closePath(); }
    path(); x.strokeStyle = 'rgba(0,25,50,.7)'; x.lineWidth = 12; x.stroke();
    path(); x.strokeStyle = c3(theme.snow, 0.98); x.lineWidth = 8; x.stroke();
    path(); x.strokeStyle = c3(theme.ice, 1); x.lineWidth = 4; x.stroke();
    (th.br || []).forEach(function (bp) { x.beginPath(); bp.forEach(function (p, i) { var px = ox + p[0] * sc, py = oy + p[1] * sc; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.strokeStyle = 'rgba(0,25,50,.7)'; x.lineWidth = 7; x.stroke(); x.strokeStyle = '#ffb347'; x.lineWidth = 3.5; x.stroke(); });
    var p0 = th.pts[0], pl = th.pts[th.pts.length - 1];
    x.fillStyle = '#4cd964'; x.beginPath(); x.arc(ox + p0[0] * sc, oy + p0[1] * sc, 6, 0, 6.3); x.fill();
    if (ti.type === 'sprint') { x.fillStyle = '#ff5a4a'; x.beginPath(); x.arc(ox + pl[0] * sc, oy + pl[1] * sc, 6, 0, 6.3); x.fill(); }
  }

  /* ---------------- personalizacion ---------------- */
  function swatches(id, list, key, onPick) {
    var el = $(id); el.innerHTML = '';
    list.forEach(function (c, i) {
      var b = document.createElement('button'); b.style.background = c; b.className = G.cfg[key] === i ? 'sel' : '';
      b.addEventListener('click', function () { G.cfg[key] = i; saveCfg(); Audio.sfx('click'); buildCustomUI(); });
      el.appendChild(b);
    });
  }
  // iconos (emoji) de cada opcion de la personalizacion
  var OPT_ICO = {
    hat: ['🚫', '🧶', '⛑️', '👑', '🎩', '🧢', '⚔️', '🎧', '🧙', '🤠', '👨‍🍳', '🐱', '🥳', '😇', '🎅', '🪖'],
    scarf: ['🚫', '🧣', '🎀', '🧷', '🏅', '🔔', '🍭'],
    glasses: ['🚫', '🥽', '🕶️', '👓', '🤖', '💖', '🦸'],
    outfit: ['🚫', '🧥', '🦸', '🎒', '🦺', '🤵', '🪽', '🚀']
  };
  function chips(id, list, key) {
    var el = $(id); el.innerHTML = '';
    var ic = OPT_ICO[key] || [];
    list.forEach(function (name, i) {
      var b = document.createElement('button'); b.className = 'opt' + (G.cfg[key] === i ? ' sel' : '');
      b.innerHTML = '<span class="oi">' + (ic[i] || '•') + '</span><small>' + esc(name) + '</small>';
      b.addEventListener('click', function () { G.cfg[key] = i; saveCfg(); Audio.sfx('click'); buildCustomUI(); });
      el.appendChild(b);
    });
  }
  G.wearSet = function (id) { var st = PG.Eco.setOf(id); if (!st) return; for (var k in st.c) G.cfg[k] = st.c[k]; saveCfg(); Audio.sfx('click'); if (G.screen === 'scrCustom') buildCustomUI(); };
  function renderSets() {
    var el = $('chSets'); if (!el) return;
    el.innerHTML = PG.SETS.map(function (st) {
      var own = PG.Eco.hasSet(st.id), on = true, k;
      for (k in st.c) if (G.cfg[k] !== st.c[k]) { on = false; break; }
      return '<button class="opt setOpt' + (on ? ' sel' : '') + (own ? '' : ' lock') + '" data-act="setWear" data-s="' + st.id + '"><span class="oi">' + st.ico + '</span><small>' + esc(st.name) + '</small><em>' + (own ? (on ? '✔ Puesto' : 'Ponerme') : '🔒 🪙' + st.price) + '</em></button>';
    }).join('') + '<button class="opt" data-act="setShop"><span class="oi">🛍️</span><small>Ir a la tienda</small></button>';
  }
  var ctabBound = false;
  function buildCustomUI() {
    var nm = $('inName'); if (document.activeElement !== nm) nm.value = G.cfg.name;
    swatches('swBody', PG.PAL.body, 'body'); swatches('swFeet', PG.PAL.feet, 'feet');
    chips('chHat', PG.OPT.hats, 'hat'); swatches('swHat', PG.PAL.accent, 'hatCol');
    chips('chScarf', PG.OPT.scarves, 'scarf'); swatches('swScarf', PG.PAL.accent, 'scarfCol');
    chips('chGlasses', PG.OPT.glasses, 'glasses'); chips('chOutfit', PG.OPT.outfits, 'outfit'); swatches('swOut', PG.PAL.accent, 'outCol'); renderSets();
    $('swHat').parentNode.style.display = G.cfg.hat ? '' : 'none'; $('swScarf').parentNode.style.display = G.cfg.scarf ? '' : 'none'; $('swOut').parentNode.style.display = G.cfg.outfit ? '' : 'none';
    if (!ctabBound) {
      ctabBound = true;
      $('ctabs').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; G.ctab = b.dataset.ct; Audio.sfx('click'); showCtab(); });
    }
    showCtab();
  }
  function showCtab() {
    var t = G.ctab || 'body';
    [].forEach.call(document.querySelectorAll('#ctabs button'), function (b) { b.classList.toggle('sel', b.dataset.ct === t); });
    [].forEach.call(document.querySelectorAll('.cpan'), function (p) { p.style.display = p.dataset.cp === t ? '' : 'none'; });
    var sc = document.querySelector('#scrCustom .scroll'); if (sc) sc.scrollTop = 0; // v3.1: al cambiar de pestaña la lista empieza arriba (no queda la primera fila cortada)
  }

  /* 200 niveles; para subir de nivel hay que reunir 100 000 puntos por nivel (cada carrera da cientos o miles de puntos) */
  var MAXLV = 200;
  var TIERS = [[1, 'Pingüino novato', '🐣'], [10, 'Aprendiz del hielo', '🧊'], [20, 'Deslizador', '⛷️'], [35, 'Veterano', '🏔️'], [55, 'Explorador polar', '🧭'], [80, 'Campeón polar', '🏆'], [110, 'Maestro del hielo', '🎖️'], [140, 'Gran maestro', '💎'], [170, 'Leyenda helada', '👑'], [200, 'Rey del Polo', '🌟']];
  function lvPts(L) { return L <= 1 ? 0 : (L - 1) * 100000; } // v2.9: cada nivel pide 100 000 puntos más (nivel 2 = 100 000, nivel 3 = 200 000...)
  function fmtN(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
  function levelOf(pts) {
    var L = 1; while (L < MAXLV && pts >= lvPts(L + 1)) L++;
    var t = TIERS[0]; for (var i = 0; i < TIERS.length; i++) if (L >= TIERS[i][0]) t = TIERS[i];
    var base = lvPts(L), nx = L < MAXLV ? lvPts(L + 1) : null;
    return { i: L, level: L, name: t[1], ico: t[2], next: nx, nextLevel: L + 1, pct: nx ? Math.round((pts - base) * 100 / (nx - base)) : 100 };
  }
  G.levelOf = levelOf;
  function donut(parts, size) {
    var tot = parts.reduce(function (a, p) { return a + p.v; }, 0), r = 38, C = 2 * Math.PI * r, off = 0, h = '<svg viewBox="0 0 100 100" width="' + size + '" height="' + size + '"><circle cx="50" cy="50" r="' + r + '" fill="none" stroke="rgba(255,255,255,.12)" stroke-width="16"/>';
    if (tot > 0) parts.forEach(function (p) { if (!p.v) return; var len = C * p.v / tot; h += '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke="' + p.c + '" stroke-width="16" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 50 50)"/>'; off += len; });
    return h + '</svg>';
  }
  function bars(vals, color, labels, W, H) {
    var n = vals.length, mx = Math.max.apply(null, vals.concat([1])), bw = W / n, h = '<svg viewBox="0 0 ' + W + ' ' + (H + 14) + '" class="bars" preserveAspectRatio="none">';
    vals.forEach(function (v, i) { var bh = Math.round(v * H / mx); h += '<rect x="' + (i * bw + bw * 0.14).toFixed(1) + '" y="' + (H - bh) + '" width="' + (bw * 0.72).toFixed(1) + '" height="' + Math.max(bh, v ? 2 : 0) + '" rx="2" fill="' + (typeof color === 'function' ? color(i) : color) + '"/>'; if (labels) h += '<text x="' + (i * bw + bw / 2).toFixed(1) + '" y="' + (H + 11) + '" text-anchor="middle" font-size="9" fill="#cfe9fb">' + labels[i] + '</text>'; });
    return h + '</svg>';
  }
  function renderStats() {
    var S = G.stats, E = PG.Eco.data, g = S.games, w = S.wins, l = g - w, pw = g ? Math.round(w * 100 / g) : 0, pl = g ? 100 - pw : 0;
    var lv = levelOf(S.points), pl2 = S.places, fin = pl2.reduce(function (a, b) { return a + b; }, 0);
    var podOnly = Math.max(0, (pl2[1] || 0) + (pl2[2] || 0)), other = Math.max(0, fin - (pl2[0] || 0) - podOnly);
    var h = '<div class="lvBox"><div class="lvIco">' + lv.ico + '</div><div class="lvTx"><b>' + esc(G.cfg.name) + '</b><span>Nivel ' + lv.level + ' / ' + MAXLV + ' · ' + esc(lv.name) + '</span><div class="lvBar"><i style="width:' + lv.pct + '%"></i></div><small>' + (lv.next ? fmtN(S.points) + ' / ' + fmtN(lv.next) + ' pts para el nivel ' + lv.nextLevel : '¡Nivel máximo!') + '</small></div></div>';
    h += '<div class="stGrid">' +
      tile('🏁', g, 'Partidas', '') + tile('🏆', w, 'Victorias', 'win') + tile('💔', l, 'Derrotas', 'lose') + tile('🥇', S.podiums | 0, 'Podios', 'gold') +
      tile('⭐', S.stars | 0, 'Estrellas', 'gold') + tile('🎯', fmtN(S.points | 0), 'Puntos', 'gold') + tile('🪙', E.coins, 'Monedas', 'gold') + tile('🌀', S.tricks | 0, 'Piruetas', '') + tile('❄️', S.elim | 0, 'Avalanchas', 'lose') + '</div>';
    h += '<div class="stCard"><h3>🏆 Victorias y derrotas</h3>' + (g ? '<div class="stChart"><div class="dn">' + donut([{ v: w, c: '#4cd964' }, { v: Math.max(0, g - w - (S.elim | 0)), c: '#ff8a7a' }, { v: S.elim | 0, c: '#8fb4d8' }], 96) + '<b>' + pw + '%</b></div><div class="lg"><div><i style="background:#4cd964"></i>Victorias <b>' + pw + '%</b> (' + w + ')</div><div><i style="background:#ff8a7a"></i>Derrotas <b>' + pl + '%</b> (' + l + ')</div><div class="mut"><i style="background:#8fb4d8"></i>Incluye ' + (S.elim | 0) + ' por avalancha</div></div></div>' : '<p class="note">Todavía no has jugado ninguna carrera.</p>') + '</div>';
    h += '<div class="stCard"><h3>🥇 Tus puestos</h3>' + (fin ? bars(pl2.map(function (v) { return Math.round(v * 100 / fin); }), function (i) { return ['#ffd45a', '#cfd8e4', '#d99a5a', '#6fa8dc', '#6fa8dc', '#6fa8dc'][i]; }, ['1º', '2º', '3º', '4º', '5º', '6º'], 180, 48) + '<div class="axisN">' + pl2.map(function (v) { return '<span>' + Math.round(v * 100 / fin) + '%</span>'; }).join('') + '</div>' : '<p class="note">Termina una carrera para ver tus puestos.</p>') + '</div>';
    var hs = S.hist || [];
    h += '<div class="stCard"><h3>⭐ Puntos y 🪙 monedas (últimas ' + Math.max(hs.length, 0) + ' carreras)</h3>' + (hs.length ? '<div class="two"><div><small>Puntos</small>' + bars(hs.map(function (x) { return x.p; }), '#7ab8ff', null, 120, 40) + '</div><div><small>Monedas</small>' + bars(hs.map(function (x) { return x.c; }), '#ffc83a', null, 120, 40) + '</div></div>' : '<p class="note">Aún sin datos.</p>') +
      '<div class="eco"><span>Ganadas <b>🪙 ' + E.earned + '</b></span><span>Gastadas <b>🪙 ' + E.spent + '</b></span><span>Tienes <b>🪙 ' + E.coins + '</b></span></div>' +
      (E.earned + E.spent ? '<div class="stBar"><i style="width:' + Math.round(E.spent * 100 / Math.max(1, E.earned)) + '%;background:#ffc83a"></i></div><small class="mut">Has gastado el ' + Math.min(100, Math.round(E.spent * 100 / Math.max(1, E.earned))) + '% de lo que ganaste</small>' : '') + '</div>';
    h += '<div class="stCard"><h3>⏱️ Últimos 3 tiempos</h3>';
    var rec = (S.recent || []).slice(-3).reverse();
    rec.forEach(function (x) {
      var ti = G.tracksInfo[x.t]; if (!ti) return; var bb = S.best[x.t], isB = bb && Math.abs(bb - x.s) < 0.011;
      h += '<div class="stRow"><span class="n">' + (ti.type === 'circuit' ? '🔁' : '⬇️') + ' ' + esc(ti.name) + ' <span class="w">· ' + x.r + 'º de ' + x.n + (isB ? ' · ⭐ récord' : (bb ? ' · mejor ' + fmtTime(bb) : '')) + '</span></span><span class="t">' + fmtTime(x.s) + '</span></div>';
    });
    if (!rec.length) h += '<p class="note">Termina una carrera para registrar tu primer tiempo.</p>';
    h += '</div>';
    $('statsBody').innerHTML = h;
  }
  function tile(ico, v, lbl, cls) { return '<div class="stBox ' + cls + '"><span class="si">' + ico + '</span><b>' + v + '</b><small>' + lbl + '</small></div>'; }
  function markQuality() {
    var bs = $('segQuality').querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('sel', +bs[i].dataset.q === G.set.quality);
    var pb = $('pSegQuality').querySelectorAll('button');
    for (i = 0; i < pb.length; i++) pb[i].classList.toggle('sel', +pb[i].dataset.q === G.set.quality);
  }

  /* ---------------- amigos (v2.7) ---------------- */
  var Fr = PG.Friends, frSent = {}, invShown = null, invT = 0;
  Fr.getInfo = function () { return { n: G.cfg.name, s: G.mode === 'race' ? 2 : (G.mp ? 1 : 0) }; };
  function frStatus(st) {
    if (!st.on) return { dot: '', txt: 'Desconectado' };
    if (st.s === 2) return { dot: 'race', txt: 'En carrera' };
    if (st.s === 1) return { dot: 'lob', txt: 'En una sala de espera' };
    return { dot: 'on', txt: 'En línea' };
  }
  // v3.0: avatar = foto de perfil si la hay; si no, un pinguino por defecto
  var AV_DEF = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fd0ff"/><stop offset="1" stop-color="#2d7fd6"/></linearGradient></defs><rect width="64" height="64" fill="url(#g)"/><ellipse cx="32" cy="40" rx="19" ry="21" fill="#1b2438"/><ellipse cx="32" cy="43" rx="12" ry="15" fill="#f4f8ff"/><circle cx="26" cy="29" r="3.6" fill="#fff"/><circle cx="38" cy="29" r="3.6" fill="#fff"/><circle cx="26.6" cy="29.4" r="1.8" fill="#111"/><circle cx="37.4" cy="29.4" r="1.8" fill="#111"/><path d="M27 34h10l-5 6z" fill="#ff9f1c"/><ellipse cx="24" cy="60" rx="6" ry="2.6" fill="#ff9f1c"/><ellipse cx="40" cy="60" rx="6" ry="2.6" fill="#ff9f1c"/></svg>').replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/'/g, '%27');
  G.avatarHtml = function (url, dot, big) {
    return '<span class="av' + (big ? ' big' : '') + '" style="background-image:url(' + (url || AV_DEF) + ')">' + (dot !== undefined ? '<i class="sd ' + dot + '"></i>' : '') + '</span>';
  };
  // reduce la foto elegida a un JPEG cuadrado de 96 px (unos 3-6 KB) para poder enviarla a los amigos
  function resizeAvatar(file, cb) {
    var img = new Image(), url = URL.createObjectURL(file);
    img.onload = function () {
      try {
        var c = document.createElement('canvas'), N = 96; c.width = c.height = N; var x = c.getContext('2d');
        var m = Math.min(img.width, img.height), sx = (img.width - m) / 2, sy = (img.height - m) / 2;
        x.fillStyle = '#fff'; x.fillRect(0, 0, N, N); x.drawImage(img, sx, sy, m, m, 0, 0, N, N);
        var q = 0.8, out = c.toDataURL('image/jpeg', q);
        while (out.length > 9000 && q > 0.3) { q -= 0.1; out = c.toDataURL('image/jpeg', q); }
        cb(out);
      } catch (e) { cb(null); }
      URL.revokeObjectURL(url);
    };
    img.onerror = function () { URL.revokeObjectURL(url); cb(null); };
    img.src = url;
  }
  function renderFriends() {
    var badge = $('frBadge'); if (badge) { var nb = Fr.reqs.length + Fr.invs.length; badge.textContent = nb; badge.classList.toggle('on', nb > 0); }
    if (G.screen !== 'scrFriends') return;
    $('frMyCode').textContent = Fr.code ? Fr.code.slice(0, 3) + ' ' + Fr.code.slice(3) : (Fr.state === 'finding' ? '…' : '—');
    $('frVis').checked = Fr.vis; $('frAv').style.backgroundImage = 'url(' + (Fr.myAv || AV_DEF) + ')'; $('frPhotoDel').style.display = Fr.myAv ? '' : 'none';
    var nt = $('frNote'); if (Fr.err && !nt.dataset.own) { nt.textContent = Fr.err; nt.className = 'note err'; }
    var inRoom = !!(G.mp && G.roomCode && G.screen !== 'scrMain');
    var h = Fr.reqs.map(function (q) {
      return '<div class="frRow req">' + G.avatarHtml(Fr.avs[q.c]) + '<span class="frN"><b>' + esc(q.n || q.c) + '</b><small>Quiere ser tu amigo/a</small></span><button class="btn small primary" data-act="frAcc" data-c="' + q.c + '">Aceptar</button><button class="btn small ghost" data-act="frIgn" data-c="' + q.c + '">✕</button></div>';
    }).join('');
    $('frReqs').innerHTML = h;
    var list = Fr.list.slice().sort(function (a, b) { return (Fr.status(b.c).on ? 1 : 0) - (Fr.status(a.c).on ? 1 : 0) || String(a.n || a.c).localeCompare(String(b.n || b.c)); });
    $('frCount').textContent = list.length ? '(' + list.filter(function (f) { return Fr.status(f.c).on; }).length + ' en línea de ' + list.length + ')' : '';
    $('frList').innerHTML = list.length ? list.map(function (f) {
      var st = Fr.status(f.c), ss = frStatus(st), sent = frSent[f.c] && Date.now() - frSent[f.c] < 6000;
      var inv = st.on && inRoom ? '<button class="btn small ' + (sent ? 'ghost' : 'primary') + '" data-act="frInv" data-c="' + f.c + '">' + (sent ? 'Invitación enviada ✓' : 'Invitar a mi sala') + '</button>' : '';
      return '<div class="frRow">' + G.avatarHtml(Fr.avs[f.c], ss.dot) + '<span class="frN"><b>' + esc(st.n || f.n || f.c) + '</b><small>' + ss.txt + ' · ' + f.c.slice(0, 3) + ' ' + f.c.slice(3) + '</small></span>' + inv + '<button class="btn small ghost" data-act="frDel" data-c="' + f.c + '" aria-label="Quitar">✕</button></div>';
    }).join('') : '<p class="note">Todavía no tienes amigos agregados. Pásales tu código o escribe el suyo arriba.</p>';
  }
  Fr.cb = renderFriends;
  // v2.9: aviso dentro del juego cuando alguien te quiere agregar: tu decides si aceptar o rechazar
  var reqShown = null;
  function hideReq() { var b = $('reqBanner'); b.classList.remove('show'); reqShown = null; }
  function showReq(q) {
    var b = $('reqBanner'); reqShown = q;
    b.innerHTML = '<span>👥 <b>' + esc(q.n || 'Un jugador') + '</b> quiere agregarte como amigo</span><button class="btn small primary" id="reqYes">Aceptar</button><button class="btn small ghost" id="reqNo">Rechazar</button>';
    b.classList.add('show'); Audio.sfx('item');
  }
  Fr.onRequest = function (q) { if (G.mode !== 'race' && !reqShown) showReq(q); };
  setInterval(function () { // solicitudes que llegaron en plena carrera (o varias seguidas): se muestran al terminar
    if (reqShown && Fr.reqs.indexOf(reqShown) < 0) hideReq();
    if (!reqShown && G.mode !== 'race' && Fr.reqs.length) showReq(Fr.reqs[0]);
  }, 1200);
  function hideInvite() { var b = $('invBanner'); b.classList.remove('show'); invShown = null; clearTimeout(invT); }
  function showInvite(inv) {
    var b = $('invBanner'); invShown = inv;
    b.innerHTML = '<span>🐧 <b>' + esc(inv.n) + '</b> te invita a su sala <b>' + esc(inv.r) + '</b></span><button class="btn small primary" id="invYes">Unirme</button><button class="btn small ghost" id="invNo">✕</button>';
    b.classList.add('show'); Audio.sfx('item');
    clearTimeout(invT); invT = setTimeout(function () { Fr.dropInv(inv); hideInvite(); }, 30000);
  }
  Fr.onInvite = function (inv) { if (G.mode !== 'race' && !invShown) showInvite(inv); };
  setInterval(function () { // invitaciones que llegaron en plena carrera: se muestran al terminar
    if (!invShown && G.mode !== 'race' && Fr.invs.length) { var inv = Fr.invs[Fr.invs.length - 1]; if (Date.now() - inv.t < 60000) showInvite(inv); else Fr.dropInv(inv); }
  }, 1500);
  function joinInvite(inv) {
    Fr.dropInv(inv); hideInvite();
    if (G.mode === 'race') return;
    if (G.mp) { Voice.leave(true); Net.close(); G.mp = false; G.online = false; G.players = {}; }
    G.set.code = inv.r; saveSet(); G.nav = []; G.mp = true; G.online = true; G.roomCode = inv.r;
    toast('Entrando a la sala de ' + inv.n + '…', 2600);
    Net.joinOnline(inv.r);
  }
  function frShare() {
    if (!Fr.code) return;
    var txt = 'Agrégame en Penguin Slippery. Mi código de amigo: ' + Fr.code;
    try { if (navigator.share) { navigator.share({ text: txt }); return; } } catch (e) { }
    try { if (navigator.clipboard) { navigator.clipboard.writeText(Fr.code); toast('Código copiado'); return; } } catch (e) { }
    toast('Tu código: ' + Fr.code);
  }

  /* ---------------- acciones de UI ---------------- */
  var actions = {
    friends: function () { go('scrFriends'); },
    frCopy: frShare,
    frPhoto: function () { $('frFile').value = ''; $('frFile').click(); },
    frPhotoDel: function () { Fr.setAvatar(''); toast('Foto quitada'); },
    frAdd: function () { var n = $('frNote'); n.dataset.own = '1'; var e = Fr.add($('frIn').value); n.textContent = e || '¡Listo! Le avisamos para que te agregue también.'; n.className = 'note' + (e ? ' err' : ''); if (!e) $('frIn').value = ''; if (!Fr.enabled()) { n.textContent = 'Conectando…'; } },
    frDel: function (t) { Fr.remove(t.dataset.c); },
    frAcc: function (t) { Fr.acceptReq(t.dataset.c); },
    frIgn: function (t) { Fr.ignoreReq(t.dataset.c); },
    frInv: function (t) { var c = t.dataset.c; if (Fr.invite(c, G.roomCode)) { frSent[c] = Date.now(); renderFriends(); toast('Invitación enviada', 1800); setTimeout(renderFriends, 6200); } },

    solo: function () { G.trackMode = 'solo'; go('scrTracks'); },
    multi: function () { go('scrMulti'); },
    custom: function () { G.cfgSnap = JSON.stringify(G.cfg); go('scrCustom'); },
    customCancel: function () { if (G.cfgSnap) { try { G.cfg = PG.fixCfg(JSON.parse(G.cfgSnap)); saveCfg(); } catch (e) { } } Audio.sfx('click'); back(); },
    shop: function () { go('scrShop'); },
    wheel: function () { go('scrWheel'); },
    spin: function () { PG.Eco.spin(); },
    shopBuy: function (el) { PG.Eco.actions.shopBuy(el); },
    shopEq: function (el) { PG.Eco.actions.shopEq(el); },
    shopAdd: function (el) { PG.Eco.actions.shopAdd(el); },
    shopDel: function (el) { PG.Eco.actions.shopDel(el); },
    shopPack: function (el) { PG.Eco.actions.shopPack(el); },
    shopSet: function (el) { PG.Eco.actions.shopSet(el); },
    shopSetWear: function (el) { PG.Eco.actions.shopSetWear(el); },
    setWear: function (el) { var st = PG.Eco.setOf(el.dataset.s); if (!st) return; if (!PG.Eco.hasSet(st.id)) { toast('Cómpralo en la tienda 🪙' + st.price, 2200); return; } G.wearSet(st.id); },
    setShop: function () { go('scrShop'); },
    stats: function () { go('scrStats'); },
    statsReset: function () { if (G.statsAsk) { G.stats = blankStats(); saveStats(); G.statsAsk = false; $('scrStats').querySelector('[data-act=statsReset]').textContent = 'Borrar'; renderStats(); toast('Progreso borrado'); } else { G.statsAsk = true; $('scrStats').querySelector('[data-act=statsReset]').textContent = '¿Seguro? Toca otra vez'; setTimeout(function () { G.statsAsk = false; var b = $('scrStats').querySelector('[data-act=statsReset]'); if (b) b.textContent = 'Borrar'; }, 3000); } },
    settings: function () { go('scrSettings'); },
    privacy: function () { go('scrPrivacy'); },
    back: function () { back(); },
    trackGo: function () {
      if (G.trackMode === 'solo') { if (G.champSolo) champStartFirst([{ id: 'solo', name: G.cfg.name, cfg: G.cfg }], false); else G.startSolo(G.selTrack); }
      else { if (G.champSet.on) G.champSet.pick = G.champPick.slice(); else G.lobby.track = G.selTrack; sendLobby(); back(); renderLobby(); }
    },
    randomPeng: function () { var c = makeBotCfg(Math.random); c.name = G.cfg.name; G.cfg = PG.fixCfg(c); saveCfg(); buildCustomUI(); },
    hostRoom: hostRoom,
    joinIp: function () { joinRoom($('inIp').value); },
    tabNet: function () { showTab(false); },
    tabLan: function () { showTab(true); },
    hostOnline: hostOnline,
    joinCode: joinOnline,
    shareCode: shareCode,
    leave: leaveRoom,
    lobbyTrack: function () { G.trackMode = 'lobby'; G.selTrack = G.lobby.track; if (G.champSet.on) G.champPick = (G.champSet.pick || []).slice(); go('scrTracks'); },
    startRace: function () {
      if (G.myId === G.hostId) { hostStart(); return; }
      if (!G.ready[G.myId] && G.champSet.bets && !PG.Eco.canBet(G.champSet.stake)) { toast('Necesitas 🪙' + G.champSet.stake + ' para esta apuesta', 3000); return; }
      if (G.ready[G.myId]) delete G.ready[G.myId]; else G.ready[G.myId] = true;
      Net.send({ t: 'ready', v: G.ready[G.myId] ? 1 : 0 }); renderLobby();
    },
    kick: function (el) {
      var id = +el.dataset.id;
      if (G.kickArm !== id) { G.kickArm = id; clearTimeout(G.kickT); G.kickT = setTimeout(function () { G.kickArm = null; renderPlayers(); }, 2500); renderPlayers(); return; }
      G.kickArm = null; var nm = G.players[id] ? G.players[id].name : 'Jugador';
      Net.send({ t: 'kick', to: id }); chatSys('Expulsaste a ' + nm); toast(nm + ' fue expulsado'); renderPlayers();
    },
    chatEmoji: function () { G.pickOpen = !G.pickOpen; renderPicker(); },
    pkTab: function (el) { G.pickTab = el.dataset.t; renderPicker(); },
    pkEmoji: function (el) { var i = $('chatInput'); if (i.value.length < 138) i.value += el.dataset.e; },
    pkSt: function (el) { sendSticker(el.dataset.id); },
    pkBuy: function (el) { var r = PG.Eco.buyPack(el.dataset.p); toast(r.msg, 2200); if (r.ok) Audio.sfx('ability'); renderPicker(); },
    lTabP: function () { setLobbyTab('p'); },
    lTabC: function () { setLobbyTab('c'); setTimeout(function () { var i = $('chatInput'); if (i && !('ontouchstart' in window)) i.focus(); }, 50); },
    chatSend: sendChat,
    vJoin: function () { Voice.join(); },
    vLeave: function () { Voice.leave(); },
    vMic: function () { Voice.toggleMic(); },
    vDeaf: function () { Voice.toggleDeaf(); },
    vPeer: function (el) { Voice.mutePeer(+el.dataset.id); },
    champDone: champDone,
    champAgain: champAgain,
    nextRace: function () {
      if (G.champ) { G.resBackSent = true; champAdvance(); return; }
      if (G.mp) { if (G.myId === G.hostId) { G.lobby.track = (G.trackIdx + 1) % PG.TRACKS.length; sendLobby(); Net.send({ t: 'back' }); onNetMsg({ t: 'back' }); } return; }
      var next = (G.trackIdx + 1) % PG.TRACKS.length; G.selTrack = next; $('scrResults').classList.remove('show'); G.startSolo(next);
    },
    repeatRace: function () {
      if (G.mp) { if (G.myId === G.hostId) { G.lobby.track = G.trackIdx; sendLobby(); Net.send({ t: 'back' }); onNetMsg({ t: 'back' }); } return; }
      $('scrResults').classList.remove('show'); G.startSolo(G.trackIdx);
    },
    resReady: function () {
      if (!G.mp || G.myId === G.hostId) return;
      if (G.ready[G.myId]) delete G.ready[G.myId]; else G.ready[G.myId] = true;
      Net.send({ t: 'ready', v: G.ready[G.myId] ? 1 : 0 }); refreshResults();
    },
    resLobby: function () { if (G.mp && G.myId === G.hostId && !G.resBackSent) { G.resBackSent = true; Net.send({ t: 'back' }); onNetMsg({ t: 'back' }); } },
    toMenu: function () { $('scrResults').classList.remove('show'); quitRace(true); },
    resume: resumeRace,
    quitRace: function () { $('scrPause').classList.remove('show'); G.paused = false; quitRace(true); }
  };
  function bindUI() {
    $('frVis').addEventListener('change', function () { Fr.setVisible($('frVis').checked); });
    $('frFile').addEventListener('change', function () {
      var f = this.files && this.files[0]; if (!f) return;
      resizeAvatar(f, function (u) { if (u && Fr.setAvatar(u)) { toast('Foto actualizada'); Fr.start(); } else toast('No se pudo usar esa imagen'); });
    });
    $('frIn').addEventListener('keydown', function (e) { if (e.key === 'Enter') actions.frAdd(); });
    $('reqBanner').addEventListener('click', function (e) {
      var id = e.target && e.target.id, q = reqShown; if (!q) return;
      if (id === 'reqYes') { Audio.init(); Audio.sfx('click'); Fr.acceptReq(q.c); hideReq(); toast('¡Ahora eres amigo de ' + (q.n || 'ese jugador') + '!', 2600); }
      else if (id === 'reqNo') { Audio.sfx('click'); Fr.ignoreReq(q.c); hideReq(); }
    });
    $('invBanner').addEventListener('click', function (e) { var id = e.target && e.target.id; if (id === 'invYes' && invShown) { Audio.init(); Audio.sfx('click'); joinInvite(invShown); } else if (id === 'invNo' && invShown) { var iv = invShown; Fr.dropInv(iv); hideInvite(); } });
    $('screens').addEventListener('click', function (e) {
      Audio.init();
      var t = e.target.closest ? e.target.closest('[data-act]') : null;
      if (t) { Audio.sfx('click'); var a = actions[t.dataset.act]; if (a) a(t); return; }
      var avEl = e.target.closest ? e.target.closest('.av') : null; // v3.2: tocar una foto de perfil (la mia o la de un amigo) la muestra en grande
      if (avEl && (G.screen === 'scrFriends' || G.screen === 'scrStats' || G.screen === 'scrLobby')) {
        var bgi = avEl.style.backgroundImage || (avEl.id === 'frAv' ? $('frAv').style.backgroundImage : ''), row = avEl.closest('.frRow'), nm = row ? (row.querySelector('.frN b') || {}).textContent : (avEl.id === 'frAv' ? G.cfg.name : '');
        if (bgi) { $('avBig').style.backgroundImage = bgi; $('avName').textContent = nm || ''; $('avBox').classList.add('show'); Audio.sfx('click'); return; }
      }
      var card = e.target.closest ? e.target.closest('.tcard') : null;
      if (card) {
        var cn = champCtx(), ci = +card.dataset.i;
        if (cn) { var pk = G.champPick.indexOf(ci); if (pk >= 0) G.champPick.splice(pk, 1); else if (G.champPick.length < cn) G.champPick.push(ci); else toast('Ya elegiste ' + cn + ' mapas', 1600); markPicks(); updTrackInfo(); carCenter(ci); Audio.sfx('click'); return; }
        G.selTrack = ci; markPicks(); updTrackInfo(); carCenter(ci); Audio.sfx('click'); return;
      }
      var room = e.target.closest ? e.target.closest('.room') : null;
      if (room) { joinRoom(room.dataset.ip); }
    });
    document.addEventListener('pointerdown', function () { Audio.init(); Audio.retry(); }, { once: false, passive: true });
    $('inName').addEventListener('input', function (e) { G.cfg.name = e.target.value.slice(0, 12) || 'Pingu'; saveCfg(); });
    $('chkBots').addEventListener('change', function (e) { G.lobby.bots = e.target.checked; sendLobby(); });
    $('inTurn').addEventListener('change', function (e) {
      var v = String(e.target.value || '').trim();
      try { if (v) localStorage.setItem('pg_turn', v); else localStorage.removeItem('pg_turn'); } catch (er) { }
      toast(v ? 'Servidor TURN guardado' : 'Usando el servidor TURN predeterminado');
    });
    $('inBroker').addEventListener('change', function (e) {
      var v = String(e.target.value || '').trim();
      try { if (v) localStorage.setItem('pg_broker', v); else localStorage.removeItem('pg_broker'); } catch (er) { }
      toast(v ? 'Servidor online guardado' : 'Usando servidores públicos');
    });
    $('screens').addEventListener('click', function (e) {
      var sb = e.target.closest ? e.target.closest('#stakeRow button') : null;
      if (sb && !sb.disabled) { Audio.sfx('click'); G.champSet.stake = +sb.dataset.st; champSetChange(); return; }
      var b = e.target.closest ? e.target.closest('.segDiff button') : null; if (!b || b.disabled) return;
      if (b.dataset.m) { // modo: carrera / campeonato
        Audio.sfx('click');
        if (G.trackMode === 'solo' && b.parentNode.id === 'segModeSolo') { G.champSolo = b.dataset.m === 'r' ? 0 : (b.dataset.m === 'm' ? 3 : 5); G.champPick = []; renderModeSolo(); markPicks(); }
        else if (G.myId === G.hostId) { G.champSet.on = b.dataset.m !== 'r'; if (G.champSet.on) G.champSet.n = b.dataset.m === 'm' ? 3 : 5; G.champPick = G.champPick.slice(0, G.champSet.n); champSetChange(); if (G.screen === 'scrTracks') { renderModeSolo(); markPicks(); } }
        return;
      }
      var d = +b.dataset.d, id = b.parentNode.id; Audio.sfx('click');
      if (id === 'segDiffSolo') { G.set.diff = d; saveSet(); renderDiff(id, d, true); }
      else { G.lobby.diff = d; G.set.diff = d; saveSet(); sendLobby(); renderDiff(id, d, true); }
    });
    carInit();
    $('chkBets').addEventListener('change', function (e) { if (G.myId !== G.hostId) { e.target.checked = !!G.champSet.bets; return; } G.champSet.bets = e.target.checked; champSetChange(); });
    $('chatInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); sendChat(); } });
    $('btnMic').addEventListener('pointerdown', function (e) { Voice.toggleMic(); e.preventDefault(); });
    function syncSet() { $('chkSound').checked = $('pChkSound').checked = G.set.sound; $('chkMusic').checked = $('pChkMusic').checked = G.set.music; markQuality(); }
    G.syncSet = syncSet;
    $('pChkSound').addEventListener('change', function (e) { G.set.sound = e.target.checked; Audio.setOn(G.set.sound); saveSet(); syncSet(); });
    $('pChkMusic').addEventListener('change', function (e) { G.set.music = e.target.checked; Audio.setMusicOn(G.set.music); saveSet(); syncSet(); });
    $('pSegQuality').addEventListener('click', function (e) { var q = e.target.dataset && e.target.dataset.q; if (q !== undefined) { G.set.quality = +q; saveSet(); markQuality(); G.R.resize(G.set.quality); } });
    $('chkAva').addEventListener('change', function (e) { G.set.ava = e.target.checked; saveSet(); });
    $('avBox').addEventListener('click', function () { $('avBox').classList.remove('show'); });
    $('chkBlur').addEventListener('change', function (e) { G.set.blurFx = e.target.checked; saveSet(); });
    $('chkMusic').addEventListener('change', function (e) { G.set.music = e.target.checked; Audio.setMusicOn(G.set.music); saveSet(); });
    document.addEventListener('visibilitychange', function () { Audio.pauseAll(document.hidden); });
    $('chkSound').addEventListener('change', function (e) { G.set.sound = e.target.checked; Audio.setOn(G.set.sound); saveSet(); });
    $('segQuality').addEventListener('click', function (e) { var q = e.target.dataset && e.target.dataset.q; if (q !== undefined) { G.set.quality = +q; saveSet(); markQuality(); G.R.resize(G.set.quality); } });
    window.addEventListener('resize', function () { if (G.R) G.R.resize(G.set.quality); });
    setupTouch();
  }

  /* ---------------- arranque ---------------- */
  function boot() {
    $('verTxt').textContent = VERSION + (Net.native ? ' · app' : ' · web');
    Audio.on = G.set.sound; Audio.musicOn = G.set.music;
    G.lobby.diff = G.set.diff;
    bindUI();
    showLoading('Preparando el hielo…');
    setTimeout(function () {
      try {
        G.R = new PG.Renderer($('gl')); G.R.resize(G.set.quality);
        PG.TRACKS.forEach(function (d) {
          var T = PG.buildTrack(d, { noMesh: true });
          G.tracksInfo.push({ name: d.name, type: d.type, theme: d.theme, len: T.type === 'circuit' ? T.L : T.D, thumb: T.thumb });
        });
        loadTrack(0);
        G.camMode = 'demo'; G.mode = 'menu';
        ensureDemo();
        G.nav = []; requestAnimationFrame(frame);
        runIntro();
      } catch (err) {
        $('loadTxt').textContent = 'Error: ' + (err && err.message ? err.message : err);
        if (window.console) console.error(err);
      }
    }, 60);
  }
  function runIntro() {
    var el = $('scrIntro'), done = false;
    show('scrIntro'); G.screen = 'scrIntro';
    function fin() {
      if (done) return; done = true; el.classList.add('out');
      setTimeout(function () { el.classList.remove('out'); G.nav = []; show('scrMain'); onScreen('scrMain'); try { Fr.autostart(); } catch (e) { } }, 550);
    }
    el.addEventListener('click', fin); setTimeout(fin, 3300);
  }
  G.boot = boot;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
