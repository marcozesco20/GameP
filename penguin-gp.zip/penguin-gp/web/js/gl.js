/* Renderer WebGL 1 minimo para el estilo low-poly (sin librerias externas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var m4 = PG.m4;

  var PREC = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';

  var VS_MAIN = [
    'attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uTint; uniform vec3 uSun; uniform vec3 uSunCol; uniform vec3 uAmb; uniform vec3 uGnd; uniform vec3 uCam; uniform vec2 uFog;',
    'varying vec3 vCol; varying float vFog; varying vec3 vN; varying vec3 vWp; varying vec4 vB;',
    'void main(){',
    ' vec4 wp = uModel * vec4(aPos,1.0);',
    ' vec3 n = normalize(mat3(uModel[0].xyz,uModel[1].xyz,uModel[2].xyz) * aNor);',
    ' float l = max(dot(n,uSun),0.0);',
    ' vec3 amb = mix(uGnd,uAmb,n.y*0.5+0.5);',
    ' vec3 base = aCol.rgb*uTint;',
    ' vCol = mix(base*(amb+uSunCol*l), base, aCol.a);',
    ' vN = n; vWp = wp.xyz; vB = vec4(base, aCol.a);',
    ' vFog = clamp((length(wp.xyz-uCam)-uFog.x)/(uFog.y-uFog.x),0.0,1.0);',
    ' gl_Position = uVP*wp;',
    '}'].join('\n');
  // v3.2: brillo por pixel (hielo con reflejo del cielo, destello del sol y chispas; nieve con destellos; luz de borde suave en todo)
  var FS_MAIN = PREC + [
    'uniform vec3 uFogC; uniform float uAlpha; uniform vec3 uCamF; uniform vec3 uSunF; uniform vec3 uSunColF; uniform float uTime; uniform float uGloss; uniform float uCkF;',
    'varying vec3 vCol; varying float vFog; varying vec3 vN; varying vec3 vWp; varying vec4 vB;',
    'float h3(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }',
    'float vn(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);',
    ' return mix(mix(mix(h3(i),h3(i+vec3(1.,0.,0.)),f.x),mix(h3(i+vec3(0.,1.,0.)),h3(i+vec3(1.,1.,0.)),f.x),f.y),',
    '            mix(mix(h3(i+vec3(0.,0.,1.)),h3(i+vec3(1.,0.,1.)),f.x),mix(h3(i+vec3(0.,1.,1.)),h3(i+vec3(1.,1.,1.)),f.x),f.y),f.z); }',
    'void main(){',
    ' vec3 col = vCol;',
    ' if(uGloss > 0.5 && vFog < 0.97){',
    '  vec3 N = normalize(vN); vec3 Vv = uCamF - vWp; float dist = length(Vv); Vv /= max(dist,0.001);',
    '  float ice0 = smoothstep(0.06,0.26,vB.b - vB.r) * smoothstep(0.42,0.66,vB.b) * (1.0 - vB.a);',
    '  if(ice0 > 0.05 && dist < 70.0){',
    '   float df = 1.0 - smoothstep(25.0,70.0,dist);',
    '   float na = vn(vWp*0.7), nb = vn(vWp*2.3 + 5.0), nc = vn(vWp*(vec3(5.1,1.3,5.1)) + 11.0);',
    '   float vein = pow(1.0 - abs(nb*2.0-1.0), 7.0);',
    '   float tex = (na-0.5)*0.26 + vein*0.13 + (nc-0.5)*0.10;',
    '   col *= 1.0 + ice0*tex*df;',
    '   col += vec3(0.55,0.85,1.0)*vein*ice0*df*(0.05 + 0.20*uCkF);',
    '   N = normalize(N + (vec3(na,nb,nc)-0.5)*0.20*ice0*df);',
    '  }',
    '  float up = smoothstep(0.5,0.92,N.y);',
    '  float ice = smoothstep(0.06,0.26,vB.b - vB.r) * smoothstep(0.42,0.66,vB.b) * (1.0 - vB.a);',
    '  float snow = smoothstep(0.80,0.95,min(vB.r,min(vB.g,vB.b))) * (1.0 - vB.a);',
    '  float nv = max(dot(N,Vv),0.0);',
    '  vec3 H = normalize(uSunF + Vv); float nh = max(dot(N,H),0.0);',
    '  float spec = pow(nh,56.0)*0.85 + pow(nh,9.0)*0.12;',
    '  float fr = pow(1.0 - nv, 4.0);',
    '  col += uSunColF * spec * (ice + snow*0.18) * (0.3 + 0.7*up) * 1.15;',
    '  col = mix(col, uFogC*1.06 + 0.05, fr * ice * 0.42 * up);',
    '  float rim = pow(1.0 - nv, 2.6) * 0.11 * (1.0 - 0.75*up) * (1.0 - vB.a) * (1.0 - smoothstep(40.0,140.0,dist));',
    '  col += (uFogC*0.8 + 0.2) * rim;',
    '  col += vec3(0.05,0.30,0.55) * ice * uCkF * (0.30 + 0.70*pow(1.0-nv,1.6)) * (1.0 - smoothstep(30.0,90.0,dist));',
    '  vec2 gq = vWp.xz*2.4 + vWp.y*0.6; vec2 gp = floor(gq);',
    '  float h1 = fract(sin(dot(gp,vec2(12.9898,78.233)))*43758.5453);',
    '  vec2 gc = fract(gq) - vec2(0.5 + 0.3*(fract(h1*91.7)-0.5), 0.5 + 0.3*(fract(h1*57.3)-0.5));',
    '  float tw = step(0.975,h1) * smoothstep(0.17,0.0,length(gc)) * (0.45 + 0.55*sin(uTime*5.0 + h1*60.0));',
    '  col += vec3(1.0,1.0,1.0) * tw * (ice*0.65 + snow*0.5) * up * (1.0 - smoothstep(25.0,80.0,dist)) * 0.8;',
    '  float vv = sin(vWp.x*0.31 + sin(vWp.z*0.23)*2.0) * sin(vWp.z*0.27 - sin(vWp.x*0.19)*1.7);',
    '  col *= 1.0 + ice*0.05*vv;',
    ' }',
    ' gl_FragColor = vec4(mix(col,uFogC,vFog), uAlpha);',
    '}'].join('\n');

  // v3.4: shader propio de los escudos (cristal con reflejos / plasma con rayos / burbuja brillante)
  var VS_SHD = [
    'attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uCam; uniform vec2 uFog;',
    'varying vec3 vN; varying vec3 vWp; varying vec3 vL; varying float vFog;',
    'void main(){ vec4 wp = uModel * vec4(aPos,1.0); vN = normalize(mat3(uModel[0].xyz,uModel[1].xyz,uModel[2].xyz) * aNor); vWp = wp.xyz; vL = aPos + aNor*0.0 + aCol.rgb*0.0;',
    ' vFog = clamp((length(wp.xyz-uCam)-uFog.x)/(uFog.y-uFog.x),0.0,1.0); gl_Position = uVP*wp; }'].join('\n');
  var FS_SHD = PREC + [
    'uniform vec3 uCamF; uniform vec3 uSunF; uniform vec3 uFogC; uniform float uTime; uniform float uK; uniform float uSty;',
    'varying vec3 vN; varying vec3 vWp; varying vec3 vL; varying float vFog;',
    'float h3(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }',
    'float vn(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);',
    ' return mix(mix(mix(h3(i),h3(i+vec3(1.,0.,0.)),f.x),mix(h3(i+vec3(0.,1.,0.)),h3(i+vec3(1.,1.,0.)),f.x),f.y),',
    '            mix(mix(h3(i+vec3(0.,0.,1.)),h3(i+vec3(1.,0.,1.)),f.x),mix(h3(i+vec3(0.,1.,1.)),h3(i+vec3(1.,1.,1.)),f.x),f.y),f.z); }',
    'float win(vec3 r, vec2 c, vec2 hs){ vec2 d = abs(r.xy - c) - hs; return smoothstep(0.035,0.0,max(d.x,d.y)); }',
    'void main(){',
    ' vec3 N = normalize(vN); float back = 1.0; if(!gl_FrontFacing){ N = -N; back = 0.55; }',
    ' vec3 V = normalize(uCamF - vWp); float nv = clamp(dot(N,V),0.0,1.0);',
    ' vec3 R = reflect(-V,N); vec3 H = normalize(uSunF + V); float nh = max(dot(N,H),0.0);',
    ' vec3 pl = normalize(vL); float T = uTime;',
    ' vec3 col; float a;',
    ' if(uSty < 0.5){', // cristal azul
    '  float fr = pow(1.0-nv,2.3);',
    '  vec3 sky = mix(vec3(0.45,0.72,1.0), vec3(0.95,0.99,1.0), R.y*0.5+0.5);',
    '  vec3 irid = 0.5+0.5*cos(6.2832*(nv*1.1+vec3(0.0,0.33,0.67)));',
    '  float cau = 1.0 - abs(vn(pl*3.2+vec3(0.0,T*0.45,0.0))*2.0-1.0); cau = pow(cau,7.0);',
    '  float sp = pow(nh,140.0)*1.6 + pow(nh,18.0)*0.18;',
    '  float w = win(R,vec2(0.42,0.46),vec2(0.17,0.09)) + 0.6*win(R,vec2(-0.32,0.30),vec2(0.07,0.14));',
    '  col = vec3(0.30,0.62,0.98)*(0.42+0.25*nv) + sky*fr*0.85 + irid*fr*0.22 + vec3(0.7,0.95,1.0)*cau*0.22*(0.4+fr) + vec3(1.0)*(sp+w*0.8);',
    '  a = 0.06 + fr*0.62 + cau*0.08 + sp*0.8 + w*0.55;',
    ' } else if(uSty < 1.5){', // plasma electrico
    '  float fr = pow(1.0-nv,1.8);',
    '  float n1 = vn(pl*3.1 + vec3(T*0.9, T*0.6, -T*0.7)), n2 = vn(pl*6.3 + vec3(-T*1.4, T*1.1, T*0.8));',
    '  float r1 = pow(1.0-abs(n1*2.0-1.0), 9.0), r2 = pow(1.0-abs(n2*2.0-1.0), 12.0);',
    '  float fl = 0.65 + 0.35*step(0.5, fract(sin(floor(T*14.0)*12.9898)*43758.5453));',
    '  float core = pow(nv,2.2);',
    '  col = vec3(1.0,0.62,0.10)*(0.30*core + 0.55*fr) + vec3(1.0,0.93,0.55)*(r1*1.15 + r2*0.8)*fl + vec3(1.0,1.0,0.85)*pow(nh,60.0)*0.5;',
    '  a = 0.10 + fr*0.50 + (r1*0.95 + r2*0.65)*fl;',
    ' } else {', // burbuja rosa brillante
    '  float fr = pow(1.0-nv,2.1);',
    '  float sw = vn(pl*2.2 + vec3(T*0.35, -T*0.25, T*0.3));',
    '  float sp = pow(nh,160.0)*1.9 + pow(nh,22.0)*0.22;',
    '  float w = win(R,vec2(0.36,0.50),vec2(0.20,0.10)) + 0.5*win(R,vec2(-0.40,0.18),vec2(0.05,0.16));',
    '  vec3 body = mix(vec3(0.82,0.12,0.50), vec3(1.0,0.38,0.74), 0.5+0.5*N.y);',
    '  col = body*(0.55+0.35*nv+0.18*sw) + vec3(1.0,0.72,0.92)*fr*0.9 + vec3(1.0)*(sp+w*0.85);',
    '  a = 0.13 + fr*0.52 + sw*0.06 + sp*0.8 + w*0.6;',
    ' }',
    ' a = clamp(a*uK*back, 0.0, 0.92);',
    ' gl_FragColor = vec4(mix(col, uFogC, vFog*0.85), a*(1.0-vFog*0.6));',
    '}'].join('\n');
  // v3.5: post-proceso (resplandor/bloom, antialiasing FXAA, curva de color suave y vineta)
  var VS_PP = 'attribute vec2 aPos; varying vec2 vUv; void main(){ vUv = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }';
  var FS_BRIGHT = PREC + 'uniform sampler2D uTex; varying vec2 vUv; void main(){ vec3 c = texture2D(uTex,vUv).rgb; float m = max(c.r,max(c.g,c.b)), ch = m - min(c.r,min(c.g,c.b)); float k = smoothstep(0.50,0.80,ch) * smoothstep(0.78,0.97,m); gl_FragColor = vec4(c*k*1.25, 1.0); }';
  var FS_BLUR = PREC + 'uniform sampler2D uTex; uniform vec2 uDir; varying vec2 vUv; void main(){ vec3 c = texture2D(uTex,vUv).rgb*0.2270; c += (texture2D(uTex,vUv+uDir*1.3846).rgb + texture2D(uTex,vUv-uDir*1.3846).rgb)*0.3162; c += (texture2D(uTex,vUv+uDir*3.2308).rgb + texture2D(uTex,vUv-uDir*3.2308).rgb)*0.0703; gl_FragColor = vec4(c,1.0); }';
  var FS_COMP = PREC + [
    'uniform sampler2D uScene; uniform sampler2D uBloom; uniform vec2 uPx; uniform float uBl; uniform float uVig; varying vec2 vUv;',
    'float lum(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }',
    'void main(){',
    ' vec3 cM = texture2D(uScene,vUv).rgb;',
    ' vec3 cN = texture2D(uScene,vUv+vec2(0.0,uPx.y)).rgb, cS = texture2D(uScene,vUv-vec2(0.0,uPx.y)).rgb, cE = texture2D(uScene,vUv+vec2(uPx.x,0.0)).rgb, cW = texture2D(uScene,vUv-vec2(uPx.x,0.0)).rgb;',
    ' float lM = lum(cM), lN = lum(cN), lS = lum(cS), lE = lum(cE), lW = lum(cW);',
    ' float lMin = min(lM,min(min(lN,lS),min(lE,lW))), lMax = max(lM,max(max(lN,lS),max(lE,lW)));',
    ' float con = lMax - lMin; vec3 col = cM;',
    ' if(con > max(0.05, lMax*0.125)){',
    '  vec2 d = vec2(-(lN-lS), (lE-lW)); float rd = 1.0/(min(abs(d.x),abs(d.y)) + max((lN+lS+lE+lW)*0.03125,0.0078)+0.0001); d = clamp(d*rd, -4.0, 4.0)*uPx;',
    '  vec3 a = 0.5*(texture2D(uScene,vUv+d*(1.0/3.0-0.5)).rgb + texture2D(uScene,vUv+d*(2.0/3.0-0.5)).rgb);',
    '  vec3 b = a*0.5 + 0.25*(texture2D(uScene,vUv+d*-0.5).rgb + texture2D(uScene,vUv+d*0.5).rgb);',
    '  float lb = lum(b); col = (lb < lMin || lb > lMax) ? a : b;',
    ' }',
    ' col += texture2D(uBloom,vUv).rgb * uBl;',
    ' float l = lum(col); col = mix(vec3(l), col, 1.10);',
    ' col = col*col*(3.0-2.0*col)*0.22 + col*0.78;',
    ' vec2 q = vUv-0.5; col *= 1.0 - uVig*smoothstep(0.30,0.80,length(q*vec2(1.0,0.85)));',
    ' gl_FragColor = vec4(col,1.0);',
    '}'].join('\n');
  var VS_SKY = 'attribute vec2 aPos; varying vec2 vP; void main(){ vP=aPos; gl_Position=vec4(aPos,0.9999,1.0); }';
  var FS_SKY = PREC + [
    'uniform vec3 uTop; uniform vec3 uHor; uniform vec3 uBot; uniform vec3 uFwd; uniform vec3 uRight; uniform vec3 uUp; uniform vec2 uTan;',
    'uniform vec3 uSunDir; uniform vec3 uSunCol; uniform float uTime; uniform float uAur; uniform float uSt; uniform vec3 uStC; varying vec2 vP;',
    'void main(){',
    ' vec3 d = normalize(uFwd + uRight*vP.x*uTan.x + uUp*vP.y*uTan.y);',
    ' float h = d.y; vec3 col;',
    ' if(h>0.0) col = mix(uHor,uTop,pow(h,0.5)); else col = mix(uHor,uBot,clamp(-h*4.0,0.0,1.0));',
    ' float sd = max(dot(d,uSunDir),0.0); col += uSunCol*(pow(sd,64.0)*0.7 + pow(sd,5.0)*0.10);',
    ' if(uAur>0.0){',
    '  float a = atan(d.x,d.z);',
    '  float b1 = sin(a*3.0+uTime*0.15+sin(h*9.0+uTime*0.3)*1.6)*0.5+0.5;',
    '  float b2 = sin(a*5.0-uTime*0.11+h*14.0)*0.5+0.5;',
    '  float mask = smoothstep(0.04,0.30,h)*(1.0-smoothstep(0.42,0.95,h));',
    '  col += mix(vec3(0.10,1.0,0.50),vec3(0.60,0.30,1.0),b2)*b1*b1*mask*0.75*uAur;',
    '  float st = step(0.9965, fract(sin(dot(floor(d.xz/(abs(h)+0.2)*90.0),vec2(12.9898,78.233)))*43758.5453));',
    '  col += vec3(st)*smoothstep(0.1,0.4,h)*0.8*uAur;',
    ' }',
    ' col = mix(col, uStC, uSt);',
    ' gl_FragColor = vec4(col,1.0);',
    '}'].join('\n');

  var VS_PART = [
    'attribute vec3 aPos; attribute float aSize; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform float uScale; varying vec4 vCol;',
    'void main(){ gl_Position = uVP*vec4(aPos,1.0); vCol=aCol; gl_PointSize = clamp(aSize*uScale/max(gl_Position.w,0.5),1.0,96.0); }'].join('\n');
  var FS_PART = PREC + [
    'varying vec4 vCol;',
    'void main(){ float d = length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; float k = 1.0-d*2.0; gl_FragColor = vec4(vCol.rgb*(1.0+0.55*k*k*k), vCol.a*smoothstep(0.5,0.08,d)); }'].join('\n');

  var VS_SNOW = [
    'attribute vec3 aOff; uniform mat4 uVP; uniform vec3 uCam; uniform float uTime; uniform float uScale; uniform vec3 uWind; uniform float uBox;',
    'varying float vA;',
    'void main(){',
    ' vec3 p = fract(aOff + vec3(uWind.x*uTime, -uWind.y*uTime*(0.6+aOff.x), uWind.z*uTime)/uBox);',
    ' vec3 w = uCam + (p-0.5)*vec3(uBox, uBox*0.6, uBox);',
    ' gl_Position = uVP*vec4(w,1.0);',
    ' vA = 1.0 - smoothstep(0.35,0.5,length(p-0.5));',
    ' gl_PointSize = clamp((0.18+aOff.y*0.1)*uScale/max(gl_Position.w,0.5),1.0,10.0);',
    '}'].join('\n');
  var FS_SNOW = PREC + 'uniform float uAmt; varying float vA; void main(){ float d=length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; float k=1.0-d*2.0; gl_FragColor=vec4(0.93+0.07*k,0.97+0.03*k,1.0,vA*(0.35+0.6*k)*uAmt); }';

  function Renderer(canvas) {
    var aa = (window.devicePixelRatio || 1) < 2;
    var gl = canvas.getContext('webgl', { antialias: aa, alpha: false, depth: true, powerPreference: 'high-performance' }) ||
      canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL no disponible');
    this.gl = gl; this.canvas = canvas;
    this.scale = 1; this.dyn = 1; this.stormK = 0; this.drawn = 0; this.culled = 0;
    this.planes = new Float32Array(24);
    this.vp = m4.create(); this.view = m4.create(); this.proj = m4.create(); this.tmp = m4.create();
    this.main = this._prog(VS_MAIN, FS_MAIN, ['aPos', 'aNor', 'aCol']);
    this.sky = this._prog(VS_SKY, FS_SKY, ['aPos']);
    this.part = this._prog(VS_PART, FS_PART, ['aPos', 'aSize', 'aCol']);
    this.snow = this._prog(VS_SNOW, FS_SNOW, ['aOff']);
    this.shd = this._prog(VS_SHD, FS_SHD, ['aPos', 'aNor', 'aCol']);
    this.ppBright = this._prog(VS_PP, FS_BRIGHT, ['aPos']); this.ppBlur = this._prog(VS_PP, FS_BLUR, ['aPos']); this.ppComp = this._prog(VS_PP, FS_COMP, ['aPos']);
    this.pp = null; this.ppOn = false;
    this.skyBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    this.partBuf = gl.createBuffer(); this.partCap = 2600;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf); gl.bufferData(gl.ARRAY_BUFFER, this.partCap * 32, gl.DYNAMIC_DRAW);
    this.partArr = new Float32Array(this.partCap * 8);
    this.nFlakes = 1800;
    var fl = new Float32Array(this.nFlakes * 3), rr = PG.rng(99);
    for (var i = 0; i < fl.length; i++) fl[i] = rr();
    this.snowBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.bufferData(gl.ARRAY_BUFFER, fl, gl.STATIC_DRAW);
    this.enabled = 0;
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.env = null;
    this.eye = [0, 0, 0];
  }
  Renderer.prototype._prog = function (vs, fs, attrs) {
    var gl = this.gl;
    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s));
      return s;
    }
    var p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
    for (var i = 0; i < attrs.length; i++) gl.bindAttribLocation(p, i, attrs[i]);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link: ' + gl.getProgramInfoLog(p));
    var u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (i = 0; i < n; i++) { var info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
    return { p: p, u: u };
  };
  Renderer.prototype._attribs = function (n) {
    var gl = this.gl;
    for (var i = 0; i < 3; i++) {
      if (i < n && i >= this.enabled) gl.enableVertexAttribArray(i);
      else if (i >= n && i < this.enabled) gl.disableVertexAttribArray(i);
    }
    this.enabled = n;
  };
  Renderer.prototype.resize = function (quality) {
    var c = this.canvas, dpr = window.devicePixelRatio || 1;
    var q = (quality === 0 ? 0.55 : (quality === 1 ? 0.8 : 1.0)) * this.dyn;
    this.gloss = (quality === 0 || this.dyn < 0.7) ? 0 : 1; // v3.2: el brillo por pixel se apaga en calidad baja o si el telefono va justo
    var w = Math.max(2, Math.floor(c.clientWidth * Math.min(dpr, 2) * q)), h = Math.max(2, Math.floor(c.clientHeight * Math.min(dpr, 2) * q));
    // limite de pixeles para no ahogar telefonos de gama baja
    var maxPix = quality === 0 ? 420000 : (quality === 1 ? 800000 : 1500000);
    if (w * h > maxPix) { var k = Math.sqrt(maxPix / (w * h)); w = Math.floor(w * k); h = Math.floor(h * k); }
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    this._ppSetup(quality === 2 && this.dyn >= 0.7 && this.postFx !== false, c.width, c.height);
    this.gl.viewport(0, 0, c.width, c.height);
    this.aspect = c.width / c.height;
  };
  Renderer.prototype._ppTex = function (w, h) {
    var gl = this.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  };
  Renderer.prototype._ppFree = function () {
    var gl = this.gl, p = this.pp; if (!p) return;
    gl.deleteFramebuffer(p.fbo); gl.deleteTexture(p.tex); gl.deleteRenderbuffer(p.rb);
    gl.deleteFramebuffer(p.fa); gl.deleteTexture(p.ta); gl.deleteFramebuffer(p.fb); gl.deleteTexture(p.tb);
    this.pp = null;
  };
  // framebuffer de escena + dos de resplandor a 1/4 de resolucion; si algo falla se queda sin post-proceso
  Renderer.prototype._ppSetup = function (on, w, h) {
    var gl = this.gl;
    if (!on) { if (this.pp) this._ppFree(); this.ppOn = false; return; }
    if (this.pp && this.pp.w === w && this.pp.h === h) { this.ppOn = true; return; }
    this._ppFree();
    try {
      var bw = Math.max(8, w >> 2), bh = Math.max(8, h >> 2), p = { w: w, h: h, bw: bw, bh: bh };
      p.tex = this._ppTex(w, h); p.fbo = gl.createFramebuffer(); p.rb = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, p.rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, w, h);
      gl.bindFramebuffer(gl.FRAMEBUFFER, p.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.tex, 0);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, p.rb);
      var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      p.ta = this._ppTex(bw, bh); p.fa = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, p.fa); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.ta, 0);
      ok = ok && gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      p.tb = this._ppTex(bw, bh); p.fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, p.fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.tb, 0);
      ok = ok && gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      if (!ok) { this.pp = p; this._ppFree(); this.ppOn = false; this.postFx = false; return; }
      this.pp = p; this.ppOn = true;
    } catch (e) { this.pp = null; this.ppOn = false; this.postFx = false; gl.bindFramebuffer(gl.FRAMEBUFFER, null); }
  };
  // al terminar la escena: resplandor + FXAA + color + vineta hacia la pantalla
  Renderer.prototype.finish = function () {
    if (!this.ppOn || !this.pp) return;
    var gl = this.gl, p = this.pp, c = this.canvas, self = this;
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.BLEND);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf); this._attribs(1); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    function pass(prog, fbo, w, h, tex0, tex1, setU) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo); gl.viewport(0, 0, w, h); gl.useProgram(prog.p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex0);
      if (tex1) { gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tex1); gl.activeTexture(gl.TEXTURE0); }
      setU(prog.u); gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    pass(this.ppBright, p.fa, p.bw, p.bh, p.tex, null, function (u) { gl.uniform1i(u.uTex, 0); });
    pass(this.ppBlur, p.fb, p.bw, p.bh, p.ta, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 1 / p.bw, 0); });
    pass(this.ppBlur, p.fa, p.bw, p.bh, p.tb, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 0, 1 / p.bh); });
    pass(this.ppBlur, p.fb, p.bw, p.bh, p.ta, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 1.6 / p.bw, 0); });
    pass(this.ppBlur, p.fa, p.bw, p.bh, p.tb, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 0, 1.6 / p.bh); });
    pass(this.ppComp, null, c.width, c.height, p.tex, p.ta, function (u) { gl.uniform1i(u.uScene, 0); gl.uniform1i(u.uBloom, 1); gl.uniform2f(u.uPx, 1 / p.w, 1 / p.h); gl.uniform1f(u.uBl, self.bloomK === undefined ? 0.7 : self.bloomK); gl.uniform1f(u.uVig, 0.22); });
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
    gl.useProgram(this.main.p);
  };
  Renderer.prototype.upload = function (desc) {
    var gl = this.gl, out = { chunks: [], tris: desc.tris, cull: desc.chunks.length > 12 };
    for (var i = 0; i < desc.chunks.length; i++) {
      var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, desc.chunks[i].buf, gl.STATIC_DRAW);
      out.chunks.push({ buf: b, n: desc.chunks[i].n, bb: desc.chunks[i].bb });
    }
    return out;
  };
  Renderer.prototype.free = function (mesh) {
    if (!mesh) return;
    for (var i = 0; i < mesh.chunks.length; i++) this.gl.deleteBuffer(mesh.chunks[i].buf);
  };

  // env: tema (colores), cam: {eye, target, fov}, time
  Renderer.prototype.begin = function (th, cam, time) {
    var gl = this.gl, uk = this.uwK || 0;
    if (uk > 0.002) { // bajo el agua: cielo, niebla y luz azul-verdosos y corta visibilidad
      var wb = [0.05, 0.34, 0.52], wt = [0.03, 0.22, 0.42], wd = [0.02, 0.14, 0.26], L3 = function (a, b) { return [a[0] + (b[0] - a[0]) * uk, a[1] + (b[1] - a[1]) * uk, a[2] + (b[2] - a[2]) * uk]; };
      th = Object.assign({}, th, { top: L3(th.top, wt), hor: L3(th.hor, wb), bot: L3(th.bot, wd), fog: L3(th.fog, wb), fogN: th.fogN * (1 - 0.8 * uk), fogF: th.fogF + (170 - th.fogF) * uk, amb: L3(th.amb, [th.amb[0] * 0.6, th.amb[1] * 0.95, th.amb[2] * 1.2]), gnd: L3(th.gnd, [th.gnd[0] * 0.5, th.gnd[1] * 0.85, th.gnd[2] * 1.1]) });
    }
    this.env = th; this.time = time;
    var e = cam.eye, t = cam.target, asp = this.aspect;
    m4.persp(this.proj, cam.fov, asp, 0.4, 1600);
    m4.lookAt(this.view, e[0], e[1], e[2], t[0], t[1], t[2], cam.roll || 0);
    m4.mul(this.vp, this.proj, this.view);
    // planos del frustum (Gribb-Hartmann) para descartar lotes fuera de camara
    var m = this.vp, P = this.planes, pi = 0, sg, ax;
    for (ax = 0; ax < 3; ax++) for (sg = -1; sg <= 1; sg += 2) {
      var a = m[3] + sg * m[ax], b = m[7] + sg * m[4 + ax], c = m[11] + sg * m[8 + ax], d = m[15] + sg * m[12 + ax];
      var l = Math.sqrt(a * a + b * b + c * c) || 1;
      P[pi++] = a / l; P[pi++] = b / l; P[pi++] = c / l; P[pi++] = d / l;
    }
    this.drawn = 0; this.culled = 0;
    this.eye[0] = e[0]; this.eye[1] = e[1]; this.eye[2] = e[2];
    this.fov = cam.fov;
    var sk = this.stormK, g0 = (th.fog[0] + th.fog[1] + th.fog[2]) / 3;
    var stC = [Math.min(1, g0 * 0.9 + 0.12), Math.min(1, g0 * 0.96 + 0.13), Math.min(1, g0 * 1.0 + 0.16)];
    var fogC = [th.fog[0] + (stC[0] - th.fog[0]) * sk * 0.85, th.fog[1] + (stC[1] - th.fog[1]) * sk * 0.85, th.fog[2] + (stC[2] - th.fog[2]) * sk * 0.85];
    var ck = this.caveK || 0;
    var vt = this.caveTint || 0;
    if (ck > 0) { var cf = vt ? [0.30, 0.07, 0.03] : [0.05, 0.07, 0.15]; fogC = [fogC[0] + (cf[0] - fogC[0]) * ck, fogC[1] + (cf[1] - fogC[1]) * ck, fogC[2] + (cf[2] - fogC[2]) * ck]; }
    this.fogC = fogC;
    if (this.ppOn && this.pp) { gl.bindFramebuffer(gl.FRAMEBUFFER, this.pp.fbo); gl.viewport(0, 0, this.pp.w, this.pp.h); }
    gl.clearColor(fogC[0], fogC[1], fogC[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // cielo
    var s = this.sky, v = this.view;
    gl.useProgram(s.p); this._attribs(1);
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.BLEND);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    // ejes de la camara (filas de la matriz de vista)
    gl.uniform3f(s.u.uRight, v[0], v[4], v[8]); gl.uniform3f(s.u.uUp, v[1], v[5], v[9]); gl.uniform3f(s.u.uFwd, -v[2], -v[6], -v[10]);
    var th2 = Math.tan(cam.fov / 2); gl.uniform2f(s.u.uTan, th2 * asp, th2);
    gl.uniform3fv(s.u.uTop, th.top); gl.uniform3fv(s.u.uHor, th.hor); gl.uniform3fv(s.u.uBot, th.bot);
    var sl = Math.sqrt(th.sun[0] * th.sun[0] + th.sun[1] * th.sun[1] + th.sun[2] * th.sun[2]);
    this.sunN = [th.sun[0] / sl, th.sun[1] / sl, th.sun[2] / sl];
    gl.uniform3fv(s.u.uSunDir, this.sunN); gl.uniform3fv(s.u.uSunCol, th.sunCol.map(function (x) { return x * 0.8; }));
    gl.uniform1f(s.u.uTime, time); gl.uniform1f(s.u.uAur, (th.aurora || 0) * (1 - sk * 0.8));
    gl.uniform1f(s.u.uSt, sk * 0.8); gl.uniform3fv(s.u.uStC, stC);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
    // programa principal
    var m = this.main;
    gl.useProgram(m.p); this._attribs(3);
    gl.uniformMatrix4fv(m.u.uVP, false, this.vp);
    var kS = 0.62 * (1 - 0.7 * ck) * (1 - 0.4 * uk), kA = (1 - 0.3 * ck) * (1 - 0.2 * uk);
    // volcan: dentro de la montana todo se tine de rojo anaranjado (luz de la lava)
    var rT = vt ? [1 + 0.9 * ck, 1 - 0.55 * ck, 1 - 0.80 * ck] : [1, 1, 1];
    gl.uniform3fv(m.u.uSun, this.sunN); var sc3 = th.sunCol.map(function (x, q) { return x * kS * rT[q]; }); gl.uniform3fv(m.u.uSunCol, sc3); gl.uniform3fv(m.u.uSunColF, sc3);
    gl.uniform3fv(m.u.uAmb, th.amb.map(function (x, q) { return x * kA * rT[q]; })); gl.uniform3fv(m.u.uGnd, th.gnd.map(function (x, q) { return x * kA * rT[q]; }));
    gl.uniform3fv(m.u.uCam, e); gl.uniform3fv(m.u.uCamF, e); gl.uniform3fv(m.u.uSunF, this.sunN); gl.uniform2f(m.u.uFog, th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)); gl.uniform3fv(m.u.uFogC, fogC);
    this._su = { cam: e, fog: [th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)], fogC: fogC, time: time % 1000 };
    gl.uniform3f(m.u.uTint, 1, 1, 1); gl.uniform1f(m.u.uAlpha, 1);
    gl.uniform1f(m.u.uCkF, ck); gl.uniform1f(m.u.uTime, time % 1000); gl.uniform1f(m.u.uGloss, this.gloss === undefined ? 1 : this.gloss);
  };
  var IDENT = m4.create(), WHITE = [1, 1, 1];
  // v3.7: reflejo en el hielo. mirrorOn(matriz de reflexion): lo que se dibuje hasta mirrorOff sale reflejado (sin test de profundidad, tenue y azulado)
  var _mt = m4.create();
  Renderer.prototype.mirrorOn = function (mir) { this.mir = mir; this.gl.disable(this.gl.DEPTH_TEST); };
  Renderer.prototype.mirrorOff = function () { this.mir = null; this.gl.enable(this.gl.DEPTH_TEST); };
  Renderer.prototype.draw = function (mesh, model, tint, alpha) {
    var gl = this.gl, m = this.main;
    var t = tint || WHITE;
    if (this.mir) { model = m4.mul(_mt, this.mir, model || IDENT); t = [t[0] * 0.72, t[1] * 0.88, t[2] * 1.05]; }
    gl.uniformMatrix4fv(m.u.uModel, false, model || IDENT);
    gl.uniform3f(m.u.uTint, t[0], t[1], t[2]);
    var a = alpha === undefined ? 1 : alpha;
    if (a < 1) { gl.enable(gl.BLEND); gl.depthMask(false); }
    gl.uniform1f(m.u.uAlpha, a);
    var cull = mesh.cull;
    for (var i = 0; i < mesh.chunks.length; i++) {
      var c = mesh.chunks[i];
      if (cull && !this._visible(c.bb)) { this.culled++; continue; }
      this.drawn++;
      gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
      gl.vertexAttribPointer(1, 3, gl.BYTE, true, 20, 12);
      gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
      gl.drawArrays(gl.TRIANGLES, 0, c.n);
    }
    if (a < 1) { gl.disable(gl.BLEND); gl.depthMask(true); }
  };
  // escudo con shader propio; en calidad baja usa el dibujo plano de siempre (tint/alpha)
  Renderer.prototype.shieldFx = function (mesh, model, sty, k, tint, alpha) {
    var gl = this.gl, S = this.shd, u = this._su;
    if (!this.gloss || !u) { this.draw(mesh, model, tint, alpha); return; }
    gl.useProgram(S.p);
    gl.uniformMatrix4fv(S.u.uVP, false, this.vp); gl.uniformMatrix4fv(S.u.uModel, false, model || IDENT);
    gl.uniform3fv(S.u.uCam, u.cam); gl.uniform3fv(S.u.uCamF, u.cam); gl.uniform3fv(S.u.uSunF, this.sunN); gl.uniform2fv(S.u.uFog, u.fog); gl.uniform3fv(S.u.uFogC, u.fogC);
    gl.uniform1f(S.u.uTime, u.time); gl.uniform1f(S.u.uK, k); gl.uniform1f(S.u.uSty, sty);
    gl.enable(gl.BLEND); gl.depthMask(false);
    if (sty === 1) gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    for (var i = 0; i < mesh.chunks.length; i++) {
      var c = mesh.chunks[i]; this.drawn++;
      gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
      gl.vertexAttribPointer(1, 3, gl.BYTE, true, 20, 12);
      gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
      gl.drawArrays(gl.TRIANGLES, 0, c.n);
    }
    if (sty === 1) gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p);
  };
  Renderer.prototype._visible = function (bb) {
    var P = this.planes;
    for (var i = 0; i < 24; i += 4) {
      var a = P[i], b = P[i + 1], c = P[i + 2], d = P[i + 3];
      var x = a > 0 ? bb[3] : bb[0], y = b > 0 ? bb[4] : bb[1], z = c > 0 ? bb[5] : bb[2];
      if (a * x + b * y + c * z + d < 0) return false;
    }
    return true;
  };
  Renderer.prototype.drawParticles = function (arr, count) {
    if (!count) return;
    var gl = this.gl, p = this.part;
    gl.useProgram(p.p); this._attribs(3);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, arr.subarray(0, count * 8));
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(1, 1, gl.FLOAT, false, 32, 12);
    gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 32, 16);
    gl.drawArrays(gl.POINTS, 0, count);
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  Renderer.prototype.drawSnow = function (time, amt, wind) {
    if (amt <= 0) return;
    var gl = this.gl, p = this.snow;
    gl.useProgram(p.p); this._attribs(1);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform3fv(p.u.uCam, this.eye); gl.uniform1f(p.u.uTime, time);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.uniform3f(p.u.uWind, wind[0], wind[1], wind[2]); gl.uniform1f(p.u.uBox, 70); gl.uniform1f(p.u.uAmt, Math.min(1, amt));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.POINTS, 0, Math.floor(this.nFlakes * Math.min(1, amt * 0.4)));
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  PG.Renderer = Renderer;
})();
