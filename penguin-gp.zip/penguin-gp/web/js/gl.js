/* Renderer WebGL 1 minimo para el estilo low-poly (sin librerias externas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var m4 = PG.m4;

  var PREC = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';

  var VS_MAIN = [
    'attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uTint; uniform vec3 uSun; uniform vec3 uSunCol; uniform vec3 uAmb; uniform vec3 uGnd; uniform vec3 uCam; uniform vec2 uFog;',
    'varying vec3 vCol; varying float vFog;',
    'void main(){',
    ' vec4 wp = uModel * vec4(aPos,1.0);',
    ' vec3 n = normalize(mat3(uModel[0].xyz,uModel[1].xyz,uModel[2].xyz) * aNor);',
    ' float l = max(dot(n,uSun),0.0);',
    ' vec3 amb = mix(uGnd,uAmb,n.y*0.5+0.5);',
    ' vec3 base = aCol.rgb*uTint;',
    ' vCol = mix(base*(amb+uSunCol*l), base, aCol.a);',
    ' vFog = clamp((length(wp.xyz-uCam)-uFog.x)/(uFog.y-uFog.x),0.0,1.0);',
    ' gl_Position = uVP*wp;',
    '}'].join('\n');
  var FS_MAIN = PREC + [
    'uniform vec3 uFogC; uniform float uAlpha; varying vec3 vCol; varying float vFog;',
    'void main(){ gl_FragColor = vec4(mix(vCol,uFogC,vFog), uAlpha); }'].join('\n');

  var VS_SKY = 'attribute vec2 aPos; varying vec2 vP; void main(){ vP=aPos; gl_Position=vec4(aPos,0.9999,1.0); }';
  var FS_SKY = PREC + [
    'uniform vec3 uTop; uniform vec3 uHor; uniform vec3 uBot; uniform vec3 uFwd; uniform vec3 uRight; uniform vec3 uUp; uniform vec2 uTan;',
    'uniform vec3 uSunDir; uniform vec3 uSunCol; uniform float uTime; uniform float uAur; uniform float uSt; uniform vec3 uStC; varying vec2 vP;',
    'void main(){',
    ' vec3 d = normalize(uFwd + uRight*vP.x*uTan.x + uUp*vP.y*uTan.y);',
    ' float h = d.y; vec3 col;',
    ' if(h>0.0) col = mix(uHor,uTop,pow(h,0.5)); else col = mix(uHor,uBot,clamp(-h*4.0,0.0,1.0));',
    ' float sd = max(dot(d,uSunDir),0.0); col += uSunCol*(pow(sd,64.0)*0.7 + pow(sd,5.0)*0.10);',
    ' if(uAur>0.0){',
    '  float a = atan(d.x,d.z);',
    '  float b1 = sin(a*3.0+uTime*0.15+sin(h*9.0+uTime*0.3)*1.6)*0.5+0.5;',
    '  float b2 = sin(a*5.0-uTime*0.11+h*14.0)*0.5+0.5;',
    '  float mask = smoothstep(0.04,0.30,h)*(1.0-smoothstep(0.42,0.95,h));',
    '  col += mix(vec3(0.10,1.0,0.50),vec3(0.60,0.30,1.0),b2)*b1*b1*mask*0.75*uAur;',
    '  float st = step(0.9965, fract(sin(dot(floor(d.xz/(abs(h)+0.2)*90.0),vec2(12.9898,78.233)))*43758.5453));',
    '  col += vec3(st)*smoothstep(0.1,0.4,h)*0.8*uAur;',
    ' }',
    ' col = mix(col, uStC, uSt);',
    ' gl_FragColor = vec4(col,1.0);',
    '}'].join('\n');

  var VS_PART = [
    'attribute vec3 aPos; attribute float aSize; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform float uScale; varying vec4 vCol;',
    'void main(){ gl_Position = uVP*vec4(aPos,1.0); vCol=aCol; gl_PointSize = clamp(aSize*uScale/max(gl_Position.w,0.5),1.0,96.0); }'].join('\n');
  var FS_PART = PREC + [
    'varying vec4 vCol;',
    'void main(){ float d = length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; gl_FragColor = vec4(vCol.rgb, vCol.a*smoothstep(0.5,0.15,d)); }'].join('\n');

  var VS_SNOW = [
    'attribute vec3 aOff; uniform mat4 uVP; uniform vec3 uCam; uniform float uTime; uniform float uScale; uniform vec3 uWind; uniform float uBox;',
    'varying float vA;',
    'void main(){',
    ' vec3 p = fract(aOff + vec3(uWind.x*uTime, -uWind.y*uTime*(0.6+aOff.x), uWind.z*uTime)/uBox);',
    ' vec3 w = uCam + (p-0.5)*vec3(uBox, uBox*0.6, uBox);',
    ' gl_Position = uVP*vec4(w,1.0);',
    ' vA = 1.0 - smoothstep(0.35,0.5,length(p-0.5));',
    ' gl_PointSize = clamp((0.18+aOff.y*0.1)*uScale/max(gl_Position.w,0.5),1.0,10.0);',
    '}'].join('\n');
  var FS_SNOW = PREC + 'uniform float uAmt; varying float vA; void main(){ float d=length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; gl_FragColor=vec4(1.0,1.0,1.0,vA*0.85*uAmt); }';

  function Renderer(canvas) {
    var aa = (window.devicePixelRatio || 1) < 2;
    var gl = canvas.getContext('webgl', { antialias: aa, alpha: false, depth: true, powerPreference: 'high-performance' }) ||
      canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL no disponible');
    this.gl = gl; this.canvas = canvas;
    this.scale = 1; this.dyn = 1; this.stormK = 0; this.drawn = 0; this.culled = 0;
    this.planes = new Float32Array(24);
    this.vp = m4.create(); this.view = m4.create(); this.proj = m4.create(); this.tmp = m4.create();
    this.main = this._prog(VS_MAIN, FS_MAIN, ['aPos', 'aNor', 'aCol']);
    this.sky = this._prog(VS_SKY, FS_SKY, ['aPos']);
    this.part = this._prog(VS_PART, FS_PART, ['aPos', 'aSize', 'aCol']);
    this.snow = this._prog(VS_SNOW, FS_SNOW, ['aOff']);
    this.skyBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    this.partBuf = gl.createBuffer(); this.partCap = 1500;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf); gl.bufferData(gl.ARRAY_BUFFER, this.partCap * 32, gl.DYNAMIC_DRAW);
    this.partArr = new Float32Array(this.partCap * 8);
    this.nFlakes = 1800;
    var fl = new Float32Array(this.nFlakes * 3), rr = PG.rng(99);
    for (var i = 0; i < fl.length; i++) fl[i] = rr();
    this.snowBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.bufferData(gl.ARRAY_BUFFER, fl, gl.STATIC_DRAW);
    this.enabled = 0;
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.env = null;
    this.eye = [0, 0, 0];
  }
  Renderer.prototype._prog = function (vs, fs, attrs) {
    var gl = this.gl;
    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s));
      return s;
    }
    var p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
    for (var i = 0; i < attrs.length; i++) gl.bindAttribLocation(p, i, attrs[i]);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link: ' + gl.getProgramInfoLog(p));
    var u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (i = 0; i < n; i++) { var info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
    return { p: p, u: u };
  };
  Renderer.prototype._attribs = function (n) {
    var gl = this.gl;
    for (var i = 0; i < 3; i++) {
      if (i < n && i >= this.enabled) gl.enableVertexAttribArray(i);
      else if (i >= n && i < this.enabled) gl.disableVertexAttribArray(i);
    }
    this.enabled = n;
  };
  Renderer.prototype.resize = function (quality) {
    var c = this.canvas, dpr = window.devicePixelRatio || 1;
    var q = (quality === 0 ? 0.55 : (quality === 1 ? 0.8 : 1.0)) * this.dyn;
    var w = Math.max(2, Math.floor(c.clientWidth * Math.min(dpr, 2) * q)), h = Math.max(2, Math.floor(c.clientHeight * Math.min(dpr, 2) * q));
    // limite de pixeles para no ahogar telefonos de gama baja
    var maxPix = quality === 0 ? 420000 : (quality === 1 ? 800000 : 1500000);
    if (w * h > maxPix) { var k = Math.sqrt(maxPix / (w * h)); w = Math.floor(w * k); h = Math.floor(h * k); }
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    this.gl.viewport(0, 0, c.width, c.height);
    this.aspect = c.width / c.height;
  };
  Renderer.prototype.upload = function (desc) {
    var gl = this.gl, out = { chunks: [], tris: desc.tris, cull: desc.chunks.length > 12 };
    for (var i = 0; i < desc.chunks.length; i++) {
      var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, desc.chunks[i].buf, gl.STATIC_DRAW);
      out.chunks.push({ buf: b, n: desc.chunks[i].n, bb: desc.chunks[i].bb });
    }
    return out;
  };
  Renderer.prototype.free = function (mesh) {
    if (!mesh) return;
    for (var i = 0; i < mesh.chunks.length; i++) this.gl.deleteBuffer(mesh.chunks[i].buf);
  };

  // env: tema (colores), cam: {eye, target, fov}, time
  Renderer.prototype.begin = function (th, cam, time) {
    var gl = this.gl;
    this.env = th; this.time = time;
    var e = cam.eye, t = cam.target, asp = this.aspect;
    m4.persp(this.proj, cam.fov, asp, 0.4, 1600);
    m4.lookAt(this.view, e[0], e[1], e[2], t[0], t[1], t[2], cam.roll || 0);
    m4.mul(this.vp, this.proj, this.view);
    // planos del frustum (Gribb-Hartmann) para descartar lotes fuera de camara
    var m = this.vp, P = this.planes, pi = 0, sg, ax;
    for (ax = 0; ax < 3; ax++) for (sg = -1; sg <= 1; sg += 2) {
      var a = m[3] + sg * m[ax], b = m[7] + sg * m[4 + ax], c = m[11] + sg * m[8 + ax], d = m[15] + sg * m[12 + ax];
      var l = Math.sqrt(a * a + b * b + c * c) || 1;
      P[pi++] = a / l; P[pi++] = b / l; P[pi++] = c / l; P[pi++] = d / l;
    }
    this.drawn = 0; this.culled = 0;
    this.eye[0] = e[0]; this.eye[1] = e[1]; this.eye[2] = e[2];
    this.fov = cam.fov;
    var sk = this.stormK, g0 = (th.fog[0] + th.fog[1] + th.fog[2]) / 3;
    var stC = [Math.min(1, g0 * 0.9 + 0.12), Math.min(1, g0 * 0.96 + 0.13), Math.min(1, g0 * 1.0 + 0.16)];
    var fogC = [th.fog[0] + (stC[0] - th.fog[0]) * sk * 0.85, th.fog[1] + (stC[1] - th.fog[1]) * sk * 0.85, th.fog[2] + (stC[2] - th.fog[2]) * sk * 0.85];
    var ck = this.caveK || 0;
    if (ck > 0) { var cf = [0.05, 0.07, 0.15]; fogC = [fogC[0] + (cf[0] - fogC[0]) * ck, fogC[1] + (cf[1] - fogC[1]) * ck, fogC[2] + (cf[2] - fogC[2]) * ck]; }
    this.fogC = fogC;
    gl.clearColor(fogC[0], fogC[1], fogC[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // cielo
    var s = this.sky, v = this.view;
    gl.useProgram(s.p); this._attribs(1);
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.BLEND);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    // ejes de la camara (filas de la matriz de vista)
    gl.uniform3f(s.u.uRight, v[0], v[4], v[8]); gl.uniform3f(s.u.uUp, v[1], v[5], v[9]); gl.uniform3f(s.u.uFwd, -v[2], -v[6], -v[10]);
    var th2 = Math.tan(cam.fov / 2); gl.uniform2f(s.u.uTan, th2 * asp, th2);
    gl.uniform3fv(s.u.uTop, th.top); gl.uniform3fv(s.u.uHor, th.hor); gl.uniform3fv(s.u.uBot, th.bot);
    var sl = Math.sqrt(th.sun[0] * th.sun[0] + th.sun[1] * th.sun[1] + th.sun[2] * th.sun[2]);
    this.sunN = [th.sun[0] / sl, th.sun[1] / sl, th.sun[2] / sl];
    gl.uniform3fv(s.u.uSunDir, this.sunN); gl.uniform3fv(s.u.uSunCol, th.sunCol.map(function (x) { return x * 0.8; }));
    gl.uniform1f(s.u.uTime, time); gl.uniform1f(s.u.uAur, (th.aurora || 0) * (1 - sk * 0.8));
    gl.uniform1f(s.u.uSt, sk * 0.8); gl.uniform3fv(s.u.uStC, stC);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
    // programa principal
    var m = this.main;
    gl.useProgram(m.p); this._attribs(3);
    gl.uniformMatrix4fv(m.u.uVP, false, this.vp);
    var kS = 0.62 * (1 - 0.8 * ck), kA = 1 - 0.5 * ck;
    gl.uniform3fv(m.u.uSun, this.sunN); gl.uniform3fv(m.u.uSunCol, th.sunCol.map(function (x) { return x * kS; }));
    gl.uniform3fv(m.u.uAmb, th.amb.map(function (x) { return x * kA; })); gl.uniform3fv(m.u.uGnd, th.gnd.map(function (x) { return x * kA; }));
    gl.uniform3fv(m.u.uCam, e); gl.uniform2f(m.u.uFog, th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)); gl.uniform3fv(m.u.uFogC, fogC);
    gl.uniform3f(m.u.uTint, 1, 1, 1); gl.uniform1f(m.u.uAlpha, 1);
  };
  var IDENT = m4.create(), WHITE = [1, 1, 1];
  Renderer.prototype.draw = function (mesh, model, tint, alpha) {
    var gl = this.gl, m = this.main;
    gl.uniformMatrix4fv(m.u.uModel, false, model || IDENT);
    var t = tint || WHITE; gl.uniform3f(m.u.uTint, t[0], t[1], t[2]);
    var a = alpha === undefined ? 1 : alpha;
    if (a < 1) { gl.enable(gl.BLEND); gl.depthMask(false); }
    gl.uniform1f(m.u.uAlpha, a);
    var cull = mesh.cull;
    for (var i = 0; i < mesh.chunks.length; i++) {
      var c = mesh.chunks[i];
      if (cull && !this._visible(c.bb)) { this.culled++; continue; }
      this.drawn++;
      gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
      gl.vertexAttribPointer(1, 3, gl.BYTE, true, 20, 12);
      gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
      gl.drawArrays(gl.TRIANGLES, 0, c.n);
    }
    if (a < 1) { gl.disable(gl.BLEND); gl.depthMask(true); }
  };
  Renderer.prototype._visible = function (bb) {
    var P = this.planes;
    for (var i = 0; i < 24; i += 4) {
      var a = P[i], b = P[i + 1], c = P[i + 2], d = P[i + 3];
      var x = a > 0 ? bb[3] : bb[0], y = b > 0 ? bb[4] : bb[1], z = c > 0 ? bb[5] : bb[2];
      if (a * x + b * y + c * z + d < 0) return false;
    }
    return true;
  };
  Renderer.prototype.drawParticles = function (arr, count) {
    if (!count) return;
    var gl = this.gl, p = this.part;
    gl.useProgram(p.p); this._attribs(3);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, arr.subarray(0, count * 8));
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(1, 1, gl.FLOAT, false, 32, 12);
    gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 32, 16);
    gl.drawArrays(gl.POINTS, 0, count);
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  Renderer.prototype.drawSnow = function (time, amt, wind) {
    if (amt <= 0) return;
    var gl = this.gl, p = this.snow;
    gl.useProgram(p.p); this._attribs(1);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform3fv(p.u.uCam, this.eye); gl.uniform1f(p.u.uTime, time);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.uniform3f(p.u.uWind, wind[0], wind[1], wind[2]); gl.uniform1f(p.u.uBox, 70); gl.uniform1f(p.u.uAmt, Math.min(1, amt));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.POINTS, 0, Math.floor(this.nFlakes * Math.min(1, amt * 0.4)));
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  PG.Renderer = Renderer;
})();
