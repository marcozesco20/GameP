/* Renderer WebGL 1 minimo para el estilo low-poly (sin librerias externas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var m4 = PG.m4;

  var PREC = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';

  // v4.6: ruido de valor 3D leido de una textura (1 lectura en vez de 8 hashes por llamada): mismo aspecto, mucho menos calculo por pixel
  // la textura guarda en R el ruido y en G el mismo ruido desplazado (37,17), asi la capa z+1 sale de la misma lectura bilineal
  var NOISE_GLSL = [
    'uniform sampler2D uNoise;',
    'float vn(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);',
    ' vec2 uv = i.xy + vec2(37.0,17.0)*mod(i.z,256.0) + f.xy;',
    ' vec2 rg = texture2D(uNoise, (uv + 0.5)*0.00390625).xy;',
    ' return mix(rg.x, rg.y, f.z); }'].join('\n');

  var VS_MAIN = [
    'attribute vec3 aPos; attribute vec4 aNor; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uTint; uniform vec3 uSun; uniform vec3 uSunCol; uniform vec3 uAmb; uniform vec3 uGnd; uniform vec3 uCam; uniform vec2 uFog;',
    'varying vec3 vCol; varying float vFog; varying vec3 vN; varying vec3 vWp; varying vec4 vB; varying vec3 vLp; varying float vM;',
    'void main(){',
    ' vLp = aPos; vM = aNor.w;',
    ' vec4 wp = uModel * vec4(aPos,1.0);',
    ' vec3 n = normalize(mat3(uModel[0].xyz,uModel[1].xyz,uModel[2].xyz) * aNor.xyz);',
    ' float l = max(dot(n,uSun),0.0);',
    ' vec3 amb = mix(uGnd,uAmb,n.y*0.5+0.5);',
    ' vec3 base = aCol.rgb*uTint;',
    ' vCol = mix(base*(amb+uSunCol*l), base, aCol.a);',
    ' vN = n; vWp = wp.xyz; vB = vec4(base, aCol.a);',
    ' vFog = clamp((length(wp.xyz-uCam)-uFog.x)/(uFog.y-uFog.x),0.0,1.0);',
    ' gl_Position = uVP*wp;',
    '}'].join('\n');
  // v3.2: brillo por pixel (hielo con reflejo del cielo, destello del sol y chispas; nieve con destellos; luz de borde suave en todo)
  var FS_MAIN = PREC + [
    'uniform vec3 uFogC; uniform float uAlpha; uniform vec3 uCamF; uniform vec3 uSunF; uniform vec3 uSunColF; uniform float uTime; uniform float uGloss; uniform float uCkF; uniform sampler2D uRefl; uniform vec2 uRfInv; uniform float uRfOn; uniform float uRfGain; uniform float uWaterY; uniform float uMat;',
    'varying vec3 vCol; varying float vFog; varying vec3 vN; varying vec3 vWp; varying vec4 vB; varying vec3 vLp; varying float vM;',
    NOISE_GLSL,
    'void main(){',
    ' vec3 col = vCol;',
    ' if(uMat > 0.5 || vM > 0.004){',
    // v4.2: materiales del pinguino (id en el 4o byte de la normal): 0 pelaje, 1 punto/lana, 2 tela/fieltro, 3 piel larga, 4 plastico, 5 metal
    '  if(uGloss > 0.5 && vFog < 0.97){',
    '   vec3 N = normalize(vN); vec3 Vv = uCamF - vWp; float dist = length(Vv); Vv /= max(dist,0.001);',
    '   float mid = floor(vM*127.0 + 0.5);',
    '   float em = clamp(vB.a*1.6,0.0,1.0), nv = max(dot(N,Vv),0.0);',
    '   float lum = dot(vB.rgb, vec3(0.3,0.55,0.15));',
    '   float skin = smoothstep(0.30,0.50,vB.r - vB.b) * smoothstep(0.55,0.75,vB.r) * (1.0 - em) * step(mid,0.5);',
    '   float df = 1.0 - smoothstep(12.0,40.0,dist);',
    '   vec3 H = normalize(uSunF + Vv); float nh = max(dot(N,H),0.0);',
    '   vec3 q = vLp; float uu = abs(vN.x) > abs(vN.z) ? q.z : q.x;',
    '   float f1 = vn(q*vec3(15.0,28.0,15.0)), f2 = vn(q*vec3(40.0,64.0,40.0) + 3.0), tuft = vn(q*5.5 + 9.0), f3 = vn(q*vec3(75.0,24.0,75.0) + 21.0);',
    '   float sheen = 0.0, rimK = 0.17;',
    '   if(mid < 0.5){',   // pelaje: vetas, mechones, hebras verticales y micro-sombreado por normal perturbada
    '    float rows = 0.5 + 0.5*sin(q.y*110.0 + sin(q.x*70.0 + q.z*40.0)*1.6);',
    '    float fur = (f1-0.5)*0.24 + (f2-0.5)*0.15 + (tuft-0.5)*0.12 + (f3-0.5)*0.22 + (rows-0.5)*0.07*smoothstep(0.5,0.85,lum);',
    '    vec3 dN = vec3(f1-0.5, f3-0.5, f2-0.5)*0.55; float micro = dot(dN, uSunF)*0.35;',
    '    col *= 1.0 + (fur + micro)*df*(1.0-skin)*(1.0-em)*(1.0-0.5*smoothstep(0.6,0.9,lum));',
    '    col *= 1.0 + (vn(q*48.0)-0.5)*0.16*skin*df;',
    '    sheen = pow(nh,12.0)*0.11*(1.0-skin)*(1.0-em) + pow(nh,34.0)*0.40*skin;',
    '   } else if(mid < 1.5){',  // punto: costillas verticales y filas de puntadas
    '    float ribs = 0.5 + 0.5*sin(uu*95.0), rows = 0.5 + 0.5*sin(q.y*70.0 + sin(uu*95.0)*1.3);',
    '    float knit = ribs*0.5 + rows*0.5 + (f2-0.5)*0.35;',
    '    col *= mix(1.0, 0.72 + 0.38*knit, df);',
    '    sheen = pow(nh,8.0)*0.07; rimK = 0.30;',
    '   } else if(mid < 2.5){',  // tela y fieltro: trama fina y pelusa
    '    float weave = sin(q.x*190.0)*sin(q.z*190.0 + q.y*60.0);',
    '    col *= 1.0 + ((f2-0.5)*0.20 + (f1-0.5)*0.12 + weave*0.035)*df;',
    '    sheen = pow(nh,10.0)*0.06; rimK = 0.26;',
    '   } else if(mid < 3.5){',  // piel larga (ribetes, orejeras, plumas)
    '    float strand = vn(q*vec3(34.0,14.0,34.0) + 5.0)*0.6 + vn(q*vec3(90.0,30.0,90.0))*0.4;',
    '    col *= mix(0.9, 0.78 + 0.5*strand, df);',
    '    sheen = pow(nh,9.0)*0.10; rimK = 0.40;',
    '   } else if(mid > 7.5 && mid < 8.5){',  // v4.6 roca: estratos de tono propio, grietas finas y gruesas, vetas minerales, liquen, escarcha, granulado y brillo humedo
    '    float sn8 = smoothstep(0.70,0.90,lum), d8 = 1.0 - smoothstep(35.0,130.0,dist);',
    '    vec3 P8 = vWp;',
    '    float gr = vn(P8*2.1)*0.5 + vn(P8*6.3+3.0)*0.33 + vn(P8*15.0+9.0)*0.17;',
    '    float tl = P8.y*2.3 + vn(P8*0.30)*5.5 + (P8.x - P8.z)*0.12, bnd = floor(tl/3.14159), bh = fract(sin(bnd*12.9898 + 1.7)*43758.5453);',
    '    float stt = 0.5 + 0.5*sin(tl);',
    '    float cr1 = 1.0 - smoothstep(0.0,0.035,abs(vn(P8*vec3(1.3,0.9,1.3)+5.0)-0.5)), cr2 = 1.0 - smoothstep(0.0,0.03,abs(vn(P8*vec3(3.6,2.6,3.6)+11.0)-0.5));',
    '    float vein = 1.0 - smoothstep(0.0,0.02,abs(vn(vec3(P8.x*0.9+P8.z*0.5, P8.y*3.2, P8.z*0.9 - P8.x*0.5)+23.0)-0.5));',
    '    float tone = (0.80 + 0.40*bh) * (0.88 + 0.20*stt) * (0.78 + 0.40*gr);',
    '    tone *= 1.0 - 0.38*cr1*d8 - 0.22*cr2*d8;',
    '    vec3 tc8 = mix(vec3(1.06,1.0,0.94), vec3(0.93,0.99,1.08), bh);',
    '    col = col * mix(vec3(1.0), tc8*tone, 1.0 - sn8*0.85);',
    '    col = mix(col, col*1.45 + vec3(0.04), vein*0.28*d8*(1.0-sn8));',
    '    float up8 = smoothstep(0.35,0.80,N.y);',
    '    float lich = smoothstep(0.60,0.82, vn(P8*1.9+2.0)) * up8 * (1.0 - sn8);',
    '    col = mix(col, vec3(0.46,0.52,0.38)*(0.6+lum*0.6), lich*0.40);',
    '    float dust = smoothstep(0.55,0.95,N.y) * smoothstep(0.38,0.62, vn(P8*3.3+1.0)) * (1.0 - sn8);',
    '    col = mix(col, vec3(0.93,0.96,1.0), dust*0.62);',
    '    col *= 1.0 + (vn(P8*9.0)-0.5)*(0.35 + 0.4*uSunF.y)*d8*(1.0-sn8);',
    '    float wet = smoothstep(0.52,0.9,gr) * (1.0 - sn8);',
    '    float spk = step(0.945, vn(P8*47.0)) * (0.5 + 0.5*sin(uTime*1.7 + P8.x*11.0 + P8.z*7.0)) * d8 * (1.0 - sn8);',
    '    sheen = (pow(nh,34.0)*0.34*wet + pow(nh,9.0)*0.05*(1.0-sn8) + pow(nh,60.0)*0.35*sn8 + spk*0.55); rimK = 0.22;',
    '   } else if(mid > 8.5 && mid < 9.5){',  // v4.5 cristal de hielo: facetas internas, destello agudo, fresnel y nucleo luminoso
    '    float fa = vn(vWp*vec3(2.4,1.1,2.4)+7.0)*0.6 + vn(vWp*6.5)*0.4, d9 = 1.0 - smoothstep(30.0,110.0,dist);',
    '    float core = pow(nv,1.4);',
    '    col *= 0.90 + 0.26*fa*d9;',
    '    col = mix(col*vec3(0.80,0.90,1.04), col*1.10, core*0.65);',
    '    float tw9 = step(0.965, vn(vWp*8.0+vec3(0.0,uTime*0.35,0.0))) * (0.5+0.5*sin(uTime*4.0+vWp.x*9.0));',
    '    col += vec3(0.8,0.95,1.0)*tw9*0.45*d9;',
    '    sheen = pow(nh,80.0)*1.5 + pow(nh,16.0)*0.28; rimK = 0.60;',
    '   } else if(mid > 9.5 && mid < 10.5){',  // v4.5 follaje: agujas, mechones y nieve con brillo suave
    '    float d10 = 1.0 - smoothstep(30.0,100.0,dist);',
    '    float nd = vn(vWp*vec3(4.5,3.0,4.5))*0.5 + vn(vWp*13.0+2.0)*0.35 + vn(vWp*29.0)*0.15;',
    '    col *= mix(1.0, 0.70 + 0.55*nd, d10);',
    '    float sw10 = smoothstep(0.78,0.95,min(vB.r,min(vB.g,vB.b)));',
    '    sheen = pow(nh,46.0)*0.28*sw10 + pow(nh,10.0)*0.03; rimK = 0.20;',
    '   } else if(mid > 10.5 && mid < 11.5){',  // v4.6 madera: tablas con juntas escalonadas, vetas largas, nudos y desgaste gris por la intemperie
    '    float d11 = (1.0 - smoothstep(28.0,95.0,dist)) * (1.0 - smoothstep(0.66,0.88,min(vB.r,min(vB.g,vB.b)))), hz11 = smoothstep(0.55,0.85,abs(N.y));',
    '    vec2 tg11 = normalize(vec2(-N.z, N.x) + vec2(0.0001));',
    '    float aL = mix(dot(q.xz,tg11), dot(q.xz,vec2(0.8,0.6)), hz11), aC = mix(q.y, dot(q.xz,vec2(-0.6,0.8)), hz11);',
    '    float pk = aC*1.7, pid = floor(pk), pf = fract(pk), h1 = fract(sin(pid*12.9898 + 4.1)*43758.5453);',
    '    float seamH = 1.0 - smoothstep(0.0,0.07,pf)*smoothstep(1.0,0.93,pf);',
    '    float jf = fract((aL + h1*5.0)/3.6), seamV = (1.0 - smoothstep(0.0,0.025,jf)*smoothstep(1.0,0.975,jf)) * step(0.15,pf) * step(pf,0.85);',
    '    float g1 = vn(vec3(aL*0.55, aC*13.0, pid*4.3)), g2 = vn(vec3(aL*1.9+3.0, aC*46.0, pid*2.1)), g3 = vn(vec3(aL*0.12, aC*3.2, pid*7.7+5.0));',
    '    float grain = (g1-0.5)*0.34 + (g2-0.5)*0.22, knot = smoothstep(0.86,0.94,g3);',
    '    col *= mix(1.0, (0.86 + 0.28*h1)*(1.0+grain)*(1.0-0.30*knot), d11);',
    '    col *= 1.0 - (0.42*seamH + 0.30*seamV)*d11;',
    '    float wear = smoothstep(0.55,0.85, vn(vec3(aL*0.25, aC*0.9, pid) + 9.0));',
    '    col = mix(col, col*vec3(0.78,0.80,0.84) + 0.03, wear*0.35*d11);',
    '    sheen = pow(nh,16.0)*0.05; rimK = 0.14;',
    '   } else if(mid > 5.5 && mid < 6.5){',  // rampa (superficie): rejilla antideslizante fina, grano de hielo y brillo
    '    float gx = abs(fract(q.x*1.1)-0.5), gz = abs(fract(q.z*1.1)-0.5), gq = smoothstep(0.455,0.5,max(gx,gz));',
    '    col *= (1.0 - 0.20*gq*df) * (1.0 + (f2-0.5)*0.16 + (f1-0.5)*0.10);',
    '    sheen = pow(nh,34.0)*0.55 + pow(nh,9.0)*0.06; rimK = 0.14;',
    '   } else if(mid > 6.5){',  // rampa (laterales): bloques de hielo con juntas y vetas
    '    float sy = abs(fract(q.y*1.15)-0.5), sx = abs(fract((q.x+q.z)*0.85 + floor(q.y*1.15)*0.5)-0.5), sm = smoothstep(0.43,0.5,max(sy,sx));',
    '    col *= (1.0 - 0.26*sm*df) * (1.0 + (f1-0.5)*0.22 + (f3-0.5)*0.10);',
    '    sheen = pow(nh,20.0)*0.18; rimK = 0.14;',
    '   } else if(mid < 4.5){',  // plastico brillante
    '    sheen = pow(nh,38.0)*0.75 + pow(nh,8.0)*0.10; rimK = 0.12;',
    '   } else {',  // metal: reflejo del entorno y brillo agudo con fibra cepillada
    '    float brush = vn(q*vec3(160.0,6.0,160.0))*0.5;',
    '    vec3 Rr = reflect(-Vv,N); vec3 env = mix(uFogC*1.1, vec3(0.78,0.88,1.0), smoothstep(-0.2,0.8,Rr.y));',
    '    col = mix(col, col*env*1.35, 0.55) + vec3(0.04)*brush;',
    '    sheen = pow(nh,55.0)*1.1 + pow(nh,10.0)*0.12; rimK = 0.12;',
    '   }',
    '   col += uSunColF*sheen*(0.4+lum);',
    '   float rim = pow(1.0 - nv, 2.2);',
    '   col += (mix(uFogC,vec3(1.0),0.55))*rim*rimK*(0.35+lum)*(1.0-em)*(1.0-skin*0.5);',
    '   col += vec3(0.30,0.07,0.0)*pow(1.0-nv,1.7)*skin*0.55;',
    '  }',
    ' } else if(uGloss > 0.5 && vFog < 0.97){',
    '  vec3 N = normalize(vN); vec3 Vv = uCamF - vWp; float dist = length(Vv); Vv /= max(dist,0.001);',
    '  float ice0 = smoothstep(0.06,0.26,vB.b - vB.r) * smoothstep(0.34,0.60,vB.b) * (1.0 - vB.a);',
    '  float up0 = smoothstep(0.55,0.9,normalize(vN).y);',
    '  if(ice0 > 0.05 && dist < 70.0){',
    '   float df = 1.0 - smoothstep(25.0,70.0,dist);',
    '   float na = vn(vWp*0.45), nb = vn(vWp*1.7 + 5.0), nc = vn(vWp*3.9 + 11.0);',
    '   float tex = (na-0.5)*0.07 + (nb-0.5)*0.035 + (nc-0.5)*0.02;',  // v3.9: hielo liso: sin venas ni lineas brillantes (parecian causticas de piscina)
    '   col *= 1.0 + ice0*tex*df;',
    '   float pa = vn(vWp*0.13 + 7.0)*0.62 + vn(vWp*0.41 + 2.0)*0.38;',  // v4.2: parches de nieve polvo sobre el hielo, escarcha y granulado
    '   float patch = smoothstep(0.60,0.80,pa) * ice0 * up0;',
    '   float grain = vn(vWp*7.5)*0.6 + vn(vWp*17.0 + 3.0)*0.4;',
    '   col = mix(col, vec3(0.90,0.95,1.0)*(0.88+0.16*grain), patch*0.42*(1.0-0.6*df*0.0));',
    '   float frost = smoothstep(0.66,0.84, vn(vWp*1.1 + 13.0)*0.7 + vn(vWp*3.3)*0.3) * ice0 * up0;',
    '   col += vec3(0.10,0.13,0.16) * frost * (0.5 + grain*0.7) * df;',
    '   col *= 1.0 + (grain-0.5)*0.07*ice0*df;',
    '   N = normalize(N + (vec3(na,nb,nc)-0.5)*0.05*ice0*df);',
    '  }',
    '  float wcz = step(vWp.y, uWaterY - 0.12) * smoothstep(0.30,0.80,N.y);', // v3.9: fondo del agua: causticas de luz que se mueven
    '  if(wcz > 0.0 && dist < 80.0){',
    '   vec2 cp = vWp.xz*0.46; float c1 = 1.0-abs(vn(vec3(cp, uTime*0.42))*2.0-1.0), c2 = 1.0-abs(vn(vec3(cp*1.9+3.7, uTime*0.58+5.0))*2.0-1.0);',
    '   float cau = pow(c1,7.0)*0.9 + pow(c2,7.0)*0.7 + pow(c1*c2,2.5)*0.5;',
    '   float dz = 1.0 - clamp((uWaterY - vWp.y)/16.0,0.0,1.0)*0.75;',
    '   col += vec3(0.50,0.92,1.0)*cau*0.50*wcz*dz*(1.0-smoothstep(25.0,80.0,dist));',
    '  }',
    '  float up = smoothstep(0.5,0.92,N.y);',
    '  float ice = smoothstep(0.06,0.26,vB.b - vB.r) * smoothstep(0.34,0.60,vB.b) * (1.0 - vB.a);',
    '  float snow = smoothstep(0.80,0.95,min(vB.r,min(vB.g,vB.b))) * (1.0 - vB.a);',
    '  float nv = max(dot(N,Vv),0.0);',
    '  vec3 H = normalize(uSunF + Vv); float nh = max(dot(N,H),0.0);',
    '  float spec = pow(nh,56.0)*0.85 + pow(nh,9.0)*0.12;',
    '  float fr = pow(1.0 - nv, 4.0);',
    '  col += uSunColF * spec * (ice + snow*0.18) * (0.3 + 0.7*up) * 1.15;',
    '  col = mix(col, uFogC*1.06 + 0.05, fr * ice * 0.42 * up);',
    '  if(uRfOn > 0.5 && up > 0.35 && dist < 130.0){',
    '   float rfm = smoothstep(0.02,0.14,vB.b - vB.r) * smoothstep(0.30,0.56,vB.b) * (1.0 - vB.a);',
    '   if(rfm > 0.02){',
    '    vec2 ruv = gl_FragCoord.xy * uRfInv + (N.xz - normalize(vN).xz) * 0.05;',
    '    vec4 rc = texture2D(uRefl, ruv);',
    '    float rk = rc.a * rfm * up * (0.45 + 0.55*fr) * (1.0 - smoothstep(45.0,100.0,dist)) * 0.55;',
    '    col = mix(col, rc.rgb*uRfGain, rk*0.62) + rc.rgb*rk*0.12;',
    '   }',
    '  }',
    '  float rim = pow(1.0 - nv, 2.6) * 0.11 * (1.0 - 0.75*up) * (1.0 - vB.a) * (1.0 - smoothstep(40.0,140.0,dist));',
    '  col += (uFogC*0.8 + 0.2) * rim;',
    '  col += vec3(0.02,0.07,0.12) * ice * uCkF * (0.30 + 0.70*pow(1.0-nv,1.6)) * (1.0 - smoothstep(30.0,90.0,dist));',
    '  vec2 gq = vWp.xz*2.4 + vWp.y*0.6; vec2 gp = floor(gq);',
    '  float h1 = fract(sin(dot(gp,vec2(12.9898,78.233)))*43758.5453);',
    '  vec2 gc = fract(gq) - vec2(0.5 + 0.3*(fract(h1*91.7)-0.5), 0.5 + 0.3*(fract(h1*57.3)-0.5));',
    '  float tw = step(0.975,h1) * smoothstep(0.17,0.0,length(gc)) * (0.45 + 0.55*sin(uTime*5.0 + h1*60.0));',
    '  col += vec3(1.0,1.0,1.0) * tw * (ice*0.65 + snow*0.5) * up * (1.0 - smoothstep(25.0,80.0,dist)) * 0.8;',
    ' }',
    ' gl_FragColor = vec4(mix(col,uFogC,vFog), uAlpha);',
    '}'].join('\n');

  // v3.9: agua con shader propio: olas (normal a partir de ruido animado), reflejo del cielo con fresnel, destello del sol, espuma en las crestas;
  // vista desde debajo: superficie plateada con reflexion total en los angulos rasantes y ventana de luz arriba
  var FS_WATER = PREC + [
    'uniform vec3 uFogC; uniform float uAlpha; uniform vec3 uCamF; uniform vec3 uSunF; uniform vec3 uSunColF; uniform float uTime; uniform float uUnder; uniform vec3 uZen;',
    'varying vec3 vCol; varying float vFog; varying vec3 vN; varying vec3 vWp; varying vec4 vB;',
    NOISE_GLSL,
    'float wh(vec2 p, float t){ return vn(vec3(p*0.20 + vec2(t*0.17,t*0.10), t*0.23))*0.55 + vn(vec3(p*0.58 - vec2(t*0.22,-t*0.16), t*0.38+3.0))*0.30 + vn(vec3(p*1.55 + vec2(t*0.46,t*0.31), t*0.66+7.0))*0.15; }',
    'void main(){',
    ' vec2 p = vWp.xz; float t = uTime; float e = 0.3;',
    ' float h0 = wh(p,t), hx = wh(p+vec2(e,0.0),t), hz = wh(p+vec2(0.0,e),t);',
    ' vec3 N = normalize(vec3(-(hx-h0)/e*0.55, 1.0, -(hz-h0)/e*0.55));',
    ' vec3 Vv = uCamF - vWp; float dist = length(Vv); Vv /= max(dist,0.001);',
    ' float slope = 1.0 - smoothstep(60.0,260.0,dist); N = normalize(mix(vec3(0.0,1.0,0.0), N, 0.35 + 0.65*slope));',
    ' vec3 col; float a;',
    ' vec3 H = normalize(uSunF + Vv);',
    ' if(uUnder < 0.5){',
    '  float nv = max(dot(N,Vv),0.0), fr = 0.04 + 0.96*pow(1.0-nv,5.0);',
    '  vec3 R = reflect(-Vv,N); vec3 sky = mix(uFogC, uZen, smoothstep(0.0,0.75,R.y));',
    '  vec3 deep = mix(vec3(0.05,0.30,0.62), vB.rgb*0.8, 0.25);',
    '  vec3 body = mix(deep, vec3(0.16,0.58,0.82), pow(nv,1.5)*0.55 + (h0-0.5)*0.25);',
    '  float nh = max(dot(N,H),0.0), spec = pow(nh,170.0)*2.4 + pow(nh,26.0)*0.22;',
    '  float crest = smoothstep(0.72,0.90,h0 + (vn(vec3(p*2.3,t*0.8))-0.5)*0.22);',
    '  col = mix(body, sky, fr*0.9) + uSunColF*spec + vec3(1.0)*crest*0.38;',
    '  a = clamp(uAlpha + fr*0.30 + crest*0.25 + spec*0.4, 0.0, 0.92);',
    ' } else {',
    '  vec3 Nb = -N; float nv = max(dot(Nb,Vv),0.0);',
    '  float tir = smoothstep(0.30,0.72,1.0-nv);',
    '  vec3 win = vec3(0.55,0.88,1.0)*(0.80 + 0.45*(h0-0.5));',
    '  vec3 mir = vec3(0.10,0.38,0.58) + vec3(0.12,0.26,0.30)*(vn(vec3(p*0.5,t*0.3)));',
    '  col = mix(win, mir, tir);',
    '  float nh = max(dot(Nb,normalize(uSunF + Vv)),0.0); col += uSunColF*pow(nh,40.0)*0.35*(1.0-tir);',
    '  a = clamp(0.62 + tir*0.2, 0.0, 0.9);',
    ' }',
    ' gl_FragColor = vec4(mix(col,uFogC,vFog), a);',
    '}'].join('\n');

  // v3.4: shader propio de los escudos (cristal con reflejos / plasma con rayos / burbuja brillante)
  var VS_SHD = [
    'attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uCam; uniform vec2 uFog;',
    'varying vec3 vN; varying vec3 vWp; varying vec3 vL; varying float vFog;',
    'void main(){ vec4 wp = uModel * vec4(aPos,1.0); vN = normalize(mat3(uModel[0].xyz,uModel[1].xyz,uModel[2].xyz) * aNor); vWp = wp.xyz; vL = aPos + aNor*0.0 + aCol.rgb*0.0;',
    ' vFog = clamp((length(wp.xyz-uCam)-uFog.x)/(uFog.y-uFog.x),0.0,1.0); gl_Position = uVP*wp; }'].join('\n');
  var FS_SHD = PREC + [
    'uniform vec3 uCamF; uniform vec3 uSunF; uniform vec3 uFogC; uniform float uTime; uniform float uK; uniform float uSty;',
    'varying vec3 vN; varying vec3 vWp; varying vec3 vL; varying float vFog;',
    NOISE_GLSL,
    'float win(vec3 r, vec2 c, vec2 hs){ vec2 d = abs(r.xy - c) - hs; return smoothstep(0.035,0.0,max(d.x,d.y)); }',
    'void main(){',
    ' vec3 N = normalize(vN); float back = 1.0; if(!gl_FrontFacing){ N = -N; back = 0.55; }',
    ' vec3 V = normalize(uCamF - vWp); float nv = clamp(dot(N,V),0.0,1.0);',
    ' vec3 R = reflect(-V,N); vec3 H = normalize(uSunF + V); float nh = max(dot(N,H),0.0);',
    ' vec3 pl = normalize(vL); float T = uTime;',
    ' vec3 col; float a;',
    ' if(uSty < 0.5){', // cristal azul
    '  float fr = pow(1.0-nv,2.3);',
    '  vec3 sky = mix(vec3(0.45,0.72,1.0), vec3(0.95,0.99,1.0), R.y*0.5+0.5);',
    '  vec3 irid = 0.5+0.5*cos(6.2832*(nv*1.1+vec3(0.0,0.33,0.67)));',
    '  float cau = 1.0 - abs(vn(pl*3.2)*2.0-1.0); cau = pow(cau,7.0);',
    '  float sp = pow(nh,140.0)*1.6 + pow(nh,18.0)*0.18;',
    '  float w = win(R,vec2(0.42,0.46),vec2(0.17,0.09)) + 0.6*win(R,vec2(-0.32,0.30),vec2(0.07,0.14));',
    '  col = vec3(0.30,0.62,0.98)*(0.42+0.25*nv) + sky*fr*0.85 + irid*fr*0.22 + vec3(0.7,0.95,1.0)*cau*0.22*(0.4+fr) + vec3(1.0)*(sp+w*0.8);',
    '  a = 0.06 + fr*0.62 + cau*0.08 + sp*0.8 + w*0.55;',
    ' } else if(uSty < 1.5){', // plasma electrico
    '  float fr = pow(1.0-nv,1.8);',
    '  float n1 = vn(pl*3.1 + vec3(T*0.9, T*0.6, -T*0.7)), n2 = vn(pl*6.3 + vec3(-T*1.4, T*1.1, T*0.8));',
    '  float r1 = pow(1.0-abs(n1*2.0-1.0), 9.0), r2 = pow(1.0-abs(n2*2.0-1.0), 12.0);',
    '  float fl = 0.65 + 0.35*step(0.5, fract(sin(floor(T*14.0)*12.9898)*43758.5453));',
    '  float core = pow(nv,2.2);',
    '  col = vec3(1.0,0.62,0.10)*(0.30*core + 0.55*fr) + vec3(1.0,0.93,0.55)*(r1*1.15 + r2*0.8)*fl + vec3(1.0,1.0,0.85)*pow(nh,60.0)*0.5;',
    '  a = 0.10 + fr*0.50 + (r1*0.95 + r2*0.65)*fl;',
    ' } else {', // burbuja rosa brillante
    '  float fr = pow(1.0-nv,2.1);',
    '  float sw = vn(pl*2.2 + vec3(T*0.35, -T*0.25, T*0.3));',
    '  float sp = pow(nh,160.0)*1.9 + pow(nh,22.0)*0.22;',
    '  float w = win(R,vec2(0.36,0.50),vec2(0.20,0.10)) + 0.5*win(R,vec2(-0.40,0.18),vec2(0.05,0.16));',
    '  vec3 body = mix(vec3(0.82,0.12,0.50), vec3(1.0,0.38,0.74), 0.5+0.5*N.y);',
    '  col = body*(0.55+0.35*nv+0.18*sw) + vec3(1.0,0.72,0.92)*fr*0.9 + vec3(1.0)*(sp+w*0.85);',
    '  a = 0.13 + fr*0.52 + sw*0.06 + sp*0.8 + w*0.6;',
    ' }',
    ' a = clamp(a*uK*back, 0.0, 0.92);',
    ' gl_FragColor = vec4(mix(col, uFogC, vFog*0.85), a*(1.0-vFog*0.6));',
    '}'].join('\n');
  // v3.5: post-proceso (resplandor/bloom, antialiasing FXAA, curva de color suave y vineta)
  var VS_PP = 'attribute vec2 aPos; varying vec2 vUv; void main(){ vUv = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }';
  var FS_BRIGHT = PREC + 'uniform sampler2D uTex; varying vec2 vUv; void main(){ vec3 c = texture2D(uTex,vUv).rgb; float m = max(c.r,max(c.g,c.b)), ch = m - min(c.r,min(c.g,c.b)); float k = smoothstep(0.50,0.80,ch) * smoothstep(0.78,0.97,m); gl_FragColor = vec4(c*k*1.25, 1.0); }';
  var FS_BLUR = PREC + 'uniform sampler2D uTex; uniform vec2 uDir; varying vec2 vUv; void main(){ vec3 c = texture2D(uTex,vUv).rgb*0.2270; c += (texture2D(uTex,vUv+uDir*1.3846).rgb + texture2D(uTex,vUv-uDir*1.3846).rgb)*0.3162; c += (texture2D(uTex,vUv+uDir*3.2308).rgb + texture2D(uTex,vUv-uDir*3.2308).rgb)*0.0703; gl_FragColor = vec4(c,1.0); }';
  var FS_COMP = PREC + [
    'uniform sampler2D uScene; uniform sampler2D uBloom; uniform vec2 uPx; uniform float uBl; uniform float uVig; varying vec2 vUv;',
    'float lum(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }',
    'void main(){',
    ' vec3 cM = texture2D(uScene,vUv).rgb;',
    ' vec3 cN = texture2D(uScene,vUv+vec2(0.0,uPx.y)).rgb, cS = texture2D(uScene,vUv-vec2(0.0,uPx.y)).rgb, cE = texture2D(uScene,vUv+vec2(uPx.x,0.0)).rgb, cW = texture2D(uScene,vUv-vec2(uPx.x,0.0)).rgb;',
    ' float lM = lum(cM), lN = lum(cN), lS = lum(cS), lE = lum(cE), lW = lum(cW);',
    ' float lMin = min(lM,min(min(lN,lS),min(lE,lW))), lMax = max(lM,max(max(lN,lS),max(lE,lW)));',
    ' float con = lMax - lMin; vec3 col = cM;',
    ' if(con > max(0.05, lMax*0.125)){',
    '  vec2 d = vec2(-(lN-lS), (lE-lW)); float rd = 1.0/(min(abs(d.x),abs(d.y)) + max((lN+lS+lE+lW)*0.03125,0.0078)+0.0001); d = clamp(d*rd, -4.0, 4.0)*uPx;',
    '  vec3 a = 0.5*(texture2D(uScene,vUv+d*(1.0/3.0-0.5)).rgb + texture2D(uScene,vUv+d*(2.0/3.0-0.5)).rgb);',
    '  vec3 b = a*0.5 + 0.25*(texture2D(uScene,vUv+d*-0.5).rgb + texture2D(uScene,vUv+d*0.5).rgb);',
    '  float lb = lum(b); col = (lb < lMin || lb > lMax) ? a : b;',
    ' }',
    ' col += texture2D(uBloom,vUv).rgb * uBl;',
    ' float l = lum(col); col = mix(vec3(l), col, 1.10);',
    ' col = col*col*(3.0-2.0*col)*0.22 + col*0.78;',
    ' vec2 q = vUv-0.5; col *= 1.0 - uVig*smoothstep(0.30,0.80,length(q*vec2(1.0,0.85)));',
    ' gl_FragColor = vec4(col,1.0);',
    '}'].join('\n');
  var VS_SKY = 'attribute vec2 aPos; varying vec2 vP; void main(){ vP=aPos; gl_Position=vec4(aPos,0.9999,1.0); }';
  var FS_SKY = PREC + [
    'uniform vec3 uTop; uniform vec3 uHor; uniform vec3 uBot; uniform vec3 uFwd; uniform vec3 uRight; uniform vec3 uUp; uniform vec2 uTan;',
    'uniform vec3 uSunDir; uniform vec3 uSunCol; uniform float uTime; uniform float uAur; uniform float uSt; uniform vec3 uStC; varying vec2 vP;',
    'void main(){',
    ' vec3 d = normalize(uFwd + uRight*vP.x*uTan.x + uUp*vP.y*uTan.y);',
    ' float h = d.y; vec3 col;',
    ' if(h>0.0) col = mix(uHor,uTop,pow(h,0.5)); else col = mix(uHor,uBot,clamp(-h*4.0,0.0,1.0));',
    ' float sd = max(dot(d,uSunDir),0.0); col += uSunCol*(pow(sd,64.0)*0.7 + pow(sd,5.0)*0.10);',
    ' if(uAur>0.0){',
    '  float a = atan(d.x,d.z);',
    '  float b1 = sin(a*3.0+uTime*0.15+sin(h*9.0+uTime*0.3)*1.6)*0.5+0.5;',
    '  float b2 = sin(a*5.0-uTime*0.11+h*14.0)*0.5+0.5;',
    '  float mask = smoothstep(0.04,0.30,h)*(1.0-smoothstep(0.42,0.95,h));',
    '  col += mix(vec3(0.10,1.0,0.50),vec3(0.60,0.30,1.0),b2)*b1*b1*mask*0.75*uAur;',
    '  float st = step(0.9965, fract(sin(dot(floor(d.xz/(abs(h)+0.2)*90.0),vec2(12.9898,78.233)))*43758.5453));',
    '  col += vec3(st)*smoothstep(0.1,0.4,h)*0.8*uAur;',
    ' }',
    ' col = mix(col, uStC, uSt);',
    ' gl_FragColor = vec4(col,1.0);',
    '}'].join('\n');

  var VS_PART = [
    'attribute vec3 aPos; attribute float aSize; attribute vec4 aCol;',
    'uniform mat4 uVP; uniform float uScale; varying vec4 vCol;',
    'void main(){ gl_Position = uVP*vec4(aPos,1.0); vCol=aCol; gl_PointSize = clamp(aSize*uScale/max(gl_Position.w,0.5),1.0,96.0); }'].join('\n');
  var FS_PART = PREC + [
    'varying vec4 vCol;',
    'void main(){ float d = length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; float k = 1.0-d*2.0; gl_FragColor = vec4(vCol.rgb*(1.0+0.55*k*k*k), vCol.a*smoothstep(0.5,0.08,d)); }'].join('\n');

  var VS_SNOW = [
    'attribute vec3 aOff; uniform mat4 uVP; uniform vec3 uCam; uniform float uTime; uniform float uScale; uniform vec3 uWind; uniform float uBox;',
    'varying float vA;',
    'void main(){',
    ' vec3 p = fract(aOff + vec3(uWind.x*uTime, -uWind.y*uTime*(0.6+aOff.x), uWind.z*uTime)/uBox);',
    ' vec3 w = uCam + (p-0.5)*vec3(uBox, uBox*0.6, uBox);',
    ' gl_Position = uVP*vec4(w,1.0);',
    ' vA = 1.0 - smoothstep(0.35,0.5,length(p-0.5));',
    ' gl_PointSize = clamp((0.18+aOff.y*0.1)*uScale/max(gl_Position.w,0.5),1.0,10.0);',
    '}'].join('\n');
  var FS_SNOW = PREC + 'uniform float uAmt; varying float vA; void main(){ float d=length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard; float k=1.0-d*2.0; gl_FragColor=vec4(0.93+0.07*k,0.97+0.03*k,1.0,vA*(0.35+0.6*k)*uAmt); }';

  function Renderer(canvas) {
    var aa = (window.devicePixelRatio || 1) < 2;
    var gl = canvas.getContext('webgl', { antialias: aa, alpha: false, depth: true, powerPreference: 'high-performance' }) ||
      canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL no disponible');
    this.gl = gl; this.canvas = canvas;
    this.scale = 1; this.dyn = 1; this.stormK = 0; this.drawn = 0; this.culled = 0;
    this.planes = new Float32Array(24);
    this.vp = m4.create(); this.view = m4.create(); this.proj = m4.create(); this.tmp = m4.create();
    this.noiseTex = this._noiseTex();
    this.main = this._prog(VS_MAIN, FS_MAIN, ['aPos', 'aNor', 'aCol']);
    this.sky = this._prog(VS_SKY, FS_SKY, ['aPos']);
    this.part = this._prog(VS_PART, FS_PART, ['aPos', 'aSize', 'aCol']);
    this.snow = this._prog(VS_SNOW, FS_SNOW, ['aOff']);
    this.shd = this._prog(VS_SHD, FS_SHD, ['aPos', 'aNor', 'aCol']);
    try { this.wat = this._prog(VS_MAIN, FS_WATER, ['aPos', 'aNor', 'aCol']); } catch (er) { this.wat = null; }
    this.waterY = -1e5;
    this.ppBright = this._prog(VS_PP, FS_BRIGHT, ['aPos']); this.ppBlur = this._prog(VS_PP, FS_BLUR, ['aPos']); this.ppComp = this._prog(VS_PP, FS_COMP, ['aPos']);
    this.pp = null; this.ppOn = false;
    this.rf = null; this.rfOn = false; this.capPool = []; this.capPool2 = []; this.capN = 0; this.capN2 = 0; this.capPrev = []; this.capOn = false; this.inRefl = false; this.vpm = m4.create(); this.rfGain = 1.4;
    this.skyBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    this.partBuf = gl.createBuffer(); this.partCap = 2600;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf); gl.bufferData(gl.ARRAY_BUFFER, this.partCap * 32, gl.DYNAMIC_DRAW);
    this.partArr = new Float32Array(this.partCap * 8);
    this.nFlakes = 1800;
    var fl = new Float32Array(this.nFlakes * 3), rr = PG.rng(99);
    for (var i = 0; i < fl.length; i++) fl[i] = rr();
    this.snowBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.bufferData(gl.ARRAY_BUFFER, fl, gl.STATIC_DRAW);
    this.enabled = 0;
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.env = null;
    this.eye = [0, 0, 0]; this._fog2 = 1e12; this._bd = 0;
    this._ord = new Int32Array(4096); this._ordB = new Int32Array(4096); this._ordK = new Uint8Array(4096); this._cnt = new Int32Array(33);
  }
  // textura de ruido 256x256: R = valor, G = el mismo valor desplazado (37,17)
  Renderer.prototype._noiseTex = function () {
    var gl = this.gl, N = 256, rr = PG.rng(2468), v = new Uint8Array(N * N), d = new Uint8Array(N * N * 4), i, x, y;
    for (i = 0; i < v.length; i++) v[i] = Math.floor(rr() * 256);
    for (y = 0; y < N; y++) for (x = 0; x < N; x++) { i = (y * N + x) * 4; d[i] = v[y * N + x]; d[i + 1] = v[((y + 17) & 255) * N + ((x + 37) & 255)]; d[i + 2] = 0; d[i + 3] = 255; }
    var t = gl.createTexture(); gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, N, N, 0, gl.RGBA, gl.UNSIGNED_BYTE, d);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.activeTexture(gl.TEXTURE0);
    return t;
  };
  Renderer.prototype._prog = function (vs, fs, attrs) {
    var gl = this.gl;
    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s));
      return s;
    }
    var p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
    for (var i = 0; i < attrs.length; i++) gl.bindAttribLocation(p, i, attrs[i]);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link: ' + gl.getProgramInfoLog(p));
    var u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (i = 0; i < n; i++) { var info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
    if (u.uNoise) { gl.useProgram(p); gl.uniform1i(u.uNoise, 2); }
    return { p: p, u: u };
  };
  Renderer.prototype._attribs = function (n) {
    var gl = this.gl;
    for (var i = 0; i < 3; i++) {
      if (i < n && i >= this.enabled) gl.enableVertexAttribArray(i);
      else if (i >= n && i < this.enabled) gl.disableVertexAttribArray(i);
    }
    this.enabled = n;
  };
  Renderer.prototype.resize = function (quality) {
    var c = this.canvas, dpr = window.devicePixelRatio || 1;
    var q = (quality === 0 ? 0.55 : (quality === 1 ? 0.8 : 1.0)) * this.dyn;
    // v3.9: la calidad elegida decide los efectos; la resolucion adaptativa SOLO baja pixeles (antes dyn<0.7 apagaba brillo, reflejos y bloom en plena carrera)
    this.gloss = quality === 0 ? 0 : 1;
    var w = Math.max(2, Math.floor(c.clientWidth * Math.min(dpr, 2) * q)), h = Math.max(2, Math.floor(c.clientHeight * Math.min(dpr, 2) * q));
    // limite de pixeles para no ahogar telefonos de gama baja
    var maxPix = quality === 0 ? 420000 : (quality === 1 ? 800000 : 1500000);
    if (w * h > maxPix) { var k = Math.sqrt(maxPix / (w * h)); w = Math.floor(w * k); h = Math.floor(h * k); }
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    this._ppSetup(quality === 2 && this.postFx !== false, c.width, c.height);
    this._rfSetup(!!this.gloss && (quality === 2 || this.dyn >= 0.62) && this.reflFx !== false, c.width, c.height);
    this.gl.viewport(0, 0, c.width, c.height);
    this.aspect = c.width / c.height;
  };
  Renderer.prototype._ppTex = function (w, h) {
    var gl = this.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  };
  Renderer.prototype._ppFree = function () {
    var gl = this.gl, p = this.pp; if (!p) return;
    gl.deleteFramebuffer(p.fbo); gl.deleteTexture(p.tex); gl.deleteRenderbuffer(p.rb);
    gl.deleteFramebuffer(p.fa); gl.deleteTexture(p.ta); gl.deleteFramebuffer(p.fb); gl.deleteTexture(p.tb);
    this.pp = null;
  };
  // framebuffer de escena + dos de resplandor a 1/4 de resolucion; si algo falla se queda sin post-proceso
  Renderer.prototype._ppSetup = function (on, w, h) {
    var gl = this.gl;
    if (!on) { if (this.pp) this._ppFree(); this.ppOn = false; return; }
    if (this.pp && this.pp.w === w && this.pp.h === h) { this.ppOn = true; return; }
    this._ppFree();
    try {
      var bw = Math.max(8, w >> 2), bh = Math.max(8, h >> 2), p = { w: w, h: h, bw: bw, bh: bh };
      p.tex = this._ppTex(w, h); p.fbo = gl.createFramebuffer(); p.rb = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, p.rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, w, h);
      gl.bindFramebuffer(gl.FRAMEBUFFER, p.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.tex, 0);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, p.rb);
      var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      p.ta = this._ppTex(bw, bh); p.fa = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, p.fa); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.ta, 0);
      ok = ok && gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      p.tb = this._ppTex(bw, bh); p.fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, p.fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.tb, 0);
      ok = ok && gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      if (!ok) { this.pp = p; this._ppFree(); this.ppOn = false; this.postFx = false; return; }
      this.pp = p; this.ppOn = true;
    } catch (e) { this.pp = null; this.ppOn = false; this.postFx = false; gl.bindFramebuffer(gl.FRAMEBUFFER, null); }
  };
  // al terminar la escena: resplandor + FXAA + color + vineta hacia la pantalla
  Renderer.prototype.finish = function () {
    if (!this.ppOn || !this.pp) return;
    var gl = this.gl, p = this.pp, c = this.canvas, self = this;
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.BLEND);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf); this._attribs(1); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    function pass(prog, fbo, w, h, tex0, tex1, setU) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo); gl.viewport(0, 0, w, h); gl.useProgram(prog.p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex0);
      if (tex1) { gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tex1); gl.activeTexture(gl.TEXTURE0); }
      setU(prog.u); gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    pass(this.ppBright, p.fa, p.bw, p.bh, p.tex, null, function (u) { gl.uniform1i(u.uTex, 0); });
    pass(this.ppBlur, p.fb, p.bw, p.bh, p.ta, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 1 / p.bw, 0); });
    pass(this.ppBlur, p.fa, p.bw, p.bh, p.tb, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 0, 1 / p.bh); });
    pass(this.ppBlur, p.fb, p.bw, p.bh, p.ta, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 1.6 / p.bw, 0); });
    pass(this.ppBlur, p.fa, p.bw, p.bh, p.tb, null, function (u) { gl.uniform1i(u.uTex, 0); gl.uniform2f(u.uDir, 0, 1.6 / p.bh); });
    pass(this.ppComp, null, c.width, c.height, p.tex, p.ta, function (u) { gl.uniform1i(u.uScene, 0); gl.uniform1i(u.uBloom, 1); gl.uniform2f(u.uPx, 1 / p.w, 1 / p.h); gl.uniform1f(u.uBl, self.bloomK === undefined ? 0.7 : self.bloomK); gl.uniform1f(u.uVig, 0.22); });
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
    gl.useProgram(this.main.p);
  };
  // v3.7: textura de reflejo (pinguinos, esferas...) renderizada con la camara reflejada respecto al plano del suelo; el shader del hielo la muestrea en pantalla
  Renderer.prototype._rfFree = function () {
    var gl = this.gl, r = this.rf; if (!r) return;
    gl.deleteFramebuffer(r.fbo); gl.deleteTexture(r.tex); gl.deleteRenderbuffer(r.rb); this.rf = null;
  };
  Renderer.prototype._rfSetup = function (on, cw, ch) {
    var gl = this.gl;
    if (!on) { this._rfFree(); this.rfOn = false; return; }
    var w = Math.max(64, cw >> 1), h = Math.max(64, ch >> 1);
    if (this.rf && this.rf.w === w && this.rf.h === h) { this.rfOn = true; return; }
    this._rfFree();
    try {
      var r = { w: w, h: h }; r.tex = this._ppTex(w, h); r.fbo = gl.createFramebuffer(); r.rb = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, r.rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, w, h);
      gl.bindFramebuffer(gl.FRAMEBUFFER, r.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, r.tex, 0);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, r.rb);
      var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      this.rf = r; if (!ok) { this._rfFree(); this.rfOn = false; this.reflFx = false; return; }
      this.rfOn = true;
    } catch (e) { this.rf = null; this.rfOn = false; this.reflFx = false; gl.bindFramebuffer(gl.FRAMEBUFFER, null); }
  };
  // se llama justo despues de begin(): dibuja en la textura lo capturado el cuadro anterior (con la camara reflejada) y deja el shader listo
  Renderer.prototype.reflRender = function (mir) {
    var gl = this.gl, rf = this.rf, list = this.capPool, nL = this.capN, m = this.main, c = this.canvas, i, vw, vh;
    this.capPrev = list; this.capN2 = nL; // se dibuja lo capturado el cuadro anterior; los objetos se recapturan en un segundo conjunto
    var tmpP = this.capPool; this.capPool = this.capPool2; this.capPool2 = tmpP; this.capN = 0;
    list = tmpP;
    if (!this.rfOn || !rf) { gl.uniform1f(m.u.uRfOn, 0); return; }
    vw = this.ppOn && this.pp ? this.pp.w : c.width; vh = this.ppOn && this.pp ? this.pp.h : c.height;
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null); gl.activeTexture(gl.TEXTURE0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, rf.fbo); gl.viewport(0, 0, rf.w, rf.h);
    gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    m4.mul(this.vpm, this.vp, mir);
    gl.uniformMatrix4fv(m.u.uVP, false, this.vpm); gl.uniform1f(m.u.uGloss, 0); gl.uniform1f(m.u.uRfOn, 0);
    this.inRefl = true;
    for (i = 0; i < nL; i++) this.draw(list[i].mesh, list[i].model, list[i].tint, list[i].alpha);
    this.inRefl = false;
    gl.uniformMatrix4fv(m.u.uVP, false, this.vp); gl.uniform1f(m.u.uGloss, this.gloss === undefined ? 1 : this.gloss);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.ppOn && this.pp ? this.pp.fbo : null); gl.viewport(0, 0, vw, vh);
    var fc = this.fogC; gl.clearColor(fc[0], fc[1], fc[2], 1);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, rf.tex); gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(m.u.uRefl, 1); gl.uniform2f(m.u.uRfInv, 1 / vw, 1 / vh); gl.uniform1f(m.u.uRfOn, 1);
    var am = this.env ? this.env.amb : [0.5, 0.5, 0.5], lum = (am[0] + am[1] + am[2]) / 3;
    gl.uniform1f(m.u.uRfGain, 1.0 + 1.5 * Math.max(0, Math.min(1, 1 - lum * 1.5)));
  };
  Renderer.prototype.upload = function (desc) {
    var gl = this.gl, out = { chunks: [], tris: desc.tris, cull: desc.chunks.length > 12 };
    for (var i = 0; i < desc.chunks.length; i++) {
      var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, desc.chunks[i].buf, gl.STATIC_DRAW);
      out.chunks.push({ buf: b, n: desc.chunks[i].n, bb: desc.chunks[i].bb });
    }
    return out;
  };
  Renderer.prototype.free = function (mesh) {
    if (!mesh) return;
    this.capN = 0; this.capN2 = 0; this.capPool.length = 0; this.capPool2.length = 0; // v3.7: lo capturado para el reflejo puede apuntar a mallas liberadas
    for (var i = 0; i < mesh.chunks.length; i++) this.gl.deleteBuffer(mesh.chunks[i].buf);
  };

  // env: tema (colores), cam: {eye, target, fov}, time
  Renderer.prototype.begin = function (th, cam, time) {
    var gl = this.gl, uk = this.uwK || 0;
    if (uk > 0.002) { // bajo el agua: cielo, niebla y luz azul-verdosos y corta visibilidad
      var wb = [0.05, 0.34, 0.52], wt = [0.03, 0.22, 0.42], wd = [0.02, 0.14, 0.26], L3 = function (a, b) { return [a[0] + (b[0] - a[0]) * uk, a[1] + (b[1] - a[1]) * uk, a[2] + (b[2] - a[2]) * uk]; };
      th = Object.assign({}, th, { top: L3(th.top, wt), hor: L3(th.hor, wb), bot: L3(th.bot, wd), fog: L3(th.fog, wb), fogN: th.fogN * (1 - 0.8 * uk), fogF: th.fogF + (170 - th.fogF) * uk, amb: L3(th.amb, [th.amb[0] * 0.6, th.amb[1] * 0.95, th.amb[2] * 1.2]), gnd: L3(th.gnd, [th.gnd[0] * 0.5, th.gnd[1] * 0.85, th.gnd[2] * 1.1]) });
    }
    this.env = th; this.time = time;
    var e = cam.eye, t = cam.target, asp = this.aspect;
    m4.persp(this.proj, cam.fov, asp, 0.8, 1400); // v3.9: plano cercano mas lejos = mas precision de profundidad (sin parpadeos en GPUs de 16 bits)
    m4.lookAt(this.view, e[0], e[1], e[2], t[0], t[1], t[2], cam.roll || 0);
    m4.mul(this.vp, this.proj, this.view);
    // planos del frustum (Gribb-Hartmann) para descartar lotes fuera de camara
    var m = this.vp, P = this.planes, pi = 0, sg, ax;
    for (ax = 0; ax < 3; ax++) for (sg = -1; sg <= 1; sg += 2) {
      var a = m[3] + sg * m[ax], b = m[7] + sg * m[4 + ax], c = m[11] + sg * m[8 + ax], d = m[15] + sg * m[12 + ax];
      var l = Math.sqrt(a * a + b * b + c * c) || 1;
      P[pi++] = a / l; P[pi++] = b / l; P[pi++] = c / l; P[pi++] = d / l;
    }
    this.drawn = 0; this.culled = 0; this.verts = 0;
    this.eye[0] = e[0]; this.eye[1] = e[1]; this.eye[2] = e[2];
    this.fov = cam.fov;
    var sk = this.stormK, g0 = (th.fog[0] + th.fog[1] + th.fog[2]) / 3;
    var stC = [Math.min(1, g0 * 0.9 + 0.12), Math.min(1, g0 * 0.96 + 0.13), Math.min(1, g0 * 1.0 + 0.16)];
    var fogC = [th.fog[0] + (stC[0] - th.fog[0]) * sk * 0.85, th.fog[1] + (stC[1] - th.fog[1]) * sk * 0.85, th.fog[2] + (stC[2] - th.fog[2]) * sk * 0.85];
    var ck = this.caveK || 0;
    var vt = this.caveTint || 0;
    if (ck > 0) { var cf = vt ? [0.30, 0.07, 0.03] : [0.05, 0.07, 0.15]; fogC = [fogC[0] + (cf[0] - fogC[0]) * ck, fogC[1] + (cf[1] - fogC[1]) * ck, fogC[2] + (cf[2] - fogC[2]) * ck]; }
    this.fogC = fogC;
    if (this.ppOn && this.pp) { gl.bindFramebuffer(gl.FRAMEBUFFER, this.pp.fbo); gl.viewport(0, 0, this.pp.w, this.pp.h); }
    gl.clearColor(fogC[0], fogC[1], fogC[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // cielo
    var s = this.sky, v = this.view;
    gl.useProgram(s.p); this._attribs(1);
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.BLEND);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    // ejes de la camara (filas de la matriz de vista)
    gl.uniform3f(s.u.uRight, v[0], v[4], v[8]); gl.uniform3f(s.u.uUp, v[1], v[5], v[9]); gl.uniform3f(s.u.uFwd, -v[2], -v[6], -v[10]);
    var th2 = Math.tan(cam.fov / 2); gl.uniform2f(s.u.uTan, th2 * asp, th2);
    gl.uniform3fv(s.u.uTop, th.top); gl.uniform3fv(s.u.uHor, th.hor); gl.uniform3fv(s.u.uBot, th.bot);
    var sl = Math.sqrt(th.sun[0] * th.sun[0] + th.sun[1] * th.sun[1] + th.sun[2] * th.sun[2]);
    this.sunN = [th.sun[0] / sl, th.sun[1] / sl, th.sun[2] / sl];
    gl.uniform3fv(s.u.uSunDir, this.sunN); gl.uniform3fv(s.u.uSunCol, th.sunCol.map(function (x) { return x * 0.8; }));
    gl.uniform1f(s.u.uTime, time); gl.uniform1f(s.u.uAur, (th.aurora || 0) * (1 - sk * 0.8));
    gl.uniform1f(s.u.uSt, sk * 0.8); gl.uniform3fv(s.u.uStC, stC);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
    // programa principal
    var m = this.main;
    gl.useProgram(m.p); this._attribs(3);
    gl.uniformMatrix4fv(m.u.uVP, false, this.vp);
    var kS = 0.62 * (1 - 0.7 * ck) * (1 - 0.4 * uk), kA = (1 - 0.3 * ck) * (1 - 0.2 * uk);
    // volcan: dentro de la montana todo se tine de rojo anaranjado (luz de la lava)
    var rT = vt ? [1 + 0.9 * ck, 1 - 0.55 * ck, 1 - 0.80 * ck] : [1, 1, 1];
    gl.uniform3fv(m.u.uSun, this.sunN); var sc3 = th.sunCol.map(function (x, q) { return x * kS * rT[q]; }); gl.uniform3fv(m.u.uSunCol, sc3); gl.uniform3fv(m.u.uSunColF, sc3);
    gl.uniform3fv(m.u.uAmb, th.amb.map(function (x, q) { return x * kA * rT[q]; })); gl.uniform3fv(m.u.uGnd, th.gnd.map(function (x, q) { return x * kA * rT[q]; }));
    gl.uniform3fv(m.u.uCam, e); gl.uniform3fv(m.u.uCamF, e); gl.uniform3fv(m.u.uSunF, this.sunN); gl.uniform2f(m.u.uFog, th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)); gl.uniform3fv(m.u.uFogC, fogC);
    this._fog2 = Math.pow(th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck) * 1.02 + 8, 2); this._bd = 0;
    this._su = { cam: e, fog: [th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)], fogC: fogC, time: time % 1000 };
    gl.uniform3f(m.u.uTint, 1, 1, 1); gl.uniform1f(m.u.uAlpha, 1); this._c0 = this._c1 = this._c2 = 1; this._ca = 1;
    gl.uniform1f(m.u.uCkF, ck); gl.uniform1f(m.u.uTime, time % 1000); gl.uniform1f(m.u.uGloss, this.gloss === undefined ? 1 : this.gloss);
    gl.uniform1f(m.u.uWaterY, this.waterY); gl.uniform1f(m.u.uMat, 0); this._mt = 0;
    this._wu = { sc3: sc3, amb: th.amb.map(function (x, q) { return x * kA * rT[q]; }), gnd: th.gnd.map(function (x, q) { return x * kA * rT[q]; }), zen: th.top, fog: [th.fogN * (1 - 0.72 * sk) * (1 - 0.35 * ck), th.fogF * (1 - 0.55 * sk) * (1 - 0.6 * ck)] };
  };
  // v3.9: dibuja la superficie del agua con su shader (si no esta disponible o la calidad es baja, el dibujo plano de siempre)
  Renderer.prototype.drawWater = function (mesh, alpha, under, tint) {
    var gl = this.gl, W = this.wat, u = this._wu; under = under || this.eye[1] < this.waterY;
    if (!W || !this.gloss || !u || this.inRefl || this.mir) { this.draw(mesh, null, tint, alpha); return; }
    gl.useProgram(W.p); this._attribs(3);
    gl.uniformMatrix4fv(W.u.uVP, false, this.vp); gl.uniformMatrix4fv(W.u.uModel, false, IDENT);
    gl.uniform3f(W.u.uTint, 1, 1, 1); gl.uniform3fv(W.u.uSun, this.sunN); gl.uniform3fv(W.u.uSunCol, u.sc3); gl.uniform3fv(W.u.uAmb, u.amb); gl.uniform3fv(W.u.uGnd, u.gnd);
    gl.uniform3fv(W.u.uCam, this.eye); gl.uniform2f(W.u.uFog, u.fog[0], u.fog[1]);
    gl.uniform3fv(W.u.uFogC, this.fogC); gl.uniform3fv(W.u.uCamF, this.eye); gl.uniform3fv(W.u.uSunF, this.sunN); gl.uniform3fv(W.u.uSunColF, u.sc3);
    gl.uniform1f(W.u.uTime, this.time % 1000); gl.uniform1f(W.u.uAlpha, alpha); gl.uniform1f(W.u.uUnder, under ? 1 : 0); gl.uniform3fv(W.u.uZen, u.zen);
    gl.enable(gl.BLEND); gl.depthMask(false);
    for (var i = 0; i < mesh.chunks.length; i++) {
      var c = mesh.chunks[i];
      if (mesh.cull && !this._visible(c.bb)) { this.culled++; continue; }
      this.drawn++;
      gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0); gl.vertexAttribPointer(1, 4, gl.BYTE, true, 20, 12); gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
      gl.drawArrays(gl.TRIANGLES, 0, c.n);
    }
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p);
  };
  var IDENT = m4.create(), WHITE = [1, 1, 1];
  // v3.7: reflejo en el hielo. mirrorOn(matriz de reflexion): lo que se dibuje hasta mirrorOff sale reflejado (sin test de profundidad, tenue y azulado)
  var _mt = m4.create(), _tr = [1, 1, 1];
  Renderer.prototype.mirrorOn = function (mir) { this.mir = mir; this.gl.disable(this.gl.DEPTH_TEST); };
  Renderer.prototype.mirrorOff = function () { this.mir = null; this.gl.enable(this.gl.DEPTH_TEST); };
  Renderer.prototype.draw = function (mesh, model, tint, alpha, alt) {
    var gl = this.gl, m = this.main;
    var t = tint || WHITE;
    if (this.capOn && !this.inRefl && !this.mir && this.rfOn) { // v4.6: lista de captura reutilizada (antes creaba un objeto y un Float32Array por pieza y cuadro = tirones por el recolector de basura)
      var cp = this.capPool[this.capN]; if (!cp) cp = this.capPool[this.capN] = { mesh: null, model: new Float32Array(16), tint: null, alpha: 1 };
      cp.mesh = alt || mesh; cp.model.set(model || IDENT); cp.tint = tint; cp.alpha = alpha; this.capN++;
    }
    if (this.inRefl) { var tr = _tr; tr[0] = t[0] * 1.5; tr[1] = t[1] * 1.5; tr[2] = t[2] * 1.55; t = tr; }
    if (this.mir) { model = m4.mul(_mt, this.mir, model || IDENT); var tm = _tr; tm[0] = t[0] * 0.72; tm[1] = t[1] * 0.88; tm[2] = t[2] * 1.05; t = tm; }
    gl.uniformMatrix4fv(m.u.uModel, false, model || IDENT);
    if (t[0] !== this._c0 || t[1] !== this._c1 || t[2] !== this._c2) { this._c0 = t[0]; this._c1 = t[1]; this._c2 = t[2]; gl.uniform3f(m.u.uTint, t[0], t[1], t[2]); } // v4.6: no repetir uniformes iguales
    var a = alpha === undefined ? 1 : alpha;
    if (a < 1) { gl.enable(gl.BLEND); gl.depthMask(false); }
    if (a !== this._ca) { this._ca = a; gl.uniform1f(m.u.uAlpha, a); }
    var mt = this.mat ? 1 : 0; if (mt !== this._mt) { this._mt = mt; gl.uniform1f(m.u.uMat, mt); }
    var cull = mesh.cull, chs = mesh.chunks, nC = chs.length, i, c;
    if (cull && a >= 1 && nC <= 4096 && !this.inRefl && !this.mir) {
      // v4.6: lotes visibles de cerca a lejos (32 bandas, orden por conteo): el hielo/roca se sombrea una sola vez por pixel (menos sobredibujo) y no se pierde nada
      var ord = this._ord, ordB = this._ordB, ordK = this._ordK, cnt = this._cnt, nv = 0, band = this._fog2 > 1 ? 31 / Math.sqrt(this._fog2) : 0, bk;
      for (i = 0; i < 33; i++) cnt[i] = 0;
      for (i = 0; i < nC; i++) {
        if (!this._visible(chs[i].bb)) { this.culled++; continue; }
        bk = Math.sqrt(this._bd) * band | 0; if (bk > 31) bk = 31;
        ord[nv] = i; ordK[nv] = bk; cnt[bk + 1]++; nv++;
      }
      for (i = 1; i < 33; i++) cnt[i] += cnt[i - 1];
      for (i = 0; i < nv; i++) ordB[cnt[ordK[i]]++] = ord[i];
      for (i = 0; i < nv; i++) {
        c = chs[ordB[i]]; this.drawn++; this.verts += c.n;
        gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
        gl.vertexAttribPointer(1, 4, gl.BYTE, true, 20, 12);
        gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
        gl.drawArrays(gl.TRIANGLES, 0, c.n);
      }
    } else {
      for (i = 0; i < nC; i++) {
        c = chs[i];
        if (cull && !this._visible(c.bb)) { this.culled++; continue; }
        this.drawn++; this.verts += c.n;
        gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
        gl.vertexAttribPointer(1, 4, gl.BYTE, true, 20, 12);
        gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
        gl.drawArrays(gl.TRIANGLES, 0, c.n);
      }
    }
    if (a < 1) { gl.disable(gl.BLEND); gl.depthMask(true); }
  };
  // escudo con shader propio; en calidad baja usa el dibujo plano de siempre (tint/alpha)
  Renderer.prototype.shieldFx = function (mesh, model, sty, k, tint, alpha) {
    var gl = this.gl, S = this.shd, u = this._su;
    if (!this.gloss || !u) { this.draw(mesh, model, tint, alpha); return; }
    gl.useProgram(S.p);
    gl.uniformMatrix4fv(S.u.uVP, false, this.vp); gl.uniformMatrix4fv(S.u.uModel, false, model || IDENT);
    gl.uniform3fv(S.u.uCam, u.cam); gl.uniform3fv(S.u.uCamF, u.cam); gl.uniform3fv(S.u.uSunF, this.sunN); gl.uniform2fv(S.u.uFog, u.fog); gl.uniform3fv(S.u.uFogC, u.fogC);
    gl.uniform1f(S.u.uTime, u.time); gl.uniform1f(S.u.uK, k); gl.uniform1f(S.u.uSty, sty);
    gl.enable(gl.BLEND); gl.depthMask(false);
    if (sty === 1) gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    for (var i = 0; i < mesh.chunks.length; i++) {
      var c = mesh.chunks[i]; this.drawn++;
      gl.bindBuffer(gl.ARRAY_BUFFER, c.buf);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
      gl.vertexAttribPointer(1, 4, gl.BYTE, true, 20, 12);
      gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 20, 16);
      gl.drawArrays(gl.TRIANGLES, 0, c.n);
    }
    if (sty === 1) gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p);
  };
  // v4.6: ademas del frustum, se descartan los lotes cuyo punto mas cercano queda mas lejos que el final de la niebla (ahi todo es del color de la niebla)
  // y se guarda la distancia al lote en this._bd (para dibujar de cerca a lejos)
  Renderer.prototype._visible = function (bb) {
    var P = this.planes;
    for (var i = 0; i < 24; i += 4) {
      var a = P[i], b = P[i + 1], c = P[i + 2], d = P[i + 3];
      var x = a > 0 ? bb[3] : bb[0], y = b > 0 ? bb[4] : bb[1], z = c > 0 ? bb[5] : bb[2];
      if (a * x + b * y + c * z + d < 0) return false;
    }
    var e = this.eye, dx = bb[0] - e[0], dy = bb[1] - e[1], dz = bb[2] - e[2], t;
    if (dx < 0) { t = e[0] - bb[3]; dx = t > 0 ? t : 0; }
    if (dy < 0) { t = e[1] - bb[4]; dy = t > 0 ? t : 0; }
    if (dz < 0) { t = e[2] - bb[5]; dz = t > 0 ? t : 0; }
    var d2 = dx * dx + dy * dy + dz * dz;
    if (d2 > this._fog2) return false;
    this._bd = d2;
    return true;
  };
  // v4.1: las primeras `count` particulas se mezclan normal; las `nAdd` siguientes son aditivas (llamas, chispas, destellos)
  Renderer.prototype.drawParticles = function (arr, count, nAdd) {
    nAdd = nAdd || 0;
    if (!count && !nAdd) return;
    var gl = this.gl, p = this.part;
    gl.useProgram(p.p); this._attribs(3);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.partBuf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, arr.subarray(0, (count + nAdd) * 8));
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(1, 1, gl.FLOAT, false, 32, 12);
    gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 32, 16);
    if (count) gl.drawArrays(gl.POINTS, 0, count);
    if (nAdd) { gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.drawArrays(gl.POINTS, count, nAdd); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); }
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  Renderer.prototype.drawSnow = function (time, amt, wind) {
    if (amt <= 0) return;
    var gl = this.gl, p = this.snow;
    gl.useProgram(p.p); this._attribs(1);
    gl.uniformMatrix4fv(p.u.uVP, false, this.vp);
    gl.uniform3fv(p.u.uCam, this.eye); gl.uniform1f(p.u.uTime, time);
    gl.uniform1f(p.u.uScale, this.canvas.height / (2 * Math.tan(this.fov / 2)));
    gl.uniform3f(p.u.uWind, wind[0], wind[1], wind[2]); gl.uniform1f(p.u.uBox, 70); gl.uniform1f(p.u.uAmt, Math.min(1, amt));
    gl.enable(gl.BLEND); gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.snowBuf); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.POINTS, 0, Math.floor(this.nFlakes * Math.min(1, amt * 0.4)));
    gl.disable(gl.BLEND); gl.depthMask(true);
    gl.useProgram(this.main.p); this._attribs(3);
  };
  PG.Renderer = Renderer;
})();
