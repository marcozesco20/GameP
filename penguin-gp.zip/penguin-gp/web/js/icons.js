/* Iconos vectoriales del menu (v3.0): estilo "hielo" blanco con contorno azul, a juego con Penguin Fort.
   Uso: PG.ico('flag') devuelve el <svg>; los elementos con data-ico="nombre" se rellenan solos al arrancar. */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var S = 'stroke="#0a3d91" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"';
  var W = 'fill="url(#icW)" ' + S, B = 'fill="#1f78d8" ' + S, G = 'fill="url(#icG)" ' + S, O = 'fill="url(#icO)" ' + S;
  function gearPath() {
    var d = '', n = 8, i, a0, a1, a2, a3, ro = 21, ri = 15.5;
    for (i = 0; i < n; i++) {
      a0 = (i - 0.18) / n * 6.2832; a1 = (i + 0.18) / n * 6.2832; a2 = (i + 0.32) / n * 6.2832; a3 = (i + 0.68) / n * 6.2832;
      function p(a, r) { return (24 + Math.cos(a) * r).toFixed(1) + ' ' + (24 + Math.sin(a) * r).toFixed(1); }
      d += (i ? 'L' : 'M') + p(a0, ri) + 'L' + p(a0 + 0.06, ro) + 'L' + p(a1 - 0.06, ro) + 'L' + p(a1, ri) + 'L' + p(a3 - 0.05, ri);
    }
    return d + 'Z';
  }
  var D = {
    flag: '<path d="M11 5v38" ' + S + '/><path d="M13 8c8-5 14 5 23 0v19c-9 5-15-5-23 0z" ' + O + '/><path d="M19 9v8h8V8.5zM27 17v8h8v-8zM19 17h8v8h-8z" fill="#fff" stroke="none" opacity=".9"/>',
    shirt: '<path d="M17 5L4 12l5 9 7-3v25h16V18l7 3 5-9-13-7c-1.2 4.2-4 6-8 6s-6.800-1.800-8-6z" ' + W + '/><path d="M18.500 6.500c1.500 3.500 4 5 5.500 5s4-1.500 5.500-5" fill="none" ' + S + ' opacity=".6"/>',
    pad: '<path d="M14 12h20c6.500 0 10 6 11 15l1.500 8c.7 4.500-3.500 7.500-7 5l-7-5.500H15L8 40c-3.500 2.500-7.700-.5-7-5L2.500 27C3.500 18 7.500 12 14 12z" ' + W + '/><path d="M13 22v8M9 26h8" ' + S + ' stroke-width="3"/><circle cx="33" cy="23" r="2.200" ' + B + '/><circle cx="38" cy="28" r="2.200" ' + B + '/><circle cx="28" cy="28" r="2.200" ' + B + '/><circle cx="33" cy="33" r="2.200" ' + B + '/>',
    users: '<circle cx="17" cy="15" r="7" ' + W + '/><path d="M3 41c0-9 6-14 14-14s14 5 14 14z" ' + W + '/><circle cx="34" cy="17" r="6" ' + W + '/><path d="M32 28c9-1 15 4 15 13H35" ' + W + '/>',
    gear: '<path d="' + gearPath() + '" ' + W + '/><circle cx="24" cy="24" r="6.500" ' + B + '/>',
    chart: '<path d="M6 42h38" ' + S + '/><rect x="8" y="28" width="8" height="14" rx="1.500" ' + W + '/><rect x="20" y="20" width="8" height="22" rx="1.500" ' + W + '/><rect x="32" y="12" width="8" height="30" rx="1.500" ' + W + '/><path d="M8 20l10-8 8 4 14-10m0 0h-7m7 0v7" fill="none" ' + S + ' stroke="#ff8a1f"/>',
    cart: '<path d="M3 7h7l5 24h24l5-17H13" ' + W + '/><circle cx="19" cy="40" r="4" ' + B + '/><circle cx="36" cy="40" r="4" ' + B + '/>',
    snow: '<path d="M24 3v42M5.800 13.500l36.400 21M5.800 34.500l36.400-21" fill="none" ' + S + ' stroke-width="3.200"/><path d="M18 7l6 5 6-5M18 41l6-5 6 5M7 22l3 7M41 26l-3-7" fill="none" ' + S + '/>',
    coin: '<circle cx="24" cy="24" r="20" ' + G + '/><circle cx="24" cy="24" r="14.500" fill="none" stroke="#b8730a" stroke-width="2"/><path d="M28 17.500c-1-2-3-2.500-4.500-2.500-2.500 0-4.500 1.300-4.500 3.500 0 5 9.500 2.500 9.500 7.500 0 2.200-2 3.500-4.700 3.500-2 0-4-.8-5-3M24 12v3M24 33v3" fill="none" stroke="#9a5a05" stroke-width="3" stroke-linecap="round"/>',
    star: '<path d="M24 3l6.200 13.500 14.800 1.700-11 10 3 14.600L24 35l-13 7.800 3-14.600-11-10 14.800-1.700z" ' + G + '/>',
    camera: '<path d="M6 15h9l3-5h12l3 5h9v26H6z" ' + W + '/><circle cx="24" cy="28" r="8" ' + B + '/><circle cx="24" cy="28" r="3.500" fill="#cfeaff" stroke="none"/>',
    paint: '<path d="M24 4C12 4 3 13 3 24c0 10 8 18 18 18 4 0 5-3 3-5-2-3 0-6 4-6h6c6 0 11-3 11-9C45 11 36 4 24 4z" ' + W + '/><circle cx="14" cy="22" r="3.200" fill="#e33b3b" stroke="none"/><circle cx="21" cy="13" r="3.200" fill="#f6d433" stroke="none"/><circle cx="32" cy="13" r="3.200" fill="#4cc45a" stroke="none"/><circle cx="38" cy="22" r="3.200" fill="#3a6df0" stroke="none"/>',
    hat: '<path d="M13 30V12c0-3 3-5 11-5s11 2 11 5v18z" ' + W + '/><path d="M13 25h22v5H13z" ' + O + '/><path d="M5 32c0-2.500 7-4 19-4s19 1.500 19 4-7 5-19 5-19-2.500-19-5z" ' + W + '/>',
    scarf: '<path d="M7 14c10 6 24 6 34 0v10c-10 6-24 6-34 0z" ' + O + '/><path d="M28 27l8 15h-9l-6-13z" ' + O + '/><path d="M13 17v8M20 19v8M27 19.500v8M34 18v8" fill="none" stroke="#fff" stroke-width="2.200" opacity=".85"/>',
    glasses: '<rect x="3" y="14" width="20" height="18" rx="7" fill="#1f78d8" ' + S + '/><rect x="25" y="14" width="20" height="18" rx="7" fill="#1f78d8" ' + S + '/><path d="M22 21c1.500-2 2.500-2 4 0M3 19L1 12M45 19l2-7" fill="none" ' + S + '/><path d="M8 20a4 4 0 013-2.500M30 20a4 4 0 013-2.500" fill="none" stroke="#bfe6ff" stroke-width="2.600"/>',
    jacket: '<path d="M16 4l-11 7v12l7 2v19h24V25l7-2V11L32 4c-1 4-4 6-8 6s-7-2-8-6z" ' + W + '/><path d="M24 10v32" ' + S + '/><circle cx="21" cy="22" r="1.600" fill="#0a3d91" stroke="none"/><circle cx="21" cy="30" r="1.600" fill="#0a3d91" stroke="none"/>',
    back: '<path d="M30 9L14 24l16 15" fill="none" stroke="#0a3d91" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M30 9L14 24l16 15" fill="none" stroke="#fff" stroke-width="6.500" stroke-linecap="round" stroke-linejoin="round"/>',
    check: '<path d="M8 25l11 11L40 12" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>',
    dice: '<rect x="6" y="6" width="36" height="36" rx="8" ' + W + '/><circle cx="16" cy="16" r="3" fill="#0a3d91" stroke="none"/><circle cx="32" cy="16" r="3" fill="#0a3d91" stroke="none"/><circle cx="24" cy="24" r="3" fill="#0a3d91" stroke="none"/><circle cx="16" cy="32" r="3" fill="#0a3d91" stroke="none"/><circle cx="32" cy="32" r="3" fill="#0a3d91" stroke="none"/>',
    chat: '<path d="M6 8h36v26H22l-10 8v-8H6z" ' + W + '/><path d="M13 17h22M13 24h14" fill="none" ' + S + '/>',
    bolt: '<path d="M27 3L9 27h12l-3 18 19-26H25z" ' + O + '/>',
    lock: '<rect x="9" y="21" width="30" height="22" rx="5" ' + W + '/><path d="M15 21v-6a9 9 0 0118 0v6" fill="none" ' + S + '/>',
    mic: '<rect x="17" y="4" width="14" height="24" rx="7" ' + W + '/><path d="M10 22a14 14 0 0028 0M24 36v8M16 44h16" fill="none" ' + S + '/>',
    pack: '<rect x="8" y="12" width="32" height="30" rx="6" ' + W + '/><path d="M16 12V8a8 8 0 0116 0v4M8 26h32" fill="none" ' + S + '/><rect x="20" y="22" width="8" height="8" rx="2" ' + O + '/>'
  };
  PG.ico = function (n) {
    return '<svg class="ic2" viewBox="0 0 48 48" aria-hidden="true">' + (D[n] || '') + '</svg>';
  };
  PG.fillIcons = function (root) {
    var els = (root || document).querySelectorAll('[data-ico]');
    for (var i = 0; i < els.length; i++) if (!els[i].firstChild) els[i].innerHTML = PG.ico(els[i].dataset.ico);
  };
  // definiciones de degradado compartidas por todos los iconos
  var defs = document.createElement('div');
  defs.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
  defs.innerHTML = '<svg width="0" height="0"><defs><linearGradient id="icW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#bfe3ff"/></linearGradient><linearGradient id="icG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe680"/><stop offset="1" stop-color="#f0a010"/></linearGradient><linearGradient id="icO" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc04a"/><stop offset="1" stop-color="#ff7a14"/></linearGradient></defs></svg>';
  (document.body || document.documentElement).appendChild(defs);
  PG.fillIcons();
})();
