/* Iconos vectoriales del menu (v3.0): estilo "hielo" blanco con contorno azul, a juego con Penguin Fort.
   Uso: PG.ico('flag') devuelve el <svg>; los elementos con data-ico="nombre" se rellenan solos al arrancar. */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var S = 'stroke="#0a3d91" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"';
  var W = 'fill="url(#icW)" ' + S, B = 'fill="#1f78d8" ' + S, G = 'fill="url(#icG)" ' + S, O = 'fill="url(#icO)" ' + S;
  function gearPath() {
    var d = '', n = 8, i, a0, a1, a2, a3, ro = 21, ri = 15.5;
    for (i = 0; i < n; i++) {
      a0 = (i - 0.18) / n * 6.2832; a1 = (i + 0.18) / n * 6.2832; a2 = (i + 0.32) / n * 6.2832; a3 = (i + 0.68) / n * 6.2832;
      function p(a, r) { return (24 + Math.cos(a) * r).toFixed(1) + ' ' + (24 + Math.sin(a) * r).toFixed(1); }
      d += (i ? 'L' : 'M') + p(a0, ri) + 'L' + p(a0 + 0.06, ro) + 'L' + p(a1 - 0.06, ro) + 'L' + p(a1, ri) + 'L' + p(a3 - 0.05, ri);
    }
    return d + 'Z';
  }
  var D = {
    flag: '<path d="M11 5v38" ' + S + '/><path d="M13 8c8-5 14 5 23 0v19c-9 5-15-5-23 0z" ' + O + '/><path d="M19 9v8h8V8.5zM27 17v8h8v-8zM19 17h8v8h-8z" fill="#fff" stroke="none" opacity=".9"/>',
    shirt: '<path d="M17 5L4 12l5 9 7-3v25h16V18l7 3 5-9-13-7c-1.2 4.2-4 6-8 6s-6.800-1.800-8-6z" ' + W + '/><path d="M18.500 6.500c1.500 3.500 4 5 5.500 5s4-1.500 5.500-5" fill="none" ' + S + ' opacity=".6"/>',
    pad: '<path d="M14 12h20c6.500 0 10 6 11 15l1.500 8c.7 4.500-3.500 7.500-7 5l-7-5.500H15L8 40c-3.500 2.500-7.700-.5-7-5L2.500 27C3.500 18 7.500 12 14 12z" ' + W + '/><path d="M13 22v8M9 26h8" ' + S + ' stroke-width="3"/><circle cx="33" cy="23" r="2.200" ' + B + '/><circle cx="38" cy="28" r="2.200" ' + B + '/><circle cx="28" cy="28" r="2.200" ' + B + '/><circle cx="33" cy="33" r="2.200" ' + B + '/>',
    users: '<circle cx="17" cy="15" r="7" ' + W + '/><path d="M3 41c0-9 6-14 14-14s14 5 14 14z" ' + W + '/><circle cx="34" cy="17" r="6" ' + W + '/><path d="M32 28c9-1 15 4 15 13H35" ' + W + '/>',
    gear: '<path d="' + gearPath() + '" ' + W + '/><circle cx="24" cy="24" r="6.500" ' + B + '/>',
    chart: '<path d="M6 42h38" ' + S + '/><rect x="8" y="28" width="8" height="14" rx="1.500" ' + W + '/><rect x="20" y="20" width="8" height="22" rx="1.500" ' + W + '/><rect x="32" y="12" width="8" height="30" rx="1.500" ' + W + '/><path d="M8 20l10-8 8 4 14-10m0 0h-7m7 0v7" fill="none" ' + S + ' stroke="#ff8a1f"/>',
    cart: '<path d="M3 7h7l5 24h24l5-17H13" ' + W + '/><circle cx="19" cy="40" r="4" ' + B + '/><circle cx="36" cy="40" r="4" ' + B + '/>',
    snow: '<path d="M24 3v42M5.800 13.500l36.400 21M5.800 34.500l36.400-21" fill="none" stroke="#0a3d91" stroke-width="8" stroke-linecap="round"/><path d="M18 7l6 5 6-5M18 41l6-5 6 5" fill="none" stroke="#0a3d91" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><path d="M24 3v42M5.800 13.500l36.400 21M5.800 34.500l36.400-21" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M18 7l6 5 6-5M18 41l6-5 6 5" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    coin: '<circle cx="24" cy="24" r="20" ' + G + '/><circle cx="24" cy="24" r="14.500" fill="none" stroke="#b8730a" stroke-width="2"/><path d="M28 17.500c-1-2-3-2.500-4.500-2.500-2.500 0-4.500 1.300-4.500 3.500 0 5 9.500 2.500 9.500 7.500 0 2.200-2 3.500-4.700 3.500-2 0-4-.8-5-3M24 12v3M24 33v3" fill="none" stroke="#9a5a05" stroke-width="3" stroke-linecap="round"/>',
    star: '<path d="M24 3l6.200 13.500 14.800 1.700-11 10 3 14.600L24 35l-13 7.800 3-14.600-11-10 14.800-1.700z" ' + G + '/>',
    camera: '<path d="M6 15h9l3-5h12l3 5h9v26H6z" ' + W + '/><circle cx="24" cy="28" r="8" ' + B + '/><circle cx="24" cy="28" r="3.500" fill="#cfeaff" stroke="none"/>',
    paint: '<path d="M24 4C12 4 3 13 3 24c0 10 8 18 18 18 4 0 5-3 3-5-2-3 0-6 4-6h6c6 0 11-3 11-9C45 11 36 4 24 4z" ' + W + '/><circle cx="14" cy="22" r="3.200" fill="#e33b3b" stroke="none"/><circle cx="21" cy="13" r="3.200" fill="#f6d433" stroke="none"/><circle cx="32" cy="13" r="3.200" fill="#4cc45a" stroke="none"/><circle cx="38" cy="22" r="3.200" fill="#3a6df0" stroke="none"/>',
    hat: '<path d="M13 30V12c0-3 3-5 11-5s11 2 11 5v18z" ' + W + '/><path d="M13 25h22v5H13z" ' + O + '/><path d="M5 32c0-2.500 7-4 19-4s19 1.500 19 4-7 5-19 5-19-2.500-19-5z" ' + W + '/>',
    scarf: '<path d="M7 14c10 6 24 6 34 0v10c-10 6-24 6-34 0z" ' + O + '/><path d="M28 27l8 15h-9l-6-13z" ' + O + '/><path d="M13 17v8M20 19v8M27 19.500v8M34 18v8" fill="none" stroke="#fff" stroke-width="2.200" opacity=".85"/>',
    glasses: '<rect x="3" y="14" width="20" height="18" rx="7" fill="#1f78d8" ' + S + '/><rect x="25" y="14" width="20" height="18" rx="7" fill="#1f78d8" ' + S + '/><path d="M22 21c1.500-2 2.500-2 4 0M3 19L1 12M45 19l2-7" fill="none" ' + S + '/><path d="M8 20a4 4 0 013-2.500M30 20a4 4 0 013-2.500" fill="none" stroke="#bfe6ff" stroke-width="2.600"/>',
    jacket: '<path d="M16 4l-11 7v12l7 2v19h24V25l7-2V11L32 4c-1 4-4 6-8 6s-7-2-8-6z" ' + W + '/><path d="M24 10v32" ' + S + '/><circle cx="21" cy="22" r="1.600" fill="#0a3d91" stroke="none"/><circle cx="21" cy="30" r="1.600" fill="#0a3d91" stroke="none"/>',
    back: '<path d="M30 9L14 24l16 15" fill="none" stroke="#0a3d91" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M30 9L14 24l16 15" fill="none" stroke="#fff" stroke-width="6.500" stroke-linecap="round" stroke-linejoin="round"/>',
    check: '<path d="M8 25l11 11L40 12" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>',
    dice: '<rect x="6" y="6" width="36" height="36" rx="8" ' + W + '/><circle cx="16" cy="16" r="3" fill="#0a3d91" stroke="none"/><circle cx="32" cy="16" r="3" fill="#0a3d91" stroke="none"/><circle cx="24" cy="24" r="3" fill="#0a3d91" stroke="none"/><circle cx="16" cy="32" r="3" fill="#0a3d91" stroke="none"/><circle cx="32" cy="32" r="3" fill="#0a3d91" stroke="none"/>',
    chat: '<path d="M6 8h36v26H22l-10 8v-8H6z" ' + W + '/><path d="M13 17h22M13 24h14" fill="none" ' + S + '/>',
    bolt: '<path d="M27 3L9 27h12l-3 18 19-26H25z" ' + O + '/>',
    lock: '<rect x="9" y="21" width="30" height="22" rx="5" ' + W + '/><path d="M15 21v-6a9 9 0 0118 0v6" fill="none" ' + S + '/>',
    mic: '<rect x="17" y="4" width="14" height="24" rx="7" ' + W + '/><path d="M10 22a14 14 0 0028 0M24 36v8M16 44h16" fill="none" ' + S + '/>',
    pack: '<rect x="8" y="12" width="32" height="30" rx="6" ' + W + '/><path d="M16 12V8a8 8 0 0116 0v4M8 26h32" fill="none" ' + S + '/><rect x="20" y="22" width="8" height="8" rx="2" ' + O + '/>',
    none: '<circle cx="24" cy="24" r="17" fill="none" stroke="#0a3d91" stroke-width="9" opacity=".9"/><circle cx="24" cy="24" r="17" fill="none" stroke="#fff" stroke-width="4.500"/><path d="M12 36L36 12" stroke="#0a3d91" stroke-width="9" stroke-linecap="round"/><path d="M12 36L36 12" stroke="#fff" stroke-width="4.500" stroke-linecap="round"/>',
    tick2: '<path d="M8 25l11 11L40 12" fill="none" stroke="#0a3d91" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 25l11 11L40 12" fill="none" stroke="#7CF08B" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>',
    // ---- v4.1: iconos propios que sustituyen a los emojis (mismo estilo: blanco hielo, contorno azul, detalles naranja y dorado) ----
    globe: '<circle cx="24" cy="24" r="19" ' + W + '/><path d="M5 24h38M24 5c-9 9-9 29 0 38M24 5c9 9 9 29 0 38M9 14h30M9 34h30" fill="none" ' + S + ' stroke-width="1.8"/>',
    wifi: '<path d="M4 18c11-10 29-10 40 0M11 26c7-6.500 19-6.500 26 0M18 33c3.500-3 8.500-3 12 0" fill="none" ' + S + ' stroke-width="4.500"/><path d="M4 18c11-10 29-10 40 0M11 26c7-6.500 19-6.500 26 0M18 33c3.500-3 8.500-3 12 0" fill="none" stroke="#fff" stroke-width="2"/><circle cx="24" cy="40" r="4" ' + O + '/>',
    smile: '<circle cx="24" cy="24" r="19" ' + G + '/><circle cx="17" cy="20" r="2.800" fill="#0a3d91" stroke="none"/><circle cx="31" cy="20" r="2.800" fill="#0a3d91" stroke="none"/><path d="M14 29c3 7 17 7 20 0" fill="none" ' + S + '/>',
    trophy: '<path d="M14 6h20v14c0 7-4.500 11-10 11s-10-4-10-11z" ' + G + '/><path d="M14 10H6c0 8 3 12 9 13M34 10h8c0 8-3 12-9 13" fill="none" ' + S + '/><path d="M24 31v6M15 42h18l-2-5H17z" ' + G + '/><path d="M19 11v8" stroke="#fff" stroke-width="2.600" stroke-linecap="round" opacity=".8"/>',
    thumb: '<path d="M4 21h9v21H4z" ' + B + '/><path d="M13 22l8-15c4 0 5 3 4 7l-1.500 6H38c3.500 0 5 3 4 6l-4 14c-1 3-3 4-6 4H13z" ' + W + '/>',
    target: '<circle cx="24" cy="24" r="19" ' + W + '/><circle cx="24" cy="24" r="12.500" ' + O + '/><circle cx="24" cy="24" r="6" fill="#fff" ' + S + '/><path d="M24 24L41 7M36 6l5 1 1 5" fill="none" ' + S + ' stroke-width="2.800"/>',
    spk: '<path d="M5 18h8l10-9v30l-10-9H5z" ' + W + '/><path d="M30 17c4 4 4 10 0 14M35 11c8 7 8 19 0 26" fill="none" ' + S + '/>',
    spkoff: '<path d="M5 18h8l10-9v30l-10-9H5z" ' + W + '/><path d="M31 18l11 12M42 18L31 30" fill="none" ' + S + ' stroke-width="3.200"/>',
    micoff: '<rect x="17" y="4" width="14" height="24" rx="7" ' + W + '/><path d="M10 22a14 14 0 0028 0M24 36v8M16 44h16" fill="none" ' + S + '/><path d="M6 6l36 36" fill="none" stroke="#0a3d91" stroke-width="7" stroke-linecap="round"/><path d="M6 6l36 36" fill="none" stroke="#e33b3b" stroke-width="3.500" stroke-linecap="round"/>',
    alert: '<path d="M24 4L45 41H3z" ' + O + '/><path d="M24 17v13" fill="none" stroke="#fff" stroke-width="4.500" stroke-linecap="round"/><circle cx="24" cy="35" r="2.600" fill="#fff" stroke="none"/>',
    rocket: '<path d="M24 3c8 6 10 16 9 27H15C14 19 16 9 24 3z" ' + W + '/><circle cx="24" cy="17" r="4.500" ' + B + '/><path d="M15 24l-8 10 8-1zM33 24l8 10-8-1z" ' + O + '/><path d="M19 32h10l-5 12z" ' + G + '/>',
    eye: '<path d="M2 24c6-11 14-16 22-16s16 5 22 16c-6 11-14 16-22 16S8 35 2 24z" ' + W + '/><circle cx="24" cy="24" r="9" ' + B + '/><circle cx="24" cy="24" r="4" fill="#0a2a66" stroke="none"/><circle cx="27" cy="21" r="2" fill="#fff" stroke="none"/>',
    cross: '<path d="M10 10l28 28M38 10L10 38" fill="none" stroke="#0a3d91" stroke-width="11" stroke-linecap="round"/><path d="M10 10l28 28M38 10L10 38" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/>',
    clock: '<circle cx="24" cy="24" r="19" ' + W + '/><path d="M24 11v14l9 6" fill="none" ' + S + ' stroke-width="3.400"/><circle cx="24" cy="24" r="2" fill="#0a3d91" stroke="none"/>',
    medal1: '<path d="M14 3l6 15h8l6-15h-8l-2 6-2-6z" fill="#e33b3b" ' + S + '/><circle cx="24" cy="31" r="14" ' + G + '/><path d="M24 24v14M20 27l4-3" fill="none" ' + S + ' stroke-width="3"/>',
    medal2: '<path d="M14 3l6 15h8l6-15h-8l-2 6-2-6z" fill="#e33b3b" ' + S + '/><circle cx="24" cy="31" r="14" fill="#dfe8f3" ' + S + '/><path d="M18 27c1-4 11-4 12 0 0 5-12 6-12 11h12" fill="none" ' + S + ' stroke-width="3"/>',
    medal3: '<path d="M14 3l6 15h8l6-15h-8l-2 6-2-6z" fill="#e33b3b" ' + S + '/><circle cx="24" cy="31" r="14" fill="#e59a5c" ' + S + '/><path d="M18 26c3-3 10-2 10 2 0 3-4 3-4 3s5 0 5 4c0 4-8 5-12 1" fill="none" ' + S + ' stroke-width="2.800"/>',
    bag: '<path d="M8 15h32l-2 28H10z" ' + W + '/><path d="M16 20v-8a8 8 0 0116 0v8" fill="none" ' + S + '/><circle cx="24" cy="29" r="5" ' + O + '/>',
    loop: '<path d="M38 20a14 14 0 00-26-4M10 28a14 14 0 0026 4" fill="none" ' + S + ' stroke-width="4"/><path d="M40 8v13H27M8 40V27h13" fill="none" ' + S + ' stroke-width="4"/>',
    down: '<path d="M24 6v32M10 26l14 14 14-14" fill="none" stroke="#0a3d91" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M24 6v32M10 26l14 14 14-14" fill="none" stroke="#fff" stroke-width="5.500" stroke-linecap="round" stroke-linejoin="round"/>',
    next: '<path d="M14 6l26 18-26 18z" ' + W + '/>',
    prev: '<path d="M34 6L8 24l26 18z" ' + W + '/>',
    penguin: '<path d="M24 3c10 0 15 9 15 20 0 13-6 21-15 21S9 36 9 23C9 12 14 3 24 3z" fill="#1d3f7c" ' + S + '/><path d="M24 17c6 0 9 6 9 14s-3 11-9 11-9-3-9-11 3-14 9-14z" fill="#fff" stroke="none"/><circle cx="19" cy="14" r="2.200" fill="#fff" stroke="none"/><circle cx="29" cy="14" r="2.200" fill="#fff" stroke="none"/><path d="M20 19h8l-4 5z" ' + O + '/>',
    chick: '<circle cx="24" cy="25" r="18" ' + G + '/><circle cx="18" cy="21" r="2.400" fill="#0a3d91" stroke="none"/><circle cx="30" cy="21" r="2.400" fill="#0a3d91" stroke="none"/><path d="M20 27h8l-4 6z" ' + O + '/><path d="M20 8c0-3 3-4 4-1 1-3 4-2 4 1" fill="none" ' + S + '/>',
    cube: '<path d="M24 5l17 9v20l-17 9-17-9V14z" ' + W + '/><path d="M7 14l17 9 17-9M24 23v20" fill="none" ' + S + ' stroke-width="2"/><path d="M13 14l5 3" stroke="#8fd0ff" stroke-width="2.500" fill="none" stroke-linecap="round"/>',
    skier: '<circle cx="28" cy="7" r="4.500" ' + O + '/><path d="M26 13l-6 11 8 4-2 12M20 24l-9 3M28 28l9-4M4 44l36-8" fill="none" ' + S + ' stroke-width="3.600"/>',
    mountain: '<path d="M2 42L17 13l8 14 6-9 15 24z" ' + W + '/><path d="M17 13l-5 10 5-3 4 4 4-5zM31 18l-4 7 4-2 3 3 3-5z" fill="#8fd0ff" stroke="none"/>',
    compass: '<circle cx="24" cy="24" r="19" ' + W + '/><path d="M31 17l-5 9-9 5 5-9z" ' + O + '/><circle cx="24" cy="24" r="2" fill="#0a3d91" stroke="none"/>',
    gem: '<path d="M12 6h24l9 11-21 25L3 17z" fill="#46c3ff" ' + S + '/><path d="M3 17h42M17 6l-5 11 12 25M31 6l5 11-12 25" fill="none" ' + S + ' stroke-width="1.800"/>',
    crown: '<path d="M5 36L3 13l12 11 9-16 9 16 12-11-2 23z" ' + G + '/><path d="M6 39h36v4H6z" ' + O + '/><circle cx="24" cy="30" r="2.600" fill="#e33b3b" stroke="none"/>',
    heart: '<path d="M24 42C8 30 4 21 4 15c0-6 4-10 9-10 5 0 9 3 11 7 2-4 6-7 11-7 5 0 9 4 9 10 0 6-4 15-20 27z" fill="#ff5c7a" ' + S + '/><path d="M12 13c2-3 5-3 7-1" fill="none" stroke="#fff" stroke-width="2.600" stroke-linecap="round" opacity=".8"/>',
    swirl: '<path d="M24 24c3 0 3 4 0 4s-6-3-6-7 5-9 10-9 12 5 12 12-7 14-16 14S4 31 4 22" fill="none" stroke="#0a3d91" stroke-width="9" stroke-linecap="round"/><path d="M24 24c3 0 3 4 0 4s-6-3-6-7 5-9 10-9 12 5 12 12-7 14-16 14S4 31 4 22" fill="none" stroke="#bfe3ff" stroke-width="4.500" stroke-linecap="round"/>',
    medalstar: '<path d="M14 3l6 15h8l6-15h-8l-2 6-2-6z" fill="#3a86e8" ' + S + '/><circle cx="24" cy="31" r="14" ' + G + '/><path d="M24 22l2.600 5.400 5.900.8-4.300 4.100 1 5.800-5.200-2.800-5.200 2.800 1-5.800-4.300-4.100 5.900-.8z" fill="#fff" stroke="none"/>',
    // gorros
    h_beanie: '<path d="M8 32c0-14 7-22 16-22s16 8 16 22z" fill="#e8583c" ' + S + '/><path d="M6 32h36v7H6z" ' + W + '/><path d="M14 33v5M20 33v5M26 33v5M32 33v5" fill="none" ' + S + ' stroke-width="1.800"/><circle cx="24" cy="8" r="5" ' + W + '/>',
    h_helmet: '<path d="M9 31c0-12 6-19 15-19s15 7 15 19z" fill="#f6d433" ' + S + '/><path d="M20 12v18M28 12v18" fill="none" ' + S + ' stroke-width="2"/><path d="M4 31h40v6H4z" fill="#f6d433" ' + S + '/>',
    h_top: '<path d="M13 30V8h22v22z" fill="#2a3552" ' + S + '/><path d="M13 24h22v5H13z" ' + O + '/><path d="M4 33c0-3 8-4 20-4s20 1 20 4-8 5-20 5S4 36 4 33z" fill="#2a3552" ' + S + '/>',
    h_cap: '<path d="M8 30c0-12 7-18 17-18 8 0 14 6 14 18z" fill="#3a86e8" ' + S + '/><path d="M25 30c5 0 14 1 19 5-8 3-16 2-19 0z" fill="#2a65b8" ' + S + '/><circle cx="24" cy="10" r="2.500" ' + W + '/>',
    h_horns: '<path d="M9 33c0-12 6-18 15-18s15 6 15 18z" fill="#aab6c8" ' + S + '/><path d="M10 25C3 24 2 15 5 8c1 7 5 10 9 10zM38 25c7-1 8-10 5-17-1 7-5 10-9 10z" ' + W + '/><path d="M8 33h32v5H8z" fill="#7b4a2a" ' + S + '/>',
    h_phones: '<path d="M8 28C8 14 15 7 24 7s16 7 16 21" fill="none" ' + S + ' stroke-width="4.500"/><path d="M8 28C8 14 15 7 24 7s16 7 16 21" fill="none" stroke="#fff" stroke-width="2"/><rect x="4" y="25" width="10" height="17" rx="4" ' + O + '/><rect x="34" y="25" width="10" height="17" rx="4" ' + O + '/>',
    h_wizard: '<path d="M24 3l13 32H11z" fill="#6c4bd8" ' + S + '/><path d="M3 38c0-3 9-5 21-5s21 2 21 5-9 5-21 5S3 41 3 38z" fill="#6c4bd8" ' + S + '/><path d="M24 15l1.800 3.600 4 .6-2.900 2.800.7 4-3.600-1.900-3.600 1.900.7-4-2.900-2.800 4-.6z" fill="#ffd23a" stroke="none"/>',
    h_cowboy: '<path d="M14 30c-2-12 2-20 10-14 8-6 12 2 10 14z" fill="#a8703c" ' + S + '/><path d="M2 24c4 8 12 13 22 13s18-5 22-13c-5 3-10 4-22 4S7 27 2 24z" fill="#a8703c" ' + S + '/><path d="M14 30c6 2 14 2 20 0" fill="none" ' + S + ' stroke-width="3"/>',
    h_chef: '<path d="M11 26c-6-1-8-9-2-12 1-6 9-8 12-4 3-5 12-3 12 3 6 1 7 9 1 13z" ' + W + '/><path d="M11 25h26v13H11z" ' + W + '/><path d="M18 28v8M24 28v8M30 28v8" fill="none" ' + S + ' stroke-width="1.800"/>',
    h_cat: '<path d="M7 40V9l11 9h12l11-9v31z" fill="#7b86a0" ' + S + '/><path d="M11 17l5 4M37 17l-5 4" fill="none" stroke="#ffb3c6" stroke-width="3.500" stroke-linecap="round"/><circle cx="17" cy="28" r="2.500" fill="#0a3d91" stroke="none"/><circle cx="31" cy="28" r="2.500" fill="#0a3d91" stroke="none"/><path d="M22 33h4l-2 2.500z" fill="#ff8aa6" stroke="none"/>',
    h_party: '<path d="M24 5l14 34H10z" fill="#c86bff" ' + S + '/><path d="M16 26l16 0M19 33h10" fill="none" stroke="#ffd23a" stroke-width="3.600"/><circle cx="24" cy="6" r="4.500" ' + G + '/><circle cx="14" cy="43" r="2" fill="#ff7ab0" stroke="none"/><circle cx="36" cy="43" r="2" fill="#46c3ff" stroke="none"/>',
    h_halo: '<ellipse cx="24" cy="14" rx="17" ry="7" fill="none" ' + S + ' stroke-width="9"/><ellipse cx="24" cy="14" rx="17" ry="7" fill="none" stroke="#ffe680" stroke-width="5"/><circle cx="24" cy="36" r="8" fill="#e8f1fb" ' + S + '/>',
    h_santa: '<path d="M8 36c1-16 8-26 18-26 6 0 9 3 10 7 3 0 6 3 6 8 0 4-1 8-1 11z" fill="#e33b3b" ' + S + '/><path d="M5 34h38v8H5z" ' + W + '/><circle cx="39" cy="17" r="5" ' + W + '/>',
    h_ushanka: '<path d="M10 28c0-11 6-17 14-17s14 6 14 17z" fill="#8a6a4c" ' + S + '/><path d="M6 27h36v6H6z" fill="#6b4f36" ' + S + '/><path d="M6 31c-3 5-3 11 1 12 3 0 4-5 4-12zM42 31c3 5 3 11-1 12-3 0-4-5-4-12z" fill="#8a6a4c" ' + S + '/><path d="M24 14l2 4 4 .6-3 2.800.7 4-3.700-2-3.700 2 .7-4-3-2.800 4-.6z" fill="#ffd23a" stroke="none"/>',
    // bufandas y collares
    s_bow: '<path d="M24 24L5 12v24zM24 24l19-12v24z" fill="#e33b3b" ' + S + '/><circle cx="24" cy="24" r="6" fill="#ff7a8a" ' + S + '/>',
    s_pin: '<path d="M8 24l12-8v16zM40 24L28 16v16z" fill="#2a3552" ' + S + '/><rect x="19" y="17" width="10" height="14" rx="3" ' + O + '/>',
    s_bell: '<path d="M8 12c4 6 28 6 32 0" fill="none" ' + S + ' stroke-width="4"/><path d="M13 36c0-10 3-16 11-16s11 6 11 16z" ' + G + '/><circle cx="24" cy="38" r="3.500" fill="#b8730a" stroke="none"/><path d="M24 14v6" fill="none" ' + S + '/>',
    s_candy: '<circle cx="24" cy="20" r="15" fill="#ff7ab0" ' + S + '/><path d="M24 20c0-4 5-4 5 0s-8 4-8-3 7-8 12-4" fill="none" stroke="#fff" stroke-width="3.200" stroke-linecap="round"/><path d="M24 35v10" fill="none" ' + S + ' stroke-width="4"/>',
    // lentes
    g_goggles: '<path d="M3 21h42v8c0 7-5 11-11 11-5 0-8-3-10-6-2 3-5 6-10 6-6 0-11-4-11-11z" fill="#ff9a3c" ' + S + '/><circle cx="13" cy="28" r="7" fill="#9ad8ff" ' + S + '/><circle cx="35" cy="28" r="7" fill="#9ad8ff" ' + S + '/><path d="M3 24H0M45 24h3" fill="none" ' + S + '/>',
    g_shades: '<path d="M3 17h42l-2 14c-1 5-5 7-9 7-5 0-8-3-9-8h-4c-1 5-4 8-9 8-4 0-8-2-9-7z" fill="#1d2640" ' + S + '/><path d="M10 22l5 5M31 22l5 5" fill="none" stroke="#fff" stroke-width="2.600" stroke-linecap="round" opacity=".6"/>',
    g_round: '<circle cx="13" cy="26" r="10" fill="#d8f0ff" fill-opacity=".7" ' + S + '/><circle cx="35" cy="26" r="10" fill="#d8f0ff" fill-opacity=".7" ' + S + '/><path d="M23 24c1.500-2 2.500-2 4 0M3 22L1 15M45 22l2-7" fill="none" ' + S + '/>',
    g_visor: '<path d="M3 20c0-6 6-9 21-9s21 3 21 9v7c0 5-5 8-12 8H15C8 35 3 32 3 27z" fill="#1f9bd8" ' + S + '/><path d="M10 18c6-3 22-3 28 0" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".7"/><circle cx="40" cy="42" r="2.600" fill="#ffd23a" stroke="none"/>',
    g_heart: '<path d="M13 40C3 33 2 27 2 23c0-4 3-6 6-6 3 0 5 2 5 4 0-2 2-4 5-4 3 0 6 2 6 6 0 4-1 10-11 17z" fill="#ff5c7a" ' + S + '/><path d="M35 40c-10-7-11-13-11-17 0-4 3-6 6-6 3 0 5 2 5 4 0-2 2-4 5-4 3 0 6 2 6 6 0 4-1 10-11 17z" fill="#ff5c7a" ' + S + ' transform="translate(1 -4) scale(.9)"/>',
    g_mask: '<path d="M3 20c6-6 12-6 21-2 9-4 15-4 21 2-1 11-8 18-14 18-4 0-5-5-7-5s-3 5-7 5C11 38 4 31 3 20z" fill="#3a86e8" ' + S + '/><ellipse cx="15" cy="25" rx="5" ry="3.500" fill="#fff" stroke="none"/><ellipse cx="33" cy="25" rx="5" ry="3.500" fill="#fff" stroke="none"/>',
    // ropa
    o_cape: '<path d="M14 6h20l9 36c-6 3-13 4-19 4s-13-1-19-4z" fill="#e33b3b" ' + S + '/><path d="M14 6c3 6 17 6 20 0" fill="none" ' + S + '/><circle cx="24" cy="10" r="3" ' + G + '/>',
    o_pack: '<rect x="10" y="10" width="28" height="34" rx="8" fill="#3a86e8" ' + S + '/><path d="M16 10V8a8 8 0 0116 0v2" fill="none" ' + S + '/><rect x="15" y="26" width="18" height="12" rx="3" fill="#2a65b8" ' + S + '/><path d="M15 31h18" fill="none" ' + S + '/>',
    o_vest: '<path d="M14 4l-4 8v32h12V22l2 4 2-4v22h12V12l-4-8-6 8-4-4-4 4z" fill="#ff9a3c" ' + S + '/><path d="M10 30h12M26 30h12" fill="none" stroke="#fff" stroke-width="3.500"/>',
    o_tux: '<path d="M14 4l-4 38h28l-4-38-10 14z" fill="#2a3552" ' + S + '/><path d="M19 14l5 28 5-28-5 8z" fill="#fff" stroke="none"/><path d="M21 16l3-1.500 3 1.500-3 3z" fill="#e33b3b" stroke="#0a3d91" stroke-width="1.600"/>',
    o_wings: '<path d="M22 40C12 38 3 28 3 8c8 2 14 6 19 14zM26 40c10-2 19-12 19-32-8 2-14 6-19 14z" ' + W + '/><path d="M10 14c3 6 7 10 12 13M38 14c-3 6-7 10-12 13" fill="none" ' + S + ' stroke-width="1.800"/>',
    o_jet: '<rect x="8" y="8" width="13" height="28" rx="6" fill="#c3ccd9" ' + S + '/><rect x="27" y="8" width="13" height="28" rx="6" fill="#c3ccd9" ' + S + '/><path d="M10 36h9l-4.500 9zM29 36h9l-4.500 9z" ' + O + '/><path d="M21 18h6" fill="none" ' + S + ' stroke-width="3"/>',
    // trajes
    set_explorer: '<circle cx="24" cy="24" r="19" ' + W + '/><path d="M31 17l-5 9-9 5 5-9z" ' + O + '/><circle cx="24" cy="24" r="2" fill="#0a3d91" stroke="none"/>',
    set_racer: '<path d="M6 30c0-10 8-16 18-16 9 0 18 5 18 14v4H6z" fill="#e33b3b" ' + S + '/><path d="M14 22c4-4 16-4 22 0" fill="none" stroke="#fff" stroke-width="3" opacity=".7" stroke-linecap="round"/><path d="M4 36h40v5H4z" fill="#2a3552" ' + S + '/>',
    wreath: '<circle cx="24" cy="24" r="19" fill="none" ' + S + ' stroke-width="9"/><circle cx="24" cy="24" r="19" fill="none" stroke="#3aa356" stroke-width="5"/><circle cx="12" cy="14" r="3" fill="#e33b3b" stroke="none"/><circle cx="36" cy="14" r="3" fill="#e33b3b" stroke="none"/><circle cx="24" cy="43" r="3" fill="#e33b3b" stroke="none"/>',
    flame: '<path d="M24 3c3 8 12 13 12 25a12 12 0 01-24 0c0-5 2-8 5-11 0 4 2 6 4 6 0-7-1-12 3-20z" fill="#ff7a1a" ' + S + '/><path d="M24 26c2 3 6 5 6 9a6 6 0 01-12 0c0-4 4-6 6-9z" fill="#ffd23a" stroke="none"/>',
    snowman: '<circle cx="24" cy="32" r="13" ' + W + '/><circle cx="24" cy="13" r="9" ' + W + '/><circle cx="21" cy="12" r="1.600" fill="#0a3d91" stroke="none"/><circle cx="27" cy="12" r="1.600" fill="#0a3d91" stroke="none"/><path d="M24 14l6 2-6 1z" ' + O + '/>'
  };
  PG.ico = function (n) {
    return '<svg class="ic2" viewBox="0 0 48 48" aria-hidden="true">' + (D[n] || '') + '</svg>';
  };
  PG.fillIcons = function (root) {
    var els = (root || document).querySelectorAll('[data-ico]');
    for (var i = 0; i < els.length; i++) if (!els[i].firstChild) els[i].innerHTML = PG.ico(els[i].dataset.ico);
  };
  // definiciones de degradado compartidas por todos los iconos
  var defs = document.createElement('div');
  defs.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
  defs.innerHTML = '<svg width="0" height="0"><defs><linearGradient id="pwRed" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff8a8a"/><stop offset="1" stop-color="#d4202c"/></linearGradient><linearGradient id="pwGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3a0"/><stop offset="1" stop-color="#ff9d1c"/></linearGradient><linearGradient id="pwBlue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8e4ff"/><stop offset="1" stop-color="#2a7be8"/></linearGradient><linearGradient id="pwIce" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#a6dcff"/></linearGradient><linearGradient id="pwGreen" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c2ff94"/><stop offset="1" stop-color="#2fb844"/></linearGradient><linearGradient id="pwPink" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffa6ec"/><stop offset="1" stop-color="#c3249f"/></linearGradient><linearGradient id="pwOrange" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd885"/><stop offset="1" stop-color="#ff5a1a"/></linearGradient><linearGradient id="pwStone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1f5fb"/><stop offset="1" stop-color="#8ea2c0"/></linearGradient><linearGradient id="pwOlive" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8da78"/><stop offset="1" stop-color="#3a7524"/></linearGradient><radialGradient id="pwGlow"><stop offset="0" stop-color="#9fe4ff" stop-opacity=".55"/><stop offset="1" stop-color="#9fe4ff" stop-opacity="0"/></radialGradient><linearGradient id="icW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#bfe3ff"/></linearGradient><linearGradient id="icG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe680"/><stop offset="1" stop-color="#f0a010"/></linearGradient><linearGradient id="icO" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc04a"/><stop offset="1" stop-color="#ff7a14"/></linearGradient></defs></svg>';
  (document.body || document.documentElement).appendChild(defs);
  PG.fillIcons();
})();
