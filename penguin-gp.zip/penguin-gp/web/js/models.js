/* Modelos 3D low-poly: pinguinos personalizables, obstaculos, objetos y efectos */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;
  var hex = PG.hex, shade = PG.shade;

  PG.PAL = {
    body: ['#1c2230', '#35476b', '#5b3a2e', '#7c8494', '#2f7d4f', '#b03a3f', '#d8a53a', '#6a47a3', '#2b8fc4', '#e57fb0', '#f3f5f8', '#2b2e36'],
    accent: ['#e33b3b', '#f28a1e', '#f6d433', '#4cc45a', '#27b8cc', '#3a6df0', '#8b4dd6', '#f06aa8', '#ffffff', '#20242c'],
    belly: ['#ffffff', '#f6efe0', '#dfe9f5', '#ffe3ec'],
    feet: ['#f59a23', '#f4c430', '#e8534a', '#3fb6d1']
  };
  PG.OPT = {
    hats: ['Sin gorro', 'Gorro con pompón', 'Casco', 'Corona', 'Sombrero de copa', 'Gorra', 'Cuernos vikingos', 'Audífonos'],
    scarves: ['Sin bufanda', 'Bufanda', 'Corbatín', 'Pañuelo'],
    glasses: ['Sin lentes', 'Gafas de esquí', 'Gafas de sol', 'Lentes redondos'],
    outfits: ['Sin ropa', 'Chaqueta', 'Capa', 'Mochila']
  };
  PG.defaultCfg = function () {
    return { name: 'Pingu' + (10 + Math.floor(Math.random() * 90)), body: 0, belly: 0, feet: 0, hat: 1, hatCol: 0, scarf: 1, scarfCol: 0, glasses: 0, outfit: 0, outCol: 5 };
  };
  PG.fixCfg = function (c) {
    var d = PG.defaultCfg(); c = c || {};
    var o = {};
    for (var k in d) o[k] = (c[k] === undefined || c[k] === null) ? d[k] : c[k];
    o.name = String(o.name).slice(0, 12) || d.name;
    o.body = ((o.body | 0) % PG.PAL.body.length + PG.PAL.body.length) % PG.PAL.body.length;
    o.belly = (o.belly | 0) % PG.PAL.belly.length; o.feet = (o.feet | 0) % PG.PAL.feet.length;
    o.hat = (o.hat | 0) % PG.OPT.hats.length; o.hatCol = (o.hatCol | 0) % PG.PAL.accent.length;
    o.scarf = (o.scarf | 0) % PG.OPT.scarves.length; o.scarfCol = (o.scarfCol | 0) % PG.PAL.accent.length;
    o.glasses = (o.glasses | 0) % PG.OPT.glasses.length; o.outfit = (o.outfit | 0) % PG.OPT.outfits.length; o.outCol = (o.outCol | 0) % PG.PAL.accent.length;
    return o;
  };

  var penguinCache = {};
  PG.penguinModel = function (cfg) {
    cfg = PG.fixCfg(cfg);
    var key = [cfg.body, cfg.belly, cfg.feet, cfg.hat, cfg.hatCol, cfg.scarf, cfg.scarfCol, cfg.glasses, cfg.outfit, cfg.outCol].join('.');
    if (penguinCache[key]) return penguinCache[key];
    var BODY = hex(PG.PAL.body[cfg.body]), BELLY = hex(PG.PAL.belly[cfg.belly]), FEET = hex(PG.PAL.feet[cfg.feet]);
    var HAT = hex(PG.PAL.accent[cfg.hatCol]), SCF = hex(PG.PAL.accent[cfg.scarfCol]), OUT = hex(PG.PAL.accent[cfg.outCol]);
    var DARK = [0.08, 0.09, 0.12], WHITE = [1, 1, 1], GOLD = [1.0, 0.82, 0.22];
    var parts = [];
    var mb = new PG.MB();
    // cuerpo
    mb.ell(0, 0.46, -0.08, 0.50, 0.43, 0.86, 8, 6, BODY, 0, 0.10);
    mb.ell(0, 0.30, -0.36, 0.40, 0.26, 0.62, 8, 5, BELLY, 0, 0.04);
    mb.ell(0, 0.80, 0.52, 0.36, 0.33, 0.36, 8, 6, BODY, 0, 0.10);
    mb.ell(0, 0.76, 0.70, 0.27, 0.22, 0.22, 7, 5, BELLY, 0, 0.0);
    mb.ell(-0.14, 0.86, 0.90, 0.08, 0.09, 0.05, 6, 4, WHITE, 0.1);
    mb.ell(0.14, 0.86, 0.90, 0.08, 0.09, 0.05, 6, 4, WHITE, 0.1);
    mb.ell(-0.14, 0.86, 0.945, 0.045, 0.055, 0.03, 5, 3, DARK, 0);
    mb.ell(0.14, 0.86, 0.945, 0.045, 0.055, 0.03, 5, 3, DARK, 0);
    mb.push().translate(0, 0.74, 0.92).rotX(PI / 2); mb.cone(0, 0, 0, 0.13, 0.34, 6, FEET, 0.05); mb.pop();
    mb.ell(-0.26, 0.12, -0.90, 0.20, 0.05, 0.30, 6, 3, FEET, 0);
    mb.ell(0.26, 0.12, -0.90, 0.20, 0.05, 0.30, 6, 3, FEET, 0);
    // gorros
    var h = cfg.hat;
    if (h === 1) {
      mb.ell(0, 1.00, 0.50, 0.40, 0.31, 0.40, 8, 5, HAT);
      mb.cyl(0, 0.84, 0.50, 0.41, 0.41, 0.14, 8, shade(HAT, 0.8));
      mb.ell(0, 1.36, 0.50, 0.12, 0.12, 0.12, 6, 4, WHITE);
    } else if (h === 2) {
      mb.ell(0, 0.98, 0.50, 0.42, 0.35, 0.42, 8, 5, HAT);
      mb.box(0, 0.90, 0.88, 0.55, 0.07, 0.26, shade(HAT, 0.6));
      mb.box(0, 1.28, 0.50, 0.10, 0.06, 0.7, WHITE);
    } else if (h === 3) {
      mb.cyl(0, 1.08, 0.50, 0.30, 0.36, 0.17, 8, GOLD, 0.2);
      for (var k = 0; k < 5; k++) { var a = 2 * PI * k / 5; mb.cone(Math.cos(a) * 0.30, 1.25, 0.5 + Math.sin(a) * 0.30, 0.07, 0.22, 4, GOLD, 0.2); }
      mb.ell(0, 1.17, 0.81, 0.05, 0.05, 0.05, 4, 3, HAT, 0.5);
    } else if (h === 4) {
      mb.cyl(0, 1.10, 0.50, 0.46, 0.46, 0.05, 10, DARK);
      mb.cyl(0, 1.14, 0.50, 0.27, 0.27, 0.52, 10, DARK);
      mb.cyl(0, 1.20, 0.50, 0.275, 0.275, 0.12, 10, HAT);
    } else if (h === 5) {
      mb.ell(0, 1.00, 0.50, 0.38, 0.24, 0.38, 8, 4, HAT);
      mb.box(0, 1.01, 0.88, 0.42, 0.04, 0.32, shade(HAT, 0.7));
    } else if (h === 6) {
      mb.ell(0, 0.98, 0.50, 0.40, 0.28, 0.40, 8, 5, [0.62, 0.64, 0.70]);
      var sgn;
      for (sgn = -1; sgn <= 1; sgn += 2) {
        mb.push().translate(sgn * 0.36, 1.05, 0.5).rotZ(-sgn * 0.8); mb.cone(0, 0, 0, 0.09, 0.42, 5, [0.96, 0.93, 0.82]); mb.pop();
      }
    } else if (h === 7) {
      for (var q = 0; q <= 6; q++) { var an = PI * q / 6; mb.push().translate(Math.cos(an) * 0.42, 0.82 + Math.sin(an) * 0.36, 0.5).rotZ(an); mb.box(0, 0, 0, 0.05, 0.14, 0.1, DARK); mb.pop(); }
      mb.ell(-0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
      mb.ell(0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
    }
    // bufandas
    var sc = cfg.scarf;
    if (sc === 1) { mb.push().translate(0, 0.62, 0.34).rotX(0.35); mb.cyl(0, -0.08, 0, 0.47, 0.47, 0.20, 10, SCF); mb.pop(); }
    else if (sc === 2) {
      mb.ell(0, 0.58, 0.82, 0.07, 0.07, 0.07, 5, 3, SCF);
      mb.push().translate(-0.14, 0.58, 0.82).rotZ(PI / 2); mb.cone(0, 0, 0, 0.12, 0.2, 4, SCF); mb.pop();
      mb.push().translate(0.14, 0.58, 0.82).rotZ(-PI / 2); mb.cone(0, 0, 0, 0.12, 0.2, 4, SCF); mb.pop();
    } else if (sc === 3) {
      mb.push().translate(0, 0.62, 0.34).rotX(0.35); mb.cyl(0, -0.06, 0, 0.47, 0.47, 0.13, 10, SCF); mb.pop();
      var o0 = mb.ref; mb.ref = [0, 0.5, 0.45];
      mb.tri([-0.34, 0.66, 0.62], [0.34, 0.66, 0.62], [0, 0.34, 0.86], SCF);
      mb.ref = o0;
    }
    // lentes
    var gl = cfg.glasses;
    if (gl === 1) {
      mb.cyl(0, 0.78, 0.52, 0.375, 0.375, 0.13, 8, DARK);
      mb.ell(-0.14, 0.87, 0.90, 0.13, 0.10, 0.06, 6, 4, [1.0, 0.55, 0.2], 0.45);
      mb.ell(0.14, 0.87, 0.90, 0.13, 0.10, 0.06, 6, 4, [1.0, 0.55, 0.2], 0.45);
    } else if (gl === 2) {
      mb.box(-0.14, 0.87, 0.93, 0.21, 0.11, 0.05, DARK); mb.box(0.14, 0.87, 0.93, 0.21, 0.11, 0.05, DARK);
      mb.box(0, 0.88, 0.93, 0.08, 0.025, 0.04, DARK);
    } else if (gl === 3) {
      var sx;
      for (sx = -1; sx <= 1; sx += 2) {
        mb.push().translate(sx * 0.14, 0.87, 0.94).rotX(PI / 2); mb.cyl(0, 0, 0, 0.11, 0.11, 0.035, 8, GOLD, 0.2); mb.pop();
        mb.ell(sx * 0.14, 0.87, 0.955, 0.085, 0.085, 0.02, 6, 3, [0.7, 0.9, 1.0], 0.4);
      }
    }
    // chaqueta / mochila
    var of = cfg.outfit;
    if (of === 1) {
      mb.ell(0, 0.46, -0.30, 0.545, 0.465, 0.62, 8, 5, OUT);
      mb.ell(0, 0.62, 0.20, 0.50, 0.30, 0.16, 8, 4, shade(OUT, 0.85));
    } else if (of === 3) {
      mb.box(0, 0.88, -0.30, 0.46, 0.34, 0.38, OUT);
      mb.box(0, 0.98, -0.30, 0.48, 0.06, 0.40, shade(OUT, 0.7));
      mb.box(-0.20, 0.70, -0.10, 0.06, 0.06, 0.5, DARK); mb.box(0.20, 0.70, -0.10, 0.06, 0.06, 0.5, DARK);
    }
    parts.push({ mesh: mb.finish(), kind: 'body', pivot: [0, 0, 0] });

    // aletas
    var mf = new PG.MB(); mf.ell(0.40, -0.03, -0.12, 0.42, 0.06, 0.17, 6, 3, BODY, 0, 0.1);
    parts.push({ mesh: mf.finish(), kind: 'flipR', pivot: [0.44, 0.55, 0.25] });
    var ml = new PG.MB(); ml.ell(-0.40, -0.03, -0.12, 0.42, 0.06, 0.17, 6, 3, BODY, 0, 0.1);
    parts.push({ mesh: ml.finish(), kind: 'flipL', pivot: [-0.44, 0.55, 0.25] });
    // cola de bufanda / capa
    if (sc === 1) {
      var mt = new PG.MB(); mt.box(0.0, 0.0, -0.40, 0.20, 0.035, 0.80, SCF); mt.box(0.0, 0.0, -0.78, 0.22, 0.04, 0.12, shade(SCF, 0.75));
      parts.push({ mesh: mt.finish(), kind: 'tail', pivot: [0.20, 0.64, 0.12], amp: 1 });
    }
    if (of === 2) {
      var mc = new PG.MB(); mc.box(0, 0, -0.50, 0.84, 0.035, 1.0, OUT); mc.box(0, 0, -1.0, 0.86, 0.04, 0.1, shade(OUT, 0.75));
      parts.push({ mesh: mc.finish(), kind: 'tail', pivot: [0, 0.76, 0.0], amp: 0.6 });
    }
    var model = { parts: parts, key: key };
    penguinCache[key] = model;
    return model;
  };

  /* ---------- modelos varios ---------- */
  PG.Models = {};
  PG.buildModels = function (theme) {
    var M = PG.Models = {}, t = theme || PG.THEMES.day, mb;
    var snow = t.snow, rock = t.rock, ice = t.ice, shd = shade;

    function rockMesh(seed) {
      var m = new PG.MB(); m.rnd = PG.rng(seed);
      m.ell(0, 0.75, 0, 1.9, 1.1, 1.7, 6, 4, shd(rock, 0.9), 0, 0.30);
      m.ell(0.2, 1.25, 0, 1.3, 0.55, 1.2, 6, 3, snow, 0, 0.05);
      return m.finish();
    }
    M.rock = [rockMesh(3), rockMesh(9), rockMesh(21)];
    mb = new PG.MB();
    mb.box(0, 1.1, 0, 2.5, 2.2, 2.5, [0.62, 0.86, 1.0], 0.25);
    mb.push().rotY(0.7); mb.box(0, 1.2, 0, 2.1, 2.4, 2.1, [0.78, 0.94, 1.0], 0.3); mb.pop();
    mb.crystal(0.4, 2.2, 0.2, 0.5, 1.0, [0.85, 0.97, 1.0], 0.4, 5);
    M.ice = mb.finish();
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.80, 0.95, 7, 5, snow, 0, 0.03);
    mb.ell(0, 1.75, 0, 0.70, 0.62, 0.70, 7, 5, snow, 0, 0.03);
    mb.ell(0, 2.55, 0, 0.50, 0.46, 0.50, 7, 5, snow, 0, 0.03);
    mb.push().translate(0, 2.55, 0.45).rotX(PI / 2); mb.cone(0, 0, 0, 0.09, 0.5, 5, [1, 0.5, 0.1]); mb.pop();
    mb.cyl(0, 2.15, 0, 0.55, 0.55, 0.18, 8, [0.85, 0.15, 0.2]);
    mb.cyl(0, 2.92, 0, 0.48, 0.48, 0.06, 8, [0.1, 0.1, 0.12]); mb.cyl(0, 2.95, 0, 0.30, 0.30, 0.42, 8, [0.1, 0.1, 0.12]);
    mb.ell(-0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]);
    M.snowman = mb.finish();
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.7, 1.7, 8, 5, [0.50, 0.46, 0.46], 0, 0.1);
    mb.ell(0, 0.95, 1.5, 0.55, 0.50, 0.55, 7, 5, [0.55, 0.50, 0.50]);
    mb.ell(0, 0.85, 1.95, 0.22, 0.18, 0.2, 5, 3, [0.1, 0.1, 0.1]);
    mb.ell(-0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]);
    mb.ell(-1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]); mb.ell(1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]);
    mb.ell(0, 0.45, -1.8, 0.45, 0.08, 0.3, 5, 3, [0.45, 0.4, 0.4]);
    M.seal = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(5);
    mb.ell(0, 0, 0, 1.9, 1.9, 1.9, 8, 6, [0.95, 0.97, 1.0], 0, 0.12);
    mb.ell(0.6, 0.9, 0.5, 0.7, 0.6, 0.7, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    mb.ell(-0.8, -0.5, 1.0, 0.6, 0.5, 0.6, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    M.ball = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.7, 0.7, 0.7, 7, 5, [1, 1, 1], 0.15, 0.06); M.snowball = mb.finish();
    mb = new PG.MB();
    mb.box(0, 0.5, 0, 1.0, 1.0, 1.0, [0.55, 0.85, 1.0], 0.35);
    mb.cone(0.3, 0.9, 0.2, 0.18, 0.5, 4, [0.8, 0.95, 1.0], 0.4); mb.cone(-0.3, 0.9, -0.2, 0.18, 0.4, 4, [0.8, 0.95, 1.0], 0.4);
    M.trap = mb.finish();
    // caja de objeto
    mb = new PG.MB();
    mb.push().rotY(0.785).rotX(0.6154);
    mb.box(0, 0, 0, 1.3, 1.3, 1.3, [0.45, 0.80, 1.0], 0.55);
    mb.box(0, 0, 0, 0.7, 0.7, 0.7, [1.0, 1.0, 1.0], 0.9);
    mb.pop();
    M.itemBox = mb.finish();
    // cristal de habilidad sobre pedestal (como en el arte conceptual)
    mb = new PG.MB();
    mb.cyl(0, 0, 0, 1.5, 1.2, 0.9, 8, [0.45, 0.50, 0.60]);
    mb.cyl(0, 0.9, 0, 1.25, 1.25, 0.18, 8, [0.62, 0.68, 0.78]);
    M.pedestal = mb.finish();
    mb = new PG.MB();
    mb.push().translate(0, 1.0, 0);
    mb.crystal(0, 0, 0, 0.55, 2.2, [0.55, 0.95, 1.0], 0.6, 6);
    mb.push().rotZ(0.4); mb.crystal(0.1, 0, 0, 0.38, 1.6, [0.75, 0.70, 1.0], 0.6, 5); mb.pop();
    mb.push().rotZ(-0.45); mb.crystal(-0.1, 0, 0.1, 0.40, 1.7, [0.60, 0.85, 1.0], 0.6, 5); mb.pop();
    mb.push().rotX(0.5); mb.crystal(0, 0, 0.1, 0.32, 1.3, [0.95, 0.75, 1.0], 0.6, 5); mb.pop();
    mb.push().rotX(-0.5); mb.crystal(0, 0, -0.1, 0.34, 1.4, [0.7, 1.0, 0.95], 0.6, 5); mb.pop();
    mb.pop();
    M.crystal = mb.finish();
    // ventisca
    mb = new PG.MB();
    for (var i = 0; i < 7; i++) { var r0 = 1.2 + i * 0.55; mb.cyl(0, i * 1.4, 0, r0, r0 + 0.55, 1.5, 8, [0.9, 0.96, 1.0], 0.3); }
    M.tornado = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.25, 1.05, 1.5, 10, 7, [0.6, 0.85, 1.0], 0.5); M.shield = mb.finish();
    mb = new PG.MB(); mb.up = true;
    mb.cyl(0, 0, 0, 0.62, 0.62, 0.02, 10, [0.05, 0.08, 0.15]); M.shadow = mb.finish();
    // anillo de brillo para pads etc.
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.12, 0.12, 0.12, 4, 3, [1, 1, 1], 1); M.spark = mb.finish();
  };
})();
