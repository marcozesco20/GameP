/* Modelos 3D low-poly: pinguinos personalizables, obstaculos, objetos y efectos */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;
  var hex = PG.hex, shade = PG.shade;

  PG.PAL = {
    body: ['#1c2230', '#35476b', '#5b3a2e', '#7c8494', '#2f7d4f', '#b03a3f', '#d8a53a', '#6a47a3', '#2b8fc4', '#e57fb0', '#f3f5f8', '#2b2e36'],
    accent: ['#e33b3b', '#f28a1e', '#f6d433', '#4cc45a', '#27b8cc', '#3a6df0', '#8b4dd6', '#f06aa8', '#ffffff', '#20242c'],
    belly: ['#ffffff', '#f6efe0', '#dfe9f5', '#ffe3ec'],
    feet: ['#f59a23', '#f4c430', '#e8534a', '#3fb6d1']
  };
  PG.OPT = {
    hats: ['Sin gorro', 'Gorro con pompón', 'Casco', 'Corona', 'Sombrero de copa', 'Gorra', 'Cuernos vikingos', 'Audífonos', 'Sombrero de mago', 'Sombrero vaquero', 'Gorro de chef', 'Orejas de gato', 'Gorro de fiesta', 'Aureola', 'Gorro de Papá Noel', 'Ushanka de piel'],
    scarves: ['Sin bufanda', 'Bufanda', 'Corbatín', 'Pañuelo', 'Medalla', 'Collar de cascabel', 'Bufanda a rayas'],
    glasses: ['Sin lentes', 'Gafas de esquí', 'Gafas de sol', 'Lentes redondos', 'Visor futurista', 'Corazones', 'Antifaz'],
    outfits: ['Sin ropa', 'Chaqueta', 'Capa', 'Mochila', 'Chaleco acolchado', 'Esmoquin', 'Alas de ángel', 'Jetpack']
  };
  // v3.4: conjuntos de ropa (se compran en la tienda y se ponen de golpe desde Mi pingüino)
  PG.SETS = [
    { id: 'arctic', name: 'Explorador Ártico', ico: ':ic_set_explorer:', price: 420, d: 'Ushanka, gafas de esquí y chaqueta naranja para las expediciones polares.', c: { hat: 15, hatCol: 1, scarf: 1, scarfCol: 0, glasses: 1, outfit: 1, outCol: 1 } },
    { id: 'racer', name: 'Piloto de Carreras', ico: ':ic_set_racer:', price: 480, d: 'Casco, visor futurista y chaqueta roja: listo para la parrilla.', c: { hat: 2, hatCol: 0, scarf: 0, scarfCol: 0, glasses: 4, outfit: 1, outCol: 0 } },
    { id: 'ski', name: 'Esquiador Vintage', ico: ':ic_skier:', price: 360, d: 'Gorro con pompón, gafas de esquí y bufanda a rayas, estilo retro.', c: { hat: 1, hatCol: 4, scarf: 6, scarfCol: 0, glasses: 1, outfit: 4, outCol: 5 } },
    { id: 'king', name: 'Rey del Hielo', ico: ':ic_crown:', price: 700, d: 'Corona dorada, capa real y medalla: el soberano de la nieve.', c: { hat: 3, hatCol: 2, scarf: 4, scarfCol: 2, glasses: 0, outfit: 2, outCol: 6 } },
    { id: 'dandy', name: 'Dandy Clásico', ico: ':ic_h_top:', price: 560, d: 'Sombrero de copa, lentes redondos, corbatín y esmoquin.', c: { hat: 4, hatCol: 0, scarf: 2, scarfCol: 0, glasses: 3, outfit: 5, outCol: 9 } },
    { id: 'xmas', name: 'Navidad Festiva', ico: ':ic_h_santa:', price: 380, d: 'Gorro de Papá Noel, bufanda a rayas y chaqueta roja.', c: { hat: 14, hatCol: 0, scarf: 6, scarfCol: 3, glasses: 0, outfit: 1, outCol: 0 } },
    { id: 'viking', name: 'Guerrero Vikingo', ico: ':ic_h_horns:', price: 520, d: 'Casco con cuernos y capa de guerra con medalla.', c: { hat: 6, hatCol: 0, scarf: 4, scarfCol: 1, glasses: 0, outfit: 2, outCol: 1 } },
    { id: 'tact', name: 'Aventurero Táctico', ico: ':ic_h_ushanka:', price: 450, d: 'Gorra, gafas de sol, chaleco acolchado y mochila de campaña.', c: { hat: 5, hatCol: 3, scarf: 3, scarfCol: 3, glasses: 2, outfit: 4, outCol: 3 } }
  ];
  PG.defaultCfg = function () {
    return { name: 'Pingu' + (10 + Math.floor(Math.random() * 90)), body: 0, belly: 0, feet: 0, hat: 1, hatCol: 0, scarf: 1, scarfCol: 0, glasses: 0, outfit: 0, outCol: 5 };
  };
  PG.fixCfg = function (c) {
    var d = PG.defaultCfg(); c = c || {};
    var o = {};
    for (var k in d) o[k] = (c[k] === undefined || c[k] === null) ? d[k] : c[k];
    o.name = String(o.name).slice(0, 12) || d.name;
    o.body = ((o.body | 0) % PG.PAL.body.length + PG.PAL.body.length) % PG.PAL.body.length;
    o.belly = (o.belly | 0) % PG.PAL.belly.length; o.feet = (o.feet | 0) % PG.PAL.feet.length;
    o.hat = (o.hat | 0) % PG.OPT.hats.length; o.hatCol = (o.hatCol | 0) % PG.PAL.accent.length;
    o.scarf = (o.scarf | 0) % PG.OPT.scarves.length; o.scarfCol = (o.scarfCol | 0) % PG.PAL.accent.length;
    o.glasses = (o.glasses | 0) % PG.OPT.glasses.length; o.outfit = (o.outfit | 0) % PG.OPT.outfits.length; o.outCol = (o.outCol | 0) % PG.PAL.accent.length;
    return o;
  };

  var penguinCache = {};
  // el modelo original tiene la cabeza levantada (pose de deslizamiento): de pie se baja para que mire al frente
  var HEAD_NOD = 0.6;
  function warpHead(mesh, np, beta) {
    var y0 = 0.48, y1 = 0.63, c = {};
    mesh.chunks.forEach(function (ch) {
      var f = new Float32Array(ch.buf), i8 = new Int8Array(ch.buf), o, k, q;
      for (o = 0; o < ch.n; o += 3) {
        var oldN = [i8[o * 20 + 12], i8[o * 20 + 13], i8[o * 20 + 14]], P = [];
        for (k = 0; k < 3; k++) {
          q = (o + k) * 5; var y = f[q + 1], z = f[q + 2];
          var t = Math.max(0, Math.min(1, (y - y0) / (y1 - y0))); t = t * t * (3 - 2 * t);
          var a = beta * t, ca = Math.cos(a), sa = Math.sin(a), dy = y - np[1], dz = z - np[2];
          f[q + 1] = np[1] + dy * ca - dz * sa; f[q + 2] = np[2] + dy * sa + dz * ca;
          P.push([f[q], f[q + 1], f[q + 2]]);
        }
        var ux = P[1][0] - P[0][0], uy = P[1][1] - P[0][1], uz = P[1][2] - P[0][2], vx = P[2][0] - P[0][0], vy = P[2][1] - P[0][1], vz = P[2][2] - P[0][2];
        var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
        if (nx * oldN[0] + ny * oldN[1] + nz * oldN[2] < 0) { nx = -nx; ny = -ny; nz = -nz; }
        for (k = 0; k < 3; k++) { var ob = (o + k) * 20; i8[ob + 12] = (nx / len * 127) | 0; i8[ob + 13] = (ny / len * 127) | 0; i8[ob + 14] = (nz / len * 127) | 0; }
      }
    });
    return mesh;
  }
  function buildPenguin(cfg, standing, hi) {
    cfg = PG.fixCfg(cfg);
    var key = (standing ? 's' : 'r') + (hi ? 'h' : '') + [cfg.body, cfg.belly, cfg.feet, cfg.hat, cfg.hatCol, cfg.scarf, cfg.scarfCol, cfg.glasses, cfg.outfit, cfg.outCol].join('.');
    if (penguinCache[key]) return penguinCache[key];
    var Ci = Math.cos(PG.FBX.pen.theta), Si = Math.sin(PG.FBX.pen.theta);
    var BODY = hex(PG.PAL.body[cfg.body]), BELLY = hex(PG.PAL.belly[cfg.belly]), FEET = hex(PG.PAL.feet[cfg.feet]);
    var HAT = hex(PG.PAL.accent[cfg.hatCol]), SCF = hex(PG.PAL.accent[cfg.scarfCol]), OUT = hex(PG.PAL.accent[cfg.outCol]);
    var DARK = [0.08, 0.09, 0.12], WHITE = [1, 1, 1], GOLD = [1.0, 0.82, 0.22], HAT_MASK = shade(HAT, 0.9);
    var P = PG.FBX.pen, TH = P.theta, PS = P.scale, YO = P.yo, ZC = P.zc, AL = P.alpha, NP = P.np;
    var ALh = standing ? 0.52 - HEAD_NOD : AL; // inclinacion de la cabeza para gorros y lentes (de pie la cabeza esta menos inclinada)
    var pal = [BODY, BELLY, FEET, [0.04, 0.04, 0.06], WHITE];
    var parts = [];
    var mb = new PG.MB(); mb.subdiv = !!hi;
    // pose de deslizamiento: el modelo original (de pie) se acuesta sobre la panza y se escala
    function stand() { if (standing) mb.push(); else mb.push().scale(PS, PS, PS).translate(0, YO, -ZC).rotX(TH); }
    // punto del espacio 'pose de deslizamiento' -> espacio de pie (inverso de stand())
    function unslide(p) { var x = p[0] / PS, y = p[1] / PS - YO, z = p[2] / PS + ZC; return [x, y * Ci + z * Si, -y * Si + z * Ci]; }
    // punto del modelo "de pie" -> mundo (para pivotes)
    function slideP(x, y, z) { var c = Math.cos(TH), s = Math.sin(TH); return [x * PS, (y * c - z * s + YO) * PS, (y * s + z * c - ZC) * PS]; }
    var mbb = standing ? new PG.MB() : mb; // de pie: el cuerpo base va aparte para poder bajar la cabeza (mirar al frente)
    mbb.push(); mbb.m = null;
    if (standing) mbb.rotX(-TH).translate(0, -YO, ZC).scale(1 / PS, 1 / PS, 1 / PS);
    mbb.subdiv = !!hi; mbb.fbx(P.parts[0], pal, 0.02);
    mbb.pop();
    var bodyBase = standing ? warpHead(mbb.finish(), NP, HEAD_NOD) : null;
    // patas palmeadas atras (las del modelo original apuntarian al suelo en esta pose)
    var fi, fx;
    for (fi = 0; !standing && fi < 2; fi++) {
      fx = P.feet[fi];
      mb.ell(fx[0] * 1.05, fx[1] + 0.02, fx[2] - 0.12, 0.115, 0.035, 0.2, 6, 3, FEET, 0, 0.1);
    }
    // ---- ropa y accesorios (se dibujan en el espacio "de pie" y se transforman con la pose) ----
    stand();
    // gorros: se reutilizan los disenos con una transformacion a la cabeza del modelo (centro 0,0.71,-0.03; radio ~0.21)
    var HATMAT = [0, 1, 4, 5, 2, 2, 5, 4, 2, 2, 2, 3, 2, 5, 1, 3], SCMAT = [0, 1, 2, 2, 5, 5, 2], GLMAT = [0, 4, 4, 4, 4, 4, 2], OFMAT = [0, 2, 2, 2, 2, 2, 3, 5];
    mb.mat = HATMAT[cfg.hat] | 0;
    var h = cfg.hat, HATSC = standing ? { 4: 0.54, 8: 0.5, 9: 0.5 } : {}, HATTILT = { 4: 0.2, 8: 0.26, 9: 0.2 }, HATBACK = { 4: [0.01, -0.03], 8: [0.0, -0.045], 9: [0.01, -0.03] };
    // v3.1: de pie los gorros altos (copa, mago, fiesta, chef, corona, aureola) se asientan casi verticales sobre la cabeza (antes se inclinaban hacia delante y tapaban la cara)
    var ALhat = (standing && (h === 3 || h === 4 || h === 8 || h === 10 || h === 12 || h === 13 || h === 14)) ? ALh * 0.22 : ALh;
    mb.push().translate(NP[0], NP[1], NP[2]).rotX(-ALhat).translate(-NP[0], -NP[1], -NP[2]);
    if (standing) mb.translate(0, { 1: 0.02, 2: 0.012, 4: 0.012, 8: 0.095, 9: 0.03, 10: 0.05, 11: 0.012, 12: 0.065, 14: 0.03, 15: 0.05 }[h] || 0, 0); // v3.2.1: sombreros con ala suben un poco para no tapar los ojos / lentes
    // de pie los gorros bajos (pompón, gorra, casco) se echan hacia atrás y arriba para dejar ver los ojos
    if (standing && (h === 1 || h === 2 || h === 5 || h === 6 || h === 9 || h === 10 || h === 11 || h === 15)) mb.push().translate(0, 0.715, -0.03).rotX(-0.42).translate(0, 0.055, -0.045).translate(0, -0.715, 0.03);
    else if (standing && (h === 4 || h === 8 || h === 9)) mb.push().translate(0, 0.715, -0.03).rotX(-HATTILT[h]).translate(0, HATBACK[h][0], HATBACK[h][1]).translate(0, -0.715, 0.03); // v3.4: copa/mago/vaquero se echan un poco hacia atras para que el ala no tape ojos ni lentes
    else mb.push();
    mb.push().translate(0, 0.715, -0.03).scale(HATSC[h] || 0.58, HATSC[h] || 0.58, HATSC[h] || 0.58).translate(0, -0.80, -0.52);
    if (h === 1) {
      mb.ell(0, 1.00, 0.50, 0.40, 0.31, 0.40, 8, 5, HAT);
      mb.cyl(0, 0.84, 0.50, 0.41, 0.41, 0.14, 8, shade(HAT, 0.8));
      mb.ell(0, 1.36, 0.50, 0.12, 0.12, 0.12, 6, 4, WHITE);
    } else if (h === 2) {
      mb.ell(0, 0.98, 0.50, 0.42, 0.35, 0.42, 8, 5, HAT);
      mb.box(0, 0.90, 0.88, 0.55, 0.07, 0.26, shade(HAT, 0.6));
      mb.box(0, 1.28, 0.50, 0.10, 0.06, 0.7, WHITE);
    } else if (h === 3) {
      mb.cyl(0, 1.08, 0.50, 0.30, 0.36, 0.17, 8, GOLD, 0.2);
      for (var k = 0; k < 5; k++) { var a = 2 * PI * k / 5; mb.cone(Math.cos(a) * 0.30, 1.25, 0.5 + Math.sin(a) * 0.30, 0.07, 0.22, 4, GOLD, 0.2); }
      mb.ell(0, 1.17, 0.81, 0.05, 0.05, 0.05, 4, 3, HAT, 0.5);
    } else if (h === 4) {
      mb.cyl(0, 1.10, 0.50, 0.46, 0.46, 0.05, 10, DARK);
      mb.cyl(0, 1.14, 0.50, 0.27, 0.27, 0.52, 10, DARK);
      mb.cyl(0, 1.20, 0.50, 0.275, 0.275, 0.12, 10, HAT);
    } else if (h === 5) {
      mb.ell(0, 1.00, 0.50, 0.38, 0.24, 0.38, 8, 4, HAT);
      mb.box(0, 1.01, 0.88, 0.42, 0.04, 0.32, shade(HAT, 0.7));
    } else if (h === 6) {
      mb.ell(0, 0.98, 0.50, 0.40, 0.28, 0.40, 8, 5, [0.62, 0.64, 0.70]);
      var sgn;
      for (sgn = -1; sgn <= 1; sgn += 2) {
        mb.push().translate(sgn * 0.36, 1.05, 0.5).rotZ(-sgn * 0.8); mb.cone(0, 0, 0, 0.09, 0.42, 5, [0.96, 0.93, 0.82]); mb.pop();
      }
    } else if (h === 7) {
      for (var q = 0; q <= 6; q++) { var an = PI * q / 6; mb.push().translate(Math.cos(an) * 0.42, 0.82 + Math.sin(an) * 0.36, 0.5).rotZ(an); mb.box(0, 0, 0, 0.05, 0.14, 0.1, DARK); mb.pop(); }
      mb.ell(-0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
      mb.ell(0.42, 0.82, 0.50, 0.09, 0.17, 0.17, 6, 4, HAT);
    }
    else if (h === 8) { // mago: cono con ala ancha, cinta dorada, punta doblada y estrellas
      mb.cyl(0, 0.89, 0.50, 0.54, 0.54, 0.05, 12, shade(HAT, 0.78));
      mb.cone(0, 0.91, 0.50, 0.37, 0.56, 10, HAT);
      mb.cyl(0, 0.95, 0.50, 0.375, 0.375, 0.07, 10, GOLD, 0.25);
      mb.push().translate(0, 1.43, 0.50).rotZ(-0.55); mb.cone(0, 0, 0, 0.15, 0.34, 8, HAT); mb.pop();
      mb.push().translate(0.17, 1.72, 0.50).rotZ(-1.1); mb.cone(0, 0, 0, 0.07, 0.19, 6, shade(HAT, 1.1)); mb.pop();
      var wsa = [0.9, 2.7, 4.6, 5.6], wsy = [1.12, 1.26, 1.02, 1.36];
      for (var ws = 0; ws < 4; ws++) { var wr = 0.37 * (1 - (wsy[ws] - 0.91) / 0.56) * 1.03; mb.push().translate(Math.cos(wsa[ws]) * wr, wsy[ws], 0.50 + Math.sin(wsa[ws]) * wr).rotY(-wsa[ws] + PI / 2); mb.ell(0, 0, 0, 0.055, 0.055, 0.02, 5, 3, GOLD, 0.7); mb.pop(); }
    } else if (h === 9) { // vaquero: ala curvada hacia arriba, copa hundida y cinta con hebilla
      mb.cyl(0, 0.89, 0.50, 0.62, 0.62, 0.04, 12, shade(HAT, 0.72));
      for (var vs = -1; vs <= 1; vs += 2) { mb.push().translate(vs * 0.56, 0.96, 0.50).rotZ(-vs * 0.5); mb.box(0, 0, 0, 0.14, 0.035, 0.46, shade(HAT, 0.72)); mb.pop(); }
      mb.push().translate(0, 0.90, 0.88).rotX(-0.2); mb.box(0, 0.02, 0, 0.30, 0.03, 0.2, shade(HAT, 0.72)); mb.pop();
      mb.ell(0, 1.06, 0.50, 0.31, 0.24, 0.31, 9, 5, HAT);
      mb.box(0, 1.27, 0.50, 0.05, 0.05, 0.4, shade(HAT, 0.6)); // hendidura de la copa
      mb.cyl(0, 0.95, 0.50, 0.325, 0.325, 0.07, 9, DARK);
      mb.box(0, 0.95, 0.83, 0.07, 0.07, 0.03, GOLD, 0.3);
    } else if (h === 10) { // chef: banda y copa abombada hecha con varias bolas
      mb.cyl(0, 0.88, 0.50, 0.36, 0.36, 0.17, 10, [0.97, 0.97, 1.0]);
      mb.cyl(0, 0.84, 0.50, 0.37, 0.37, 0.035, 10, HAT);
      mb.ell(0, 1.20, 0.50, 0.40, 0.30, 0.40, 9, 5, [1, 1, 1]);
      for (var cb = 0; cb < 6; cb++) { var ca = cb / 6 * 2 * PI; mb.ell(Math.cos(ca) * 0.31, 1.12, 0.50 + Math.sin(ca) * 0.31, 0.20, 0.22, 0.20, 7, 4, [0.95, 0.96, 1.0]); }
      mb.ell(0, 1.34, 0.50, 0.26, 0.2, 0.26, 7, 4, [1, 1, 1]);
    } else if (h === 11) { // orejas de gato: diadema y dos orejas con interior rosa
      for (var gq = 0; gq <= 8; gq++) { var gan = PI * gq / 8; mb.push().translate(Math.cos(gan) * 0.40, 0.84 + Math.sin(gan) * 0.34, 0.50).rotZ(gan); mb.box(0, 0, 0, 0.045, 0.12, 0.09, DARK); mb.pop(); }
      for (var gs = -1; gs <= 1; gs += 2) {
        mb.push().translate(gs * 0.27, 1.10, 0.46).rotZ(-gs * 0.32); mb.cone(0, 0, 0, 0.17, 0.36, 4, HAT); mb.pop();
        mb.push().translate(gs * 0.265, 1.12, 0.505).rotZ(-gs * 0.32); mb.cone(0, 0, 0, 0.10, 0.24, 4, [1.0, 0.72, 0.8]); mb.pop();
      }
    } else if (h === 12) { // gorro de fiesta: cono con rayas, borla dorada y tiras
      mb.cone(0, 0.93, 0.50, 0.30, 0.82, 10, HAT);
      var fr = [0.18, 0.38, 0.58];
      for (var fq = 0; fq < 3; fq++) mb.cyl(0, 0.93 + fr[fq], 0.50, 0.30 * (1 - fr[fq] / 0.82) + 0.012, 0.30 * (1 - fr[fq] / 0.82) + 0.012, 0.055, 10, [1, 1, 1]);
      mb.cyl(0, 0.93, 0.50, 0.305, 0.305, 0.05, 10, GOLD, 0.2);
      for (var fz = 0; fz < 6; fz++) { var fa = fz / 6 * 2 * PI; mb.ell(Math.cos(fa) * 0.34, 0.99, 0.50 + Math.sin(fa) * 0.34, 0.035, 0.035, 0.035, 4, 3, GOLD, 0.5); }
      mb.ell(0, 1.77, 0.50, 0.11, 0.11, 0.11, 7, 4, GOLD, 0.5);
    } else if (h === 13) { // aureola: anillo dorado flotando sobre la cabeza
      for (var hq = 0; hq < 14; hq++) { var haa = hq / 14 * 2 * PI; mb.push().translate(Math.cos(haa) * 0.34, 1.34, 0.50 + Math.sin(haa) * 0.34).rotY(-haa); mb.box(0, 0, 0, 0.04, 0.04, 0.115, GOLD, 0.9); mb.pop(); }
      mb.ell(0, 1.34, 0.50, 0.30, 0.012, 0.30, 12, 2, [1.0, 0.95, 0.6], 0.6);
    }
    else if (h === 14) { // Papa Noel: cono caido con ribete blanco y pompon
      mb.cone(0, 0.90, 0.50, 0.40, 0.56, 10, HAT);
      mb.push().translate(0.02, 1.40, 0.50).rotZ(-0.75); mb.cone(0, 0, 0, 0.23, 0.46, 9, HAT); mb.pop();
      mb.push().translate(0, 0.88, 0.50); mb.cyl(0, 0, 0, 0.435, 0.435, 0.12, 12, [0.98, 0.98, 1.0]); mb.pop();
      mb.ell(0.30, 1.70, 0.50, 0.11, 0.11, 0.11, 7, 5, [1, 1, 1]);
    } else if (h === 15) { // ushanka: copa de piel con orejeras y escudo dorado
      var FUR = shade(HAT, 0.8);
      mb.ell(0, 0.98, 0.50, 0.43, 0.31, 0.43, 9, 5, FUR);
      mb.cyl(0, 0.86, 0.50, 0.44, 0.44, 0.10, 10, shade(HAT, 0.65));
      for (var us = -1; us <= 1; us += 2) { mb.push().translate(us * 0.42, 0.70, 0.50).rotZ(us * 0.12); mb.ell(0, 0, 0, 0.11, 0.25, 0.18, 7, 4, FUR); mb.pop(); }
      mb.box(0, 1.27, 0.50, 0.05, 0.03, 0.30, shade(HAT, 0.6));
      mb.ell(0, 0.97, 0.88, 0.06, 0.06, 0.03, 6, 3, GOLD, 0.4);
    }
    mb.pop(); mb.pop(); mb.pop(); // fin gorro
    // bufandas
    mb.mat = SCMAT[cfg.scarf] | 0;
    var sc = cfg.scarf;
    if (sc === 1) mb.ell(0, 0.50, -0.065, 0.30, 0.055, 0.275, 10, 3, SCF);
    else if (sc === 2) {
      mb.ell(0, 0.55, 0.19, 0.04, 0.04, 0.04, 5, 3, SCF);
      mb.push().translate(-0.08, 0.55, 0.19).rotZ(PI / 2); mb.cone(0, 0, 0, 0.07, 0.11, 4, SCF); mb.pop();
      mb.push().translate(0.08, 0.55, 0.19).rotZ(-PI / 2); mb.cone(0, 0, 0, 0.07, 0.11, 4, SCF); mb.pop();
    } else if (sc === 3) {
      mb.ell(0, 0.505, -0.065, 0.30, 0.04, 0.275, 10, 3, SCF);
      mb.tri([-0.2, 0.58, 0.14], [0.2, 0.58, 0.14], [0, 0.36, 0.21], SCF);
    } else if (sc === 4) { // medalla de oro con cinta en V y estrella
      mb.ell(0, 0.50, -0.065, 0.285, 0.035, 0.265, 10, 3, shade(SCF, 0.85));
      mb.tri([-0.15, 0.53, 0.10], [-0.07, 0.53, 0.14], [0, 0.34, 0.225], SCF);
      mb.tri([0.15, 0.53, 0.10], [0.07, 0.53, 0.14], [0, 0.34, 0.225], shade(SCF, 0.8));
      mb.push().translate(0, 0.325, 0.232).rotX(PI / 2); mb.cyl(0, 0, 0, 0.05, 0.05, 0.025, 12, GOLD, 0.35); mb.cyl(0, 0.01, 0, 0.034, 0.034, 0.025, 12, [1.0, 0.93, 0.55], 0.5); mb.pop();
    } else if (sc === 5) { // collar con cascabel dorado
      mb.ell(0, 0.50, -0.065, 0.295, 0.04, 0.27, 10, 3, SCF);
      mb.ell(0, 0.455, 0.215, 0.06, 0.06, 0.06, 7, 5, GOLD, 0.45);
      mb.box(0, 0.445, 0.268, 0.05, 0.008, 0.01, DARK); mb.ell(0, 0.43, 0.27, 0.012, 0.012, 0.012, 4, 3, DARK);
      mb.box(0, 0.505, 0.205, 0.05, 0.02, 0.02, shade(SCF, 0.75));
    } else if (sc === 6) { // bufanda a rayas: dos colores y un extremo colgando por delante
      mb.ell(0, 0.525, -0.065, 0.30, 0.03, 0.275, 10, 3, SCF);
      mb.ell(0, 0.495, -0.065, 0.305, 0.03, 0.28, 10, 3, [0.97, 0.97, 1.0]);
      mb.ell(0, 0.465, -0.065, 0.30, 0.03, 0.275, 10, 3, SCF);
      mb.box(0.10, 0.37, 0.205, 0.09, 0.19, 0.025, SCF); mb.box(0.10, 0.40, 0.22, 0.092, 0.035, 0.012, [0.97, 0.97, 1.0]); mb.box(0.10, 0.33, 0.22, 0.092, 0.035, 0.012, [0.97, 0.97, 1.0]);
      for (var tf = 0; tf < 4; tf++) mb.box(0.062 + tf * 0.025, 0.265, 0.21, 0.008, 0.05, 0.01, shade(SCF, 0.8));
    }
    mb.mat = GLMAT[cfg.glasses] | 0;
    // lentes (sobre los ojos del modelo: x=+-0.10, y=0.71, z=0.18)
    var gl = cfg.glasses;
    mb.push().translate(NP[0], NP[1], NP[2]).rotX(-ALh).translate(-NP[0], -NP[1], -NP[2]);
    if (standing) mb.translate(0, 0.10, -0.108); // v3.4: mas pegado a la cara; v3.0: ajustado a la linea de los ojos y pegado a la cara
    if (gl === 1) {
      mb.cyl(0, 0.685, -0.03, 0.222, 0.222, 0.06, 9, DARK);
      mb.ell(-0.10, 0.712, 0.19, 0.08, 0.06, 0.04, 6, 4, [1.0, 0.55, 0.2], 0.45);
      mb.ell(0.10, 0.712, 0.19, 0.08, 0.06, 0.04, 6, 4, [1.0, 0.55, 0.2], 0.45);
    } else if (gl === 2) {
      mb.box(-0.10, 0.714, 0.205, 0.125, 0.062, 0.03, DARK); mb.box(0.10, 0.714, 0.205, 0.125, 0.062, 0.03, DARK);
      mb.box(0, 0.722, 0.205, 0.06, 0.016, 0.026, DARK);
    } else if (gl === 3) {
      var sx;
      for (sx = -1; sx <= 1; sx += 2) {
        mb.push().translate(sx * 0.10, 0.714, 0.2).rotX(PI / 2); mb.cyl(0, 0, 0, 0.06, 0.06, 0.03, 8, GOLD, 0.2); mb.pop();
        mb.ell(sx * 0.10, 0.714, 0.222, 0.047, 0.047, 0.014, 6, 3, [0.7, 0.9, 1.0], 0.4);
      }
    } else if (gl === 4) { // visor futurista: franja luminosa con marco oscuro y patillas
      mb.box(0, 0.714, 0.205, 0.34, 0.07, 0.03, [0.1, 0.9, 1.0], 0.85);
      mb.box(0, 0.752, 0.206, 0.35, 0.014, 0.034, DARK); mb.box(0, 0.676, 0.206, 0.35, 0.014, 0.034, DARK);
      mb.box(0, 0.714, 0.222, 0.30, 0.012, 0.01, [0.85, 1.0, 1.0], 0.9);
      mb.box(-0.178, 0.714, 0.12, 0.014, 0.05, 0.19, DARK); mb.box(0.178, 0.714, 0.12, 0.014, 0.05, 0.19, DARK);
    } else if (gl === 5) { // lentes de corazon
      var hx;
      for (hx = -1; hx <= 1; hx += 2) {
        mb.ell(hx * 0.10 - 0.024, 0.727, 0.214, 0.042, 0.04, 0.012, 6, 4, [1.0, 0.35, 0.55], 0.45);
        mb.ell(hx * 0.10 + 0.024, 0.727, 0.214, 0.042, 0.04, 0.012, 6, 4, [1.0, 0.35, 0.55], 0.45);
        mb.tri([hx * 0.10 - 0.066, 0.722, 0.214], [hx * 0.10 + 0.066, 0.722, 0.214], [hx * 0.10, 0.665, 0.214], [1.0, 0.35, 0.55], 0.45);
        mb.tri([hx * 0.10 - 0.066, 0.722, 0.2145], [hx * 0.10 + 0.066, 0.722, 0.2145], [hx * 0.10, 0.665, 0.2145], [1.0, 0.35, 0.55], 0.45);
      }
      mb.box(0, 0.722, 0.208, 0.07, 0.012, 0.014, DARK);
    } else if (gl === 6) { // antifaz de superheroe con ojos blancos
      mb.ell(0, 0.714, 0.195, 0.205, 0.058, 0.04, 10, 4, HAT_MASK);
      mb.tri([-0.205, 0.742, 0.17], [-0.275, 0.77, 0.10], [-0.2, 0.69, 0.16], HAT_MASK);
      mb.tri([0.205, 0.742, 0.17], [0.275, 0.77, 0.10], [0.2, 0.69, 0.16], HAT_MASK);
      mb.ell(-0.10, 0.714, 0.226, 0.048, 0.034, 0.012, 6, 3, [1, 1, 1], 0.5); mb.ell(0.10, 0.714, 0.226, 0.048, 0.034, 0.012, 6, 3, [1, 1, 1], 0.5);
    }
    mb.pop();
    mb.mat = OFMAT[cfg.outfit] | 0;
    // chaqueta / mochila
    var of = cfg.outfit;
    if (of === 1) {
      if (standing) { // v2.9: de pie la chaqueta abraza el cuerpo (antes era un globo mas ancho que el pinguino)
        mb.ell(0, 0.27, -0.035, 0.305, 0.32, 0.31, 14, 9, OUT, 0, 0.0);
        mb.ell(0, 0.50, -0.05, 0.285, 0.095, 0.275, 10, 3, shade(OUT, 0.8), 0, 0.02);
      } else {
        mb.ell(0, 0.30, -0.03, 0.355, 0.345, 0.345, 14, 9, OUT, 0, 0.0);
        mb.ell(0, 0.52, -0.05, 0.315, 0.105, 0.31, 10, 3, shade(OUT, 0.8), 0, 0.02);
      }
    } else if (of === 3) {
      if (standing) { // mochila apoyada en la espalda, a la altura de los omoplatos, con tirantes sobre los hombros
        mb.box(0, 0.33, -0.30, 0.25, 0.27, 0.12, OUT);
        mb.box(0, 0.47, -0.30, 0.26, 0.035, 0.13, shade(OUT, 0.7));
        mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
      } else {
        mb.box(0, 0.40, -0.285, 0.25, 0.27, 0.12, OUT);
        mb.box(0, 0.54, -0.29, 0.26, 0.035, 0.13, shade(OUT, 0.7));
        mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
      }
    } else if (of === 2) {
      // capa: esclavina sobre los hombros + panel pegado a la espalda (tambien de pie)
      if (standing) { // de pie cae como tela: estrecha arriba (en los hombros) y se abre hacia abajo siguiendo la espalda
        mb.ell(0, 0.50, -0.05, 0.285, 0.095, 0.275, 10, 3, shade(OUT, 0.8), 0, 0.02);
        // v3.2.1: la capa envuelve la espalda (antes era un plano rigido que sobresalia hacia atras): tela curva que sigue el cuerpo y se abre un poco abajo
        (function () {
          var rowsN = 6, colsN = 9, a0 = -1.25, ri, ci, prev = null, o2 = mb.ref; mb.ref = [0, 0.27, -0.035];
          for (ri = 0; ri <= rowsN; ri++) {
            var tq = ri / rowsN, yy = 0.5 - tq * 0.42, ss = Math.sqrt(Math.max(0.12, 1 - Math.pow((yy - 0.27) / 0.36, 2))), fl = 1 + 0.10 * tq * tq, row = [];
            for (ci = 0; ci <= colsN; ci++) {
              var an = a0 + (-2 * a0) * ci / colsN, wav = 1 + 0.025 * Math.sin(ci * 2.1 + ri) * tq;
              row.push([Math.sin(an) * (0.335 * ss + 0.012) * fl * wav, yy, -0.035 - Math.cos(an) * (0.34 * ss + 0.012) * fl * wav]);
            }
            if (prev) for (ci = 0; ci < colsN; ci++) mb.quad(prev[ci], prev[ci + 1], row[ci + 1], row[ci], ((ci + ri) & 1) ? OUT : shade(OUT, 0.9));
            prev = row;
          }
          mb.ref = o2;
        })();
      } else {
        mb.ell(0, 0.52, -0.05, 0.315, 0.105, 0.31, 10, 3, shade(OUT, 0.8), 0, 0.02);
        mb.box(0, 0.36, -0.265, 0.50, 0.44, 0.03, OUT);
      }
    }
    else if (of === 4) { // chaleco acolchado: torso con costuras horizontales y cuello alto
      var vk = standing ? 1 : 1.21, vy = standing ? 0 : 0.02;
      mb.ell(0, 0.26 + vy, -0.03, 0.31 * vk, 0.31, 0.32 * vk, 14, 9, OUT, 0, 0.0);
      for (var vq = 0; vq < 4; vq++) mb.ell(0, 0.16 + vq * 0.1 + vy, -0.01, 0.304 * vk, 0.011, 0.31 * vk, 10, 3, shade(OUT, 0.68));
      mb.ell(0, 0.50 + vy, -0.05, 0.27 * vk, 0.075, 0.26 * vk, 10, 3, shade(OUT, 0.82));
      mb.box(0, 0.30 + vy, 0.23 * vk, 0.012, 0.3, 0.012, [0.9, 0.92, 0.95]);
    } else if (of === 5) { // esmoquin: frac oscuro, pechera blanca, solapas y mono
      var tk = standing ? 1 : 1.21, ty = standing ? 0 : 0.02;
      mb.ell(0, 0.27 + ty, -0.035, 0.30 * tk, 0.31, 0.30 * tk, 14, 9, [0.07, 0.08, 0.11], 0, 0.0);
      mb.ell(0, 0.30 + ty, 0.14 * tk, 0.135 * tk, 0.215, 0.165 * tk, 8, 5, [0.98, 0.98, 1.0]);
      for (var tl = -1; tl <= 1; tl += 2) { mb.push().translate(tl * 0.115 * tk, 0.40 + ty, 0.215 * tk).rotZ(tl * 0.38); mb.box(0, 0, 0, 0.03, 0.17, 0.03, [0.03, 0.03, 0.05]); mb.pop(); }
      for (var tb = 0; tb < 3; tb++) mb.ell(0, 0.34 - tb * 0.07 + ty, 0.255 * tk, 0.014, 0.014, 0.012, 5, 3, GOLD, 0.4);
      mb.ell(0, 0.495 + ty, 0.215 * tk, 0.03, 0.03, 0.03, 5, 3, OUT);
      mb.push().translate(-0.065, 0.495 + ty, 0.215 * tk).rotZ(PI / 2); mb.cone(0, 0, 0, 0.065, 0.1, 4, OUT); mb.pop();
      mb.push().translate(0.065, 0.495 + ty, 0.215 * tk).rotZ(-PI / 2); mb.cone(0, 0, 0, 0.065, 0.1, 4, OUT); mb.pop();
      mb.ell(0, 0.50 + ty, -0.05, 0.27 * tk, 0.07, 0.26 * tk, 10, 3, [0.05, 0.06, 0.09]);
    } else if (of === 6) { // alas de angel: dos alas con tres plumas cada una
      var ay = standing ? 0 : 0.07;
      for (var asg = -1; asg <= 1; asg += 2) {
        mb.push().translate(asg * 0.10, 0.40 + ay, -0.31).rotZ(asg * 0.85).rotY(asg * 0.30);
        mb.ell(asg * 0.19, 0.04, 0, 0.27, 0.035, 0.12, 7, 3, [1, 1, 1], 0.25);
        mb.ell(asg * 0.22, -0.045, 0, 0.23, 0.032, 0.105, 7, 3, [0.95, 0.97, 1.0], 0.25);
        mb.ell(asg * 0.24, -0.125, 0, 0.19, 0.03, 0.09, 7, 3, [0.9, 0.94, 1.0], 0.25);
        mb.ell(asg * 0.04, 0.0, 0, 0.07, 0.07, 0.07, 6, 3, [0.96, 0.98, 1.0], 0.2);
        mb.pop();
      }
    } else if (of === 7) { // jetpack: dos depósitos con tapa, boquillas, llamas y correas
      var jy = standing ? 0 : 0.07;
      for (var jx = -1; jx <= 1; jx += 2) {
        mb.cyl(jx * 0.085, 0.34 + jy, -0.31, 0.065, 0.065, 0.36, 8, [0.72, 0.74, 0.8], 0.05);
        mb.cone(jx * 0.085, 0.52 + jy, -0.31, 0.065, 0.1, 8, OUT);
        mb.cyl(jx * 0.085, 0.36 + jy, -0.31, 0.068, 0.068, 0.04, 8, OUT);
        mb.push().translate(jx * 0.085, 0.15 + jy, -0.31).rotX(PI); mb.cone(0, 0, 0, 0.05, 0.16, 7, [1.0, 0.62, 0.12], 0.9); mb.cone(0, 0, 0, 0.03, 0.1, 6, [1.0, 0.95, 0.6], 1); mb.pop();
        mb.cyl(jx * 0.085, 0.17 + jy, -0.31, 0.055, 0.075, 0.05, 8, DARK);
      }
      mb.box(0, 0.40 + jy, -0.265, 0.2, 0.05, 0.04, DARK);
      mb.box(-0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK); mb.box(0.11, 0.40, -0.12, 0.03, 0.03, 0.40, DARK);
    }
    mb.mat = 0;
    mb.pop();
    parts.push({ mesh: PG.smoothMesh(standing ? PG.mergeMeshes([bodyBase, mb.finish()]) : mb.finish(), 0.1), kind: 'body', pivot: [0, 0, 0] });

    // aletas (aletas hacia los lados): geometria relativa a su hombro
    function wing(entry, piv, kind) {
      var m = new PG.MB(); m.rnd = PG.rng(kind === 'flipR' ? 5 : 6);
      var pv2 = standing ? unslide(piv) : piv;
      m.push().translate(-pv2[0], -pv2[1], -pv2[2]);
      if (standing) m.rotX(-TH).translate(0, -YO, ZC).scale(1 / PS, 1 / PS, 1 / PS);
      m.subdiv = !!hi; m.fbx(entry, pal, 0.02);
      m.pop();
      parts.push({ mesh: PG.smoothMesh(m.finish(), 0.1), kind: kind, pivot: pv2.slice() });
    }
    wing(P.parts[1], P.pivR, 'flipR');
    wing(P.parts[2], P.pivL, 'flipL');
    // cola de bufanda / capa
    var pv;
    if ((sc === 1 || sc === 6) && !standing) {
      pv = slideP(0.10, 0.52, -0.16);
      var mt = new PG.MB(); mt.box(0.0, 0.0, -0.36, 0.17, 0.035, 0.72, SCF); mt.box(0.0, 0.0, -0.70, 0.19, 0.04, 0.12, shade(SCF, 0.75));
      parts.push({ mesh: mt.finish(), kind: 'tail', pivot: pv, amp: 1 });
    }
    if (of === 2 && !standing) {
      pv = [0, 0.80, -0.02];
      var mc = new PG.MB(); mc.box(0, 0, -0.46, 0.80, 0.035, 0.92, OUT); mc.box(0, 0, -0.92, 0.82, 0.04, 0.1, shade(OUT, 0.75));
      parts.push({ mesh: mc.finish(), kind: 'tail', pivot: pv, amp: 0.6 });
    }
    var model = { parts: parts, key: key };
    penguinCache[key] = model;
    return model;
  }
  PG.penguinHi = false; // la partida lo activa segun la calidad grafica
  PG.penguinModel = function (cfg) { return buildPenguin(cfg, false, PG.penguinHi); };
  PG.penguinModelLo = function (cfg) { return buildPenguin(cfg, false, false); }; // v4.6: version de menos poligonos para rivales lejanos y para el reflejo
  // el mismo pinguino, de pie (espectadores): cuerpo + aletas animables alrededor de los hombros
  // el modelo de pie queda inclinado hacia atras (pose de deslizamiento = 78 grados, no 90): se endereza al dibujarlo
  PG.STAND_TILT = Math.PI / 2 - PG.FBX.pen.theta;
  PG.spectatorModel = function (cfg) { return buildPenguin(cfg, true); };
  PG.menuModel = function (cfg) { return buildPenguin(cfg, true, true); }; // pingüino de pie en Personalizar / Mi progreso: alta resolucion
  // version barata (lejos): mismos colores y accesorios principales con primitivas
  var liteCache = {};
  PG.spectatorLite = function (cfg) {
    cfg = PG.fixCfg(cfg);
    var key = [cfg.body, cfg.belly, cfg.feet, cfg.hat, cfg.hatCol, cfg.scarf, cfg.scarfCol].join('.');
    if (liteCache[key]) return liteCache[key];
    var BODY = hex(PG.PAL.body[cfg.body]), BELLY = hex(PG.PAL.belly[cfg.belly]), FEET = hex(PG.PAL.feet[cfg.feet]), HAT = hex(PG.PAL.accent[cfg.hatCol]), SCF = hex(PG.PAL.accent[cfg.scarfCol]);
    var m = new PG.MB(); m.rnd = PG.rng(9);
    m.ell(0, 0.46, 0, 0.36, 0.46, 0.30, 6, 4, BODY, 0, 0.05);
    m.ell(0, 0.42, 0.14, 0.27, 0.36, 0.2, 6, 3, BELLY);
    m.ell(0, 0.86, 0.02, 0.2, 0.2, 0.2, 6, 3, BODY);
    m.cone(0, 0.8, 0.2, 0.06, 0.16, 4, FEET);
    m.box(-0.12, 0.03, 0.1, 0.14, 0.06, 0.26, FEET); m.box(0.12, 0.03, 0.1, 0.14, 0.06, 0.26, FEET);
    if (cfg.scarf) m.cyl(0, 0.62, 0, 0.25, 0.24, 0.1, 7, SCF);
    if (cfg.hat) m.ell(0, 1.04, 0, 0.21, 0.15, 0.21, 6, 3, HAT);
    m.box(-0.38, 0.45, 0, 0.07, 0.34, 0.16, BODY); m.box(0.38, 0.45, 0, 0.07, 0.34, 0.16, BODY);
    var mesh = m.finish(); liteCache[key] = mesh; return mesh;
  };

  /* ---------- modelos varios ---------- */
  PG.Models = {};
  PG.buildModels = function (theme) {
    var M = PG.Models = {}, t = theme || PG.THEMES.day, mb;
    var snow = t.snow, rock = t.rock, ice = t.ice, shd = shade;

    // v4.6: roca angulosa (poliedro irregular con facetas planas, no una esfera suave): vertices desplazados al azar, base plana y cada faceta con su tono
    function boulder(m, cx, cy, cz, rx, ry, rz, nseg, nring, col, rough, rot, tone) {
      var o = m.ref, pts = [], i, j, ph, th, f, row, ycut = cy - ry * 0.62;
      m.ref = [cx, cy, cz];
      for (i = 0; i <= nring; i++) {
        ph = Math.PI * i / nring; row = [];
        for (j = 0; j <= nseg; j++) {
          var jj = j % nseg; th = 2 * Math.PI * jj / nseg + rot; f = 1 + (m.rnd() - 0.5) * rough * (i === 0 || i === nring ? 0.4 : 1);
          if (j === nseg) { row.push(row[0]); continue; }
          row.push([cx + Math.cos(th) * Math.sin(ph) * rx * f, Math.max(ycut, cy + Math.cos(ph) * ry * (0.92 + 0.16 * f)), cz + Math.sin(th) * Math.sin(ph) * rz * f]);
        }
        pts.push(row);
      }
      for (i = 0; i < nring; i++) for (j = 0; j < nseg; j++) {
        var c1 = shd(col, (tone || 1) * (0.80 + 0.36 * m.rnd())), c2 = shd(col, (tone || 1) * (0.80 + 0.36 * m.rnd()));
        m.tri(pts[i][j], pts[i + 1][j], pts[i + 1][j + 1], c1, 0);
        m.tri(pts[i][j], pts[i + 1][j + 1], pts[i][j + 1], c2, 0);
      }
      m.ref = o;
    }
    function rockMesh(seed) {
      var m = new PG.MB(); m.rnd = PG.rng(seed);
      m.tint = PG.tints.rock(1.4); m.mat = 8; // v4.5: roca con estratos, grietas, liquen y nieve; v4.6: facetas angulosas
      boulder(m, 0, 0.78, 0, 1.95, 1.3, 1.75, 9, 5, rock, 0.46, m.rnd() * 6, 0.95);
      boulder(m, -1.35, 0.4, 0.95, 0.95, 0.7, 0.85, 7, 4, rock, 0.5, m.rnd() * 6, 0.85);
      boulder(m, 1.3, 0.38, -0.95, 0.85, 0.62, 0.78, 7, 4, rock, 0.5, m.rnd() * 6, 1.0);
      boulder(m, 0.55, 0.22, 1.5, 0.55, 0.38, 0.5, 6, 3, rock, 0.5, m.rnd() * 6, 0.8);
      boulder(m, 0.25, 1.62, 0.05, 1.25, 0.42, 1.1, 8, 3, snow, 0.28, m.rnd() * 6, 1.0);
      return m.finish();
    }
    M.rock = [rockMesh(3), rockMesh(9), rockMesh(21)];
    // obstaculo de hielo: racimo de cristales azules inclinados sobre una base de nieve (no es una caja)
    mb = new PG.MB(); mb.rnd = PG.rng(57);
    mb.ell(0, 0.28, 0, 1.75, 0.55, 1.75, 8, 3, snow, 0, 0.05);
    var CR = [[0, 0, 0, 0.62, 3.9, 0, 0], [0.95, 0, 0.3, 0.46, 2.7, 0.0, -0.42], [-0.9, 0, 0.35, 0.5, 3.0, 0.0, 0.4], [0.2, 0, -0.95, 0.44, 2.5, -0.38, 0.0], [-0.1, 0, 0.98, 0.4, 2.1, 0.4, 0.05], [0.7, 0, -0.65, 0.3, 1.5, -0.3, -0.3]];
    for (var ci = 0; ci < CR.length; ci++) {
      var c = CR[ci], col = ci % 2 ? [0.30, 0.66, 0.98] : [0.42, 0.78, 1.0];
      mb.push().translate(c[0], 0.35, c[2]).rotX(c[5]).rotZ(c[6]);
      mb.tint = PG.tints.crystal(0.35, 4.0); mb.mat = 9; // v4.5: mismo tratamiento que el hielo de la pista (facetas, nucleo, destello)
      mb.cyl(0, 0, 0, c[3], c[3] * 0.9, c[4] * 0.62, 6, col, 0.2);
      mb.cone(0, c[4] * 0.62, 0, c[3] * 0.9, c[4] * 0.38, 6, [0.78, 0.94, 1.0], 0.3);
      mb.tint = null; mb.mat = 0;
      mb.pop();
    }
    M.ice = mb.finish();
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.80, 0.95, 7, 5, snow, 0, 0.03);
    mb.ell(0, 1.75, 0, 0.70, 0.62, 0.70, 7, 5, snow, 0, 0.03);
    mb.ell(0, 2.55, 0, 0.50, 0.46, 0.50, 7, 5, snow, 0, 0.03);
    mb.push().translate(0, 2.55, 0.45).rotX(PI / 2); mb.cone(0, 0, 0, 0.09, 0.5, 5, [1, 0.5, 0.1]); mb.pop();
    mb.cyl(0, 2.15, 0, 0.55, 0.55, 0.18, 8, [0.85, 0.15, 0.2]);
    mb.cyl(0, 2.92, 0, 0.48, 0.48, 0.06, 8, [0.1, 0.1, 0.12]); mb.cyl(0, 2.95, 0, 0.30, 0.30, 0.42, 8, [0.1, 0.1, 0.12]);
    mb.ell(-0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.17, 2.62, 0.42, 0.06, 0.06, 0.04, 4, 3, [0.05, 0.05, 0.05]);
    M.snowman = PG.smoothMesh(mb.finish(), 0.3);
    mb = new PG.MB();
    mb.ell(0, 0.65, 0, 0.95, 0.7, 1.7, 8, 5, [0.50, 0.46, 0.46], 0, 0.1);
    mb.ell(0, 0.95, 1.5, 0.55, 0.50, 0.55, 7, 5, [0.55, 0.50, 0.50]);
    mb.ell(0, 0.85, 1.95, 0.22, 0.18, 0.2, 5, 3, [0.1, 0.1, 0.1]);
    mb.ell(-0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]); mb.ell(0.22, 1.15, 1.8, 0.07, 0.07, 0.05, 4, 3, [0.05, 0.05, 0.05]);
    mb.ell(-1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]); mb.ell(1.0, 0.3, 0.5, 0.45, 0.07, 0.25, 5, 3, [0.45, 0.4, 0.4]);
    mb.ell(0, 0.45, -1.8, 0.45, 0.08, 0.3, 5, 3, [0.45, 0.4, 0.4]);
    M.seal = PG.smoothMesh(mb.finish(), 0.3);
    mb = new PG.MB(); mb.rnd = PG.rng(5);
    mb.ell(0, 0, 0, 1.9, 1.9, 1.9, 8, 6, [0.95, 0.97, 1.0], 0, 0.12);
    mb.ell(0.6, 0.9, 0.5, 0.7, 0.6, 0.7, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    mb.ell(-0.8, -0.5, 1.0, 0.6, 0.5, 0.6, 5, 3, [0.62, 0.66, 0.74], 0, 0.1);
    M.ball = PG.smoothMesh(mb.finish(), 0.3);
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.7, 0.7, 0.7, 7, 5, [1, 1, 1], 0.15, 0.06); M.snowball = PG.smoothMesh(mb.finish(), 0.3);
    // v3.1: bloque de hielo rehecho: losa hexagonal con nieve, cristal central alto y racimo de cristales inclinados con nucleo brillante
    mb = new PG.MB(); mb.rnd = PG.rng(17);
    mb.cyl(0, 0, 0, 1.55, 1.35, 0.22, 8, [0.80, 0.93, 1.0], 0.15);
    mb.cyl(0, 0.22, 0, 1.30, 1.05, 0.16, 8, [0.62, 0.84, 0.98], 0.3);
    mb.ell(0, 0.30, 0, 1.25, 0.28, 1.25, 8, 3, [1, 1, 1], 0.12, 0.06);
    mb.crystal(0, 0.25, 0, 0.78, 2.9, [0.40, 0.78, 1.0], 0.6, 6);
    mb.crystal(0, 0.55, 0, 0.38, 1.7, [0.85, 0.97, 1.0], 0.95, 6);
    var tilt = [[0.85, 0.5, 0.55, 1.3], [-0.8, 0.4, -0.5, 1.0], [0.2, -0.85, 0.5, 1.15], [-0.4, 0.85, -0.45, 0.95], [0.9, -0.5, 0.4, 0.8], [-0.95, -0.2, -0.6, 0.85]];
    for (var ti = 0; ti < tilt.length; ti++) {
      var tt = tilt[ti], ang = Math.atan2(tt[1], tt[0]), rr0 = Math.sqrt(tt[0] * tt[0] + tt[1] * tt[1]) * 0.9;
      mb.push().translate(Math.cos(ang) * rr0, 0.2, Math.sin(ang) * rr0).rotY(-ang).rotZ(0.38 + 0.1 * (ti % 3));
      mb.crystal(0, 0, 0, 0.34 + 0.05 * (ti % 2), 1.35 * tt[3], ti % 2 ? [0.5, 0.82, 1.0] : [0.72, 0.92, 1.0], 0.55, 5); mb.pop();
    }
    for (var si = 0; si < 5; si++) { var sa = si * 1.26 + 0.4; mb.ell(Math.cos(sa) * 1.15, 0.32, Math.sin(sa) * 1.15, 0.28, 0.13, 0.28, 5, 3, [1, 1, 1], 0.1, 0.1); }
    M.trap = mb.finish();
    // ---- esferas luminosas con iconos (objetos y habilidades) ----
    function iconSnow(m, z, col) {
      for (var a = 0; a < 3; a++) {
        m.push().translate(0, 0, z).rotZ(a * PI / 3);
        m.box(0, 0, 0, 0.14, 1.12, 0.2, col, 1);
        for (var sg = -1; sg <= 1; sg += 2) for (var sd = -1; sd <= 1; sd += 2) {
          m.push().translate(0, sg * 0.34, 0).rotZ(sd * 0.85); m.box(0, sd * 0.0 + 0.0, 0, 0.1, 0.34, 0.2, col, 1); m.pop();
        }
        m.pop();
      }
    }
    function iconBolt(m, z, col) {
      m.push().translate(0, 0, z);
      m.push().translate(0.13, 0.40, 0).rotZ(-0.42); m.box(0, 0, 0, 0.27, 0.66, 0.2, col, 1); m.pop();
      m.push().translate(-0.13, -0.40, 0).rotZ(-0.42); m.box(0, 0, 0, 0.27, 0.66, 0.2, col, 1); m.pop();
      m.box(0, 0, 0, 0.66, 0.2, 0.2, col, 1);
      m.pop();
    }
    function beads(m, n, rad, size, col, tilt) {
      m.push().rotZ(tilt);
      for (var i = 0; i < n; i++) { var a = 2 * PI * i / n; m.ell(Math.cos(a) * rad, 0, Math.sin(a) * rad, size, size, size, 5, 3, col, 1); }
      m.pop();
    }
    // objeto: esfera azul con copo de nieve
    mb = new PG.MB();
    mb.ell(0, 0, 0, 0.95, 0.95, 0.95, 12, 8, [0.16, 0.56, 1.0], 0.9);
    mb.ell(-0.3, 0.38, 0.38, 0.26, 0.2, 0.2, 5, 3, [0.7, 0.92, 1.0], 1);
    iconSnow(mb, 0.93, [1, 1, 1]); iconSnow(mb, -0.93, [1, 1, 1]);
    M.orbItem = mb.finish();
    mb = new PG.MB(); beads(mb, 10, 1.45, 0.1, [0.75, 1.0, 1.0], 0.45); M.orbRingI = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.3, 1.3, 1.3, 12, 8, [0.45, 0.85, 1.0], 1); M.orbShellI = mb.finish();
    mb = new PG.MB();
    mb.cyl(0, 0.03, 0, 1.6, 1.6, 0.04, 14, [0.4, 0.85, 1.0], 1);
    mb.cyl(0, 0.05, 0, 0.95, 0.5, 5.5, 10, [0.55, 0.92, 1.0], 1);
    M.glowI = mb.finish();
    // habilidad: esfera violeta con rayo dorado y anillo orbital
    mb = new PG.MB();
    mb.ell(0, 0, 0, 1.15, 1.15, 1.15, 12, 8, [0.62, 0.22, 0.98], 0.9);
    mb.ell(-0.36, 0.46, 0.46, 0.3, 0.22, 0.22, 5, 3, [0.9, 0.7, 1.0], 1);
    iconBolt(mb, 1.12, [1.0, 0.9, 0.25]); iconBolt(mb, -1.12, [1.0, 0.9, 0.25]);
    M.orbAbil = mb.finish();
    mb = new PG.MB(); beads(mb, 12, 1.85, 0.13, [1.0, 0.85, 0.3], 0.5); beads(mb, 12, 1.85, 0.13, [1.0, 0.6, 0.9], -0.5); M.orbRingA = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.55, 1.55, 1.55, 12, 8, [0.85, 0.55, 1.0], 1); M.orbShellA = mb.finish();
    mb = new PG.MB();
    mb.cyl(0, 0.03, 0, 2.0, 2.0, 0.04, 14, [0.8, 0.5, 1.0], 1);
    mb.cyl(0, 0.05, 0, 1.15, 0.6, 7.0, 10, [0.85, 0.6, 1.0], 1);
    M.glowA = mb.finish();
    // arma de nieve (modelo del usuario), montada sobre la espalda del pinguino apuntando al frente
    mb = new PG.MB(); mb.rnd = PG.rng(77);
    mb.push().translate(0, 0.74, 0.08).scale(0.92, 0.92, 0.92);
    mb.fbx(PG.FBX.gun, [[0.66, 0.70, 0.78], [0.17, 0.19, 0.24], [1.0, 0.55, 0.15]], 0.05, [0, 0, 0.6]);
    mb.pop();
    M.cannon = mb.finish();
    // canon de granadas (mismo modelo, otra paleta y algo mayor)
    mb = new PG.MB(); mb.rnd = PG.rng(78);
    mb.push().translate(0, 0.78, 0.08).scale(1.08, 1.08, 1.08);
    mb.fbx(PG.FBX.gun, [[0.38, 0.52, 0.30], [0.14, 0.2, 0.12], [1.0, 0.25, 0.1]], 0.05, [0, 0, 0.6]);
    mb.pop();
    M.cannon2 = mb.finish();
    // granada (v4.2): cuerpo oliva con rejilla de surcos, tapa, palanca, anilla del seguro, banda amarilla de aviso y mecha encendida
    mb = new PG.MB(); mb.rnd = PG.rng(5);
    mb.ell(0, 0, 0, 0.55, 0.62, 0.55, 12, 9, [0.30, 0.45, 0.22], 0.0, 0.05);
    for (var gi = 0; gi < 4; gi++) { var gy0 = -0.36 + gi * 0.24, gr = 0.56 * Math.sqrt(Math.max(0.1, 1 - Math.pow(gy0 / 0.64, 2))); mb.cyl(0, gy0, 0, gr + 0.012, gr + 0.012, 0.035, 12, [0.13, 0.2, 0.1]); }
    for (var gj = 0; gj < 10; gj++) { var ga = gj / 10 * 2 * PI; mb.push().translate(Math.cos(ga) * 0.5, 0, Math.sin(ga) * 0.5).rotY(-ga); mb.box(0.045, 0, 0, 0.03, 0.96, 0.03, [0.13, 0.2, 0.1]); mb.pop(); }
    mb.cyl(0, 0.54, 0, 0.19, 0.2, 0.2, 8, [0.72, 0.74, 0.8], 0.04);
    mb.cyl(0, 0.66, 0, 0.23, 0.23, 0.06, 8, [0.55, 0.57, 0.64]);
    mb.cyl(0, 0.0, 0, 0.585, 0.585, 0.1, 12, [0.98, 0.78, 0.1], 0.25);
    mb.cyl(0, -0.2, 0, 0.55, 0.55, 0.04, 12, [0.1, 0.1, 0.12]);
    mb.push().translate(0.22, 0.5, 0).rotZ(-0.35); mb.box(0.06, 0, 0, 0.1, 0.62, 0.15, [0.8, 0.82, 0.88], 0.05); mb.pop();
    for (var gk = 0; gk < 10; gk++) { var gb = gk / 10 * 2 * PI; mb.push().translate(-0.22 + Math.cos(gb) * 0.15, 0.7 + Math.sin(gb) * 0.15, 0).rotZ(gb); mb.box(0, 0, 0, 0.1, 0.04, 0.05, [0.95, 0.82, 0.25], 0.35); mb.pop(); }
    mb.ell(0.01, 0.82, 0, 0.1, 0.1, 0.1, 6, 4, [1, 0.55, 0.12], 1);
    mb.ell(0.01, 0.84, 0, 0.055, 0.055, 0.055, 5, 3, [1, 0.95, 0.6], 1);
    M.grenade = mb.finish();
    // mega bola de nieve
    mb = new PG.MB(); mb.rnd = PG.rng(31);
    mb.ell(0, 0, 0, 2.2, 2.2, 2.2, 9, 7, [0.93, 0.98, 1.0], 0.22, 0.14);
    for (var si = 0; si < 9; si++) { var sa = si * 2.399, sy = (si / 8) * 2 - 1, sr = Math.sqrt(1 - sy * sy); mb.ell(Math.cos(sa) * sr * 2.0, sy * 2.0, Math.sin(sa) * sr * 2.0, 0.65, 0.6, 0.65, 5, 3, [0.7, 0.88, 1.0], 0.3, 0.1); }
    mb.ell(-0.8, 0.5, 1.9, 0.38, 0.38, 0.2, 5, 3, [0.1, 0.12, 0.2]); mb.ell(0.8, 0.5, 1.9, 0.38, 0.38, 0.2, 5, 3, [0.1, 0.12, 0.2]);
    mb.box(0, -0.6, 2.0, 1.3, 0.22, 0.3, [0.85, 0.15, 0.2], 0.2);
    M.megaball = PG.smoothMesh(mb.finish(), 0.3);
    // arbol (obstaculo): pino nevado
    mb = new PG.MB(); mb.rnd = PG.rng(12);
    var leaf = t.tree || [0.14, 0.42, 0.26];
    mb.cyl(0, 0, 0, 0.55, 0.7, 3.0, 6, [0.38, 0.25, 0.16]);
    mb.tint = PG.tints.tree(0, 10.5); mb.mat = 10;
    for (var ti = 0; ti < 4; ti++) {
      var ty = 2.0 + ti * 2.2, tr = 3.0 - ti * 0.62;
      mb.cone(0, ty, 0, tr, 3.4, 9, shd(leaf, 0.9 - ti * 0.04), 0, 0.12);
      mb.cone(0, ty + 1.2, 0, tr * 0.72, 2.4, 9, snow, 0, 0.05);
    }
    mb.tint = null; mb.mat = 0;
    M.tree = mb.finish();
    // carambano de la cueva (punta hacia abajo, origen en la base pegada al techo)
    mb = new PG.MB(); mb.rnd = PG.rng(44);
    mb.push().rotX(PI); mb.cone(0, 0, 0, 1.4, 5.4, 6, [0.80, 0.97, 1.0], 0.85, 0.1); mb.pop();
    mb.push().translate(0.55, 0, 0.3).rotX(PI); mb.cone(0, 0, 0, 0.7, 2.8, 5, [0.92, 1.0, 1.0], 0.9, 0.05); mb.pop();
    mb.ell(0, 0.1, 0, 1.4, 0.45, 1.4, 6, 3, [0.55, 0.62, 0.72], 0, 0.1);
    M.icicle = mb.finish();
    // ---- v4.3: obstaculos del barco y el castillo ----
    var WOOD = [0.50, 0.32, 0.17], WOODD = [0.30, 0.19, 0.10], SNW = [0.96, 0.98, 1.0];
    mb = new PG.MB(); mb.rnd = PG.rng(81); // caja de madera con tiras de metal y nieve encima
    mb.mat = 11; mb.box(0, 1.15, 0, 2.3, 2.3, 2.3, WOOD, 0);
    for (var cp = -1; cp <= 1; cp += 2) { mb.box(0, 1.15, cp * 1.17, 2.4, 0.22, 0.12, WOODD, 0); mb.box(cp * 1.17, 1.15, 0, 0.12, 0.22, 2.4, WOODD, 0); mb.box(cp * 1.0, 1.15, 0, 0.2, 2.4, 2.4, WOODD, 0); mb.box(0, 1.15, cp * 1.0, 2.4, 2.4, 0.2, WOODD, 0); }
    mb.mat = 5; for (cp = -1; cp <= 1; cp += 2) { mb.box(cp * 1.16, 1.15, 1.16, 0.14, 2.4, 0.14, [0.62, 0.66, 0.74], 0); mb.box(cp * 1.16, 1.15, -1.16, 0.14, 2.4, 0.14, [0.62, 0.66, 0.74], 0); } mb.mat = 0;
    mb.ell(0, 2.35, 0, 1.25, 0.34, 1.25, 7, 3, SNW, 0.04, 0.06);
    M.crate = mb.finish();
    // v4.4: regalo (5 colores) que cargan los pingüinos de la ciudad navideña
    M.gift = [[0.88, 0.14, 0.18], [0.2, 0.5, 0.95], [0.2, 0.7, 0.35], [0.7, 0.35, 0.9], [1.0, 0.55, 0.15]].map(function (gc, gi) {
      var g = new PG.MB(); g.rnd = PG.rng(300 + gi);
      g.box(0, 0.5, 0, 1.0, 1.0, 1.0, gc, 0.1); g.box(0, 1.03, 0, 1.08, 0.12, 1.08, shade(gc, 1.12), 0.1);
      g.box(0, 0.5, 0, 1.04, 1.04, 0.2, [1.0, 0.88, 0.4], 0.5); g.box(0, 0.5, 0, 0.2, 1.04, 1.04, [1.0, 0.88, 0.4], 0.5);
      g.ell(-0.2, 1.22, 0, 0.26, 0.2, 0.2, 6, 3, [1.0, 0.88, 0.4], 0.5, 0.05); g.ell(0.2, 1.22, 0, 0.26, 0.2, 0.2, 6, 3, [1.0, 0.88, 0.4], 0.5, 0.05); g.box(0, 1.17, 0, 0.16, 0.16, 0.16, [1.0, 0.78, 0.25], 0.5);
      return g.finish();
    });
    mb = new PG.MB(); mb.rnd = PG.rng(82); // barril
    mb.mat = 11; mb.cyl(0, 0, 0, 0.85, 1.05, 1.0, 10, WOOD, 0); mb.cyl(0, 1.0, 0, 1.05, 0.85, 1.0, 10, WOOD, 0);
    mb.mat = 5; mb.cyl(0, 0.1, 0, 0.95, 0.96, 0.14, 10, [0.30, 0.33, 0.40], 0); mb.cyl(0, 1.0, 0, 1.07, 1.07, 0.16, 10, [0.30, 0.33, 0.40], 0); mb.cyl(0, 1.8, 0, 0.88, 0.88, 0.14, 10, [0.30, 0.33, 0.40], 0); mb.mat = 0;
    mb.ell(0, 2.02, 0, 0.9, 0.22, 0.9, 7, 3, SNW, 0.04, 0.05);
    M.barrel = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(83); // bloque de piedra del castillo (con escarcha)
    var STN = [0.50, 0.55, 0.72];
    mb.box(0, 1.1, 0, 2.5, 2.2, 2.5, STN, 0); mb.box(0, 0.55, 0, 2.7, 0.2, 2.7, [0.38, 0.42, 0.58], 0); mb.box(0, 1.65, 0, 2.7, 0.2, 2.7, [0.38, 0.42, 0.58], 0);
    mb.box(0, 1.1, 1.26, 2.3, 0.1, 0.1, [0.32, 0.36, 0.5], 0); mb.box(1.26, 1.1, 0, 0.1, 0.1, 2.3, [0.32, 0.36, 0.5], 0);
    mb.cone(-0.8, 2.2, 0.3, 0.3, 0.9, 5, [0.75, 0.93, 1.0], 0.5, true); mb.cone(0.7, 2.2, -0.5, 0.25, 0.7, 5, [0.75, 0.93, 1.0], 0.5, true);
    mb.ell(0, 2.3, 0, 1.2, 0.3, 1.2, 7, 3, SNW, 0.04, 0.06);
    M.stone = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(84); // bola con pinchos de un pendulo
    mb.mat = 5; mb.ell(0, 0, 0, 1.45, 1.45, 1.45, 10, 7, [0.46, 0.50, 0.60], 0.02, 0.04);
    var SPD = [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0.7, 0.7, 0], [-0.7, 0.7, 0], [0.7, -0.7, 0], [-0.7, -0.7, 0], [0, 0.7, 0.7], [0, 0.7, -0.7], [0, -0.7, 0.7], [0, -0.7, -0.7], [0.7, 0, 0.7], [-0.7, 0, 0.7], [0.7, 0, -0.7], [-0.7, 0, -0.7]];
    for (var sp = 0; sp < SPD.length; sp++) {
      var sv = SPD[sp], sl = Math.hypot(sv[0], sv[1], sv[2]), ax = sv[0] / sl, ay = sv[1] / sl, az = sv[2] / sl;
      mb.push().translate(ax * 1.2, ay * 1.2, az * 1.2);
      var yaw = Math.atan2(ax, az), pit = Math.acos(Math.max(-1, Math.min(1, ay)));
      mb.rotY(yaw).rotX(pit); mb.cone(0, 0, 0, 0.34, 0.95, 5, [0.78, 0.82, 0.9], 0.04, true); mb.pop();
    }
    mb.mat = 0; mb.box(0, 1.6, 0, 0.5, 0.3, 0.5, [0.3, 0.32, 0.4], 0);
    M.pendBall = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(85); // cadena de longitud 1 (se escala en Y); cuelga hacia -Y desde el origen
    mb.mat = 5; for (var cl = 0; cl < 10; cl++) { mb.box(0, -0.05 - cl * 0.1, 0, cl & 1 ? 0.14 : 0.04, 0.12, cl & 1 ? 0.04 : 0.14, [0.46, 0.5, 0.6], 0); } mb.mat = 0;
    M.pendChain = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(86); // placa de pinchos de suelo (la altura de los pinchos se escala en Y)
    mb.mat = 5; mb.cyl(0, 0, 0, 1.55, 1.6, 0.18, 10, [0.30, 0.34, 0.44], 0);
    var SPK = [[0, 0], [0.8, 0], [-0.8, 0], [0.4, 0.7], [-0.4, 0.7], [0.4, -0.7], [-0.4, -0.7]];
    for (var sk = 0; sk < SPK.length; sk++) mb.cone(SPK[sk][0], 0.1, SPK[sk][1], 0.26, 1.7, 5, [0.82, 0.86, 0.94], 0.05, true);
    mb.mat = 0;
    M.spikes = mb.finish();
    mb = new PG.MB(); mb.rnd = PG.rng(87); // bloque que cae del techo (con cadena corta rota)
    mb.box(0, 1.6, 0, 3.8, 3.2, 3.8, [0.46, 0.50, 0.68], 0); mb.box(0, 0.25, 0, 4.1, 0.5, 4.1, [0.34, 0.38, 0.54], 0); mb.box(0, 3.0, 0, 4.1, 0.4, 4.1, [0.34, 0.38, 0.54], 0);
    mb.mat = 5; mb.cone(0, 0.02, 0, 0.28, 0.5, 5, [0.8, 0.84, 0.92], 0.05, true); mb.mat = 0;
    for (var bq = -1; bq <= 1; bq += 2) mb.cone(bq * 1.3, 0.0, 1.0, 0.3, 0.9, 5, [0.78, 0.94, 1.0], 0.55, true);
    mb.cone(0, 0.0, -1.1, 0.34, 1.0, 5, [0.78, 0.94, 1.0], 0.55, true);
    M.blk = mb.finish();
    // bola de nieve de la avalancha (varias forman el muro)
    mb = new PG.MB(); mb.rnd = PG.rng(77);
    mb.ell(0, 0, 0, 1, 1, 1, 7, 5, [0.97, 0.99, 1.0], 0.62, 0.16);
    mb.ell(0.35, 0.3, 0.1, 0.62, 0.6, 0.62, 6, 4, [0.9, 0.95, 1.0], 0.55, 0.16);
    M.avBall = mb.finish();
    // misil teledirigido (apunta a +Z)
    mb = new PG.MB(); mb.rnd = PG.rng(66);
    mb.push().translate(0, 0, -1.2).rotX(PI / 2);
    mb.cyl(0, 0, 0, 0.46, 0.46, 2.2, 8, [0.86, 0.14, 0.16], 0.1);
    mb.cyl(0, 0.7, 0, 0.48, 0.48, 0.3, 8, [0.96, 0.96, 0.98], 0.15);
    mb.cone(0, 2.2, 0, 0.46, 1.0, 8, [0.96, 0.96, 0.98], 0.15);
    mb.box(0.62, 0.35, 0, 0.8, 0.8, 0.07, [0.2, 0.25, 0.4], 0.05); mb.box(-0.62, 0.35, 0, 0.8, 0.8, 0.07, [0.2, 0.25, 0.4], 0.05);
    mb.box(0, 0.35, 0.62, 0.07, 0.8, 0.8, [0.2, 0.25, 0.4], 0.05); mb.box(0, 0.35, -0.62, 0.07, 0.8, 0.8, [0.2, 0.25, 0.4], 0.05);
    mb.push().rotX(PI); mb.cone(0, 0, 0, 0.36, 1.3, 7, [1, 0.62, 0.12], 0.96); mb.pop();
    mb.pop();
    M.missile = mb.finish();
    // marcador de aviso en el suelo
    mb = new PG.MB(); mb.up = true;
    mb.cyl(0, 0.04, 0, 2.2, 2.2, 0.03, 14, [1.0, 0.25, 0.2], 1);
    mb.cyl(0, 0.06, 0, 1.2, 1.2, 0.03, 14, [1.0, 0.8, 0.2], 1);
    M.warn = mb.finish();
    // ventisca (v4.2): embudo de capas giratorias con brazos en espiral y bloques de nieve que orbitan
    mb = new PG.MB(); mb.rnd = PG.rng(77);
    for (var i = 0; i < 12; i++) {
      var hh = i * 0.85, r0 = 0.7 + i * 0.36 + (i > 8 ? (i - 8) * 0.25 : 0), ox = Math.sin(i * 0.9) * 0.35, oz = Math.cos(i * 0.9) * 0.35;
      mb.push().translate(ox, hh, oz).rotY(i * 0.55); mb.cyl(0, 0, 0, r0, r0 + 0.36, 0.95, 10, i % 2 ? [0.86, 0.94, 1.0] : [0.96, 0.99, 1.0], 0.34, 0.06); mb.pop();
      if (i % 2 === 0) for (var ar = 0; ar < 3; ar++) { var aa = ar / 3 * 2 * PI + i * 0.7; mb.push().translate(ox + Math.cos(aa) * r0 * 1.02, hh + 0.25, oz + Math.sin(aa) * r0 * 1.02).rotY(-aa); mb.box(0, 0, 0, 0.12, 0.5, r0 * 0.7, [1, 1, 1], 0.5); mb.pop(); }
    }
    for (var ch = 0; ch < 9; ch++) { var ca = ch / 9 * 2 * PI * 1.7, cy = 1 + ch * 0.95, cr = 1.3 + ch * 0.42; mb.ell(Math.cos(ca) * cr, cy, Math.sin(ca) * cr, 0.38, 0.28, 0.38, 5, 4, [0.92, 0.97, 1.0], 0.2, 0.15); }
    M.tornado = mb.finish();
    mb = new PG.MB(); mb.ell(0, 0, 0, 1.25, 1.05, 1.5, 28, 18, [0.6, 0.85, 1.0], 0.5); M.shield = PG.smoothMesh(mb.finish(), 0.2);
    // v3.2: escudos con "textura": paneles hexagonales alternados, anillos y rayos
    (function () {
      var RX = 1.27, RY = 1.07, RZ = 1.52;
      function panels(seg, rings, cA, cB, eA, eB) { // esfera de paneles (checker) con cada panel algo hundido: parece facetas de cristal
        var m = new PG.MB(); m.ref = [0, 0, 0];
        var pts = [], i, j;
        for (i = 0; i <= rings; i++) { var phi = Math.PI * i / rings, y = Math.cos(phi) * RY, rr = Math.sin(phi), row = []; for (j = 0; j <= seg; j++) { var th = 2 * Math.PI * (j % seg) / seg; row.push([Math.cos(th) * rr * RX, y, Math.sin(th) * rr * RZ]); } pts.push(row); }
        for (i = 0; i < rings; i++) for (j = 0; j < seg; j++) {
          var odd = ((i + j) & 1) === 1, c = odd ? cA : cB, e = odd ? eA : eB, k = odd ? 1.0 : 0.965;
          function sh(p) { return [p[0] * k, p[1] * k, p[2] * k]; }
          m.tri(sh(pts[i][j]), sh(pts[i + 1][j]), sh(pts[i + 1][j + 1]), c, e); m.tri(sh(pts[i][j]), sh(pts[i + 1][j + 1]), sh(pts[i][j + 1]), c, e);
        }
        return m.finish();
      }
      function ring(rot, col, w) { // aro delgado alrededor de la esfera
        var m = new PG.MB(); m.ref = null; m.up = false; var n = 28, i;
        for (i = 0; i < n; i++) { var a0 = 2 * Math.PI * i / n, a1 = 2 * Math.PI * (i + 1) / n, mx = Math.cos((a0 + a1) / 2) * RX * 1.02, mz = Math.sin((a0 + a1) / 2) * RZ * 1.02, L = Math.hypot((Math.cos(a1) - Math.cos(a0)) * RX, (Math.sin(a1) - Math.sin(a0)) * RZ);
          m.push().rotY(0).translate(mx, 0, mz).rotY(-(a0 + a1) / 2 - Math.PI / 2); m.box(0, 0, 0, w, w, L * 1.02, col, 1); m.pop(); }
        return m.finish();
      }
      M.shieldRing = ring(0, [0.9, 1.0, 1.0], 0.07);
      // anillo ecuatorial (franja que sube y baja en el escudo normal)
      
      // rayos (4 variantes): zigzag desde el polo hasta el ecuador, cada uno distinto
      M.bolts = [];
      for (var bi = 0; bi < 5; bi++) {
        var bm = new PG.MB(), rr2 = PG.rng(900 + bi * 37); bm.ref = null; bm.up = false;
        var az = rr2() * 6.28, steps = 9, prev = [0, 1.0, 0], k;
        for (k = 1; k <= steps; k++) {
          var tt = k / steps, ph = tt * Math.PI * 0.5 + (rr2() - 0.5) * 0.18, th = az + (rr2() - 0.5) * 0.55 * (k > 1 ? 1 : 0);
          var q = [Math.cos(th) * Math.sin(ph) * RX * 1.04, Math.cos(ph) * RY * 1.04, Math.sin(th) * Math.sin(ph) * RZ * 1.04];
          var dx = q[0] - prev[0], dy = q[1] - prev[1], dz = q[2] - prev[2], L = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
          bm.push().translate((q[0] + prev[0]) / 2, (q[1] + prev[1]) / 2, (q[2] + prev[2]) / 2).rotY(Math.atan2(dx, dz)).rotX(-Math.asin(dy / L));
          bm.box(0, 0, 0, 0.045, 0.045, L * 1.05, [1, 1, 0.8], 1); bm.pop();
          if (rr2() < 0.45) { // ramita
            var ex = q[0] + (rr2() - 0.5) * 0.7, ey = q[1] + (rr2() - 0.5) * 0.5, ez = q[2] + (rr2() - 0.5) * 0.7, bdx = ex - q[0], bdy = ey - q[1], bdz = ez - q[2], bl = Math.sqrt(bdx * bdx + bdy * bdy + bdz * bdz) || 1;
            bm.push().translate((q[0] + ex) / 2, (q[1] + ey) / 2, (q[2] + ez) / 2).rotY(Math.atan2(bdx, bdz)).rotX(-Math.asin(bdy / bl)); bm.box(0, 0, 0, 0.026, 0.026, bl, [1, 0.95, 0.55], 1); bm.pop();
          }
          prev = q;
        }
        M.bolts.push(bm.finish());
      }
    })();
    mb = new PG.MB(); mb.up = true;
    mb.cyl(0, 0, 0, 0.62, 0.62, 0.02, 10, [0.05, 0.08, 0.15]); M.shadow = mb.finish();
    // v3.7: surco que dejan los pinguinos al deslizar (dos lineas finas; se dibuja por segmentos con transparencia)
    mb = new PG.MB(); mb.up = true;
    [-0.33, 0.33].forEach(function (ox) { mb.quad([ox - 0.045, 0, -0.5], [ox + 0.045, 0, -0.5], [ox + 0.03, 0, 0.5], [ox - 0.03, 0, 0.5], [0.86, 0.95, 1.0]); });
    M.streak = mb.finish();
    // anillo de brillo para pads etc.
    mb = new PG.MB(); mb.ell(0, 0, 0, 0.12, 0.12, 0.12, 4, 3, [1, 1, 1], 1); M.spark = mb.finish();
  };
})();
