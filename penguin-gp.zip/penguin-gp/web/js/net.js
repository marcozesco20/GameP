/* Red local: en la app Android usa NativeNet (TCP + descubrimiento UDP);
   en el navegador usa WebSocket contra server/server.js (para pruebas desde un PC). */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};

  var Net = PG.Net = {
    PORT: 47777,
    native: (typeof window.NativeNet !== 'undefined'),
    connected: false, ws: null, role: 'none',
    on: { open: null, msg: null, close: null, error: null, rooms: null, hosted: null, room: null },
    online: null, code: '',
    sendCount: 0
  };

  function emit(type, a) { var f = Net.on[type]; if (f) { try { f(a); } catch (e) { if (window.console) console.error(e); } } }

  // eventos que llegan desde Java
  window.PGNative = {
    onEvent: function (type, payload) {
      if (type === 'open') { Net.connected = true; emit('open'); }
      else if (type === 'msg') { var o; try { o = JSON.parse(payload); } catch (e) { return; } emit('msg', o); }
      else if (type === 'close') { Net.connected = false; emit('close', payload); }
      else if (type === 'error') { Net.connected = false; emit('error', payload); }
      else if (type === 'rooms') { var r = []; try { r = JSON.parse(payload); } catch (e) { } emit('rooms', r); }
      else if (type === 'hosted') { var h = {}; try { h = JSON.parse(payload); } catch (e) { } emit('hosted', h); }
    }
  };

  // Crear sala (solo app): levanta el servidor interno y luego se conecta a si mismo
  Net.host = function (name) {
    if (!Net.native) { emit('error', 'Crear sala solo esta disponible en la app Android. Desde un PC ejecuta server/server.js y usa "Unirse".'); return; }
    Net.role = 'host';
    window.NativeNet.startHost(Net.PORT, String(name || 'Sala'));
    // Java avisa con 'hosted' y entonces conectamos a 127.0.0.1
  };
  Net.connect = function (addr) {
    Net.role = Net.role === 'host' ? 'host' : 'client';
    addr = String(addr || '').trim();
    if (Net.native) {
      var ip = addr, port = Net.PORT, m = addr.match(/^(.*):(\d+)$/);
      if (m) { ip = m[1]; port = parseInt(m[2], 10); }
      window.NativeNet.connect(ip, port);
    } else {
      try {
        var url = 'ws://' + (addr || location.host);
        var ws = Net.ws = new WebSocket(url);
        ws.onopen = function () { Net.connected = true; emit('open'); };
        ws.onmessage = function (ev) { var o; try { o = JSON.parse(ev.data); } catch (e) { return; } emit('msg', o); };
        ws.onclose = function () { var was = Net.connected; Net.connected = false; Net.ws = null; if (was) emit('close', 'cerrada'); else emit('error', 'No se pudo conectar'); };
        ws.onerror = function () { };
      } catch (e) { emit('error', String(e)); }
    }
  };
  // Internet: sala con codigo (MQTT publico, ver online.js)
  function onlineCbs() {
    return {
      onMsg: function (o) { if (o && o.t === 'welcome') Net.connected = true; emit('msg', o); },
      onRoom: function (code) { Net.code = code; emit('room', code); },
      onClose: function (why) { Net.connected = false; Net.online = null; emit('close', why); },
      onError: function (why) { Net.connected = false; Net.online = null; emit('error', why); }
    };
  }
  Net.hostOnline = function () { Net.close(); Net.role = 'host'; Net.code = ''; Net.online = PG.Online.host(onlineCbs()); };
  Net.joinOnline = function (code) { Net.close(); Net.role = 'client'; Net.code = ''; Net.online = PG.Online.join(code, onlineCbs()); };
  Net.send = function (obj) {
    if (Net.online) { if (Net.connected) Net.online.send(obj); return; }
    if (!Net.connected) return;
    var s = JSON.stringify(obj);
    Net.sendCount++;
    if (Net.native) window.NativeNet.send(s);
    else if (Net.ws && Net.ws.readyState === 1) Net.ws.send(s);
  };
  Net.close = function () {
    if (Net.online) { try { Net.online.close(); } catch (e) { } Net.online = null; Net.connected = false; Net.role = 'none'; return; }
    if (Net.native) { try { window.NativeNet.disconnect(); window.NativeNet.stopHost(); window.NativeNet.stopDiscovery(); } catch (e) { } }
    else if (Net.ws) { try { Net.ws.close(); } catch (e) { } }
    Net.ws = null; Net.connected = false; Net.role = 'none';
  };
  Net.startDiscovery = function () { if (Net.native) window.NativeNet.startDiscovery(); };
  Net.stopDiscovery = function () { if (Net.native) window.NativeNet.stopDiscovery(); };
  Net.localIp = function () { if (Net.native) { try { return String(window.NativeNet.getLocalIp()); } catch (e) { } } return ''; };
})();
