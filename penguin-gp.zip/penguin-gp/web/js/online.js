/* Multijugador por Internet con codigo de sala.
   No hace falta ningun servidor propio: usa brokers MQTT publicos (MQTT sobre WebSocket seguro) como "buzon" entre telefonos.
   - El anfitrion crea la sala: genera un codigo de 5 letras, escucha en su tema y hace de servidor de la sala
     (misma logica que server/server.js y que el servidor interno de la app: asigna ids, reenvia mensajes, avisa entradas/salidas).
   - Los demas escriben el codigo, se conectan al mismo broker (el ultimo caracter del codigo indica cual) y envian mensajes al anfitrion.
   Temas:  pgp2/<codigo>/up (jugadores -> anfitrion)   pgp2/<codigo>/all (anfitrion -> todos, en lotes)   pgp2/<codigo>/dn/<clave> (anfitrion -> uno) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};

  var BROKERS = ['wss://broker.hivemq.com:8884/mqtt', 'wss://broker.emqx.io:8084/mqtt', 'wss://test.mosquitto.org:8081/mqtt'];
  var ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 simbolos sin I ni O
  var TE = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null, TD = typeof TextDecoder !== 'undefined' ? new TextDecoder() : null;
  var FLUSH_MS = 50, HB_MS = 3000, PING_MS = 4000, CLIENT_TIMEOUT = 15000, HOST_TIMEOUT = 12000, JOIN_TIMEOUT = 7000, CONNECT_TIMEOUT = 8000;

  function brokerList() {
    var custom = ''; try { custom = (window.localStorage && localStorage.getItem('pg_broker')) || ''; } catch (e) { }
    custom = String(custom || '').trim();
    return custom ? [custom] : (PG.Online && PG.Online.brokers ? PG.Online.brokers : BROKERS);
  }
  function rndStr(n, alpha) { var s = ''; for (var i = 0; i < n; i++) s += alpha.charAt(Math.floor(Math.random() * alpha.length)); return s; }
  function newCode(brokerIdx) { return rndStr(4, ALPHA) + ALPHA.charAt(brokerIdx * 8 + Math.floor(Math.random() * 8)); }
  function normCode(c) { return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/[^ABCDEFGHJKLMNPQRSTUVWXYZ23456789]/g, ''); }
  function brokerOf(code) { return Math.floor(ALPHA.indexOf(code.charAt(4)) / 8); }

  /* ---------------- cliente MQTT 3.1.1 minimo (solo QoS 0) ---------------- */
  function pushStr(a, s) { var b = TE.encode(s); a.push((b.length >> 8) & 255, b.length & 255); for (var i = 0; i < b.length; i++) a.push(b[i]); }
  function pushBytes(a, b) { for (var i = 0; i < b.length; i++) a.push(b[i]); }
  function varLen(n) { var a = []; do { var b = n % 128; n = Math.floor(n / 128); if (n > 0) b |= 128; a.push(b); } while (n > 0); return a; }
  function packet(first, body) {
    var h = varLen(body.length), out = new Uint8Array(1 + h.length + body.length), i;
    out[0] = first; for (i = 0; i < h.length; i++) out[1 + i] = h[i];
    for (i = 0; i < body.length; i++) out[1 + h.length + i] = body[i];
    return out;
  }

  function Mqtt(url, will) {
    this.url = url; this.will = will || null; this.ws = null; this.buf = new Uint8Array(0);
    this.ready = false; this.closed = false; this.onmessage = null; this.onclose = null; this.pingT = 0; this._sub = null; this._ok = null; this._fail = null; this._tm = 0;
  }
  Mqtt.prototype.connect = function (ok, fail, timeoutMs) {
    var self = this, done = false;
    function bad(why) { if (done) return; done = true; clearTimeout(self._tm); self.close(true); fail(why); }
    this._tm = setTimeout(function () { bad('tiempo agotado'); }, timeoutMs || CONNECT_TIMEOUT);
    try { this.ws = new WebSocket(this.url, 'mqtt'); } catch (e) { bad(String(e)); return; }
    var ws = this.ws; ws.binaryType = 'arraybuffer';
    ws.onopen = function () {
      var b = [], flags = 2; // sesion limpia
      pushBytes(b, [0, 4, 77, 81, 84, 84, 4]);
      if (self.will) flags |= 4;
      b.push(flags, 0, 30);
      pushStr(b, 'pg' + rndStr(12, 'abcdefghijklmnopqrstuvwxyz0123456789'));
      if (self.will) { pushStr(b, self.will.topic); var wb = TE.encode(self.will.msg); b.push((wb.length >> 8) & 255, wb.length & 255); pushBytes(b, wb); }
      ws.send(packet(0x10, b));
    };
    ws.onmessage = function (ev) {
      var d = new Uint8Array(ev.data), nb = new Uint8Array(self.buf.length + d.length);
      nb.set(self.buf, 0); nb.set(d, self.buf.length); self.buf = nb;
      for (;;) {
        var bf = self.buf; if (bf.length < 2) return;
        var i = 1, mul = 1, len = 0, x;
        do { if (i >= bf.length) return; x = bf[i++]; len += (x & 127) * mul; mul *= 128; } while ((x & 128) && i < 5);
        if (bf.length < i + len) return;
        var body = bf.subarray(i, i + len), type = bf[0] >> 4, fl = bf[0] & 15;
        self.buf = bf.slice(i + len);
        if (type === 2) { if (body[1] === 0) { if (!done) { done = true; clearTimeout(self._tm); self.ready = true; self._startPing(); ok(); } } else bad('rechazado (' + body[1] + ')'); }
        else if (type === 3) {
          var tl = (body[0] << 8) | body[1], topic = TD.decode(body.subarray(2, 2 + tl)), off = 2 + tl + (((fl >> 1) & 3) ? 2 : 0);
          if (self.onmessage) { try { self.onmessage(topic, TD.decode(body.subarray(off))); } catch (e) { if (window.console) console.error(e); } }
        } else if (type === 9) { var cb = self._sub; self._sub = null; if (cb) cb(); }
      }
    };
    ws.onerror = function () { bad('error de conexion'); };
    ws.onclose = function () { if (!done) bad('conexion cerrada'); else if (!self.closed) { self.closed = true; self.ready = false; clearInterval(self.pingT); if (self.onclose) self.onclose(); } };
  };
  Mqtt.prototype._startPing = function () {
    var self = this;
    this.pingT = setInterval(function () { if (self.ws && self.ws.readyState === 1) try { self.ws.send(new Uint8Array([0xC0, 0])); } catch (e) { } }, 15000);
  };
  Mqtt.prototype.subscribe = function (topics, cb) {
    var b = [0, 1], i;
    for (i = 0; i < topics.length; i++) { pushStr(b, topics[i]); b.push(0); }
    this._sub = cb; this.ws.send(packet(0x82, b));
  };
  Mqtt.prototype.publish = function (topic, str) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    var b = []; pushStr(b, topic); pushBytes(b, TE.encode(str));
    try { this.ws.send(packet(0x30, b)); } catch (e) { return false; }
    return true;
  };
  Mqtt.prototype.close = function (silent) {
    clearInterval(this.pingT); clearTimeout(this._tm);
    var was = this.closed; this.closed = true; this.ready = false;
    if (this.ws) {
      try { if (this.ws.readyState === 1) this.ws.send(new Uint8Array([0xE0, 0])); } catch (e) { }
      try { this.ws.onclose = null; this.ws.onerror = null; this.ws.onmessage = null; this.ws.close(); } catch (e) { }
      this.ws = null;
    }
    if (!silent && !was && this.onclose) this.onclose();
  };

  /* ---------------- anfitrion: servidor de la sala ---------------- */
  // cbs: onMsg(obj), onClose(motivo), onError(motivo), onRoom(codigo)
  function hostRoom(cbs) {
    var urls = brokerList(), self = { role: 'host', code: '', closed: false }, winner = null, failed = 0, attempts = [];
    var clients = {}, nextId = 1, queue = [], hbT = 0, flT = 0, tmT = 0, LOCAL = '_host', mq = null, T = null, localId = 0;
    var hellos = {};

    function topicUp() { return 'pgp2/' + self.code + '/up'; }
    function topicAll() { return 'pgp2/' + self.code + '/all'; }
    function dn(ck, obj) {
      if (ck === LOCAL) { if (cbs.onMsg) cbs.onMsg(obj); return; }
      mq.publish('pgp2/' + self.code + '/dn/' + ck, JSON.stringify(obj));
    }
    function bcast(obj, fromId, localToo) { // obj ya lleva 'f' si procede
      queue.push(JSON.stringify(obj));
      if (localToo !== false && fromId !== localId && cbs.onMsg) cbs.onMsg(obj);
    }
    function flush() {
      if (!queue.length || !mq) return;
      var s = '[' + queue.join(',') + ']'; queue.length = 0; mq.publish(topicAll(), s);
    }
    function addClient(ck) {
      var c = clients[ck]; if (c) return c;
      c = clients[ck] = { id: nextId++, last: Date.now(), ck: ck };
      if (ck === LOCAL) localId = c.id;
      dn(ck, { t: 'welcome', id: c.id, host: localId || c.id, code: self.code });
      for (var k in clients) if (clients[k] !== c && hellos[clients[k].id]) dn(ck, hellos[clients[k].id]);
      if (ck !== LOCAL) bcast({ t: 'join', id: c.id }, 0);
      return c;
    }
    function removeClient(ck) {
      var c = clients[ck]; if (!c) return;
      delete clients[ck]; delete hellos[c.id];
      bcast({ t: 'leave', id: c.id }, 0);
    }
    function fromClient(ck, obj) {
      var c = clients[ck];
      if (obj.t === 'join') { if (c) { dn(ck, { t: 'welcome', id: c.id, host: localId, code: self.code }); for (var k in clients) if (clients[k] !== c && hellos[clients[k].id]) dn(ck, hellos[clients[k].id]); c.last = Date.now(); return; } addClient(ck); return; }
      if (!c) return;
      c.last = Date.now();
      if (obj.t === 'ping') return;
      if (obj.t === 'bye') { removeClient(ck); return; }
      obj.f = c.id;
      if (obj.t === 'hello') hellos[c.id] = obj;
      bcast(obj, c.id);
    }
    function onUp(topic, txt) {
      var obj; try { obj = JSON.parse(txt); } catch (e) { return; }
      if (!obj || typeof obj.k !== 'string') return;
      var ck = obj.k; delete obj.k;
      fromClient(ck, obj);
    }
    function start(m, idx, code) {
      mq = m; self.code = code;
      m.onmessage = function (topic, txt) { if (topic === topicUp()) onUp(topic, txt); };
      m.onclose = function () { if (!self.closed) { self.closed = true; clean(); if (cbs.onClose) cbs.onClose('Se perdió la conexión a internet'); } };
      m.subscribe([topicUp()], function () {
        flT = setInterval(flush, FLUSH_MS);
        hbT = setInterval(function () { bcast({ t: 'hb' }, 0, false); }, HB_MS);
        tmT = setInterval(function () {
          var now = Date.now();
          for (var k in clients) if (k !== LOCAL && now - clients[k].last > CLIENT_TIMEOUT) removeClient(k);
        }, 2000);
        if (cbs.onRoom) cbs.onRoom(code);
        addClient(LOCAL);
      });
    }
    function clean() { clearInterval(flT); clearInterval(hbT); clearInterval(tmT); }

    self.send = function (obj) {
      if (self.closed || !localId) return;
      var o = {}, k; for (k in obj) o[k] = obj[k]; o.f = localId;
      if (o.t === 'hello') hellos[localId] = o;
      if (o.t === 'ping') return;
      queue.push(JSON.stringify(o));
      if (o.t !== 's') { /* los eventos salen ya */ flush(); }
    };
    self.close = function () {
      if (self.closed) return; self.closed = true; clean();
      for (var i = 0; i < attempts.length; i++) if (attempts[i] !== mq) attempts[i].close(true);
      if (mq) { queue.push('{"t":"closed"}'); var m = mq; flush(); setTimeout(function () { m.close(true); }, 250); }
    };
    // conectar a varios brokers a la vez y quedarse con el primero que responda
    urls.forEach(function (u, i) {
      var code = newCode(Math.min(i, 3)), willMsg = '[{"t":"closed"}]';
      if (urls.length === 1 && i === 0) code = newCode(PG.Online.customIndex || 0);
      var m = new Mqtt(u, { topic: 'pgp2/' + code + '/all', msg: willMsg });
      attempts.push(m);
      m.connect(function () {
        if (winner || self.closed) { m.close(true); return; }
        winner = m; for (var j = 0; j < attempts.length; j++) if (attempts[j] !== m) attempts[j].close(true);
        start(m, i, code);
      }, function (why) {
        failed++;
        if (failed === urls.length && !winner && cbs.onError) cbs.onError('No se pudo conectar a internet (' + why + ')');
      }, CONNECT_TIMEOUT);
    });
    return self;
  }

  /* ---------------- jugador: se une con el codigo ---------------- */
  function joinRoom(codeIn, cbs) {
    var code = normCode(codeIn), self = { role: 'client', code: code, closed: false };
    if (code.length !== 5) { setTimeout(function () { if (cbs.onError) cbs.onError('El código tiene 5 caracteres'); }, 0); return self; }
    var urls = brokerList(), idx = urls.length === 1 ? 0 : brokerOf(code);
    if (idx < 0 || idx >= urls.length) { setTimeout(function () { if (cbs.onError) cbs.onError('Código no válido'); }, 0); return self; }
    var ck = rndStr(10, 'abcdefghijklmnopqrstuvwxyz0123456789'), myId = 0, lastRx = Date.now(), welcomed = false, pingT = 0, wdT = 0, joinT = 0, joinTry = 0;
    var mq = new Mqtt(urls[idx], { topic: 'pgp2/' + code + '/up', msg: JSON.stringify({ k: ck, t: 'bye' }) });
    var up = 'pgp2/' + code + '/up';
    function upSend(obj) { var s = JSON.stringify(obj); mq.publish(up, '{"k":"' + ck + '"' + (s.length > 2 ? ',' + s.slice(1) : '}')); }
    function fail(why) { if (self.closed) return; self.closed = true; stop(); mq.close(true); if (cbs.onError) cbs.onError(why); }
    function stop() { clearInterval(pingT); clearInterval(wdT); clearInterval(joinT); }
    function handle(m) {
      lastRx = Date.now();
      if (!m) return;
      if (m.t === 'hb') return;
      if (m.t === 'closed') { if (!self.closed) { self.closed = true; stop(); mq.close(true); if (cbs.onClose) cbs.onClose('El anfitrión cerró la sala'); } return; }
      if (m.t === 'welcome') { if (welcomed) return; welcomed = true; myId = m.id; clearInterval(joinT); }
      else if (!welcomed) return;
      if (m.f !== undefined && m.f === myId) return;
      if (cbs.onMsg) cbs.onMsg(m);
    }
    mq.onmessage = function (topic, txt) {
      var o; try { o = JSON.parse(txt); } catch (e) { return; }
      if (o && o.length !== undefined && typeof o !== 'string') { for (var i = 0; i < o.length; i++) handle(o[i]); } else handle(o);
    };
    mq.onclose = function () { if (!self.closed) { self.closed = true; stop(); if (cbs.onClose) cbs.onClose('Se perdió la conexión a internet'); } };
    mq.connect(function () {
      mq.subscribe(['pgp2/' + code + '/all', 'pgp2/' + code + '/dn/' + ck], function () {
        upSend({ t: 'join' }); joinTry = 1;
        joinT = setInterval(function () {
          if (welcomed) { clearInterval(joinT); return; }
          if (++joinTry > 3) { fail('No se encontró la sala ' + code + '. Revisa el código y que el anfitrión siga en la sala.'); return; }
          upSend({ t: 'join' });
        }, JOIN_TIMEOUT / 3);
        pingT = setInterval(function () { upSend({ t: 'ping' }); }, PING_MS);
        wdT = setInterval(function () { if (welcomed && Date.now() - lastRx > HOST_TIMEOUT && !self.closed) { self.closed = true; stop(); mq.close(true); if (cbs.onClose) cbs.onClose('Sin conexión con la sala'); } }, 2000);
        if (cbs.onOpen) cbs.onOpen();
      });
    }, function (why) { fail('No se pudo conectar a internet (' + why + ')'); }, CONNECT_TIMEOUT);

    self.send = function (obj) { if (self.closed || !welcomed) return; upSend(obj); };
    self.close = function () {
      if (self.closed) return; self.closed = true; stop();
      if (welcomed) upSend({ t: 'bye' });
      setTimeout(function () { mq.close(true); }, 150);
    };
    return self;
  }

  PG.Online = { brokers: BROKERS, host: hostRoom, join: joinRoom, normCode: normCode, newCode: newCode, brokerOf: brokerOf, Mqtt: Mqtt, ALPHA: ALPHA, customIndex: 0 };
})();
