/* Monedas, tienda e inventario (guardado en el telefono). Las monedas se ganan con combos de piruetas y segun el puesto. */
(function () {
  'use strict';
  var PG = window.PG, G = PG.G, Eco = PG.Eco = {};
  var MAX = Eco.MAX = 3, SLOTS = Eco.SLOTS = 3;
  // precio y descripcion de cada poder (los mas fuertes cuestan mucho)
  Eco.ITEMS = [
    { k: 'snow', price: 60, d: 'Bola de nieve teledirigida al jugador más cercano. 3-4 impactos lo aturden.' },
    { k: 'trap', price: 60, d: 'Trampa de hielo: frena a quien pase por encima.' },
    { k: 'shield', price: 110, d: 'Escudo 10 s. A mucha velocidad rompe hielo y rocas.' },
    { k: 'eshield', price: 190, d: 'Escudo eléctrico 10 s: quien te toque se electrocuta (salvo que tenga escudo).' },
    { k: 'bshield', price: 190, d: 'Escudo de rebote 10 s: las bolas y empujones salen rebotados en cualquier dirección.' },
    { k: 'tornado', price: 150, d: 'Ventisca que molesta a los rivales cercanos.' },
    { k: 'wings', price: 180, d: 'Alas de hielo: vuelas unos segundos.' },
    { k: 'cannon', price: 200, d: 'Cañón de nieve: dispara durante 9 s.' },
    { k: 'ghost', price: 200, d: 'Fantasma: atraviesas obstáculos un rato.' },
    { k: 'superjump', price: 220, d: 'Súper salto: 9 s de saltos altos repetidos.' },
    { k: 'grenade', price: 260, d: 'Cañón de granadas con explosión en área.' },
    { k: 'quake', price: 300, d: 'Terremoto: sacude a los rivales.' },
    { k: 'hyper', price: 380, d: 'Turbo máximo: muchísimo más rápido que el turbo normal.' },
    { k: 'megaball', price: 450, d: 'Mega bola gigante que arrasa todo a su paso.' },
    { k: 'missile', price: 520, d: 'Misil teledirigido a los de delante; explota con área.' }
  ];
  var byK = {}; Eco.ITEMS.forEach(function (it) { byK[it.k] = it; });
  // stickers del chat: todos los paquetes se compran en la tienda (tambien desde la sala); los emojis son gratis
  Eco.PACKS = [
    { id: 'base', name: 'Básico', price: 80, col: '#4da8ee', st: [['🏆', '¡GG!'], ['😂', 'JAJA'], ['👍', '¡Bien!'], ['🐧', '¡Hola!'], ['🔥', '¡Fuego!'], ['😴', 'Zzz']] },
    { id: 'pol', name: 'Polar', price: 150, col: '#58c8ff', st: [['❄️', 'Brrr'], ['⛄', '¡Muñeco!'], ['🧊', 'Hielo'], ['🌨️', 'Tormenta'], ['🎿', 'Deslizando'], ['🥶', '¡Qué frío!']] },
    { id: 'race', name: 'Carrera', price: 220, col: '#ff9a3c', st: [['🏁', '¡A correr!'], ['🚀', 'Turbo'], ['💨', 'Adiós'], ['😎', 'Fácil'], ['🥇', 'Soy el 1.º'], ['😱', 'Avalancha']] },
    { id: 'fun', name: 'Fiesta', price: 300, col: '#c86bff', st: [['🎉', '¡Fiesta!'], ['🤩', 'Wow'], ['😈', 'Te atrapo'], ['🙈', 'Uy…'], ['💪', 'Revancha'], ['👑', 'Rey']] }
  ];
  Eco.EMOJIS = ['😀', '😂', '🤣', '😊', '😍', '😎', '🤩', '😜', '🤔', '😅', '😭', '😡', '😱', '🥶', '😴', '🙈', '👍', '👎', '👏', '🙌', '💪', '🤝', '✌️', '🙏', '🐧', '❄️', '⛄', '🧊', '🔥', '🚀', '🏁', '🏆', '🥇', '🎉', '💥', '⭐', '❤️', '💙', '💨', '🎿'];
  Eco.pack = function (id) { for (var i = 0; i < Eco.PACKS.length; i++) if (Eco.PACKS[i].id === id) return Eco.PACKS[i]; return null; };
  Eco.hasPack = function (id) { var pk = Eco.pack(id); return !!pk && (pk.price === 0 || !!(D.stk && D.stk[id])); };
  Eco.buyPack = function (id) {
    var pk = Eco.pack(id); if (!pk) return { ok: false, msg: 'Paquete desconocido' };
    if (Eco.hasPack(id)) return { ok: false, msg: 'Ya lo tienes' };
    if (D.coins < pk.price) return { ok: false, msg: 'Te faltan ' + (pk.price - D.coins) + ' monedas' };
    D.coins -= pk.price; D.spent += pk.price; D.stk = D.stk || {}; D.stk[id] = 1; save(); refreshWallet();
    return { ok: true, msg: '¡Paquete «' + pk.name + '» desbloqueado!' };
  };
  // v3.4: conjuntos de ropa
  Eco.setOf = function (id) { for (var i = 0; i < PG.SETS.length; i++) if (PG.SETS[i].id === id) return PG.SETS[i]; return null; };
  Eco.hasSet = function (id) { return !!(D.sets && D.sets[id]); };
  Eco.buySet = function (id) {
    var st = Eco.setOf(id); if (!st) return { ok: false, msg: 'Conjunto desconocido' };
    if (Eco.hasSet(id)) return { ok: false, msg: 'Ya lo tienes' };
    if (D.coins < st.price) return { ok: false, msg: 'Te faltan ' + (st.price - D.coins) + ' monedas' };
    D.coins -= st.price; D.spent += st.price; D.sets = D.sets || {}; D.sets[id] = 1; save(); refreshWallet();
    return { ok: true, msg: '¡Conjunto «' + st.name + '» desbloqueado!' };
  };
  // un sticker llega como "paquete:numero"; solo se aceptan los que existen
  Eco.stickerOf = function (code) {
    var a = String(code || '').split(':'), pk = Eco.pack(a[0]), i = a[1] | 0;
    return pk && pk.st[i] ? { pack: pk, e: pk.st[i][0], t: pk.st[i][1] } : null;
  };
  function blank() { return { coins: 500, earned: 0, spent: 0, inv: {}, load: [], stk: {}, sets: {} }; }
  var D = Eco.data = (G.store.get('pgp_eco', null)) || blank();
  (function () { var b = blank(); for (var k in b) if (D[k] === undefined) D[k] = b[k]; })();
  function save() { G.store.set('pgp_eco', D); }
  Eco.save = save;
  Eco.own = function (k) { return D.inv[k] | 0; };

  // recompensas
  Eco.comboCoins = function (n) { n = n | 0; return n <= 0 ? 0 : (n === 1 ? 2 : (n === 2 ? 6 : (n === 3 ? 12 : 12 + (n - 3) * 6))); };
  var PLACE_COINS = [60, 35, 20], PLACE_PTS = [10, 7, 5, 3, 2, 1], PTS_X = 500; // v2.9: cada nivel pide 100 000 puntos, asi que cada carrera da x500
  // estrellas de la carrera (0-5) segun el rendimiento (v2.9): puesto (hasta 60 pts), piruetas (hasta 15), carrera limpia (sin golpes +10),
  // caidas (-8 c/u), diferencia con el ganador (hasta -12) y ventaja si ganas (+8). Eliminado = 0. Umbrales 28 / 45 / 62 / 78.
  Eco.starScore = function (rank, total, tricks, ex) {
    ex = ex || {};
    var pos = total <= 1 ? 0.45 : (rank - 1) / (total - 1);
    var sc = 10 + 60 * Math.pow(Math.max(0, 1 - pos), 0.85);
    if (total <= 1) sc = 10 + 38;
    sc += Math.min(15, (tricks | 0) * 3);
    sc += Math.max(-8, 10 - 3 * (ex.hurt | 0));
    sc -= Math.min(16, 8 * (ex.falls | 0));
    if (rank === 1 && total > 1) sc += 8; else if (ex.gap > 0) sc -= Math.min(12, ex.gap * 100 * 1.6);
    return sc;
  };
  Eco.starsFor = function (rank, total, tricks, ex) {
    if (rank <= 0) return 0;
    var sc = Eco.starScore(rank, total, tricks, ex);
    return sc >= 78 ? 5 : sc >= 62 ? 4 : sc >= 45 ? 3 : sc >= 28 ? 2 : 1;
  };
  // rank 0 = eliminado. rc = {combo, tricks}. Ingresa las monedas y devuelve el desglose.
  // v3.1: campeonato con apuestas: apostar descuenta monedas, el premio las suma; con apuestas las monedas de cada carrera van al bote (noBank)
  Eco.canBet = function (n) { return D.coins >= n; };
  Eco.bet = function (n) { D.coins = Math.max(0, D.coins - n); D.spent += n; save(); refreshWallet(); };
  Eco.payout = function (n) { D.coins += n; D.earned += n; save(); refreshWallet(); };
  Eco.finishReward = function (rank, total, rc, noBank) {
    rc = rc || { combo: 0, tricks: 0 };
    var place = rank <= 0 ? 0 : (rank <= 3 ? PLACE_COINS[rank - 1] : 8);
    var pts = ((rank <= 0 ? 0 : (PLACE_PTS[Math.min(5, rank - 1)] || 1)) + Math.floor((rc.tricks | 0) / 2)) * PTS_X;
    var rw = { combo: rc.combo | 0, place: place, coins: (rc.combo | 0) + place, points: pts, tricks: rc.tricks | 0, rank: rank, stars: Eco.starsFor(rank, total, rc.tricks, rc) };
    if (!noBank) { D.coins += rw.coins; D.earned += rw.coins; save(); refreshWallet(); }
    return rw;
  };
  // compra / equipo
  Eco.buy = function (k) {
    var it = byK[k]; if (!it) return { ok: false, msg: 'Poder desconocido' };
    if (Eco.own(k) >= MAX) return { ok: false, msg: 'Inventario lleno (máx. ' + MAX + ')' };
    if (D.coins < it.price) return { ok: false, msg: 'Te faltan ' + (it.price - D.coins) + ' monedas' };
    D.coins -= it.price; D.spent += it.price; D.inv[k] = Eco.own(k) + 1;
    var eqd = false; if (D.load.length < SLOTS) { D.load.push(k); eqd = true; } // se equipa solo si hay casilla libre (una unidad por casilla)
    save(); refreshWallet();
    return { ok: true, msg: eqd ? '¡Comprado y equipado!' : '¡Comprado!' };
  };
  function cnt(k) { var n = 0; D.load.forEach(function (x) { if (x === k) n++; }); return n; }
  Eco.loaded = cnt;
  // v3.2: cada casilla equipada es UNA unidad (dos escudos de rebote = dos casillas). Equipar anade una unidad, quitar la retira.
  Eco.addLoad = function (k) { if (cnt(k) >= Eco.own(k) || D.load.length >= SLOTS) return false; D.load.push(k); save(); return true; };
  Eco.removeLoad = function (k) { var i = D.load.lastIndexOf(k); if (i < 0) return false; D.load.splice(i, 1); save(); return true; };
  Eco.removeSlot = function (i) { if (i < 0 || i >= D.load.length) return false; D.load.splice(i, 1); save(); return true; };
  // v3.2: las casillas del equipo valen para UNA carrera: se usen las veces que se usen (recargan), al terminar la carrera cada casilla usada
  // gasta 1 unidad del inventario y desaparece; hay que volver a comprarla. Las casillas sin usar se conservan.
  Eco.loadout = function () {
    var seen = {}, out = [];
    D.load.forEach(function (k) { seen[k] = (seen[k] | 0) + 1; if (seen[k] <= Eco.own(k) && out.length < SLOTS) out.push(k); });
    D.load = out.slice(); return out;
  };
  Eco.spend = function (k) {
    D.inv[k] = Math.max(0, Eco.own(k) - 1);
    var i = D.load.lastIndexOf(k); if (i >= 0) D.load.splice(i, 1);
    if (D.load.filter(function (x) { return x === k; }).length > Eco.own(k)) { i = D.load.lastIndexOf(k); D.load.splice(i, 1); }
    save();
  };
  Eco.consume = Eco.spend;
  // ruleta (v3.2): un giro gratis cada cierto tiempo; luego se podra ligar a anuncios
  Eco.SPIN_GAP = 3 * 3600 * 1000;
  Eco.spinLeft = function () { var t = (+D.spinAt || 0) + Eco.SPIN_GAP - Date.now(); return t > 0 ? t : 0; };
  Eco.PRIZES = [
    { t: 'coins', v: 50, w: 22, l: '50' }, { t: 'power', w: 12, l: 'Poder' }, { t: 'coins', v: 100, w: 18, l: '100' }, { t: 'pts', v: 5000, w: 14, l: '5 000' },
    { t: 'coins', v: 200, w: 10, l: '200' }, { t: 'power', w: 12, l: 'Poder' }, { t: 'pts', v: 20000, w: 5, l: '20 000' }, { t: 'coins', v: 500, w: 3, l: '500' }
  ];
  Eco.spinPick = function (rnd) {
    var tot = 0, i; Eco.PRIZES.forEach(function (p) { tot += p.w; });
    var x = (rnd === undefined ? Math.random() : rnd) * tot;
    for (i = 0; i < Eco.PRIZES.length; i++) { x -= Eco.PRIZES[i].w; if (x < 0) return i; }
    return 0;
  };
  // aplica el premio; devuelve un texto
  Eco.spinApply = function (i) {
    var p = Eco.PRIZES[i], msg = '';
    D.spinAt = Date.now();
    if (p.t === 'coins') { D.coins += p.v; D.earned += p.v; msg = '¡Ganaste 🪙' + p.v + '!'; }
    else if (p.t === 'pts') { G.stats.points = (G.stats.points | 0) + p.v; G.store.set('pgp_stats', G.stats); msg = '¡Ganaste ' + p.v + ' puntos de nivel!'; }
    else {
      var opts = Eco.ITEMS.filter(function (it) { return Eco.own(it.k) < MAX && it.price <= 260; });
      if (!opts.length) { D.coins += 150; D.earned += 150; msg = 'Inventario lleno: ¡🪙150 de regalo!'; }
      else { var it = opts[(Math.random() * opts.length) | 0]; D.inv[it.k] = Eco.own(it.k) + 1; msg = '¡Ganaste ' + PG.ITEM_NAMES[it.k] + '!'; }
    }
    save(); refreshWallet(); return msg;
  };

  /* ---------- interfaz ---------- */
  var $ = G.$, esc = G.esc, armed = null, armT = 0;
  function refreshWallet() {
    var w = $('mwCoins'); if (w) w.textContent = D.coins;
    var w2 = $('mwStars'); if (w2) w2.textContent = (G.stats && G.stats.stars) | 0;
    var s = $('swCoins'); if (s) s.textContent = D.coins;
  }
  Eco.refreshWallet = refreshWallet;
  function dots(n) { var h = ''; for (var i = 0; i < MAX; i++) h += '<i class="' + (i < n ? 'on' : '') + '"></i>'; return h; }
  var HAT_ICO = ['', ':ic_h_beanie:', ':ic_h_helmet:', ':ic_crown:', ':ic_h_top:', ':ic_h_cap:', ':ic_h_horns:', ':ic_h_phones:', ':ic_h_wizard:', ':ic_h_cowboy:', ':ic_h_chef:', ':ic_h_cat:', ':ic_h_party:', ':ic_h_halo:', ':ic_h_santa:', ':ic_h_ushanka:'], GL_ICO = ['', ':ic_g_goggles:', ':ic_g_shades:', ':ic_g_round:', ':ic_g_visor:', ':ic_g_heart:', ':ic_g_mask:'], SC_ICO = ['', ':ic_scarf:', ':ic_s_bow:', ':ic_s_pin:', ':ic_medalstar:', ':ic_s_bell:', ':ic_s_candy:'], OF_ICO = ['', ':ic_jacket:', ':ic_o_cape:', ':ic_o_pack:', ':ic_o_vest:', ':ic_o_tux:', ':ic_o_wings:', ':ic_o_jet:'];
  Eco.renderShop = function () {
    refreshWallet();
    var slots = '';
    for (var i = 0; i < SLOTS; i++) {
      var k = D.load[i];
      slots += k ? '<button class="slotB full" data-act="shopEq" data-i="' + i + '" title="Quitar"><span class="ic">' + G.ICONS[k] + '</span><small>' + esc(PG.ITEM_NAMES[k]) + '</small></button>' : '<div class="slotB"><small>Vacío</small></div>';
    }
    $('shopLoad').innerHTML = '<div class="ldT"><b>Mi equipo</b><small>Cada casilla es 1 unidad. Se recarga durante la carrera y, al terminarla, se gasta: tendrás que comprarla otra vez.</small></div><div class="ldS">' + slots + '</div>';
    var h = '';
    Eco.ITEMS.forEach(function (it) {
      var n = Eco.own(it.k), full = n >= MAX, can = D.coins >= it.price, ld = cnt(it.k), isArmed = armed === it.k;
      var buy = full ? '<button class="btn small" disabled>Lleno</button>' : '<button class="btn small ' + (can ? 'primary' : '') + '" data-act="shopBuy" data-k="' + it.k + '"' + (can ? '' : ' disabled') + '>' + (isArmed ? '¿Seguro?' : 'Comprar 🪙' + it.price) + '</button>';
      var equip = '';
      if (n > ld) equip += '<button class="btn small" data-act="shopAdd" data-k="' + it.k + '"' + (D.load.length >= SLOTS ? ' disabled' : '') + '>Equipar</button>';
      if (ld) equip += '<button class="btn small sel" data-act="shopDel" data-k="' + it.k + '">Quitar' + (ld > 1 ? ' (' + ld + ')' : '') + '</button>';
      h += '<div class="shopCard' + (n ? ' has' : '') + '"><div class="ic">' + G.ICONS[it.k] + '</div><div class="nm">' + esc(PG.ITEM_NAMES[it.k]) + '</div><div class="ds">' + esc(it.d) + '</div><div class="own"><span class="dots">' + dots(n) + '</span><small>' + n + '/' + MAX + '</small></div><div class="bt">' + buy + equip + '</div></div>';
    });
    h += '<div class="shopSec"><b>👔 Conjuntos de ropa</b><small>Atuendos completos: se compran una vez y los pones desde «Mi pingüino › Conjuntos».</small></div>';
    PG.SETS.forEach(function (st) {
      var own = Eco.hasSet(st.id), can = D.coins >= st.price, c = st.c;
      var prev = [PG.OPT.hats[c.hat] ? HAT_ICO[c.hat] : '', c.glasses ? GL_ICO[c.glasses] : '', c.scarf ? SC_ICO[c.scarf] : '', c.outfit ? OF_ICO[c.outfit] : ''].join(' ');
      h += '<div class="shopCard pack' + (own ? ' has' : '') + '" style="--pk:#ffb347"><div class="ic stkPrev"><span>' + st.ico + '</span><span style="font-size:.6em">' + prev + '</span></div><div class="nm">' + esc(st.name) + '</div><div class="ds">' + esc(st.d) + '</div><div class="own">' + (own ? '<small>✔ Comprado</small>' : '') + '</div>' +
        (own ? '<button class="btn small" data-act="shopSetWear" data-s="' + st.id + '">Ponérmelo</button>' : '<button class="btn small ' + (can ? 'primary' : '') + '" data-act="shopSet" data-s="' + st.id + '"' + (can ? '' : ' disabled') + '>Comprar 🪙' + st.price + '</button>') + '</div>';
    });
    h += '<div class="shopSec"><b>💬 Stickers del chat</b><small>Los emojis son gratis; los stickers se compran por paquete y los ven todos en la sala.</small></div>';
    Eco.PACKS.forEach(function (pk) {
      var own = Eco.hasPack(pk.id), can = D.coins >= pk.price, prev = pk.st.map(function (q) { return '<span title="' + esc(q[1]) + '">' + q[0] + '</span>'; }).join('');
      h += '<div class="shopCard pack' + (own ? ' has' : '') + '" style="--pk:' + pk.col + '"><div class="ic stkPrev">' + prev + '</div><div class="nm">Stickers «' + esc(pk.name) + '»</div><div class="ds">6 stickers con texto para el chat de la sala.</div><div class="own">' + (own ? '<small>✔ Comprado</small>' : '') + '</div>' +
        (own ? '<button class="btn small" disabled>Tuyo</button>' : '<button class="btn small ' + (can ? 'primary' : '') + '" data-act="shopPack" data-p="' + pk.id + '"' + (can ? '' : ' disabled') + '>Comprar 🪙' + pk.price + '</button>') + '</div>';
    });
    $('shopGrid').innerHTML = h;
  };
  Eco.actions = {
    shop: function () { G.go('scrShop'); },
    shopBuy: function (el) {
      var k = el.dataset.k;
      if (armed !== k) { armed = k; clearTimeout(armT); armT = setTimeout(function () { armed = null; if (G.screen === 'scrShop') Eco.renderShop(); }, 2500); Eco.renderShop(); return; }
      armed = null; var r = Eco.buy(k); G.toast(r.msg); if (r.ok && PG.Audio) PG.Audio.sfx('ability'); Eco.renderShop();
    },
    shopEq: function (el) { Eco.removeSlot(el.dataset.i | 0); Eco.renderShop(); },
    shopAdd: function (el) { Eco.addLoad(el.dataset.k); Eco.renderShop(); },
    shopDel: function (el) { Eco.removeLoad(el.dataset.k); Eco.renderShop(); },
    shopSet: function (el) { var r = Eco.buySet(el.dataset.s); G.toast(r.msg); if (r.ok && PG.Audio) PG.Audio.sfx('ability'); Eco.renderShop(); },
    shopSetWear: function (el) { if (G.wearSet) { G.wearSet(el.dataset.s); G.toast('¡Conjunto puesto!'); } },
    shopPack: function (el) { var r = Eco.buyPack(el.dataset.p); G.toast(r.msg); if (r.ok && PG.Audio) PG.Audio.sfx('ability'); Eco.renderShop(); }
  };
  /* ---------- ruleta ---------- */
  var wheelRot = 0, spinning = false, WCOL = ['#2f8fe6', '#ffb02e', '#4fc3f7', '#7ad66b', '#ff7a45', '#b78cff', '#f26ab0', '#ffd84d'];
  // iconos propios de la ruleta (moneda con $, moneda con estrella, rayo)
  function wheelIcon(x, kind, cx, cy, r) {
    x.save(); x.translate(cx, cy);
    if (kind === 'power') {
      x.beginPath(); x.moveTo(3, -r); x.lineTo(-r * .62, r * .12); x.lineTo(-r * .06, r * .12); x.lineTo(-3, r); x.lineTo(r * .66, -r * .22); x.lineTo(r * .08, -r * .22); x.closePath();
      var gp = x.createLinearGradient(0, -r, 0, r); gp.addColorStop(0, '#fff6b0'); gp.addColorStop(1, '#ffb11f'); x.fillStyle = gp; x.fill(); x.lineWidth = 2.4; x.strokeStyle = '#7a3d00'; x.lineJoin = 'round'; x.stroke();
    } else {
      var g = x.createRadialGradient(-r * .3, -r * .35, r * .1, 0, 0, r); g.addColorStop(0, '#fff3a6'); g.addColorStop(.55, '#ffc82e'); g.addColorStop(1, '#e8860c');
      x.beginPath(); x.arc(0, 0, r, 0, 7); x.fillStyle = g; x.fill(); x.lineWidth = 2.6; x.strokeStyle = '#7a3d00'; x.stroke();
      x.beginPath(); x.arc(0, 0, r * .72, 0, 7); x.lineWidth = 1.4; x.strokeStyle = 'rgba(122,61,0,.55)'; x.stroke();
      if (kind === 'coins') { x.font = '800 ' + Math.round(r * 1.25) + 'px PopH, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#7a3d00'; x.fillText('$', 0, r * .06); }
      else { x.beginPath(); for (var k = 0; k < 10; k++) { var rr = k % 2 ? r * .27 : r * .58, an = -Math.PI / 2 + k * Math.PI / 5; x.lineTo(Math.cos(an) * rr, Math.sin(an) * rr); } x.closePath(); x.fillStyle = '#fff'; x.fill(); x.lineWidth = 1.2; x.strokeStyle = '#a85d00'; x.stroke(); }
    }
    x.restore();
  }
  function drawWheel() {
    var cv = $('wheelCv'); if (!cv) return; var x = cv.getContext('2d'), W = cv.width, c = W / 2, R = c - 10, n = Eco.PRIZES.length, a = Math.PI * 2 / n;
    x.clearRect(0, 0, W, W); x.save(); x.translate(c, c); x.rotate(wheelRot);
    for (var i = 0; i < n; i++) {
      x.beginPath(); x.moveTo(0, 0); x.arc(0, 0, R, i * a - a / 2 - Math.PI / 2, (i + 1) * a - a / 2 - Math.PI / 2); x.closePath();
      var g = x.createRadialGradient(0, 0, R * .15, 0, 0, R); g.addColorStop(0, '#fff'); g.addColorStop(.25, WCOL[i % WCOL.length]); g.addColorStop(1, WCOL[i % WCOL.length]);
      x.fillStyle = g; x.fill(); x.lineWidth = 3; x.strokeStyle = '#0b3b8e'; x.stroke();
      // v3.9: numeros finos y legibles (Poppins en vez de Erica One con borde grueso) y monedas/estrella dibujadas (sin emojis)
      var pz = Eco.PRIZES[i], txt = pz.t === 'power' ? 'Poder' : String(pz.v).replace(/\B(?=(\d{3})+(?!\d))/g, '\u2009');
      x.save(); x.rotate(i * a - Math.PI / 2); x.textAlign = 'right'; x.textBaseline = 'middle'; x.lineJoin = 'round';
      x.font = '700 ' + (pz.t === 'power' ? 22 : 25) + 'px PopH, Pop, sans-serif';
      var tw = x.measureText(txt).width, ex = R - 18;
      x.lineWidth = 3; x.strokeStyle = 'rgba(8,36,92,.85)'; x.fillStyle = '#fff';
      x.strokeText(txt, ex, 1); x.fillText(txt, ex, 1);
      wheelIcon(x, pz.t, ex - tw - 17, 0, 14);
      x.restore();
    }
    x.restore();
    x.beginPath(); x.arc(c, c, R + 4, 0, 7); x.lineWidth = 8; x.strokeStyle = '#0b3b8e'; x.stroke();
    x.beginPath(); x.arc(c, c, 26, 0, 7); x.fillStyle = '#ffd84d'; x.fill(); x.lineWidth = 5; x.strokeStyle = '#0b3b8e'; x.stroke();
  }
  function fmtLeft(ms) { var s = Math.ceil(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h + ' h ' + (m < 10 ? '0' : '') + m + ' min'; }
  Eco.renderWheel = function () {
    refreshWallet(); var wc = $('whCoins'); if (wc) wc.textContent = D.coins; drawWheel();
    var left = Eco.spinLeft(), b = $('btnSpin'); if (!b) return;
    b.disabled = spinning || left > 0; $('wheelCd').textContent = left > 0 ? 'Próximo giro gratis en ' + fmtLeft(left) : '¡Giro gratis disponible!';
    var bd = $('whBadge'); if (bd) bd.style.display = left > 0 ? 'none' : 'block';
  };
  Eco.spin = function () {
    if (spinning || Eco.spinLeft() > 0) return;
    spinning = true; $('wheelRes').textContent = ''; $('btnSpin').disabled = true;
    var idx = Eco.spinPick(), n = Eco.PRIZES.length, a = Math.PI * 2 / n, start = wheelRot, extra = Math.PI * 2 * (5 + Math.random()), target = -(idx * a) + (Math.random() - .5) * a * .6;
    var end = start + extra + ((target - start) % (Math.PI * 2) - Math.PI * 2) * -1; end = start + Math.ceil((extra) / (Math.PI * 2)) * Math.PI * 2 + (((target - start) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    var t0 = performance.now(), dur = 4200, lastTick = -1;
    (function frame(now) {
      var k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3); wheelRot = start + (end - start) * e; drawWheel();
      var seg = Math.floor((wheelRot + a / 2) / a); if (seg !== lastTick) { lastTick = seg; if (PG.Audio) PG.Audio.sfx('click'); }
      if (k < 1) requestAnimationFrame(frame);
      else { spinning = false; var msg = Eco.spinApply(idx); $('wheelRes').textContent = msg; if (PG.Audio) PG.Audio.sfx('ability'); Eco.renderWheel(); }
    })(t0);
  };
  Eco.onScreen = function (id) { if (id === 'scrShop') { armed = null; Eco.renderShop(); } if (id === 'scrWheel') { $('wheelRes').textContent = ''; Eco.renderWheel(); } if (id === 'scrMain') Eco.renderWheelBadge(); };
  Eco.renderWheelBadge = function () { var bd = $('whBadge'); if (bd) bd.style.display = Eco.spinLeft() > 0 ? 'none' : 'block'; };
  refreshWallet();
})();
