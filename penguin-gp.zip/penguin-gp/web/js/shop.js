/* Monedas, tienda e inventario (guardado en el telefono). Las monedas se ganan con combos de piruetas y segun el puesto. */
(function () {
  'use strict';
  var PG = window.PG, G = PG.G, Eco = PG.Eco = {};
  var MAX = Eco.MAX = 3, SLOTS = Eco.SLOTS = 2;
  // precio y descripcion de cada poder (los mas fuertes cuestan mucho)
  Eco.ITEMS = [
    { k: 'snow', price: 60, d: 'Bola de nieve teledirigida al jugador más cercano. 3-4 impactos lo aturden.' },
    { k: 'trap', price: 60, d: 'Trampa de hielo: frena a quien pase por encima.' },
    { k: 'shield', price: 110, d: 'Escudo 10 s. A mucha velocidad rompe hielo y rocas.' },
    { k: 'tornado', price: 150, d: 'Ventisca que molesta a los rivales cercanos.' },
    { k: 'wings', price: 180, d: 'Alas de hielo: vuelas unos segundos.' },
    { k: 'cannon', price: 200, d: 'Cañón de nieve: dispara durante 9 s.' },
    { k: 'ghost', price: 200, d: 'Fantasma: atraviesas obstáculos un rato.' },
    { k: 'superjump', price: 220, d: 'Súper salto: 9 s de saltos altos repetidos.' },
    { k: 'grenade', price: 260, d: 'Cañón de granadas con explosión en área.' },
    { k: 'quake', price: 300, d: 'Terremoto: sacude a los rivales.' },
    { k: 'hyper', price: 380, d: 'Turbo máximo: muchísimo más rápido que el turbo normal.' },
    { k: 'megaball', price: 450, d: 'Mega bola gigante que arrasa todo a su paso.' },
    { k: 'missile', price: 520, d: 'Misil teledirigido a los de delante; explota con área.' }
  ];
  var byK = {}; Eco.ITEMS.forEach(function (it) { byK[it.k] = it; });
  // stickers del chat: el paquete gratis siempre esta disponible; los demas se compran en la sala
  Eco.PACKS = [
    { id: 'base', name: 'Gratis', price: 0, col: '#4da8ee', st: [['🏆', '¡GG!'], ['😂', 'JAJA'], ['👍', '¡Bien!'], ['🐧', '¡Hola!'], ['🔥', '¡Fuego!'], ['😴', 'Zzz']] },
    { id: 'pol', name: 'Polar', price: 120, col: '#58c8ff', st: [['❄️', 'Brrr'], ['⛄', '¡Muñeco!'], ['🧊', 'Hielo'], ['🌨️', 'Tormenta'], ['🎿', 'Deslizando'], ['🥶', '¡Qué frío!']] },
    { id: 'race', name: 'Carrera', price: 180, col: '#ff9a3c', st: [['🏁', '¡A correr!'], ['🚀', 'Turbo'], ['💨', 'Adiós'], ['😎', 'Fácil'], ['🥇', 'Soy el 1.º'], ['😱', 'Avalancha']] },
    { id: 'fun', name: 'Fiesta', price: 250, col: '#c86bff', st: [['🎉', '¡Fiesta!'], ['🤩', 'Wow'], ['😈', 'Te atrapo'], ['🙈', 'Uy…'], ['💪', 'Revancha'], ['👑', 'Rey']] }
  ];
  Eco.EMOJIS = ['😀', '😂', '🤣', '😊', '😍', '😎', '🤩', '😜', '🤔', '😅', '😭', '😡', '😱', '🥶', '😴', '🙈', '👍', '👎', '👏', '🙌', '💪', '🤝', '✌️', '🙏', '🐧', '❄️', '⛄', '🧊', '🔥', '🚀', '🏁', '🏆', '🥇', '🎉', '💥', '⭐', '❤️', '💙', '💨', '🎿'];
  Eco.pack = function (id) { for (var i = 0; i < Eco.PACKS.length; i++) if (Eco.PACKS[i].id === id) return Eco.PACKS[i]; return null; };
  Eco.hasPack = function (id) { var pk = Eco.pack(id); return !!pk && (pk.price === 0 || !!(D.stk && D.stk[id])); };
  Eco.buyPack = function (id) {
    var pk = Eco.pack(id); if (!pk) return { ok: false, msg: 'Paquete desconocido' };
    if (Eco.hasPack(id)) return { ok: false, msg: 'Ya lo tienes' };
    if (D.coins < pk.price) return { ok: false, msg: 'Te faltan ' + (pk.price - D.coins) + ' monedas' };
    D.coins -= pk.price; D.spent += pk.price; D.stk = D.stk || {}; D.stk[id] = 1; save(); refreshWallet();
    return { ok: true, msg: '¡Paquete «' + pk.name + '» desbloqueado!' };
  };
  // un sticker llega como "paquete:numero"; solo se aceptan los que existen
  Eco.stickerOf = function (code) {
    var a = String(code || '').split(':'), pk = Eco.pack(a[0]), i = a[1] | 0;
    return pk && pk.st[i] ? { pack: pk, e: pk.st[i][0], t: pk.st[i][1] } : null;
  };
  function blank() { return { coins: 0, earned: 0, spent: 0, inv: {}, load: [], stk: {} }; }
  var D = Eco.data = (G.store.get('pgp_eco', null)) || blank();
  (function () { var b = blank(); for (var k in b) if (D[k] === undefined) D[k] = b[k]; })();
  function save() { G.store.set('pgp_eco', D); }
  Eco.save = save;
  Eco.own = function (k) { return D.inv[k] | 0; };

  // recompensas
  Eco.comboCoins = function (n) { n = n | 0; return n <= 0 ? 0 : (n === 1 ? 2 : (n === 2 ? 6 : (n === 3 ? 12 : 12 + (n - 3) * 6))); };
  var PLACE_COINS = [60, 35, 20], PLACE_PTS = [10, 7, 5, 3, 2, 1];
  // estrellas de la carrera segun el rendimiento: terminar = 1, podio = 2, ganar = 3; con muchas piruetas (5+) sube una (maximo 3). Eliminado = 0
  Eco.starsFor = function (rank, total, tricks) {
    if (rank <= 0) return 0;
    var st = rank === 1 && total > 1 ? 3 : (rank <= 3 && total > 3 ? 2 : (total <= 1 ? 2 : 1));
    if ((tricks | 0) >= 5) st++;
    return Math.min(3, st);
  };
  // rank 0 = eliminado. rc = {combo, tricks}. Ingresa las monedas y devuelve el desglose.
  Eco.finishReward = function (rank, total, rc) {
    rc = rc || { combo: 0, tricks: 0 };
    var place = rank <= 0 ? 0 : (rank <= 3 ? PLACE_COINS[rank - 1] : 8);
    var pts = (rank <= 0 ? 0 : (PLACE_PTS[Math.min(5, rank - 1)] || 1)) + Math.floor((rc.tricks | 0) / 2);
    var rw = { combo: rc.combo | 0, place: place, coins: (rc.combo | 0) + place, points: pts, tricks: rc.tricks | 0, rank: rank, stars: Eco.starsFor(rank, total, rc.tricks) };
    D.coins += rw.coins; D.earned += rw.coins; save(); refreshWallet();
    return rw;
  };
  // compra / equipo
  Eco.buy = function (k) {
    var it = byK[k]; if (!it) return { ok: false, msg: 'Poder desconocido' };
    if (Eco.own(k) >= MAX) return { ok: false, msg: 'Inventario lleno (máx. ' + MAX + ')' };
    if (D.coins < it.price) return { ok: false, msg: 'Te faltan ' + (it.price - D.coins) + ' monedas' };
    D.coins -= it.price; D.spent += it.price; D.inv[k] = Eco.own(k) + 1; save(); refreshWallet();
    return { ok: true, msg: '¡Comprado!' };
  };
  Eco.toggleLoad = function (k) {
    var i = D.load.indexOf(k);
    if (i >= 0) { D.load.splice(i, 1); save(); return true; }
    if (!Eco.own(k) || D.load.length >= SLOTS) return false;
    D.load.push(k); save(); return true;
  };
  // al empezar la carrera: el equipo se gasta (1 unidad de cada uno)
  Eco.takeLoadout = function () {
    var out = [];
    D.load = D.load.filter(function (k) { return Eco.own(k) > 0; });
    D.load.forEach(function (k) { D.inv[k] = Eco.own(k) - 1; out.push(k); });
    D.load = D.load.filter(function (k) { return Eco.own(k) > 0; });
    save(); return out;
  };

  /* ---------- interfaz ---------- */
  var $ = G.$, esc = G.esc, armed = null, armT = 0;
  function refreshWallet() {
    var w = $('menuWallet'); if (w) w.textContent = '🪙 ' + D.coins + '   ⭐ ' + ((G.stats && G.stats.stars) | 0);
    var s = $('shopWallet'); if (s) s.textContent = '🪙 ' + D.coins;
  }
  Eco.refreshWallet = refreshWallet;
  function dots(n) { var h = ''; for (var i = 0; i < MAX; i++) h += '<i class="' + (i < n ? 'on' : '') + '"></i>'; return h; }
  Eco.renderShop = function () {
    refreshWallet();
    var slots = '';
    for (var i = 0; i < SLOTS; i++) {
      var k = D.load[i];
      slots += k ? '<button class="slotB full" data-act="shopEq" data-k="' + k + '" title="Quitar"><span class="ic">' + G.ICONS[k] + '</span><small>' + esc(PG.ITEM_NAMES[k]) + '</small></button>' : '<div class="slotB"><small>Vacío</small></div>';
    }
    $('shopLoad').innerHTML = '<div class="ldT"><b>Equipo inicial</b><small>Se usa al empezar la carrera (1 unidad de cada uno).</small></div><div class="ldS">' + slots + '</div>';
    var h = '';
    Eco.ITEMS.forEach(function (it) {
      var n = Eco.own(it.k), full = n >= MAX, can = D.coins >= it.price, eq = D.load.indexOf(it.k) >= 0, isArmed = armed === it.k;
      var buy = full ? '<button class="btn small" disabled>Lleno</button>' : '<button class="btn small ' + (can ? 'primary' : '') + '" data-act="shopBuy" data-k="' + it.k + '"' + (can ? '' : ' disabled') + '>' + (isArmed ? '¿Seguro?' : 'Comprar 🪙' + it.price) + '</button>';
      var equip = n ? '<button class="btn small ' + (eq ? 'sel' : '') + '" data-act="shopEq" data-k="' + it.k + '"' + (!eq && D.load.length >= SLOTS ? ' disabled' : '') + '>' + (eq ? 'Quitar' : 'Equipar') + '</button>' : '';
      h += '<div class="shopCard' + (n ? ' has' : '') + '"><div class="ic">' + G.ICONS[it.k] + '</div><div class="nm">' + esc(PG.ITEM_NAMES[it.k]) + '</div><div class="ds">' + esc(it.d) + '</div><div class="own"><span class="dots">' + dots(n) + '</span><small>' + n + '/' + MAX + '</small></div><div class="bt">' + buy + equip + '</div></div>';
    });
    $('shopGrid').innerHTML = h;
  };
  Eco.actions = {
    shop: function () { G.go('scrShop'); },
    shopBuy: function (el) {
      var k = el.dataset.k;
      if (armed !== k) { armed = k; clearTimeout(armT); armT = setTimeout(function () { armed = null; if (G.screen === 'scrShop') Eco.renderShop(); }, 2500); Eco.renderShop(); return; }
      armed = null; var r = Eco.buy(k); G.toast(r.msg); if (r.ok && PG.Audio) PG.Audio.sfx('ability'); Eco.renderShop();
    },
    shopEq: function (el) { Eco.toggleLoad(el.dataset.k); Eco.renderShop(); }
  };
  Eco.onScreen = function (id) { if (id === 'scrShop') { armed = null; Eco.renderShop(); } };
  refreshWallet();
})();
