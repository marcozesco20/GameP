/* Simulacion de carrera: fisica de deslizamiento, rampas/huecos, obstaculos, poderes y bots.
   No usa DOM ni WebGL (se puede ejecutar y probar en Node). */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var clamp = PG.clamp;

  var C = PG.CFG = {
    THRUST: 22, DRAG: 0.0145, GRIP: 2.0, BRAKE: 30, TURN: 2.05, G: 36, CENT: 0.42, BOOSTF: 15, RR: 0.8,
    JUMP: 12, FLIPW: 14, CANNON_T: 9, FIRE_CD: 0.3
  };
  PG.ITEMS = ['fish', 'snow', 'trap', 'shield'];
  PG.ABILITIES = ['tornado', 'wings', 'giant', 'cannon'];
  PG.ITEM_NAMES = { fish: 'Pez turbo', snow: 'Bola de nieve', trap: 'Trampa de hielo', shield: 'Escudo', tornado: 'Ventisca', wings: 'Alas de hielo', giant: 'Pingüino gigante', cannon: 'Cañón de nieve' };

  function Race(T, opts) {
    opts = opts || {};
    this.T = T; this.time = -3.5; this.racers = []; this.byId = {};
    this.proj = []; this.traps = []; this.out = []; this.fxq = []; this.tornados = [];
    this.pid = 0; this.seed = opts.seed || 1; this.rnd = PG.rng(this.seed);
    this.rnd2 = PG.rng((this.seed * 31 + 7) | 0);
    this.laps = T.laps; this.total = T.D;
    this.boxT = []; for (var i = 0; i < T.boxes.length; i++) this.boxT.push(0);
    this.crysT = []; for (i = 0; i < T.crys.length; i++) this.crysT.push(0);
    this.ko = {}; // obstaculos derribados localmente (indice -> hasta cuando)
    this.leaderU = 0; this.finishOrder = [];
    this.tmp = [0, 0];
  }
  PG.Race = Race;

  Race.prototype.addRacer = function (o) {
    var T = this.T, slot = o.slot || 0;
    var row = Math.floor(slot / 2), col = slot % 2;
    var r = {
      id: o.id, name: o.name || 'Pingüino', cfg: o.cfg || {}, own: !!o.own, bot: !!o.bot, local: !!o.local, slot: slot,
      u: -(7 + row * 5.5), d: (col ? 5.2 : -5.2), psi: 0, vf: 0, vl: 0, py: 0, vy: 0, grounded: true, overHole: false, gy: 0,
      lap: 0, finished: false, finishTime: 0, rank: slot + 1,
      fx: { boost: 0, pad: 0, spin: 0, shield: 0, giant: 0, wings: 0, ghost: 0, fall: 0, cannon: 0 },
      item: null, ability: null, charge: 0, meter: 40, holdBoost: false, hitCd: 0, padCd: 0,
      safeU: 0, safeD: 0, fell: false, fallT: 0, spinAng: 0, lean: 0, flap: 0, steerVis: 0,
      net: null, ai: null, auto: false, lastLand: 0, air: 0, wallHit: 0, speed: 0, falls: 0,
      fireCd: 0, jumpPrev: false, jumped: false, flipAcc: 0, flipMode: 0, flipping: false, flipDone: 0, flipDir: 1
    };
    if (T.type === 'sprint' && r.u < -T.startS + 4) r.u = -T.startS + 4;
    r.safeU = r.u; r.safeD = r.d;
    r.py = T.ground(T.uToS(r.u), r.d); r.gy = r.py;
    if (r.bot) {
      var rr = PG.rng((this.seed * 131 + slot * 977) | 0);
      r.ai = { lane: (rr() * 2 - 1) * 8, t: rr() * 10, ph: rr() * 6.28, skill: 0.90 + rr() * 0.10, useDelay: 1.5 + rr() * 3, rr: rr, inp: { steer: 0, tuck: 0, brake: 0, boost: false }, laneSm: 0 };
      r.ai.laneSm = r.d;
    }
    this.racers.push(r); this.byId[r.id] = r;
    return r;
  };
  Race.prototype.removeRacer = function (id) {
    var r = this.byId[id]; if (!r) return;
    this.racers.splice(this.racers.indexOf(r), 1); delete this.byId[id];
  };

  function emit(race, k, r, extra) { var e = { k: k, id: r ? r.id : null, r: r }; if (extra) for (var q in extra) e[q] = extra[q]; race.fxq.push(e); }

  /* ---------- golpes ---------- */
  function applyHit(race, r, kind) {
    var fx = r.fx;
    if (fx.ghost > 0) return false;
    if (fx.shield > 0) { fx.shield = 0; emit(race, 'shieldpop', r); return false; }
    if (fx.giant > 0) { if (kind !== 'soft' && kind !== 'pellet') r.vf *= 0.92; return false; }
    if (r.hitCd > 0) return false;
    r.hitCd = 0.5;
    if (kind === 'spin') { fx.spin = 1.3; r.vf *= 0.55; r.vl *= 0.5; }
    else if (kind === 'hard') { fx.spin = 1.7; r.vf *= 0.35; r.vl *= 0.3; }
    else if (kind === 'slip') { fx.spin = 1.0; r.vf *= 0.65; }
    else if (kind === 'soft') { r.vf *= 0.75; }
    else if (kind === 'pellet') { r.vf *= 0.86; r.vl *= 0.8; r.hitCd = 0.22; }
    if (kind !== 'soft' && kind !== 'pellet') { fx.boost = 0; fx.pad = 0; r.spinDir = r.rnd01 > 0.5 ? 1 : -1; r.spinAng = 0; }
    r.rnd01 = (r.rnd01 || 0.37) * 9.31 % 1;
    emit(race, 'hit', r, { kind: kind });
    return true;
  }
  PG.applyHit = applyHit;

  /* ---------- poderes ---------- */
  function pickWeighted(race, table) {
    var tot = 0, k; for (k in table) tot += table[k];
    var x = race.rnd2() * tot;
    for (k in table) { x -= table[k]; if (x <= 0) return k; }
    return 'fish';
  }
  function randomItem(race, r) {
    var n = race.racers.length, t;
    if (r.rank <= Math.ceil(n * 0.34)) t = { snow: 3, trap: 3, shield: 3, fish: 1 };
    else if (r.rank <= Math.ceil(n * 0.67)) t = { fish: 3, snow: 3, trap: 2, shield: 2 };
    else t = { fish: 5, snow: 3, shield: 1, trap: 1 };
    return pickWeighted(race, t);
  }
  Race.prototype.useItem = function (r) {
    if (!r.item || r.fell) return false;
    var it = r.item, T = this.T;
    if (it === 'fish') { r.fx.boost = 2.6; r.vf += 4; emit(this, 'boost', r); }
    else if (it === 'snow') {
      var p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 2.4, d: r.d, vu: Math.max(r.vf, 12) + 30, life: 3.4, age: 0 };
      this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu }); emit(this, 'throw', r);
    } else if (it === 'trap') {
      var tr = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u - 3.5, d: r.d, life: 25, age: 0 };
      this.traps.push(tr); this.out.push({ k: 'trap', id: tr.id, owner: tr.owner, u: tr.u, d: tr.d }); emit(this, 'throw', r);
    } else if (it === 'shield') { r.fx.shield = 10; emit(this, 'shield', r); }
    r.item = null; r.charge = 0;
    return true;
  };
  Race.prototype.useAbility = function (r) {
    if (!r.ability || r.fell) return false;
    var a = r.ability;
    if (a === 'tornado') {
      this.doTornado(r.id, r.u, r.d, true);
      this.out.push({ k: 'tornado', by: r.id, u: r.u, d: r.d });
    } else if (a === 'wings') { r.fx.wings = 5.5; r.fx.boost = Math.max(r.fx.boost, 1.6); emit(this, 'boost', r); emit(this, 'wings', r); }
    else if (a === 'giant') { r.fx.giant = 5; emit(this, 'giant', r); }
    else if (a === 'cannon') { r.fx.cannon = C.CANNON_T; r.fireCd = 0.2; emit(this, 'cannon', r); }
    r.ability = null;
    return true;
  };
  // disparo del canon de nieve (rafaga rapida de bolas pequenas)
  Race.prototype.fire = function (r) {
    if (r.fx.cannon <= 0 || r.fell || r.fireCd > 0) return false;
    r.fireCd = C.FIRE_CD;
    var p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 2.6, d: r.d, vu: Math.max(r.vf, 12) + 42, life: 2.0, age: 0, lt: 1 };
    this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu, lt: 1 });
    emit(this, 'shoot', r);
    return true;
  };
  Race.prototype.doTornado = function (byId, u, d) {
    this.tornados.push({ by: byId, u: u, d: d, t: 0, life: 1.6 });
    emit(this, 'tornado', this.byId[byId], { u: u });
    for (var i = 0; i < this.racers.length; i++) {
      var q = this.racers[i];
      if (!q.own || q.id === byId) continue;
      var du = q.u - u;
      if (du > -10 && du < 50) applyHit(this, q, 'hard');
    }
  };

  /* ---------- eventos de red recibidos ---------- */
  Race.prototype.applyEvent = function (e) {
    var i;
    if (e.k === 'proj') this.proj.push({ id: e.id, owner: e.owner, u: e.u, d: e.d, vu: e.vu, life: e.lt ? 2.0 : 3.4, age: 0, lt: e.lt || 0 });
    else if (e.k === 'trap') this.traps.push({ id: e.id, owner: e.owner, u: e.u, d: e.d, life: 25, age: 0 });
    else if (e.k === 'hit') {
      var list = e.pk === 'trap' ? this.traps : this.proj;
      for (i = 0; i < list.length; i++) if (list[i].id === e.id) { list.splice(i, 1); break; }
    } else if (e.k === 'tornado') this.doTornado(e.by, e.u, e.d);
    else if (e.k === 'fin') {
      var r = this.byId[e.r];
      if (r && !r.finished) { r.finished = true; r.finishTime = e.time; this.finishOrder.push(r.id); }
    }
  };

  /* ---------- paso de un pinguino propio ---------- */
  // Punto de reaparicion: siempre antes de cualquier hueco cercano (evita caer en bucle)
  function safeRespawnU(race, u) {
    var T = race.T, tries = 0, k, moved = true;
    while (moved && tries++ < 10) {
      moved = false;
      var s = T.uToS(u);
      for (k = 0; k < T.holes.length; k++) {
        var H = T.holes[k], ds0 = T.dS(s, H.s0), ds1 = T.dS(s, H.s1);
        if (ds1 > -8 && ds0 < 48) { u -= (48 - ds0); moved = true; break; }
      }
    }
    if (T.type === 'sprint') u = Math.max(u, -T.startS + 4);
    return u;
  }
  PG.safeRespawnU = safeRespawnU;
  function respawn(race, r) {
    var T = race.T;
    r.u = safeRespawnU(race, Math.min(r.safeU, r.u)); r.d = clamp(r.safeD * 0.4, -5, 5); r.psi = 0; r.vf = 12; r.vl = 0; r.vy = 0;
    r.py = T.ground(T.uToS(r.u), r.d); if (r.py < -1e8) r.py = T.centerY(T.uToS(r.u));
    r.gy = r.py; r.grounded = true; r.overHole = false; r.fell = false; r.air = 0; r.flip = 0; r.flipAcc = 0; r.jumpCd = 0;
    r.fx.ghost = 2.2; r.fx.spin = 0; r.fx.boost = 0; r.fx.pad = 0; r.fx.cannon = 0;
    emit(race, 'respawn', r);
  }

  function startFlip(r, steer, brake) {
    r.flipping = true; r.flipAcc = 0;
    if (steer > 0.35) { r.flipMode = 2; r.flipDir = 1; }
    else if (steer < -0.35) { r.flipMode = 2; r.flipDir = -1; }
    else if (brake > 0.4) { r.flipMode = 1; r.flipDir = -1; }
    else { r.flipMode = 1; r.flipDir = 1; }
  }
  function landTrick(race, r) {
    var n = r.flipDone;
    if (r.flipping && r.flipAcc > 4.4) n++;
    if (n > 0) {
      r.fx.boost = Math.max(r.fx.boost, 0.8 + 0.5 * n); r.meter = Math.min(100, r.meter + 22 * n); r.vf += 1.5 * n;
      emit(race, 'trick', r, { n: n });
    } else if (r.flipping && r.flipAcc > 1.0) {
      r.vf *= 0.88; emit(race, 'stumble', r);
    }
    r.flipping = false; r.flipAcc = 0; r.flipDone = 0; r.jumped = false;
  }

  function stepRacer(race, r, inp, dt) {
    var T = race.T, fx = r.fx, k;
    for (k in fx) if (fx[k] > 0) fx[k] = Math.max(0, fx[k] - dt);
    if (r.hitCd > 0) r.hitCd -= dt;
    if (r.padCd > 0) r.padCd -= dt;
    if (r.fireCd > 0) r.fireCd -= dt;

    if (r.fell) {
      r.flipping = false; r.flipAcc = 0; r.flipDone = 0; r.jumped = false;
      r.fallT -= dt;
      r.vy -= C.G * dt; r.py += r.vy * dt; r.vf *= Math.exp(-2 * dt);
      r.u += r.vf * dt;
      if (r.fallT <= 0) respawn(race, r);
      return;
    }

    var s = T.uToS(r.u), q = T.q(s), spinning = fx.spin > 0;
    var steer = inp.steer || 0, tuck = inp.tuck || 0, brake = inp.brake || 0;
    var cvq = q.cv, slq = q.sl;

    // impulso (medidor) - mantener Boost
    var holding = false;
    if (inp.boost && r.meter > 3 && !spinning) { holding = true; r.meter = Math.max(0, r.meter - 36 * dt); }
    r.holdBoost = holding;
    var boostOn = fx.boost > 0 || fx.pad > 0 || holding;

    // recarga del medidor segun deslizamiento
    if (r.grounded) r.meter = Math.min(100, r.meter + dt * (3 + Math.min(10, Math.abs(r.vl)) * 1.5 + (r.vf > 25 ? 2 : 0)));

    // recarga del objeto "pez"
    if (!r.item) { r.charge += dt / 15; if (r.charge >= 1) { r.item = 'fish'; r.charge = 0; emit(race, 'itemget', r); } }

    // salto y piruetas
    var jp = !!inp.jump, jedge = jp && !r.jumpPrev; r.jumpPrev = jp;
    if (jedge && !spinning) {
      if (r.grounded || (r.air < 0.12 && !r.jumped)) {
        r.vy = Math.max(r.vy, 0) + C.JUMP; r.grounded = false; r.jumped = true; r.air = Math.max(r.air, 0.001);
        emit(race, 'jump', r);
      } else if (!r.grounded && !r.flipping) startFlip(r, steer, brake);
    } else if (jp && !r.grounded && !r.flipping && r.air > 0.09 && r.flipDone === 0 && !spinning) {
      startFlip(r, steer, brake); // mantener el boton en el aire = voltereta automatica
    }

    if (r.grounded) {
      if (!spinning) {
        var tr = C.TURN * (1 - 0.35 * tuck) / (1 + Math.max(0, r.vf) * 0.012);
        r.psi = clamp(r.psi + steer * tr * dt, -1.35, 1.35);
      } else {
        r.spinAng += (r.spinDir || 1) * 14 * dt;
      }
      var cp = Math.cos(r.psi), sp = Math.sin(r.psi);
      var vpar = r.vf * cp + r.vl * sp, vperp = -r.vf * sp + r.vl * cp;
      var thrust = spinning ? 0 : C.THRUST * (1 + 0.1 * tuck) * (r.ai ? r.ai.skill * (r.ai.rubber || 1) : 1);
      if (boostOn) thrust += C.BOOSTF;
      if (fx.wings > 0) thrust += 6;
      var drag = C.DRAG * (1 - 0.25 * tuck) * (fx.giant > 0 ? 1.35 : 1);
      var a = thrust - drag * vpar * Math.abs(vpar);
      a += -C.G * slq * 0.85 * cp;
      vpar += a * dt;
      if (brake > 0) vpar = Math.max(vpar - C.BRAKE * brake * dt, Math.min(vpar, 4));
      if (spinning) vpar *= Math.exp(-1.3 * dt);
      var grip = spinning ? 0.7 : (C.GRIP + brake * 3.5);
      vperp *= Math.exp(-grip * dt);
      r.vf = vpar * cp - vperp * sp; r.vl = vpar * sp + vperp * cp;
      r.vl += -cvq * r.vf * r.vf * C.CENT * dt;
      r.steerVis += (steer - r.steerVis) * Math.min(1, dt * 10);
    } else {
      r.psi = clamp(r.psi + steer * 0.7 * dt, -1.35, 1.35);
      r.vf *= Math.exp(-0.03 * dt);
      if (spinning) r.spinAng += (r.spinDir || 1) * 10 * dt;
      r.air += dt;
      if (r.flipping) {
        r.flipAcc += C.FLIPW * dt;
        if (r.flipAcc >= 6.2832) {
          r.flipDone++; r.flipAcc = 0; r.flipping = false;
          emit(race, 'flip', r, { n: r.flipDone });
          if (jp) startFlip(r, steer, brake);
        }
      }
    }

    // movimiento
    r.u += r.vf * dt; r.d += r.vl * dt;
    var lim = T.W / 2 - 0.95;
    if (r.d > lim) { if (r.vl > 5) r.wallHit = 1; r.d = lim; if (r.vl > 0) r.vl = -r.vl * 0.3; r.vf *= (1 - 0.5 * dt); if (r.psi > 0.2) r.psi -= 0.8 * dt; }
    else if (r.d < -lim) { if (r.vl < -5) r.wallHit = 1; r.d = -lim; if (r.vl < 0) r.vl = -r.vl * 0.3; r.vf *= (1 - 0.5 * dt); if (r.psi < -0.2) r.psi += 0.8 * dt; }
    if (r.wallHit > 0) { emit(race, 'wall', r); r.wallHit = 0; }
    if (T.type === 'sprint') {
      var sEnd = T.L - 8, sNow = r.u + T.startS;
      if (sNow > sEnd) { r.u = sEnd - T.startS; r.vf *= Math.exp(-6 * dt); }
      if (sNow < 2 && r.u < 0) { r.u = 2 - T.startS; if (r.vf < 0) r.vf = 0; }
    }

    // vertical
    var s2 = T.uToS(r.u), g2 = T.ground(s2, r.d), wasGrounded = r.grounded;
    r.vy -= C.G * (fx.wings > 0 ? 0.3 : 1) * dt;
    r.py += r.vy * dt;
    if (g2 > T.NOGROUND / 2) {
      if (r.py <= g2) {
        if (r.overHole && r.py < g2 - 0.7) { // choco con el borde del hueco
          r.fell = true; r.fallT = 1.4; r.vy = Math.min(r.vy, -2); r.falls++; emit(race, 'fall', r);
          return;
        }
        var impact = -r.vy;
        r.py = g2;
        r.vy = clamp((g2 - r.gy) / dt, -22, 28);
        if (!wasGrounded && r.air > 0.25) emit(race, 'land', r, { impact: impact });
        if (!wasGrounded) landTrick(race, r);
        r.grounded = true; r.air = 0; r.overHole = false;
      } else { r.grounded = false; }
      r.gy = g2;
    } else {
      r.grounded = false; r.overHole = true;
    }
    if (r.py < T.centerY(s2) - 6 && !r.fell) { r.fell = true; r.fallT = 1.2; r.falls++; emit(race, 'fall', r); return; }

    // punto seguro (antes de huecos)
    if (r.grounded) {
      var safe = true;
      for (k = 0; k < T.holes.length; k++) {
        var H = T.holes[k], ds0 = T.dS(s2, H.s0), ds1 = T.dS(s2, H.s1);
        if (ds1 > -8 && ds0 < 48) { safe = false; break; }
      }
      if (safe) { r.safeU = r.u - 2; r.safeD = r.d; }
    }

    // pads de impulso
    if (r.grounded && r.padCd <= 0) {
      for (k = 0; k < T.pads.length; k++) {
        var P = T.pads[k], dp = T.dS(P.s, s2);
        if (dp >= 0 && dp <= P.len && r.d >= P.d0 && r.d <= P.d1) { fx.pad = 1.5; r.vf += 3; r.padCd = 1.0; emit(race, 'pad', r); break; }
      }
    }
    // cajas de objeto
    if (r.rank !== undefined && !r.finished) {
      for (k = 0; k < T.boxes.length; k++) {
        if (race.boxT[k] > race.time) continue;
        var B = T.boxes[k], db = T.dS(s2, B.s);
        if (db > -2.4 && db < 2.4 && Math.abs(B.d - r.d) < 2.4 && r.py - r.gy < 3) {
          race.boxT[k] = race.time + 5;
          if (!r.item) { r.item = randomItem(race, r); r.charge = 0; emit(race, 'itemget', r, { item: r.item }); }
          else emit(race, 'boxbreak', r);
        }
      }
      for (k = 0; k < T.crys.length; k++) {
        if (race.crysT[k] > race.time) continue;
        var Cr = T.crys[k], dcs = T.dS(s2, Cr.s);
        if (dcs > -3 && dcs < 3 && Math.abs(Cr.d - r.d) < 3 && r.py - r.gy < 3) {
          race.crysT[k] = race.time + 14;
          if (!r.ability) { r.ability = PG.ABILITIES[Math.floor(race.rnd2() * PG.ABILITIES.length)]; emit(race, 'abilityget', r, { ability: r.ability }); }
        }
      }
    }
    // obstaculos
    if (!r.finished) {
      var pos = race.tmp;
      for (k = 0; k < T.obs.length; k++) {
        var o = T.obs[k];
        if (race.ko[k] && race.ko[k] > race.time) continue;
        PG.obsPos(T, o, race.time, pos);
        var ds1 = T.dS(s2, pos[0]);
        if (ds1 > 4 || ds1 < -4) continue;
        var dd1 = r.d - pos[1], rr = o.r + C.RR;
        if (ds1 * ds1 + dd1 * dd1 < rr * rr && r.py - r.gy < 1.6 && r.hitCd <= 0) {
          var sgn = dd1 >= 0 ? 1 : -1;
          if (fx.giant > 0) { race.ko[k] = race.time + 8; emit(race, 'smash', r); r.vf *= 0.95; continue; }
          if (o.hit === 'snowman') { race.ko[k] = race.time + 6; r.vf *= 0.72; r.vy = 5; r.grounded = false; r.hitCd = 0.4; emit(race, 'smash', r); }
          else if (o.hit === 'seal') { r.vl += sgn * 9; applyHit(race, r, 'slip'); }
          else if (o.hit === 'ball') { r.vl += sgn * 6; applyHit(race, r, 'hard'); }
          else { r.vl += sgn * 7; if (applyHit(race, r, o.hit === 'ice' ? 'spin' : 'hard') === false && fx.shield <= 0 && fx.ghost <= 0) { /* gigante */ } }
        }
      }
    }
    // vueltas y meta
    if (T.type === 'circuit') r.lap = r.u < 0 ? 0 : Math.min(race.laps, Math.floor(r.u / T.L) + 1);
    var endU = T.type === 'circuit' ? race.laps * T.L : T.D;
    if (!r.finished && r.u >= endU) {
      r.finished = true; r.finishTime = race.time; r.auto = true; race.finishOrder.push(r.id);
      race.out.push({ k: 'fin', r: r.id, time: r.finishTime });
      emit(race, 'finish', r);
    }
    r.speed = Math.sqrt(r.vf * r.vf + r.vl * r.vl);
  }
  PG.stepRacer = stepRacer;

  /* ---------- actualizacion del mundo ---------- */
  Race.prototype.update = function (dt, localInput) {
    var T = this.T, i, r;
    if (this.time < 0) { this.updateRanks(); return; }
    for (i = 0; i < this.racers.length; i++) {
      r = this.racers[i];
      if (r.own) {
        var inp;
        if (r.bot || r.auto) inp = PG.aiInput(this, r, dt);
        else inp = localInput || { steer: 0 };
        if (r.local && !r.auto && localInput) {
          if (localInput.useItem) { this.useItem(r); }
          if (localInput.useAbility) { this.useAbility(r); }
          if (localInput.fire) this.fire(r);
        } else if (r.bot && inp.useItem) this.useItem(r);
        if (r.bot && inp.fire) this.fire(r);
        if (r.bot && inp.useAbility) this.useAbility(r);
        stepRacer(this, r, inp, dt);
      } else this.updateRemote(r, dt);
    }
    this.stepWorld(dt);
    this.collide(dt);
    this.updateRanks();
  };

  Race.prototype.updateRemote = function (r, dt) {
    var n = r.net, T = this.T;
    for (var k in r.fx) if (r.fx[k] > 0) r.fx[k] = Math.max(0, r.fx[k] - dt);
    if (!n) return;
    var age = clamp((this.nowMs - n.t) / 1000, 0, 0.35), f = Math.min(1, dt * 12);
    var tu = n.u + n.vf * age;
    if (Math.abs(tu - r.u) > 25) r.u = tu; else r.u += (tu - r.u) * f;
    r.d += (n.d - r.d) * f;
    r.psi += PG.angDiff(r.psi, n.psi) * f;
    r.vf = n.vf; r.vl = n.vl || 0;
    var wasG = r.grounded;
    r.py += (n.y - r.py) * Math.min(1, dt * 14);
    r.grounded = !!(n.x & 64);
    r.fell = !!(n.x & 32);
    var x = n.x;
    r.fx.boost = (x & 1) ? 0.2 : 0; r.fx.spin = (x & 2) ? 0.2 : 0; r.fx.shield = (x & 4) ? 0.2 : 0;
    r.fx.giant = (x & 8) ? 0.2 : 0; r.fx.wings = (x & 16) ? 0.2 : 0; r.fx.ghost = (x & 128) ? 0.2 : 0; r.fx.cannon = (x & 256) ? 0.2 : 0;
    var fm = n.fm || 0, fl = n.fl || 0;
    if (fm) {
      r.flipping = true; r.flipMode = Math.abs(fm); r.flipDir = fm < 0 ? -1 : 1;
      if (fl < r.flipAcc - 3) r.flipAcc = fl;
      r.flipAcc += ((fl + C.FLIPW * Math.min(age, 0.1)) - r.flipAcc) * Math.min(1, dt * 20);
    } else { r.flipping = false; r.flipAcc = 0; }
    if (r.fx.spin > 0) r.spinAng += (r.spinDir || 1) * 14 * dt;
    r.lap = n.lap || 0; r.speed = Math.abs(r.vf);
    r.item = n.it || null;
    r.steerVis += (((n.st || 0)) - r.steerVis) * Math.min(1, dt * 8);
    if (r.gy === undefined) r.gy = r.py;
    r.gy = T.ground(T.uToS(r.u), r.d); if (r.gy < -1e8) r.gy = r.py;
  };

  Race.prototype.stepWorld = function (dt) {
    var i, j, p, r, T = this.T;
    for (i = this.proj.length - 1; i >= 0; i--) {
      p = this.proj[i]; p.age += dt; p.life -= dt;
      // seguimiento suave al rival mas cercano por delante
      var best = null, bd = 50;
      for (j = 0; j < this.racers.length; j++) {
        r = this.racers[j];
        if (r.id === p.owner) continue;
        var du = r.u - p.u;
        if (du > 2 && du < bd) { bd = du; best = r; }
      }
      var vd = 0; if (best) vd = clamp((best.d - p.d) * (p.lt ? 2.2 : 1.6), -9, 9);
      p.d = clamp(p.d + vd * dt, -T.W / 2 + 1, T.W / 2 - 1);
      p.u += p.vu * dt;
      var hit = false;
      for (j = 0; j < this.racers.length && !hit; j++) {
        r = this.racers[j];
        if (!r.own || r.id === p.owner || r.fell) continue;
        if (Math.abs(r.u - p.u) < 1.8 && Math.abs(r.d - p.d) < 1.5) { applyHit(this, r, p.lt ? 'pellet' : 'spin'); hit = true; }
      }
      if (hit) { this.out.push({ k: 'hit', pk: 'proj', id: p.id }); emit(this, 'splat', null, { u: p.u, d: p.d }); this.proj.splice(i, 1); }
      else if (p.life <= 0) this.proj.splice(i, 1);
    }
    for (i = this.traps.length - 1; i >= 0; i--) {
      p = this.traps[i]; p.age += dt; p.life -= dt;
      var thit = false;
      for (j = 0; j < this.racers.length && !thit; j++) {
        r = this.racers[j];
        if (!r.own || r.fell) continue;
        if (r.id === p.owner && p.age < 1.2) continue;
        if (Math.abs(r.u - p.u) < 1.7 && Math.abs(r.d - p.d) < 1.6 && r.py - r.gy < 1.5) { applyHit(this, r, 'slip'); thit = true; }
      }
      if (thit) { this.out.push({ k: 'hit', pk: 'trap', id: p.id }); this.traps.splice(i, 1); }
      else if (p.life <= 0) this.traps.splice(i, 1);
    }
    for (i = this.tornados.length - 1; i >= 0; i--) { this.tornados[i].t += dt; if (this.tornados[i].t > this.tornados[i].life) this.tornados.splice(i, 1); }
  };

  Race.prototype.collide = function (dt) {
    var i, j, a, b;
    for (i = 0; i < this.racers.length; i++) {
      a = this.racers[i]; if (!a.own || a.fell) continue;
      for (j = 0; j < this.racers.length; j++) {
        if (i === j) continue; b = this.racers[j]; if (b.fell) continue;
        var du = a.u - b.u, dd = a.d - b.d;
        if (Math.abs(du) < 1.7 && Math.abs(dd) < 1.4 && Math.abs(a.py - b.py) < 1.3) {
          var sg = dd >= 0 ? 1 : -1; if (dd === 0) sg = (i < j) ? 1 : -1;
          a.d += sg * 0.9 * dt * 6; a.vl += sg * 5 * dt * 10 * 0.3;
          if (a.vf > b.vf) a.vf -= (a.vf - b.vf) * 0.5 * dt * 3;
          if (a.fx.giant > 0 && b.fx.giant <= 0 && b.fx.ghost <= 0) { if (b.own) applyHit(this, b, 'spin'); }
          if (b.fx.giant > 0 && a.fx.giant <= 0) applyHit(this, a, 'spin');
        }
      }
    }
  };

  Race.prototype.updateRanks = function () {
    var arr = this.racers.slice(), self = this;
    arr.sort(function (a, b) {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1; if (b.finished) return 1;
      return b.u - a.u;
    });
    var lead = -1e9;
    for (var i = 0; i < arr.length; i++) { arr[i].rank = i + 1; if (arr[i].u > lead) lead = arr[i].u; }
    this.leaderU = lead; this.order = arr;
  };

  /* ---------- IA de los bots ---------- */
  var AI_INP = null;
  PG.aiInput = function (race, r, dt) {
    var T = race.T, ai = r.ai;
    if (!ai) { // piloto automatico de un jugador que ya termino
      ai = r.ai = { lane: 0, t: 0, ph: 0, skill: 1, useDelay: 99, rr: PG.rng(5), inp: { steer: 0, tuck: 0, brake: 0, boost: false }, laneSm: r.d };
    }
    var inp = ai.inp; inp.useItem = false; inp.useAbility = false; inp.boost = false; inp.brake = 0; inp.tuck = 0.2; inp.jump = false; inp.fire = false;
    ai.t += dt;
    var s = T.uToS(r.u), look = 14 + Math.max(r.vf, 10) * 0.6, i, W2 = T.W / 2 - 3;
    var lane = ai.lane + Math.sin(ai.t * 0.35 + ai.ph) * 2.2;
    var haz = [], pos = race.tmp, o, H, ds;
    for (i = 0; i < T.obs.length; i++) {
      o = T.obs[i];
      if (race.ko[i] && race.ko[i] > race.time) continue;
      PG.obsPos(T, o, race.time + 0.35, pos);
      ds = T.dS(s, pos[0]);
      if (ds > -2 && ds < look + 10) haz.push([pos[1] - o.r - 1.5, pos[1] + o.r + 1.5]);
    }
    var needRamp = false;
    for (i = 0; i < T.holes.length; i++) {
      H = T.holes[i]; ds = T.dS(s, H.s0);
      if (ds > -4 && ds < look + 100) {
        if (H.mode === 'full') needRamp = true;
        else haz.push([H.d0 - 2.2, H.d1 + 2.2]);
      }
    }
    var target = clamp(lane, -W2, W2);
    function free(d) { for (var q = 0; q < haz.length; q++) if (d > haz[q][0] && d < haz[q][1]) return false; return true; }
    if (needRamp) target = 0;
    else {
      // pads y cajas
      var bestD = null, bs = 55;
      for (i = 0; i < T.pads.length; i++) {
        var P = T.pads[i]; ds = T.dS(s, P.s);
        if (ds > 4 && ds < bs && Math.abs((P.d0 + P.d1) / 2 - target) < 9 && free((P.d0 + P.d1) / 2)) { bs = ds; bestD = (P.d0 + P.d1) / 2; }
      }
      if (bestD === null) {
        bs = 45;
        for (i = 0; i < T.boxes.length; i++) {
          if (race.boxT[i] > race.time) continue;
          var B = T.boxes[i]; ds = T.dS(s, B.s);
          if (ds > 6 && ds < bs && Math.abs(B.d - target) < 8 && free(B.d)) { bs = ds; bestD = B.d; }
        }
      }
      if (bestD !== null && ai.skill > 0.92) target = bestD;
      if (!free(target)) {
        var cands = [3, -3, 6, -6, 9, -9, 12, -12, 0], found = false;
        for (i = 0; i < cands.length; i++) { var cd = clamp(target + cands[i], -W2, W2); if (free(cd)) { target = cd; found = true; break; } }
        if (!found) { target = 0; inp.brake = 0.35; }
      }
    }
    ai.laneSm += (target - ai.laneSm) * Math.min(1, dt * 4);
    var tgt = ai.laneSm;
    var vf = Math.max(r.vf, 12);
    var want = Math.atan2(clamp((tgt - r.d) * 1.3, -12, 12) - r.vl * 0.5, vf);
    var q = T.q(s);
    want += q.cv * vf * 0.30 * (C.CENT / 0.42);
    inp.steer = clamp((want - r.psi) * 3.0, -1, 1);
    if (!r.grounded) inp.steer = clamp(-r.psi * 2, -1, 1);

    // impulso
    if (Math.abs(inp.steer) < 0.3 && r.meter > 45 && free(r.d) && !needRamp) inp.boost = true;
    if (r.meter > 15 && r.holdBoost && Math.abs(inp.steer) < 0.35) inp.boost = true;
    // elastico (bots lentos sin ayuda cuando el humano esta lejos, sin trampas grandes)
    var gap = race.leaderU - r.u;
    ai.rubber = 1 + clamp(gap / 500, -0.03, 0.07);
    // terminado: frenar suave en sprint
    if (r.finished) {
      inp.boost = false; inp.steer = clamp((0 - r.d) * 0.1 - r.psi * 2, -1, 1);
      if (T.type === 'sprint' && r.u > T.D + 20) inp.brake = 0.7;
      else inp.tuck = 0;
    }
    // objetos
    if (!r.finished && r.item) {
      ai.useDelay -= dt;
      if (ai.useDelay <= 0) {
        var use = false, k;
        if (r.item === 'fish') use = Math.abs(inp.steer) < 0.3;
        else if (r.item === 'shield') use = true;
        else if (r.item === 'snow') { for (k = 0; k < race.racers.length; k++) { var b = race.racers[k]; if (b !== r && b.u - r.u > 4 && b.u - r.u < 50 && Math.abs(b.d - r.d) < 6) use = true; } }
        else if (r.item === 'trap') { for (k = 0; k < race.racers.length; k++) { var b2 = race.racers[k]; if (b2 !== r && r.u - b2.u > 2 && r.u - b2.u < 30 && Math.abs(b2.d - r.d) < 7) use = true; } }
        if (use) { inp.useItem = true; ai.useDelay = 1.5 + ai.rr() * 3; }
      }
    }
    // piruetas de los bots al saltar por rampas
    if (!r.grounded && !ai.inAir) { ai.inAir = true; var holeNear = false; for (i = 0; i < T.holes.length; i++) { var hd = T.dS(s, T.holes[i].s0); if (hd > -6 && hd < 170) holeNear = true; } ai.flipPlan = !holeNear && r.vy > 5 && ai.rr() < 0.6; ai.flipAt = 0.16 + ai.rr() * 0.12; }
    else if (r.grounded) ai.inAir = false;
    if (ai.inAir && ai.flipPlan && r.air > ai.flipAt && r.air < 0.9) inp.jump = true;
    // canon: dispara a quien tenga delante
    if (r.fx.cannon > 0 && !r.finished) {
      for (k = 0; k < race.racers.length; k++) { var bt = race.racers[k]; if (bt !== r && bt.u - r.u > 5 && bt.u - r.u < 60 && Math.abs(bt.d - r.d) < 8) { inp.fire = true; break; } }
    }
    if (!r.finished && r.ability) {
      var ua = false, k2;
      if (r.ability === 'cannon') { for (k2 = 0; k2 < race.racers.length; k2++) { var b4 = race.racers[k2]; if (b4 !== r && b4.u - r.u > 8 && b4.u - r.u < 55) ua = true; } }
      else if (r.ability === 'tornado') { for (k2 = 0; k2 < race.racers.length; k2++) { var b3 = race.racers[k2]; if (b3 !== r && b3.u - r.u > -4 && b3.u - r.u < 35) ua = true; } }
      else ua = ai.rr() < 0.02;
      if (ua) inp.useAbility = true;
    }
    return inp;
  };
})();
