/* Simulacion de carrera: fisica de deslizamiento, rampas/huecos, obstaculos, poderes y bots.
   No usa DOM ni WebGL (se puede ejecutar y probar en Node). */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var clamp = PG.clamp;

  var C = PG.CFG = {
    THRUST: 22, DRAG: 0.0145, GRIP: 2.7, BRAKE: 30, TURN: 3.1, TURNSPD: 0.0075, G: 36, CENT: 0.2, BOOSTF: 15, RR: 0.8,
    JUMP: 12, FLIPW: 14, CANNON_T: 9, GREN_T: 13, FIRE_CD: 0.3, GREN_CD: 1.0, PUSH_CD: 1.0, RESPAWN_ORB: 7, MAX_ABIL: 3, KO_T: 12, SJ_T: 9, SJ_V: 21, SMASH_ICE: 19, SMASH_ROCK: 25
  };
  PG.DIFFS = ['Fácil', 'Normal', 'Difícil', 'Extremo'];
  PG.ITEMS = ['fish', 'snow', 'trap', 'shield'];
  PG.ABILITIES = ['tornado', 'wings', 'cannon', 'grenade', 'megaball', 'quake', 'ghost', 'superjump', 'missile'];
  PG.COMMON = ['snow', 'trap', 'shield', 'hyper']; // poderes de las esferas azules (van a la misma cola de habilidades)
  PG.ITEM_NAMES = { fish: 'Turbo', hyper: 'Turbo máximo', missile: 'Misil teledirigido', snow: 'Bola de nieve', trap: 'Trampa de hielo', shield: 'Escudo', tornado: 'Ventisca', wings: 'Alas de hielo', cannon: 'Cañón de nieve', grenade: 'Cañón de granadas', megaball: 'Mega bola', quake: 'Terremoto', ghost: 'Fantasma', superjump: 'Súper salto' };
  PG.icicleState = function (o, t) { // fases: 0 colgando, 1 aviso (tiembla), 2 cayendo, 3 se rompe, 4 ausente
    var tt = (t + o.ph) % o.per; if (tt < 0) tt += o.per;
    if (tt >= o.per - 1.4 && tt < o.per - 0.45) return { ph: 1, f: (tt - (o.per - 1.4)) / 0.95 };
    if (tt >= o.per - 0.45) return { ph: 2, f: (tt - (o.per - 0.45)) / 0.45 };
    if (tt < 0.4) return { ph: 3, f: tt / 0.4 };
    if (tt < 1.4) return { ph: 4, f: 0 };
    return { ph: 0, f: 0 };
  };
  PG.icicleActive = function (o, t) { var st = PG.icicleState(o, t); return (st.ph === 2 && st.f > 0.9) || st.ph === 3; };

  function Race(T, opts) {
    opts = opts || {};
    this.T = T; this.time = -3.5; this.racers = []; this.byId = {};
    this.proj = []; this.traps = []; this.out = []; this.fxq = []; this.tornados = [];
    this.pid = 0; this.seed = opts.seed || 1; this.rnd = PG.rng(this.seed);
    this.rnd2 = PG.rng((this.seed * 31 + 7) | 0);
    this.laps = T.laps; this.total = T.D;
    this.boxT = []; for (var i = 0; i < T.boxes.length; i++) this.boxT.push(0);
    this.crysT = []; for (i = 0; i < T.crys.length; i++) this.crysT.push(0);
    this.ko = {}; // obstaculos derribados localmente (indice -> hasta cuando)
    this.leaderU = 0; this.finishOrder = [];
    this.tmp = [0, 0]; this.diff = opts.diff === undefined ? 1 : opts.diff | 0;
    // avalancha (determinista por semilla: todos los jugadores la ven igual)
    var ra = PG.rng((this.seed * 131 + 17) | 0), want = opts.avalanche !== false;
    var roll = ra(), tW = 12 + ra() * 14, vA = 34.5 + ra() * 3;
    this.av = null;
    if (want && (opts.avForce || roll < (opts.avProb === undefined ? 0.4 : opts.avProb))) {
      var tGo = tW + 6;
      this.av = { tW: tW, tGo: tGo, u0: Math.max(-10, 27 * tGo - 200), v: vA, acc: 0.1 };
    }
  }
  // posicion (u) del frente de la avalancha, o -1e9 si aun no avanza
  Race.prototype.avFront = function (t) {
    var a = this.av; if (!a || t < a.tGo) return -1e9;
    var x = t - a.tGo; return a.u0 + a.v * x + 0.5 * a.acc * x * x;
  };
  // 0 = sin avalancha, 1 = aviso, 2 = activa
  Race.prototype.avPhase = function (t) { var a = this.av; if (!a || t < a.tW) return 0; return t < a.tGo ? 1 : 2; };
  PG.Race = Race;

  Race.prototype.addRacer = function (o) {
    var T = this.T, slot = o.slot || 0;
    var row = Math.floor(slot / 2), col = slot % 2;
    var r = {
      id: o.id, name: o.name || 'Pingüino', cfg: o.cfg || {}, own: !!o.own, bot: !!o.bot, local: !!o.local, slot: slot,
      u: -(7 + row * 5.5), d: (col ? 5.2 : -5.2), psi: 0, vf: 0, vl: 0, py: 0, vy: 0, grounded: true, overHole: false, gy: 0,
      lap: 0, finished: false, finishTime: 0, rank: slot + 1,
      fx: { boost: 0, pad: 0, spin: 0, shield: 0, wings: 0, ghost: 0, fall: 0, cannon: 0, push: 0, superjump: 0, hyper: 0 },
      item: null, daze: 0, stunCd: 0, ability: null, abilityQ: [], gun: 'pellet', gunT: 9, bankRoll: 0, charge: 0, meter: 0, holdBoost: false, hitCd: 0, padCd: 0, pushCd: 0, aim: 1, aimV: 1, pushDir: 0,
      bonkCd: 0, safeU: 0, safeD: 0, fell: false, fallT: 0, spinAng: 0, lean: 0, flap: 0, steerVis: 0,
      net: null, ai: null, auto: false, lastLand: 0, air: 0, wallHit: 0, speed: 0, falls: 0,
      fireCd: 0, sjCd: 0, jumpPrev: false, jumped: false, flipAcc: 0, flipMode: 0, flipping: false, flipDone: 0, flipDir: 1
    };
    if (T.type === 'sprint' && r.u < -T.startS + 4) r.u = -T.startS + 4;
    r.safeU = r.u; r.safeD = r.d;
    r.py = T.ground(T.uToS(r.u), r.d); r.gy = r.py;
    if (r.bot) {
      var rr = PG.rng((this.seed * 131 + slot * 977) | 0);
      var DF = [0.88, 0.945, 0.99, 1.04][this.diff] || 0.945;
      r.ai = { diff: this.diff, lane: (rr() * 2 - 1) * 8, t: rr() * 10, ph: rr() * 6.28, skill: (0.92 + rr() * 0.08) * (DF / 0.945), aggr: 0.25 + rr() * 0.75, greed: 0.5 + rr() * 0.8, trick: 0.3 + rr() * 0.6, useDelay: 1.0 + rr() * 2.5, rr: rr, inp: { steer: 0, tuck: 0, brake: 0 }, laneSm: 0, target: 0, think: 0, jumpCd: 0, pushThink: 0, rubber: 1 };
      r.ai.laneSm = r.d;
    }
    this.racers.push(r); this.byId[r.id] = r;
    return r;
  };
  Race.prototype.removeRacer = function (id) {
    var r = this.byId[id]; if (!r) return;
    this.racers.splice(this.racers.indexOf(r), 1); delete this.byId[id];
  };

  function emit(race, k, r, extra) { var e = { k: k, id: r ? r.id : null, r: r }; if (extra) for (var q in extra) e[q] = extra[q]; race.fxq.push(e); }

  /* ---------- golpes ---------- */
  function applyHit(race, r, kind) {
    var fx = r.fx;
    if (r.dead) return false;
    if (fx.ghost > 0) return false;
    if (fx.shield > 0) { fx.shield = 0; emit(race, 'shieldpop', r); return false; }
    if (r.hitCd > 0) return false;
    r.hitCd = 0.5;
    if (kind === 'spin') { fx.spin = 1.3; r.vf *= 0.55; r.vl *= 0.5; }
    else if (kind === 'hard') { fx.spin = 1.7; r.vf *= 0.35; r.vl *= 0.3; }
    else if (kind === 'slip') { fx.spin = 1.0; r.vf *= 0.65; }
    else if (kind === 'soft') { r.vf *= 0.75; }
    else if (kind === 'snow') { r.vf *= 0.68; r.vl *= 0.8; r.hitCd = 0.35; r.daze += 1.5; }
    else if (kind === 'pellet') { r.vf *= 0.86; r.vl *= 0.8; r.hitCd = 0.22; r.daze += 1; }
    var stunned = false;
    if ((kind === 'snow' || kind === 'pellet') && r.daze >= 3.2 && r.stunCd <= 0) { // muchos impactos de nieve: aturdido un momento
      stunned = true; r.daze = 0; r.stunCd = 4; fx.spin = 1.0; r.vf *= 0.55; kind = 'stun'; emit(race, 'stun', r);
    }
    if (stunned || (kind !== 'soft' && kind !== 'pellet' && kind !== 'snow')) { fx.boost = 0; fx.pad = 0; r.spinDir = r.rnd01 > 0.5 ? 1 : -1; r.spinAng = 0; }
    r.rnd01 = (r.rnd01 || 0.37) * 9.31 % 1;
    emit(race, 'hit', r, { kind: kind });
    return true;
  }
  PG.applyHit = applyHit;

  /* ---------- poderes ---------- */
  // un mismo poder no puede repetirse mas de 2 veces: ni 3 seguidos, ni 3 a la vez en la cola
  function allowedAb(r, k) {
    var n = (r.ability === k ? 1 : 0), i;
    for (i = 0; i < r.abilityQ.length; i++) if (r.abilityQ[i] === k) n++;
    if (n >= 2) return false;
    var h = r.abHist || [];
    return !(h.length >= 2 && h[h.length - 1] === k && h[h.length - 2] === k);
  }
  function pickWeighted(race, table, r) {
    if (r) { var f = {}, any = false, kk; for (kk in table) if (allowedAb(r, kk)) { f[kk] = table[kk]; any = true; } if (any) table = f; }
    var tot = 0, k; for (k in table) tot += table[k];
    var x = race.rnd2() * tot;
    for (k in table) { x -= table[k]; if (x <= 0) return k; }
    return 'fish';
  }
  function randomItem(race, r) { // esferas azules: bola de nieve, trampa, escudo y turbo maximo (mas probable si vas muy atras)
    var n = race.racers.length, t;
    if (r.rank <= Math.ceil(n * 0.34)) t = { snow: 4, trap: 3, shield: 3, hyper: 0.3 };
    else if (r.rank <= Math.ceil(n * 0.67)) t = { snow: 3, trap: 2, shield: 2, hyper: 1.2 };
    else t = { snow: 2, trap: 1, shield: 2, hyper: 5 };
    return pickWeighted(race, t, r);
  }
  // turbo (se recarga solo)
  Race.prototype.useItem = function (r, aim) {
    if (!r.item || r.fell) return false;
    r.aim = aim < 0 ? -1 : 1;
    r.fx.boost = Math.max(r.fx.boost, 2.6); r.vf += 4; emit(this, 'boost', r);
    r.item = null; r.charge = 0;
    return true;
  };
  // proyectil pequeno / trampa / escudo / turbo maximo (ahora son habilidades de la cola)
  Race.prototype.useCommon = function (r, a, aim) {
    r.aim = aim;
    if (a === 'snow') {
      var vu = aim > 0 ? Math.max(r.vf, 12) + 30 : Math.min(r.vf - 46, -14);
      var p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 2.4 * aim, d: r.d, vu: vu, life: 3.4, age: 0, dir: aim, mine: true, h: 0.8, hm: 1 };
      this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu, dir: aim, hm: 1 }); emit(this, 'throw', r, { aim: aim });
    } else if (a === 'trap') {
      var tr = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + (aim > 0 ? 26 : -3.5), d: r.d, life: 25, age: 0 };
      this.traps.push(tr); this.out.push({ k: 'trap', id: tr.id, owner: tr.owner, u: tr.u, d: tr.d }); emit(this, 'throw', r);
    } else if (a === 'shield') { r.fx.shield = 10; emit(this, 'shield', r); }
    else if (a === 'hyper') { r.fx.boost = Math.max(r.fx.boost, 3.2); r.fx.hyper = 3.2; r.vf += 7; emit(this, 'boost', r, { hyper: true }); }
  };
  function pickAbility(race, r) {
    var n = race.racers.length, t;
    if (r.rank <= Math.ceil(n * 0.34)) t = { tornado: 2, wings: 1, cannon: 2, grenade: 2, megaball: 1, quake: 2, ghost: 2, superjump: 2, missile: 0.6 };
    else if (r.rank <= Math.ceil(n * 0.67)) t = { tornado: 2, wings: 2, cannon: 2, grenade: 2, megaball: 2, quake: 2, ghost: 2, superjump: 2, missile: 2 };
    else t = { tornado: 2, wings: 3, cannon: 2, grenade: 3, megaball: 4, quake: 2, ghost: 2, superjump: 2, missile: 3 };
    return pickWeighted(race, t, r);
  }
  Race.prototype.giveAbility = function (r, common) {
    if ((r.ability ? 1 : 0) + r.abilityQ.length >= C.MAX_ABIL) return false;
    var ab = common ? randomItem(this, r) : pickAbility(this, r);
    if (!r.ability) r.ability = ab; else r.abilityQ.push(ab);
    (r.abHist = r.abHist || []).push(ab); if (r.abHist.length > 4) r.abHist.shift();
    emit(this, 'abilityget', r, { ability: ab });
    return true;
  };
  Race.prototype.useAbility = function (r, aim) {
    if (!r.ability || r.fell) return false;
    var a = r.ability; aim = aim < 0 ? -1 : 1;
    if (a === 'snow' || a === 'trap' || a === 'shield' || a === 'hyper') this.useCommon(r, a, aim);
    else if (a === 'tornado') {
      this.doTornado(r.id, r.u, r.d, true);
      this.out.push({ k: 'tornado', by: r.id, u: r.u, d: r.d });
    } else if (a === 'wings') { r.fx.wings = 5.5; r.fx.boost = Math.max(r.fx.boost, 1.6); emit(this, 'boost', r); emit(this, 'wings', r); }
    else if (a === 'cannon') { r.gun = 'pellet'; r.gunT = C.CANNON_T; r.fx.cannon = C.CANNON_T; r.fireCd = 0.2; emit(this, 'cannon', r, { gun: 'pellet' }); }
    else if (a === 'grenade') { r.gun = 'gren'; r.gunT = C.GREN_T; r.fx.cannon = C.GREN_T; r.fireCd = 0.3; emit(this, 'cannon', r, { gun: 'gren' }); }
    else if (a === 'megaball') {
      r.aim = aim;
      var vu = aim > 0 ? Math.max(r.vf, 12) + 36 : Math.min(r.vf - 50, -16);
      var p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 3 * aim, d: r.d, vu: vu, life: 7, age: 0, dir: aim, kd: 'mega', mine: true, h: 1.4 };
      this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu, dir: aim, kd: 'mega' });
      emit(this, 'megaball', r, { aim: aim });
    } else if (a === 'missile') {
      r.aim = 1;
      var mp = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 3, d: r.d, vu: Math.max(r.vf, 12) + 32, life: 7.5, age: 0, dir: 1, kd: 'msl', mine: true, h: 1.2 };
      this.proj.push(mp); this.out.push({ k: 'proj', id: mp.id, owner: mp.owner, u: mp.u, d: mp.d, vu: mp.vu, dir: 1, kd: 'msl' });
      emit(this, 'missile', r);
    } else if (a === 'quake') { this.doQuake(r.id, r.u); this.out.push({ k: 'quake', by: r.id, u: r.u }); }
    else if (a === 'ghost') { r.fx.ghost = 6; r.fx.spin = 0; emit(this, 'ghost', r); }
    else if (a === 'superjump') { r.fx.superjump = C.SJ_T; r.sjCd = 0; r.vy = Math.max(r.vy, 0) + C.SJ_V; r.grounded = false; r.jumped = true; r.air = 0.001; r.sjCd = 0.3; emit(this, 'superjump', r); }
    r.ability = r.abilityQ.length ? r.abilityQ.shift() : null;
    return true;
  };
  // disparo del arma equipada: canon de nieve (rafaga) o canon de granadas
  Race.prototype.fire = function (r, aim) {
    if (r.fx.cannon <= 0 || r.fell || r.fireCd > 0) return false;
    aim = aim < 0 ? -1 : 1; r.aim = aim;
    var p;
    if (r.gun === 'gren') {
      r.fireCd = C.GREN_CD;
      var gv = aim > 0 ? Math.max(r.vf, 12) + 18 : Math.min(r.vf - 32, -14);
      p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 2.6 * aim, d: r.d, vu: gv, life: 2.6, age: 0, dir: aim, kd: 'gren', mine: true, h: 1.1, vh: 11 };
      this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu, dir: aim, kd: 'gren', vh: 11 });
      emit(this, 'shoot', r, { aim: aim, gun: 'gren' });
      return true;
    }
    r.fireCd = C.FIRE_CD;
    var vu2 = aim > 0 ? Math.max(r.vf, 12) + 42 : Math.min(r.vf - 52, -16);
    p = { id: r.id + '-' + (++this.pid), owner: r.id, u: r.u + 2.6 * aim, d: r.d, vu: vu2, life: 2.0, age: 0, lt: 1, dir: aim, mine: true, h: 0.8 };
    this.proj.push(p); this.out.push({ k: 'proj', id: p.id, owner: p.owner, u: p.u, d: p.d, vu: p.vu, lt: 1, dir: aim });
    emit(this, 'shoot', r, { aim: aim, gun: 'pellet' });
    return true;
  };
  // terremoto: sacude a los rivales cercanos (por delante y por detras)
  Race.prototype.doQuake = function (byId, u) {
    emit(this, 'quake', this.byId[byId], { u: u });
    for (var i = 0; i < this.racers.length; i++) {
      var q = this.racers[i];
      if (!q.own || q.id === byId || q.fell) continue;
      var du = q.u - u;
      if (Math.abs(du) < 70 && q.grounded && applyHit(this, q, 'slip')) { q.vy = Math.max(q.vy, 7); q.grounded = false; }
    }
  };
  // un obstaculo destruido: desaparece un rato (las focas salen volando)
  Race.prototype.koObs = function (k, broadcast) {
    var o = this.T.obs[k]; if (!o || (this.ko[k] && this.ko[k] > this.time)) return;
    this.ko[k] = this.time + C.KO_T;
    var pos = this.tmp2 || (this.tmp2 = [0, 0]); PG.obsPos(this.T, o, this.time, pos);
    emit(this, 'obsko', null, { i: k, type: o.type, s: pos[0], d: pos[1], yaw: o.yaw });
    if (broadcast) this.out.push({ k: 'ko', i: k });
  };
  // explosion de granada / mega bola: derriba rivales cercanos y destruye obstaculos
  Race.prototype.explode = function (u, d, kd, byId, direct) {
    var R = kd === 'mega' ? 9 : (kd === 'msl' ? 8 : 6.5), T = this.T, i, r, pos = this.tmp2 || (this.tmp2 = [0, 0]);
    emit(this, 'boom', null, { u: u, d: d, kd: kd });
    for (i = 0; i < this.racers.length; i++) {
      r = this.racers[i];
      if (!r.own || r.id === byId || r.fell) continue;
      var du = r.u - u, dd = r.d - d;
      if (Math.abs(du) < R && Math.abs(dd) < R * 1.1 && r.py - (r.gy === undefined ? r.py : r.gy) < 3.4) {
        if (applyHit(this, r, 'hard')) {
          var dr = direct === r.id; // impacto directo del misil: sale volando
          r.vl += (dd >= 0 ? 1 : -1) * (dr ? 15 : 9); r.vy = Math.max(r.vy, dr ? 17 : 8); r.grounded = false;
          if (dr) { r.vf *= 0.4; r.fx.spin = 2.2; }
        }
      }
    }
    var sU = T.uToS(u);
    for (i = 0; i < T.obs.length; i++) {
      if (this.ko[i] && this.ko[i] > this.time) continue;
      var o = T.obs[i]; PG.obsPos(T, o, this.time, pos);
      if (Math.abs(T.dS(sU, pos[0])) < R && Math.abs(pos[1] - d) < R + o.r) this.koObs(i, false);
    }
  };
  // empujon lateral a un rival cercano (en plena carrera)
  Race.prototype.push = function (r, steer) {
    if (r.fell || r.pushCd > 0 || r.fx.spin > 0) return false;
    r.pushCd = C.PUSH_CD; r.fx.push = 0.38;
    var best = null, bd = 1e9, i;
    for (i = 0; i < this.racers.length; i++) {
      var q = this.racers[i]; if (q === r || q.fell || q.dead || q.fx.ghost > 0) continue;
      var du = q.u - r.u, dd = q.d - r.d;
      if (Math.abs(du) < 3.6 && Math.abs(dd) < 4.4 && Math.abs(q.py - r.py) < 1.8) {
        var sc = du * du * 0.6 + dd * dd; if (sc < bd) { bd = sc; best = q; }
      }
    }
    var dir = best ? (best.d >= r.d ? 1 : -1) : (steer > 0.2 ? 1 : (steer < -0.2 ? -1 : (r.d > 0 ? -1 : 1)));
    r.pushDir = dir;
    emit(this, 'push', r, { dir: dir, hit: !!best });
    if (best) {
      r.vl -= dir * 1.2; r.vf *= 0.99;
      if (best.own) applyShove(this, best, dir, r); else this.out.push({ k: 'push', to: best.id, by: r.id, dir: dir });
    }
    return !!best;
  };
  function applyShove(race, t, dir, by) {
    if (t.fx.ghost > 0) return;
    if (t.fx.shield > 0) { t.fx.shield = 0; emit(race, 'shieldpop', t); return; }
    t.vl += dir * 2.3; t.d += dir * 0.25; t.vf *= 0.97; t.hitCd = Math.max(t.hitCd, 0.2);
    t.psi = clamp(t.psi + dir * 0.15, -1.35, 1.35);
    emit(race, 'shoved', t, { dir: dir });
  }
  Race.prototype.doTornado = function (byId, u, d) {
    this.tornados.push({ by: byId, u: u, d: d, t: 0, life: 1.6 });
    emit(this, 'tornado', this.byId[byId], { u: u });
    for (var i = 0; i < this.racers.length; i++) {
      var q = this.racers[i];
      if (!q.own || q.id === byId) continue;
      var du = q.u - u;
      if (du > -10 && du < 50) applyHit(this, q, 'hard');
    }
  };

  /* ---------- eventos de red recibidos ---------- */
  Race.prototype.applyEvent = function (e) {
    var i;
    if (e.k === 'proj') this.proj.push({ id: e.id, owner: e.owner, u: e.u, d: e.d, vu: e.vu, life: (e.kd === 'mega' ? 8 : (e.kd === 'msl' ? 7.5 : (e.kd === 'gren' ? 3.4 : (e.lt ? 2.0 : 3.4)))), age: 0, lt: e.lt || 0, dir: e.dir || 1, kd: e.kd || '', mine: false, h: e.kd === 'gren' ? 1.1 : 1, vh: e.vh || 0 });
    else if (e.k === 'boom') { for (i = 0; i < this.proj.length; i++) if (this.proj[i].id === e.id) { this.proj.splice(i, 1); break; } this.explode(e.u, e.d, e.kd, e.by, e.dr); }
    else if (e.k === 'ko') this.koObs(e.i, false);
    else if (e.k === 'quake') this.doQuake(e.by, e.u);
    else if (e.k === 'push') { var tg = this.byId[e.to]; if (tg && tg.own) applyShove(this, tg, e.dir, this.byId[e.by]); }
    else if (e.k === 'trap') this.traps.push({ id: e.id, owner: e.owner, u: e.u, d: e.d, life: 25, age: 0 });
    else if (e.k === 'hit') {
      var list = e.pk === 'trap' ? this.traps : this.proj;
      for (i = 0; i < list.length; i++) if (list[i].id === e.id) { list.splice(i, 1); break; }
    } else if (e.k === 'tornado') this.doTornado(e.by, e.u, e.d);
    else if (e.k === 'dead') { var rd = this.byId[e.r]; if (rd) killRacer(this, rd, e.t); }
    else if (e.k === 'fin') {
      var r = this.byId[e.r];
      if (r && !r.finished) { r.finished = true; r.finishTime = e.time; this.finishOrder.push(r.id); }
    }
  };

  /* ---------- paso de un pinguino propio ---------- */
  // Punto de reaparicion: siempre antes de cualquier hueco cercano (evita caer en bucle)
  function safeRespawnU(race, u) {
    var T = race.T, tries = 0, k, moved = true;
    while (moved && tries++ < 10) {
      moved = false;
      var s = T.uToS(u);
      for (k = 0; k < T.holes.length; k++) {
        var H = T.holes[k], ds0 = T.dS(s, H.s0), ds1 = T.dS(s, H.s1);
        if (ds1 > -8 && ds0 < 48) { u -= (48 - ds0); moved = true; break; }
      }
    }
    if (T.type === 'sprint') u = Math.max(u, -T.startS + 4);
    return u;
  }
  PG.safeRespawnU = safeRespawnU;
  function respawn(race, r) {
    var T = race.T;
    r.u = safeRespawnU(race, Math.min(r.safeU, r.u)); r.d = clamp(r.safeD * 0.4, -5, 5); r.psi = 0; r.vf = 12; r.vl = 0; r.vy = 0;
    for (var hk = 0; hk < T.holes.length; hk++) { // aparecer fuera del tramo que cubre una grieta parcial cercana
      var HH = T.holes[hk], dhs = T.dS(T.uToS(r.u), HH.s0);
      if (HH.mode === 'full' || dhs < -4 || dhs > 220) continue;
      var lo = HH.d0 - 2.6, hi = HH.d1 + 2.6;
      if (r.d > lo && r.d < hi) {
        var optA = lo, optB = hi; // lado libre mas cercano que quepa en la pista
        var okA = optA > -11.2, okB = optB < 11.2;
        if (okA && (!okB || r.d - lo <= hi - r.d)) r.d = Math.max(optA, -11.2); else if (okB) r.d = Math.min(optB, 11.2);
      }
    }
    if (r.ai) { r.ai.laneSm = r.d; r.ai.target = r.d; }
    r.py = T.ground(T.uToS(r.u), r.d); if (r.py < -1e8) r.py = T.centerY(T.uToS(r.u));
    r.gy = r.py; r.grounded = true; r.overHole = false; r.fell = false; r.air = 0; r.flip = 0; r.flipAcc = 0; r.jumpCd = 0;
    r.fx.ghost = 2.2; r.fx.spin = 0; r.fx.boost = 0; r.fx.pad = 0; r.fx.cannon = 0;
    emit(race, 'respawn', r);
  }

  function startFlip(r, steer, brake) {
    r.flipping = true; r.flipAcc = 0;
    if (steer > 0.35) { r.flipMode = 2; r.flipDir = 1; }
    else if (steer < -0.35) { r.flipMode = 2; r.flipDir = -1; }
    else if (brake > 0.4) { r.flipMode = 1; r.flipDir = -1; }
    else { r.flipMode = 1; r.flipDir = 1; }
  }
  function landTrick(race, r) {
    var n = r.flipDone;
    if (r.flipping && r.flipAcc > 4.4) n++;
    if (n > 0) {
      r.fx.boost = Math.max(r.fx.boost, 0.8 + 0.5 * n); r.vf += 1.5 * n;
      emit(race, 'trick', r, { n: n });
    } else if (r.flipping && r.flipAcc > 1.0) {
      r.vf *= 0.88; emit(race, 'stumble', r);
    }
    r.flipping = false; r.flipAcc = 0; r.flipDone = 0; r.jumped = false;
  }

  function stepRacer(race, r, inp, dt) {
    if (r.dead) { r.vf = r.vl = 0; r.speed = 0; return; }
    var T = race.T, fx = r.fx, k;
    for (k in fx) if (fx[k] > 0) fx[k] = Math.max(0, fx[k] - dt);
    if (r.hitCd > 0) r.hitCd -= dt;
    if (r.padCd > 0) r.padCd -= dt;
    if (r.fireCd > 0) r.fireCd -= dt;
    if (r.pushCd > 0) r.pushCd -= dt;
    r.aimV += (r.aim - r.aimV) * Math.min(1, dt * 12);

    if (r.fell) {
      r.flipping = false; r.flipAcc = 0; r.flipDone = 0; r.jumped = false;
      r.fallT -= dt;
      r.vy -= C.G * dt; r.py += r.vy * dt; r.vf *= Math.exp(-2 * dt);
      r.u += r.vf * dt;
      if (r.fallT <= 0) respawn(race, r);
      return;
    }

    var s = T.uToS(r.u), q = T.q(s), spinning = fx.spin > 0;
    var steer = inp.steer || 0, tuck = inp.tuck || 0, brake = inp.brake || 0;
    var cvq = q.cv, slq = q.sl;

    // impulso: solo pez turbo, pads de velocidad y piruetas (sin barra de boost)
    r.holdBoost = false;
    var rail0 = r.grounded && !r.finished && T.routeAt ? T.routeAt(s, r.d) : null; // carril turbo de un camino alternativo
    if (rail0) { if (fx.pad < 0.3) fx.pad = 0.3; if (!r.onRail) { r.onRail = true; if (race.time - (r.railT || -9) > 2) emit(race, 'rail', r); r.railT = race.time; } } else r.onRail = false;
    var boostOn = fx.boost > 0 || fx.pad > 0;

    // recarga del objeto "pez"
    if (!r.item) { r.charge += dt / 15; if (r.charge >= 1) { r.item = 'fish'; r.charge = 0; emit(race, 'itemget', r); } }

    // salto y piruetas
    var jp = !!inp.jump, jedge = jp && !r.jumpPrev; r.jumpPrev = jp;
    if (r.sjCd > 0) r.sjCd -= dt;
    if (r.daze > 0) r.daze = Math.max(0, r.daze - 0.7 * dt); if (r.stunCd > 0) r.stunCd -= dt;
    if (jedge && !spinning && fx.superjump > 0 && r.sjCd <= 0 && (r.grounded || r.py - (r.gy === undefined ? r.py : r.gy) < 7.5)) {
      // super salto: salta en el suelo y tambien en el aire (doble, triple... mientras dure)
      r.vy = C.SJ_V; r.grounded = false; r.jumped = true; r.air = Math.max(r.air, 0.001); r.sjCd = 0.28;
      r.flipping = false; r.flipAcc = 0;
      emit(race, 'sjump', r);
    } else if (jedge && !spinning) {
      if (r.grounded || (r.air < 0.12 && !r.jumped)) {
        r.vy = Math.max(r.vy, 0) + C.JUMP; r.grounded = false; r.jumped = true; r.air = Math.max(r.air, 0.001);
        emit(race, 'jump', r);
      } else if (!r.grounded && !r.flipping) startFlip(r, steer, brake);
    } else if (jp && !r.grounded && !r.flipping && r.air > 0.09 && r.flipDone === 0 && !spinning) {
      startFlip(r, steer, brake); // mantener el boton en el aire = voltereta automatica
    }

    if (r.grounded) {
      if (!spinning) {
        var tr = C.TURN * (1 - 0.25 * tuck) / (1 + Math.max(0, r.vf) * C.TURNSPD);
        r.psi = clamp(r.psi + steer * tr * dt, -1.35, 1.35);
        // asistencia: sin girar, el pinguino se alinea solo con la pista (mas facil doblar y cruzar)
        if (Math.abs(steer) < 0.12) r.psi -= r.psi * Math.min(1, dt * 1.7);
      } else {
        r.spinAng += (r.spinDir || 1) * 14 * dt;
      }
      var cp = Math.cos(r.psi), sp = Math.sin(r.psi);
      var vpar = r.vf * cp + r.vl * sp, vperp = -r.vf * sp + r.vl * cp;
      var thrust = spinning ? 0 : C.THRUST * (1 + 0.1 * tuck) * (r.ai ? r.ai.skill * (r.ai.rubber || 1) : 1);
      if (boostOn) thrust += C.BOOSTF;
      if (fx.hyper > 0) thrust += C.BOOSTF * 1.3;
      if (fx.wings > 0) thrust += 6;
      var drag = C.DRAG * (1 - 0.25 * tuck) * (fx.hyper > 0 ? 0.8 : 1);
      var a = thrust - drag * vpar * Math.abs(vpar);
      a += -C.G * slq * 0.85 * cp;
      vpar += a * dt;
      if (brake > 0) vpar = Math.max(vpar - C.BRAKE * brake * dt, Math.min(vpar, 4));
      if (spinning) vpar *= Math.exp(-1.3 * dt);
      var grip = spinning ? 0.7 : (C.GRIP + brake * 3.5);
      vperp *= Math.exp(-grip * dt);
      r.vf = vpar * cp - vperp * sp; r.vl = vpar * sp + vperp * cp;
      r.vl += -cvq * r.vf * r.vf * C.CENT * dt;
      r.steerVis += (steer - r.steerVis) * Math.min(1, dt * 10);
    } else {
      r.psi = clamp(r.psi + steer * 0.7 * dt, -1.35, 1.35);
      r.vf *= Math.exp(-0.03 * dt);
      if (spinning) r.spinAng += (r.spinDir || 1) * 10 * dt;
      r.air += dt;
      if (r.flipping) {
        r.flipAcc += C.FLIPW * dt;
        if (r.flipAcc >= 6.2832) {
          r.flipDone++; r.flipAcc = 0; r.flipping = false;
          emit(race, 'flip', r, { n: r.flipDone });
          if (jp) startFlip(r, steer, brake);
        }
      }
    }

    // movimiento
    r.u += r.vf * dt; r.d += r.vl * dt;
    var lim = T.W / 2 - 0.95;
    if (r.d > lim) { if (r.vl > 5) r.wallHit = 1; r.d = lim; if (r.vl > 0) r.vl = -r.vl * 0.3; r.vf *= (1 - 0.5 * dt); if (r.psi > 0.2) r.psi -= 0.8 * dt; }
    else if (r.d < -lim) { if (r.vl < -5) r.wallHit = 1; r.d = -lim; if (r.vl < 0) r.vl = -r.vl * 0.3; r.vf *= (1 - 0.5 * dt); if (r.psi < -0.2) r.psi += 0.8 * dt; }
    if (r.wallHit > 0) { emit(race, 'wall', r); r.wallHit = 0; }
    // paredes curvas de las cuevas: la gravedad empuja hacia el centro; con velocidad se sube por ellas
    var bankTarget = 0;
    if (T.caves.length && r.grounded) {
      var bf = T.caveF(T.uToS(r.u));
      if (bf > 0) {
        var ba = Math.abs(r.d) - 6;
        if (ba > 0) {
          var slope = 0.34 * ba * bf, sg2 = r.d > 0 ? 1 : -1;
          r.vl -= sg2 * C.G * 0.28 * slope / Math.sqrt(1 + slope * slope) * dt;
          bankTarget = -sg2 * Math.atan(slope) * 0.8;
        }
      }
    }
    r.bankRoll += (bankTarget - r.bankRoll) * Math.min(1, dt * 7);
    if (T.type === 'sprint') {
      var sEnd = T.L - 8, sNow = r.u + T.startS;
      if (sNow > sEnd) { r.u = sEnd - T.startS; r.vf *= Math.exp(-6 * dt); }
      if (sNow < 2 && r.u < 0) { r.u = 2 - T.startS; if (r.vf < 0) r.vf = 0; }
    }

    // vertical
    var s2 = T.uToS(r.u), g2 = T.ground(s2, r.d), wasGrounded = r.grounded;
    var inCaveNow = T.caves.length && T.caveF(s2) > 0;
    r.vy -= C.G * (fx.wings > 0 && !inCaveNow ? 0.3 : 1) * dt;
    r.py += r.vy * dt;
    // con alas no se puede entrar en una cueva: se choca con la boca y se cae al suelo
    if (fx.wings > 0 && T.caves.length && (inCaveNow || T.inCave(s2, 7))) {
      fx.wings = 0; fx.boost = 0; r.vf *= 0.82; if (r.vy > -9) r.vy = -9; r.vl *= 0.4;
      if (!r.bonkCd) { r.bonkCd = 0.6; emit(race, 'bonk', r); }
    }
    // techo de la cueva: no se atraviesa; con alas se choca y se cae al suelo
    if (inCaveNow) {
      var ceil = T.centerY(s2) + T.ceilAt(s2, r.d) - 1.9;
      if (r.py > ceil) {
        var ceilHard = fx.wings > 0 || r.vy > 6;
        r.py = ceil; if (r.vy > 0) r.vy = -r.vy * 0.25 - 2;
        if (fx.wings > 0) { fx.wings = 0; fx.boost = 0; r.vf *= 0.8; }
        if (ceilHard && !r.bonkCd) { r.bonkCd = 0.5; emit(race, 'bonk', r); }
      }
    }
    if (r.bonkCd > 0) r.bonkCd = Math.max(0, r.bonkCd - dt);
    if (g2 > T.NOGROUND / 2) {
      if (r.py <= g2) {
        if (r.overHole && r.py < g2 - 0.7) { // choco con el borde del hueco
          r.fell = true; r.fallT = 1.4; r.vy = Math.min(r.vy, -2); r.falls++; emit(race, 'fall', r);
          return;
        }
        var impact = -r.vy;
        r.py = g2;
        r.vy = clamp((g2 - r.gy) / dt, -22, 28);
        if (!wasGrounded && r.air > 0.25) emit(race, 'land', r, { impact: impact });
        if (!wasGrounded) landTrick(race, r);
        r.grounded = true; r.air = 0; r.overHole = false;
      } else { r.grounded = false; }
      r.gy = g2;
    } else {
      r.grounded = false; r.overHole = true;
    }
    if (r.py < T.centerY(s2) - 6 && !r.fell) { r.fell = true; r.fallT = 1.2; r.falls++; emit(race, 'fall', r); return; }

    // punto seguro (antes de huecos)
    if (r.grounded) {
      var safe = true;
      for (k = 0; k < T.holes.length; k++) {
        var H = T.holes[k], ds0 = T.dS(s2, H.s0), ds1 = T.dS(s2, H.s1);
        if (ds1 > -8 && ds0 < 48) { safe = false; break; }
      }
      if (safe) { r.safeU = r.u - 2; r.safeD = r.d; }
    }

    // pads de impulso
    if (r.grounded && r.padCd <= 0) {
      for (k = 0; k < T.pads.length; k++) {
        var P = T.pads[k], dp = T.dS(P.s, s2);
        if (dp >= 0 && dp <= P.len && r.d >= P.d0 && r.d <= P.d1) { fx.pad = 1.5; r.vf += 3; r.padCd = 1.0; emit(race, 'pad', r); break; }
      }
    }
    // cajas de objeto
    if (r.rank !== undefined && !r.finished) {
      for (k = 0; k < T.boxes.length; k++) {
        if (race.boxT[k] > race.time) continue;
        var B = T.boxes[k], db = T.dS(s2, B.s);
        if (db > -2.4 && db < 2.4 && Math.abs(B.d - r.d) < 2.4 && r.py - r.gy < 3) {
          race.boxT[k] = race.time + C.RESPAWN_ORB;
          if (!race.giveAbility(r, true)) emit(race, 'boxbreak', r);
        }
      }
      for (k = 0; k < T.crys.length; k++) {
        if (race.crysT[k] > race.time) continue;
        var Cr = T.crys[k], dcs = T.dS(s2, Cr.s);
        if (dcs > -3 && dcs < 3 && Math.abs(Cr.d - r.d) < 3 && r.py - r.gy < 3) {
          if (race.giveAbility(r)) race.crysT[k] = race.time + C.RESPAWN_ORB;
        }
      }
    }
    // obstaculos
    if (!r.finished) {
      var pos = race.tmp;
      for (k = 0; k < T.obs.length; k++) {
        var o = T.obs[k];
        if (race.ko[k] && race.ko[k] > race.time) continue;
        if (fx.ghost > 0) continue;
        if (o.type === 'icicle' && !PG.icicleActive(o, race.time)) continue;
        PG.obsPos(T, o, race.time, pos);
        var ds1 = T.dS(s2, pos[0]);
        if (ds1 > 4 || ds1 < -4) continue;
        var dd1 = r.d - pos[1], rr = o.r + C.RR;
        if (ds1 * ds1 + dd1 * dd1 < rr * rr && r.py - r.gy < 1.6 && r.hitCd <= 0) {
          var sgn = dd1 >= 0 ? 1 : -1;
          if (o.hit === 'snowman') { race.ko[k] = race.time + 6; r.vf *= 0.72; r.vy = 5; r.grounded = false; r.hitCd = 0.4; emit(race, 'smash', r); }
          else if (o.hit === 'seal') { r.vl += sgn * 9; applyHit(race, r, 'slip'); }
          else if (o.hit === 'ball') { r.vl += sgn * 6; applyHit(race, r, 'hard'); }
          else if (fx.shield > 0 && o.type === 'tree') { // arbol con escudo: rebotas, no te aturde
            r.vl += sgn * 6; r.vf *= 0.55; r.hitCd = 0.45; fx.shield = Math.max(0.5, fx.shield - 3); emit(race, 'treebump', r);
          } else if (fx.shield > 0 && r.vf >= (o.hit === 'ice' ? C.SMASH_ICE : C.SMASH_ROCK)) { // escudo + velocidad: rompes hielo y rocas
            race.koObs(k, true); r.vf *= o.hit === 'ice' ? 0.93 : 0.86; r.hitCd = 0.25; fx.shield = Math.max(0.5, fx.shield - 2); emit(race, 'smash', r);
          } else { r.vl += sgn * 7; applyHit(race, r, o.hit === 'ice' ? 'spin' : 'hard'); }
        }
      }
    }
    // muros de los caminos alternativos (bajos: se pueden saltar)
    if (!r.finished && !r.fell && T.routes && fx.ghost <= 0) {
      for (k = 0; k < T.routes.length; k++) {
        var RW = T.routes[k], drw = T.dS(RW.s0, s2);
        if (drw < RW.w0 || drw > RW.w1 || r.py - r.gy > 1.0) continue;
        for (var wq = 0; wq < RW.walls.length; wq++) {
          var wdd = r.d - RW.walls[wq], wr = 0.5 + C.RR;
          if (Math.abs(wdd) < wr) {
            var sgw = wdd >= 0 ? 1 : -1;
            r.d = RW.walls[wq] + sgw * wr; r.vl = sgw * Math.max(2.5, Math.abs(r.vl) * 0.3); r.psi *= 0.5;
            if (r.hitCd <= 0) { r.vf *= 0.9; r.hitCd = 0.25; emit(race, 'treebump', r); }
          }
        }
      }
    }
    // vueltas y meta
    if (T.type === 'circuit') r.lap = r.u < 0 ? 0 : Math.min(race.laps, Math.floor(r.u / T.L) + 1);
    var endU = T.type === 'circuit' ? race.laps * T.L : T.D;
    if (!r.finished && r.u >= endU) {
      r.finished = true; r.finishTime = race.time; r.auto = true; race.finishOrder.push(r.id);
      race.out.push({ k: 'fin', r: r.id, time: r.finishTime });
      emit(race, 'finish', r);
    }
    // avalancha: si el frente te pasa por encima y te tapa por completo, quedas eliminado
    if (!r.finished && race.av && race.time >= race.av.tGo && r.u < race.avFront(race.time) - 2.5) {
      killRacer(race, r, race.time); race.out.push({ k: 'dead', r: r.id, t: race.time });
    }
    r.speed = Math.sqrt(r.vf * r.vf + r.vl * r.vl);
  }
  // eliminado (por la avalancha): fuera de carrera, cuenta como no terminado
  function killRacer(race, r, t) {
    if (r.dead) return;
    r.dead = true; r.finished = true; r.finishTime = t; r.vf = r.vl = 0; r.speed = 0; r.deadAt = t; r.auto = false;
    r.item = null; r.ability = null; r.abilityQ = [];
    for (var k in r.fx) r.fx[k] = 0;
    emit(race, 'engulf', r);
  }
  PG.killRacer = killRacer;
  PG.stepRacer = stepRacer;

  /* ---------- actualizacion del mundo ---------- */
  Race.prototype.update = function (dt, localInput) {
    var T = this.T, i, r;
    if (this.time < 0) { this.updateRanks(); return; }
    for (i = 0; i < this.racers.length; i++) {
      r = this.racers[i];
      if (r.dead) continue;
      if (r.own) {
        var inp;
        if (r.bot || r.auto) inp = PG.aiInput(this, r, dt);
        else inp = localInput || { steer: 0 };
        if (r.local && !r.auto && localInput) {
          if (localInput.useItem) { this.useItem(r, localInput.aim); }
          if (localInput.useAbility) { this.useAbility(r, localInput.aim); }
          if (localInput.fire) this.fire(r, localInput.fireAim !== undefined ? localInput.fireAim : localInput.aim);
          if (localInput.push) this.push(r, localInput.steer);
        } else if (r.bot && inp.useItem) this.useItem(r, inp.aim);
        if (r.bot && inp.fire) this.fire(r, inp.aim);
        if (r.bot && inp.push) this.push(r, inp.steer);
        if (r.bot && inp.useAbility) this.useAbility(r, inp.aimA || 1);
        stepRacer(this, r, inp, dt);
      } else this.updateRemote(r, dt);
    }
    this.stepWorld(dt);
    this.collide(dt);
    this.updateRanks();
  };

  Race.prototype.updateRemote = function (r, dt) {
    var n = r.net, T = this.T;
    for (var k in r.fx) if (r.fx[k] > 0) r.fx[k] = Math.max(0, r.fx[k] - dt);
    if (!n) return;
    var age = clamp((this.nowMs - n.t) / 1000, 0, 0.35), f = Math.min(1, dt * 12);
    var tu = n.u + n.vf * age;
    if (Math.abs(tu - r.u) > 25) r.u = tu; else r.u += (tu - r.u) * f;
    r.d += (n.d - r.d) * f;
    r.psi += PG.angDiff(r.psi, n.psi) * f;
    r.vf = n.vf; r.vl = n.vl || 0;
    var wasG = r.grounded;
    r.py += (n.y - r.py) * Math.min(1, dt * 14);
    r.grounded = !!(n.x & 64);
    r.fell = !!(n.x & 32);
    var x = n.x;
    r.fx.boost = (x & 1) ? 0.2 : 0; r.fx.spin = (x & 2) ? 0.2 : 0; r.fx.shield = (x & 4) ? 0.2 : 0;
    r.fx.push = (x & 512) ? 0.2 : 0; r.fx.wings = (x & 16) ? 0.2 : 0; r.fx.ghost = (x & 128) ? 0.2 : 0; r.fx.cannon = (x & 256) ? 0.2 : 0; r.gun = (x & 1024) ? 'gren' : 'pellet'; r.fx.superjump = (x & 2048) ? 0.2 : 0;
    var fm = n.fm || 0, fl = n.fl || 0;
    if (fm) {
      r.flipping = true; r.flipMode = Math.abs(fm); r.flipDir = fm < 0 ? -1 : 1;
      if (fl < r.flipAcc - 3) r.flipAcc = fl;
      r.flipAcc += ((fl + C.FLIPW * Math.min(age, 0.1)) - r.flipAcc) * Math.min(1, dt * 20);
    } else { r.flipping = false; r.flipAcc = 0; }
    if (r.fx.spin > 0) r.spinAng += (r.spinDir || 1) * 14 * dt;
    r.lap = n.lap || 0; r.speed = Math.abs(r.vf);
    r.item = n.it || null;
    r.steerVis += (((n.st || 0)) - r.steerVis) * Math.min(1, dt * 8);
    if (r.gy === undefined) r.gy = r.py;
    r.gy = T.ground(T.uToS(r.u), r.d); if (r.gy < -1e8) r.gy = r.py;
  };

  Race.prototype.stepWorld = function (dt) {
    var i, j, p, r, T = this.T, pos = this.tmp2 || (this.tmp2 = [0, 0]);
    for (i = this.proj.length - 1; i >= 0; i--) {
      p = this.proj[i]; p.age += dt; p.life -= dt;
      var kd = p.kd || '';
      // seguimiento: bola pequena -> rival mas cercano; mega bola -> el de adelante; misil -> el mejor clasificado que tenga delante
      var best = null, bd = kd === 'mega' ? 180 : 70, pdir = p.dir || 1;
      if (kd === 'msl') {
        var br = 1e9;
        for (j = 0; j < this.racers.length; j++) {
          r = this.racers[j];
          if (r.id === p.owner || r.fx.ghost > 0 || r.finished || r.fell) continue;
          if ((r.u - p.u) > 1.5 && (r.rank || 99) < br) { br = r.rank || 99; best = r; }
        }
        p.tgt = best ? best.id : null;
      } else if (kd === 'mega') {
        for (j = 0; j < this.racers.length; j++) {
          r = this.racers[j];
          if (r.id === p.owner || r.fx.ghost > 0 || r.finished) continue;
          var du = (r.u - p.u) * pdir;
          if (du > 2 && du < bd) { bd = du; best = r; }
        }
      } else {
        var bs = 1e9; // el mas cercano en distancia (longitudinal + lateral), delante en la direccion del disparo
        for (j = 0; j < this.racers.length; j++) {
          r = this.racers[j];
          if (r.id === p.owner || r.fx.ghost > 0 || r.finished || r.fell) continue;
          var du2 = (r.u - p.u) * pdir; if (du2 < 1.5 || du2 > bd) continue;
          var sc2 = du2 * du2 + (r.d - p.d) * (r.d - p.d) * 2.2; if (sc2 < bs) { bs = sc2; best = r; }
        }
      }
      var vd = 0;
      if (best) {
        if (kd === 'msl') vd = clamp((best.d + (best.vl || 0) * 0.25 - p.d) * 3.2, -16, 16);
        else if (kd === 'mega') vd = clamp((best.d - p.d) * 3.4, -17, 17);
        else if (kd === 'gren') vd = clamp((best.d - p.d) * 1.0, -9, 9);
        else vd = clamp((best.d + (best.vl || 0) * 0.15 - p.d) * (p.lt ? 4.2 : 5.5), p.lt ? -16 : -22, p.lt ? 16 : 22);
      }
      p.d = clamp(p.d + vd * dt, -T.W / 2 + 1, T.W / 2 - 1);
      if ((kd === 'mega' || kd === 'msl') && best && p.mine) { var need = pdir * (Math.abs(best.vf) + (kd === 'msl' ? 16 : 15)); if (pdir > 0 ? p.vu < need : p.vu > need) p.vu += (need - p.vu) * Math.min(1, dt * 2); }
      p.u += p.vu * dt;
      if (kd === 'gren') { p.vh -= 22 * dt; p.h += p.vh * dt; }
      var hit = false;
      if (kd === 'gren' || kd === 'mega' || kd === 'msl') {
        if (p.mine) {
          var boom = p.life <= 0 || (kd === 'gren' && p.h <= 0 && p.age > 0.2), direct = null;
          for (j = 0; j < this.racers.length && !boom; j++) {
            r = this.racers[j];
            if (r.id === p.owner || r.fell || r.fx.ghost > 0 || p.age < 0.15) continue;
            if (Math.abs(r.u - p.u) < (kd === 'gren' ? 2.4 : 2.8) && Math.abs(r.d - p.d) < (kd === 'gren' ? 2.2 : 2.5) && Math.abs((r.py - (r.gy === undefined ? r.py : r.gy)) - p.h) < 3.2) { boom = true; direct = r.id; }
          }
          if (kd === 'mega') { // arrasa obstaculos por el camino
            var sp = T.uToS(p.u);
            for (j = 0; j < T.obs.length; j++) {
              if (this.ko[j] && this.ko[j] > this.time) continue;
              PG.obsPos(T, T.obs[j], this.time, pos);
              if (Math.abs(T.dS(sp, pos[0])) < 3 && Math.abs(pos[1] - p.d) < T.obs[j].r + 2.2) this.koObs(j, true);
            }
          }
          if (boom) { this.out.push({ k: 'boom', id: p.id, u: p.u, d: p.d, kd: kd, by: p.owner, dr: direct }); this.explode(p.u, p.d, kd, p.owner, direct); this.proj.splice(i, 1); }
        } else if (p.life <= 0) this.proj.splice(i, 1);
        continue;
      }
      for (j = 0; j < this.racers.length && !hit; j++) {
        r = this.racers[j];
        if (!r.own || r.id === p.owner || r.fell || r.fx.ghost > 0) continue;
        if (Math.abs(r.u - p.u) < 1.8 && Math.abs(r.d - p.d) < 1.5 && r.py - (r.gy === undefined ? r.py : r.gy) < 1.15) { if (applyHit(this, r, p.lt ? 'pellet' : 'snow')) r.vl += (r.d >= p.d ? 1 : -1) * (p.lt ? 1.5 : 5); hit = true; }
      }
      var obsHit = false;
      if (!hit && p.mine) { // las bolas destruyen obstaculos y focas
        var sq = T.uToS(p.u);
        for (j = 0; j < T.obs.length; j++) {
          var ob = T.obs[j]; if (ob.type === 'icicle' || (this.ko[j] && this.ko[j] > this.time)) continue;
          PG.obsPos(T, ob, this.time, pos);
          if (Math.abs(T.dS(sq, pos[0])) < 1.9 && Math.abs(pos[1] - p.d) < ob.r + 0.8) { this.koObs(j, true); obsHit = true; break; }
        }
      }
      if (hit || obsHit) { this.out.push({ k: 'hit', pk: 'proj', id: p.id }); emit(this, 'splat', null, { u: p.u, d: p.d }); this.proj.splice(i, 1); }
      else if (p.life <= 0) this.proj.splice(i, 1);
    }
    for (i = this.traps.length - 1; i >= 0; i--) {
      p = this.traps[i]; p.age += dt; p.life -= dt;
      var thit = false;
      for (j = 0; j < this.racers.length && !thit; j++) {
        r = this.racers[j];
        if (!r.own || r.fell) continue;
        if (r.id === p.owner && p.age < 1.2) continue;
        if (Math.abs(r.u - p.u) < 1.7 && Math.abs(r.d - p.d) < 1.6 && r.py - r.gy < 1.5) { applyHit(this, r, 'slip'); thit = true; }
      }
      if (thit) { this.out.push({ k: 'hit', pk: 'trap', id: p.id }); this.traps.splice(i, 1); }
      else if (p.life <= 0) this.traps.splice(i, 1);
    }
    for (i = this.tornados.length - 1; i >= 0; i--) { this.tornados[i].t += dt; if (this.tornados[i].t > this.tornados[i].life) this.tornados.splice(i, 1); }
  };

  Race.prototype.collide = function (dt) {
    var i, j, a, b;
    for (i = 0; i < this.racers.length; i++) {
      a = this.racers[i]; if (!a.own || a.fell || a.dead) continue;
      for (j = 0; j < this.racers.length; j++) {
        if (i === j) continue; b = this.racers[j]; if (b.fell || b.dead) continue;
        var du = a.u - b.u, dd = a.d - b.d;
        if (Math.abs(du) < 1.7 && Math.abs(dd) < 1.4 && Math.abs(a.py - b.py) < 1.3) {
          var sg = dd >= 0 ? 1 : -1; if (dd === 0) sg = (i < j) ? 1 : -1;
          a.d += sg * 0.9 * dt * 6; a.vl += sg * 5 * dt * 10 * 0.3;
          if (a.vf > b.vf) a.vf -= (a.vf - b.vf) * 0.5 * dt * 3;
        }
      }
    }
  };

  Race.prototype.updateRanks = function () {
    var arr = this.racers.slice(), self = this, T = this.T;
    var endU = T.type === 'circuit' ? this.laps * T.L : T.D;
    // un rival remoto que ya llego a la meta cuenta como terminado aunque su aviso de "meta" aun no haya llegado por la red
    function fin(r) { return r.finished || (!r.own && r.u >= endU - 0.01); }
    // orden de llegada = orden en que este jugador fue enterado (los relojes de cada telefono no son comparables)
    function ft(r) { return r.finished ? self.finishOrder.indexOf(r.id) : -1; }
    arr.sort(function (a, b) {
      if (a.dead || b.dead) { if (a.dead && b.dead) return b.deadAt - a.deadAt; return a.dead ? 1 : -1; }
      var fa = fin(a), fb = fin(b);
      if (fa && fb) return ft(a) - ft(b);
      if (fa) return -1; if (fb) return 1;
      return b.u - a.u;
    });
    var lead = -1e9;
    for (var i = 0; i < arr.length; i++) { arr[i].rank = i + 1; if (arr[i].u > lead) lead = arr[i].u; }
    this.leaderU = lead; this.order = arr;
  };

  /* ---------- IA de los bots ---------- */
  // Los bots planifican su carril evaluando el coste de varios carriles hacia adelante (obstaculos moviles, grietas,
  // trampas, proyectiles) y buscan esferas y pads; saltan obstaculos, hacen piruetas, apuntan hacia adelante o atras,
  // empujan a rivales y usan poderes con criterio.
  function aiInit(r) {
    var rr = PG.rng((r.slot * 977 + 31) | 0);
    return { lane: 0, t: 0, ph: rr() * 6.28, skill: 1, aggr: 0.5, greed: 0.8, trick: 0.6, useDelay: 99, rr: rr, inp: { steer: 0, tuck: 0, brake: 0 }, laneSm: r.d, target: r.d, think: 0, jumpCd: 0, pushThink: 0, rubber: 1 };
  }
  PG.aiInput = function (race, r, dt) {
    var T = race.T, ai = r.ai;
    if (!ai) ai = r.ai = aiInit(r);
    var inp = ai.inp; inp.useItem = false; inp.useAbility = false; inp.brake = 0; inp.tuck = [0.08, 0.25, 0.42, 0.6][race.diff | 0]; inp.jump = false; inp.fire = false; inp.push = false; inp.aim = 1;
    ai.t += dt; ai.think -= dt; ai.jumpCd -= dt; ai.pushThink -= dt;
    var s = T.uToS(r.u), vf = Math.max(r.vf, 14), look = 24 + vf * 0.75, W2 = T.W / 2 - 2.4, i, k, o, H, ds, q = T.q(s);
    var pos = race.tmp, ahead = null, behind = null, aheadD = 1e9, behindD = 1e9, rivalSide = null;

    // ---- rivales cercanos ----
    for (k = 0; k < race.racers.length; k++) {
      var b = race.racers[k]; if (b === r || b.fell || b.dead) continue;
      var du = b.u - r.u, dd = b.d - r.d;
      if (du > 3 && du < 60 && Math.abs(dd) < 7 && du < aheadD) { aheadD = du; ahead = b; }
      if (du < -3 && du > -45 && Math.abs(dd) < 7 && -du < behindD) { behindD = -du; behind = b; }
      if (Math.abs(du) < 3.0 && Math.abs(dd) > 0.6 && Math.abs(dd) < 3.8 && b.fx.ghost <= 0 && (!rivalSide || Math.abs(dd) < Math.abs(rivalSide.d - r.d))) rivalSide = b;
    }

    // ---- planificacion de carril (cada ~0.12 s) ----
    var needRamp = false, fullHole = null;
    for (i = 0; i < T.holes.length; i++) {
      H = T.holes[i]; ds = T.dS(s, H.s0);
      if (ds > -4 && ds < look + 110 && H.mode === 'full') { needRamp = true; if (ds > -2 && (!fullHole || ds < T.dS(s, fullHole.s0))) fullHole = H; }
    }
    if (ai.think <= 0) {
      ai.think = ([0.24, 0.13, 0.1, 0.07][race.diff | 0] || 0.13) + ai.rr() * 0.06;
      var best = 1e9, bestLane = ai.target, lane, c, step = 2.2, cur = r.d;
      var thr = [];
      for (k = 0; k < race.proj.length; k++) { var pj = race.proj[k]; if (pj.owner === r.id) continue; var pdu = (pj.u - r.u) * (pj.dir || 1); if (pdu < 0 && pdu > -36 && Math.abs(pj.d - r.d) < 4) thr.push(pj.d); }
      var lanesL = []; for (lane = -W2; lane <= W2 + 0.01; lane += step) lanesL.push(lane); if (lanesL[lanesL.length - 1] < W2 - 0.4) lanesL.push(W2);
      for (var li = 0; li < lanesL.length; li++) {
        lane = lanesL[li];
        c = Math.abs(lane - ai.target) * 0.05 + Math.abs(lane - cur) * 0.08 + Math.abs(lane - (ai.lane || 0)) * 0.03;
        if (Math.abs(lane) > W2 - 1.5) c += 2.5;
        if (needRamp) c += Math.abs(lane) * 0.15;
        for (i = 0; i < T.obs.length; i++) {
          o = T.obs[i]; if (race.ko[i] && race.ko[i] > race.time) continue;
          ds = T.dS(s, o.s); if (ds < -2.5 || ds > look + 8) continue;
          if (o.type === 'icicle') { var ist = PG.icicleState(o, race.time + Math.max(0, ds) / vf); if (ist.ph === 0 || ist.ph === 4) continue; }
          PG.obsPos(T, o, race.time + Math.max(0, ds) / vf, pos);
          var gap = Math.abs(lane - pos[1]) - (o.r + 1.7 + (o.mov ? 0.8 : 0));
          if (gap < 0) c += (o.hit === 'snowman' ? 20 : 90) + (-gap) * 12 + (look - ds) * 0.4;
        }
        var holeNear = false;
        for (i = 0; i < T.holes.length; i++) {
          H = T.holes[i]; if (H.mode === 'full') continue; ds = T.dS(s, H.s0);
          if (ds > -4 && ds < look + 190) { holeNear = true; if (lane > H.d0 - 2.6 && lane < H.d1 + 2.6) c += 600; }
        }
        if (holeNear) c += Math.abs(lane - cur) * 1.2; // con una grieta parcial cerca, no cambiar de lado
        for (i = 0; i < race.traps.length; i++) { var tp = race.traps[i]; if (tp.owner === r.id && tp.age < 2) continue; ds = tp.u - r.u; if (ds > -2 && ds < look + 4 && Math.abs(lane - tp.d) < 2.8) c += 70; }
        for (i = 0; i < thr.length; i++) if (Math.abs(lane - thr[i]) < 2.7) c += 55;
        for (i = 0; T.routes && i < T.routes.length; i++) {
          var RT2 = T.routes[i]; ds = T.dS(s, RT2.s0);
          if (ds + RT2.w1 > -2 && ds + RT2.w0 < look + 8) { // los muros se esquivan; dentro del tramo no se pueden cruzar
            var wall0 = ds + RT2.w0 < 8;
            for (var wq = 0; wq < RT2.walls.length; wq++) {
              if (Math.abs(lane - RT2.walls[wq]) < 2.4) c += 90;
              if (wall0 && (lane > RT2.walls[wq]) !== (r.d > RT2.walls[wq])) c += 400;
            }
          }
          if (ds > 3 && ds < look + 230) {
            var key = i + ':' + (T.type === 'circuit' ? Math.floor(r.u / T.L) : 0); if (ai.rtPlan === undefined) ai.rtPlan = {};
            if (ai.rtPlan[key] === undefined) ai.rtPlan[key] = ai.rr() < [0.2, 0.5, 0.75, 0.92][race.diff | 0];
            if (ai.rtPlan[key] && lane > RT2.l0 + 1.4 && lane < RT2.l1 - 1.4) c -= 45;
          }
        }
        if (!needRamp) {
          for (i = 0; i < T.pads.length; i++) { var P = T.pads[i]; ds = T.dS(s, P.s); if (ds > 3 && ds < look + 30 && lane > P.d0 + 0.6 && lane < P.d1 - 0.6) c -= 16 * ai.greed; }
          for (i = 0; i < T.boxes.length; i++) {
            if (race.boxT[i] > race.time) continue; var B = T.boxes[i]; ds = T.dS(s, B.s);
            if (ds > 5 && ds < look + 28 && Math.abs(lane - B.d) < 1.9) c -= (r.item ? 3 : 11) * ai.greed;
          }
          for (i = 0; i < T.crys.length; i++) {
            if (race.crysT[i] > race.time) continue; var Cr = T.crys[i]; ds = T.dS(s, Cr.s);
            if (ds > 5 && ds < look + 34 && Math.abs(lane - Cr.d) < 2.4) c -= (r.ability ? 4 : 20) * ai.greed;
          }
        }
        if (ahead && aheadD < 18 && Math.abs(lane - ahead.d) < 2.2) c += 10 * (1.2 - ai.aggr);
        if (c < best) { best = c; bestLane = lane; }
      }
      ai.target = bestLane; ai.bestCost = best;
    }
    var target = clamp(needRamp ? ai.target * 0.5 : ai.target, -W2, W2);
    ai.laneSm += (target - ai.laneSm) * Math.min(1, dt * 5);
    var tgt = ai.laneSm;
    var gain = 1.35;
    if (T.routes && ai.rtPlan) { // ir decidido hacia la entrada del camino alternativo y mantenerse en su carril
      for (i = 0; i < T.routes.length; i++) {
        var RT3 = T.routes[i], dsr3 = T.dS(s, RT3.s0), key3 = i + ':' + (T.type === 'circuit' ? Math.floor(r.u / T.L) : 0);
        if (!ai.rtPlan[key3] || needRamp || dsr3 > 170 || dsr3 < -RT3.len + 8) continue;
        var blockedH = false; // una grieta parcial entre el bot y la entrada que cubre el carril: no ir en linea recta
        for (var hq4 = 0; hq4 < T.holes.length && !blockedH; hq4++) {
          var H4 = T.holes[hq4], dh4 = T.dS(s, H4.s0);
          if (H4.mode !== 'full' && dh4 > -6 && dh4 < dsr3 + 14 && RT3.lc > H4.d0 - 3 && RT3.lc < H4.d1 + 3) blockedH = true;
        }
        if (blockedH) continue;
        if (dsr3 > -(RT3.w0 - 3)) { tgt = RT3.lc; gain = dsr3 > 0 ? 3.0 : 2.2; } // la entrada sigue abierta
        else if (r.d > RT3.l0 + 0.3 && r.d < RT3.l1) { tgt = RT3.lc; gain = 1.8; } // ya dentro
        else ai.rtPlan[key3] = false; // llego tarde: sigue por la pista principal
      }
    }
    if (T.routes) { // dentro del tramo con muro: no intentar cruzarlo
      for (i = 0; i < T.routes.length; i++) {
        var RT4 = T.routes[i], dsr4 = T.dS(s, RT4.s0);
        if (dsr4 + RT4.w0 < 6 && dsr4 + RT4.w1 > 0 && r.grounded) for (var wq4 = 0; wq4 < RT4.walls.length; wq4++) {
          var w4 = RT4.walls[wq4];
          if (r.d > w4) tgt = Math.max(tgt, w4 + 1.9); else tgt = Math.min(tgt, w4 - 1.9);
        }
      }
    }
    var want = Math.atan2(clamp((tgt - r.d) * gain, -16, 16) - r.vl * 0.4, vf);
    want += q.cv * vf * 0.30 * (C.CENT / 0.42) * 0.5;
    inp.steer = clamp((want - r.psi) * 3.4, -1, 1);
    if (!r.grounded) inp.steer = clamp(-r.psi * 2, -1, 1);
    if (Math.abs(r.d) > T.W / 2 - 1.3) inp.steer = clamp(-Math.sign(r.d) * 0.6 - r.psi, -1, 1);

    // ---- saltos: lip de grieta completa y obstaculos sin salida ----
    if (r.grounded && ai.jumpCd <= 0) {
      if (fullHole) { var dl = T.dS(s, fullHole.s0); if (dl > 0.6 && dl < 3.6 && r.vf < 34) { inp.jump = true; ai.jumpCd = 1.2; } }
      if (!inp.jump && ai.bestCost > 80) {
        for (i = 0; i < T.obs.length; i++) {
          o = T.obs[i]; if (o.hit === 'snowman' || o.type === 'icicle' || (race.ko[i] && race.ko[i] > race.time)) continue;
          ds = T.dS(s, o.s); if (ds < vf * 0.2 || ds > vf * 0.36) continue;
          PG.obsPos(T, o, race.time + ds / vf, pos);
          if (Math.abs(pos[1] - r.d) < o.r + 1.8) { inp.jump = true; ai.jumpCd = 0.9; break; }
        }
      }
    }
    // proyectil a punto de alcanzarnos: saltarlo
    if (r.grounded && ai.jumpCd <= 0 && !inp.jump) {
      for (k = 0; k < race.proj.length; k++) {
        var pj2 = race.proj[k]; if (pj2.owner === r.id) continue;
        var rel = (pj2.u - r.u) * (pj2.dir || 1), vrel = Math.abs(pj2.vu - r.vf);
        if (rel < 0 && rel > -vrel * 0.30 && rel < -vrel * 0.14 && Math.abs(pj2.d - r.d) < 1.8 && ai.rr() < 0.7) { inp.jump = true; ai.jumpCd = 0.8; break; }
      }
    }
    // piruetas en el aire (si no hay grieta cerca)
    if (!r.grounded && !ai.inAir) { ai.inAir = true; var holeNear = false; for (i = 0; i < T.holes.length; i++) { var hd = T.dS(s, T.holes[i].s0); if (hd > -6 && hd < 170) holeNear = true; } ai.flipPlan = !holeNear && r.vy > 5 && ai.rr() < ai.trick; ai.flipAt = 0.16 + ai.rr() * 0.12; }
    else if (r.grounded) ai.inAir = false;
    if (ai.inAir && ai.flipPlan && r.air > ai.flipAt && r.air < 0.9) inp.jump = true;

    // ---- elastico suave ----
    var gap2 = race.leaderU - r.u;
    ai.rubber = 1 + clamp(gap2 / 500, -0.03, 0.07);
    r.ai.rubber = ai.rubber;

    // ---- terminado: piloto automatico ----
    if (r.finished) {
      inp.steer = clamp((0 - r.d) * 0.1 - r.psi * 2, -1, 1);
      if (r.u > (T.type === 'sprint' ? T.D : race.laps * T.L) + 22) inp.brake = 0.9; else inp.tuck = 0;
      return inp;
    }

    // ---- empujones: a quien va al lado (mejor si esta cerca del borde o de una grieta) ----
    if (rivalSide && r.pushCd <= 0 && ai.pushThink <= 0 && r.grounded) {
      ai.pushThink = 0.25;
      var dirp = rivalSide.d >= r.d ? 1 : -1, edge = Math.abs(rivalSide.d + dirp * 3) > T.W / 2 - 1.2;
      if (ai.rr() < ai.aggr * (edge ? 0.9 : 0.3) * [0.25, 1, 1.25, 1.6][race.diff | 0]) inp.push = true;
    }

    // ---- avalancha cerca: a todo gas ----
    var avD = race.av && race.time >= race.av.tGo ? r.u - race.avFront(race.time) : 1e9;
    if (avD < 90) { inp.tuck = 1; if (r.item && r.grounded) { inp.useItem = true; inp.aim = 1; } }
    // ---- objetos ----
    var threatened = false;
    for (k = 0; k < race.proj.length; k++) { var pj3 = race.proj[k]; if (pj3.owner !== r.id && (pj3.u - r.u) * (pj3.dir || 1) < 0 && (pj3.u - r.u) * (pj3.dir || 1) > -26 && Math.abs(pj3.d - r.d) < 3) threatened = true; }
    if (r.item) { // turbo (cohete) que se recarga solo
      ai.useDelay -= dt;
      if (ai.useDelay <= 0 && Math.abs(inp.steer) < 0.35 && r.grounded) { inp.useItem = true; inp.aim = 1; ai.useDelay = (1.2 + ai.rr() * 2.5) * [2.4, 1, 0.8, 0.5][race.diff | 0]; }
    }
    // ---- arma de nieve: dispara al rival mas conveniente (delante o detras) ----
    if (r.fx.cannon > 0 && ai.rr() < [0.35, 0.8, 1, 1][race.diff | 0]) {
      if (ahead && aheadD < 58 && Math.abs(ahead.d - r.d) < 8) { inp.fire = true; inp.aim = 1; }
      else if (behind && behindD < 42 && Math.abs(behind.d - r.d) < 8) { inp.fire = true; inp.aim = -1; }
    }
    // ---- habilidades ----
    ai.useDelay2 = (ai.useDelay2 || 0) - dt;
    if (r.ability) {
      var ua = false, aimA = 1;
      if (r.ability === 'cannon') ua = !!((ahead && aheadD > 6) || (behind && behindD < 40 && ai.aggr > 0.4));
      else if (r.ability === 'tornado') { for (k = 0; k < race.racers.length; k++) { var b3 = race.racers[k]; if (!b3.dead && b3 !== r && b3.u - r.u > -4 && b3.u - r.u < 35) ua = true; } }
      else if (r.ability === 'wings') ua = r.grounded && (r.rank > 2 ? ai.rr() < 0.04 : ai.rr() < 0.012) && !needRamp && !T.inCave(s, 60);
      else if (r.ability === 'grenade') ua = !!((ahead && aheadD > 8) || (behind && behindD < 34 && ai.aggr > 0.4));
      else if (r.ability === 'megaball') ua = r.rank > 1 && ai.rr() < 0.05;
      else if (r.ability === 'quake') { var nq = 0; for (k = 0; k < race.racers.length; k++) { var b4 = race.racers[k]; if (!b4.dead && b4 !== r && Math.abs(b4.u - r.u) < 45) nq++; } ua = nq >= 1 && ai.rr() < 0.08; }
      else if (r.ability === 'ghost') ua = threatened || (ai.rr() < 0.01 && (T.inCave(s, 20) || r.rank > 3));
      else if (r.ability === 'shield') ua = threatened || behindD < 20 || ai.rr() < 0.02;
      else if (r.ability === 'snow') { ua = !!((ahead && aheadD < 55) || (behind && behindD < 38 && ai.aggr > 0.25)); if (ua) aimA = (ahead && aheadD < 55) ? 1 : -1; }
      else if (r.ability === 'trap') { ua = !!((behind && behindD < 28) || (ahead && aheadD < 22 && Math.abs(ahead.d - r.d) < 5 && ai.aggr > 0.5)); if (ua) aimA = (behind && behindD < 28) ? -1 : 1; }
      else if (r.ability === 'hyper') ua = r.grounded && Math.abs(inp.steer) < 0.3 && !needRamp && (r.rank >= 3 || ai.rr() < 0.01 || avD < 110);
      else if (r.ability === 'missile') ua = !!(ahead && aheadD > 10);
      else if (r.ability === 'superjump') ua = r.grounded && ai.jumpCd <= 0 && !!fullHole && T.dS(s, fullHole.s0) < 4 && T.dS(s, fullHole.s0) > 0.5 && r.vf < 30;
      if (ua && r.ability === 'cannon' || ua && r.ability === 'grenade') { if (r.fx.cannon > 0) ua = false; }
      if (ua && ai.useDelay2 > 0) ua = false;
      if (ua) { inp.useAbility = true; inp.aimA = aimA; ai.useDelay2 = (0.8 + ai.rr() * 1.2) * [2, 1, 0.8, 0.5][race.diff | 0]; }
    }
    return inp;
  };
})();
