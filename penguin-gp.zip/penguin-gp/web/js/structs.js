/* v4.3: estructuras grandes de los mapas nuevos: barco naufragado, castillo congelado y decoracion navidena (mallas estaticas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI, shade = PG.shade, mix3 = PG.mix3, smooth = PG.smooth;
  var S = PG.structs = {};

  function H2(a, b, seed) { var x = Math.sin(a * 127.1 + b * 311.7 + seed * 3.3) * 43758.5453; return x - Math.floor(x); }
  // caja orientada (yaw) en coordenadas de mundo
  function OB(mb, x, y, z, yaw, sx, sy, sz, col, emi, pitch, roll) {
    mb.push().translate(x, y, z).rotY(yaw || 0); if (pitch) mb.rotX(pitch); if (roll) mb.rotZ(roll);
    mb.box(0, 0, 0, sx, sy, sz, col, emi); mb.pop();
  }
  function lerp3(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function cen4(a, b, c, d) { return [(a[0] + b[0] + c[0] + d[0]) / 4, (a[1] + b[1] + c[1] + d[1]) / 4, (a[2] + b[2] + c[2] + d[2]) / 4]; }
  // luz decorativa (halo aditivo): la dibuja game.js cuando esta cerca de la camara
  function light(T, x, y, z, size, col, a) { (T.lights = T.lights || []).push(x, y, z, size, col[0], col[1], col[2], a); }
  S.light = light; S.OB = OB; S.H2 = H2;
  // normal de las caras interiores: se orienta hacia el eje del tunel
  function inQuad(mb, a, b, c, d, axis, col, emi) { var m = cen4(a, b, c, d); mb.ref = [2 * m[0] - axis[0], 2 * m[1] - axis[1], 2 * m[2] - axis[2]]; mb.up = false; mb.quad(a, b, c, d, col, emi); mb.ref = null; }

  var WOOD = [0.42, 0.28, 0.17], WOODL = [0.56, 0.41, 0.27], WOODD = [0.25, 0.16, 0.10], SNOW = [0.96, 0.98, 1.0], ICEC = [0.72, 0.92, 1.0];

  /* ============================ BARCO: interior ============================ */
  S.shipTube = function (c) {
    var T = c.T, mb = c.mb, P = c.P, r0 = c.r0, r1 = c.r1, hw = c.hw, seed = c.seed, K = 28, ii, kk;
    function ribIn(i) { var m = (i - r0) % 8; if (m < 0) m += 8; return (m === 0 || m === 1) ? 0.95 : ((m === 7 || m === 2) ? 0.35 : 0); }
    function ring(i, k) {
      var phi = PI * k / K, cs = Math.cos(phi), sn = Math.sin(phi), edge = (k === 0 || k === K), ins = ribIn(i) * 0.9, H = T.caveH(i) - ins;
      var jg = edge ? 0 : (H2(i >> 1, k, seed) - 0.5) * 0.45;
      return P(i, -(hw + 0.5 - ins) * cs, (H + jg) * sn + (edge ? -0.4 : 0));
    }
    var rowI = null, axis;
    mb.cut();
    for (ii = r0; ii <= r1; ii++) {
      if ((ii - r0) % 20 === 0) mb.cut();
      var I1 = []; for (kk = 0; kk <= K; kk++) I1.push(ring(ii, kk));
      axis = P(ii, 0, T.caveH(ii) * 0.4);
      if (rowI) {
        var ribHere = ribIn(ii) > 0.5 || ribIn(ii - 1) > 0.5;
        for (kk = 0; kk < K; kk++) {
          var pid = Math.floor((ii + kk * 5) / 7), h = H2(pid, kk + 7, seed), sn2 = Math.sin(PI * (kk + 0.5) / K), col, em = 0;
          col = ribHere ? shade(WOODD, 0.82 + H2(ii, kk, seed) * 0.25) : shade((kk & 1) ? WOOD : WOODL, 0.78 + h * 0.3);
          if (!ribHere && (ii + kk * 5) % 7 === 0) col = shade(col, 0.62); // juntas de tablas (cada tabla mide ~10 m)
          col = mix3(col, SNOW, (1 - smooth(0.05, 0.30, sn2)) * 0.72); // nieve acumulada abajo, contra las paredes
          if (H2(ii >> 1, kk, seed + 9) > 0.95) col = mix3(col, SNOW, 0.75); // manchas de nieve que entran por las grietas
          else if (H2(ii >> 1, kk, seed + 11) > 0.985) col = mix3(col, ICEC, 0.5);
          if ((kk === K / 2 - 1 || kk === K / 2) && !ribHere && H2(ii, 41, seed) > 0.80) { col = [1.0, 0.95, 0.78]; em = 0.9; } // rendijas de luz en la cubierta
          inQuad(mb, rowI[kk], rowI[kk + 1], I1[kk + 1], I1[kk], axis, col, em);
        }
      }
      rowI = I1;
    }
    // ---- detalles interiores ----
    var side, rr;
    for (ii = r0 + 4; ii < r1 - 3; ii++) {
      var m8 = (ii - r0) % 8;
      if (m8 === 0) { // farol colgado de la cuaderna (alternando lados) + cuerda
        side = ((ii - r0) / 8 & 1) ? 1 : -1;
        var lp = P(ii, side * hw * 0.55, T.caveH(ii) * 0.60), lt = P(ii, side * hw * 0.55, T.caveH(ii) * 0.82);
        mb.box(lt[0], (lt[1] + lp[1]) / 2 + 0.5, lt[2], 0.06, lp[1] - lt[1] + 3.2, 0.06, [0.12, 0.1, 0.08], 0);
        mb.box(lp[0], lp[1], lp[2], 0.55, 0.8, 0.55, [1.0, 0.72, 0.3], 1); mb.box(lp[0], lp[1] + 0.5, lp[2], 0.7, 0.12, 0.7, [0.16, 0.14, 0.12], 0);
        light(T, lp[0], lp[1], lp[2], 9, [1.0, 0.68, 0.3], 0.34);
        if (H2(ii, 3, seed) > 0.4) { // carambanos colgando de la cuaderna
          for (var q = 0; q < 3; q++) { var kq = 4 + Math.floor(H2(ii, 12 + q, seed) * (K - 8)), ip = ring(ii, kq); mb.push().translate(ip[0], ip[1] + 0.2, ip[2]).rotX(PI); mb.cone(0, 0, 0, 0.35 + H2(ii, q, seed) * 0.4, 2.0 + H2(ii, 20 + q, seed) * 3.8, 5, ICEC, 0.35, true); mb.pop(); }
        }
      }
      if (m8 === 4 && (ii - r0) % 16 === 4) { // montones de cajas y barriles contra la pared
        side = (((ii - r0) / 16 | 0) & 1) ? 1 : -1; var dW = side * (10.8 + H2(ii, 5, seed) * 1.4), bp = P(ii, dW, T.bankShape(Math.abs(dW)) - 0.5), yw = H2(ii, 6, seed) * 6;
        OB(mb, bp[0], bp[1] + 1.1, bp[2], yw, 2.3, 2.3, 2.3, shade(WOOD, 0.85 + H2(ii, 7, seed) * 0.3), 0); OB(mb, bp[0], bp[1] + 2.9, bp[2], yw + 0.5, 2.1, 1.4, 2.1, shade(WOODL, 0.9), 0);
        mb.ell(bp[0], bp[1] + 3.7, bp[2], 1.5, 0.3, 1.5, 6, 3, SNOW, 0.04, 0.05);
        var bp2 = P(ii + 2, dW - side * 0.2, T.bankShape(Math.abs(dW)) - 0.4); mb.cyl(bp2[0], bp2[1], bp2[2], 0.8, 0.95, 2.1, 8, shade(WOOD, 0.8), 0); mb.cyl(bp2[0], bp2[1] + 1.0, bp2[2], 1.0, 1.0, 0.16, 8, [0.28, 0.3, 0.36], 0);
      }
      if (m8 === 6 && (ii - r0) % 24 === 6) { // canon sobre la pared (lado alternante)
        side = (((ii - r0) / 24 | 0) & 1) ? -1 : 1; var dC = side * 10.2, cp = P(ii, dC, T.bankShape(Math.abs(dC)) + 0.4);
        mb.push().translate(cp[0], cp[1] + 0.7, cp[2]).rotY(Math.atan2(c.T.tx[ii], c.T.tz[ii]) + side * 0.8); mb.rotX(-0.1);
        mb.cyl(0, 0, -1.4, 0.55, 0.42, 2.8, 8, [0.2, 0.22, 0.27], 0); mb.box(0, -0.3, -0.2, 1.2, 0.5, 1.6, WOODD, 0); mb.pop();
      }
      if (H2(ii, 61, seed) > 0.97) { // cuerda o tabla rota colgando del techo
        var tp = P(ii, (H2(ii, 62, seed) - 0.5) * 12, T.caveH(ii) * 0.75), ln = 2.5 + H2(ii, 63, seed) * 3.5;
        OB(mb, tp[0], tp[1] - ln / 2, tp[2], H2(ii, 64, seed) * 3, 0.1, ln, 0.1, [0.5, 0.42, 0.28], 0);
        if (H2(ii, 65, seed) > 0.5) OB(mb, tp[0], tp[1] - ln, tp[2], H2(ii, 66, seed) * 3, 0.5, 0.18, 2.4, WOODD, 0, 0, 0.5);
      }
    }
    // entrada y salida: tablas rotas que sobresalen del casco (esqueleto del barco)
    [[r0, -1], [r1, 1]].forEach(function (pe) {
      for (kk = 1; kk < K; kk += 2) {
        var ip = ring(pe[0], kk), ln = 1.5 + H2(pe[0] + kk, 77, seed) * 4.5, tx = T.tx[pe[0]] * pe[1], tz = T.tz[pe[0]] * pe[1];
        OB(mb, ip[0] + tx * ln * 0.5, ip[1], ip[2] + tz * ln * 0.5, Math.atan2(T.tx[pe[0]], T.tz[pe[0]]) + (H2(kk, 78, seed) - 0.5) * 0.25, 0.55, 0.5, ln, shade(WOODL, 0.8 + H2(kk, 79, seed) * 0.4), 0);
      }
    });
    mb.ref = null; mb.up = false;
  };

  /* ============================ BARCO: casco exterior y cubierta ============================ */
  S.shipExterior = function (c) {
    var T = c.T, mb = c.mb, P = c.P, r0 = c.r0, r1 = c.r1, hw = c.hw, seed = c.seed, K2 = 30, nR = r1 - r0, ii, kk, ds = T.ds;
    function tt(i) { return (i - r0) / nR; }
    function hullB(i) { var t = tt(i); return hw + 4.4 + 2.4 * Math.sin(PI * Math.min(1, Math.max(0, t))) + 1.6 * (1 - t) * (1 - t); }
    function deckH(i) { var t = tt(i); return T.caveH(i) + 2.9 + 4.6 * (1 - t) * (1 - t) * (1 - t) - 0.8 * smooth(0.7, 1, t); } // la popa (entrada) es mas alta, la proa esta rota y baja
    var YB = -1.7;
    function hull(i, k) {
      var B = hullB(i), Hd = deckH(i), L1 = Hd - YB, L2 = 2 * B * 0.9, tot = 2 * L1 + L2, s = k / K2 * tot, x, y;
      if (s < L1) { y = YB + s; x = -B * (1 - 0.1 * Math.pow((y - YB) / L1, 2)); }
      else if (s < L1 + L2) { var u = (s - L1) / L2; x = -B * 0.9 + u * 2 * B * 0.9; y = Hd + 0.55 * Math.sin(PI * u); }
      else { y = YB + (tot - s); x = B * (1 - 0.1 * Math.pow((y - YB) / L1, 2)); }
      var wale = (k === 5 || k === 6 || k === K2 - 5 || k === K2 - 6) ? 0.45 : 0; // cintones que sobresalen
      return P(i, x + (x < 0 ? -wale : wale), y);
    }
    var rowO = null, ctr;
    mb.cut();
    for (ii = r0; ii <= r1; ii++) {
      if ((ii - r0) % 16 === 0) mb.cut();
      var O1 = []; for (kk = 0; kk <= K2; kk++) O1.push(hull(ii, kk));
      ctr = P(ii, 0, T.caveH(ii) * 0.5);
      if (rowO) {
        for (kk = 0; kk < K2; kk++) {
          var pid = Math.floor((ii + kk * 4) / 10), h = H2(pid, kk + 3, seed + 20), top = (kk >= 9 && kk <= K2 - 10), col;
          col = shade((kk & 1) ? [0.30, 0.20, 0.14] : [0.37, 0.26, 0.18], 0.78 + h * 0.3);
          if ((ii + kk * 4) % 10 === 0) col = shade(col, 0.66);
          if (kk === 8 || kk === K2 - 9) col = [0.52, 0.12, 0.10]; // franja roja desteñida bajo la borda
          if (kk === 7 || kk === K2 - 8) col = [0.82, 0.78, 0.66];
          if (top) { // cubierta: nieve con tablas a la vista
            var sw = 0.78 - 0.45 * H2(ii >> 1, kk, seed + 25); col = mix3(shade(WOODL, 0.85 + h * 0.2), SNOW, sw);
          } else { // casco: nieve pegada abajo y en manchas
            var low = kk < 3 || kk > K2 - 3; if (low) col = mix3(col, SNOW, 0.85); else if (H2(ii >> 1, kk, seed + 27) > 0.9) col = mix3(col, SNOW, 0.7);
          }
          mb.up = false; mb.ref = ctr; mb.quad(rowO[kk], rowO[kk + 1], O1[kk + 1], O1[kk], col, 0); mb.ref = null;
        }
        // portillos de canon (cuadrados oscuros con marco) en los costados
        if ((ii - r0) % 7 === 3 && ii > r0 + 4 && ii < r1 - 4) for (var sd = 0; sd < 2; sd++) {
          var pp = hull(ii, sd ? K2 - 12 : 12), pq = P(ii, (sd ? 1 : -1) * (hullB(ii) + 0.2), YB + 7.8);
          var yaw = Math.atan2(T.tx[ii], T.tz[ii]); OB(mb, pq[0], pq[1], pq[2], yaw, 0.35, 2.0, 2.0, WOODD, 0); OB(mb, pq[0], pq[1], pq[2], yaw, 0.55, 1.4, 1.4, [0.04, 0.04, 0.05], 0);
        }
      }
      rowO = O1;
    }
    // caras de corte en los extremos (madera clara) y vigas rotas que sobresalen
    [[r0, -1], [r1, 1]].forEach(function (pe) {
      var i = pe[0], ctr2 = P(i - pe[1] * 12, 0, 8);
      for (kk = 0; kk < K2; kk++) {
        var oa = hull(i, kk), ob = hull(i, kk + 1), ia = P(i, 0, 0);
        // anillo entre la cubierta interior y el casco exterior: se rellena con puntos del arco interior
        var kin = Math.round(kk / K2 * 28), kin2 = Math.round((kk + 1) / K2 * 28), ph1 = PI * kin / 28, ph2 = PI * kin2 / 28;
        var ina = P(i, -(hw + 0.5) * Math.cos(ph1), T.caveH(i) * Math.sin(ph1) + (kin === 0 || kin === 28 ? -0.4 : 0)), inb = P(i, -(hw + 0.5) * Math.cos(ph2), T.caveH(i) * Math.sin(ph2) + (kin2 === 0 || kin2 === 28 ? -0.4 : 0));
        mb.up = false; mb.ref = ctr2; mb.quad(ina, inb, ob, oa, shade((kk & 1) ? [0.74, 0.58, 0.37] : [0.55, 0.40, 0.25], 0.88 + H2(kk, i, seed) * 0.2), 0); mb.ref = null;
      }
      for (kk = 0; kk <= K2; kk += 2) {
        var op = hull(i, kk), ln = 1.2 + H2(i + kk, 91, seed) * 6.5;
        if (H2(kk, 92 + i, seed) > 0.78) continue;
        OB(mb, op[0] + T.tx[i] * pe[1] * ln * 0.5, op[1], op[2] + T.tz[i] * pe[1] * ln * 0.5, Math.atan2(T.tx[i], T.tz[i]) + (H2(kk, 93, seed) - 0.5) * 0.3, 0.7, 0.7, ln, shade(WOODL, 0.7 + H2(kk, 94, seed) * 0.4), 0, (H2(kk, 95, seed) - 0.5) * 0.2);
        if (kk > 8 && kk < K2 - 8) mb.ell(op[0] + T.tx[i] * pe[1] * ln * 0.5, op[1] + 0.45, op[2] + T.tz[i] * pe[1] * ln * 0.5, 0.5, 0.2, ln * 0.5, 5, 3, SNOW, 0.04, 0.05);
      }
    });
    mb.ref = null;
    // ---- cubierta: borda, castillo de popa, mastiles, velas rotas, aparejo ----
    var yawOf = function (i) { return Math.atan2(T.tx[i], T.tz[i]); };
    for (ii = r0 + 2; ii < r1 - 1; ii += 4) { // balaustrada con tramos rotos
      if (H2(ii, 100, seed) > 0.72) continue;
      for (var sdn = -1; sdn <= 1; sdn += 2) {
        var B = hullB(ii) * 0.9, bp = P(ii, sdn * B, deckH(ii) + 0.55), yy = yawOf(ii);
        OB(mb, bp[0], bp[1] + 0.9, bp[2], yy, 0.4, 1.8, 0.4, WOODD, 0);
        if (H2(ii, 101 + sdn, seed) > 0.25) { OB(mb, bp[0], bp[1] + 1.55, bp[2] + T.tz[ii] * ds * 2, yy, 0.22, 0.28, ds * 4.1, WOOD, 0); mb.ell(bp[0], bp[1] + 1.8, bp[2] + T.tz[ii] * ds * 2, 0.22, 0.12, ds * 2, 5, 3, SNOW, 0.04, 0.04); }
      }
    }
    var iC = r0 + Math.round(nR * 0.1); // castillo de popa
    (function () {
      var len = Math.round(nR * 0.2), hB = hullB(iC) * 0.8, base = deckH(iC) + 0.5, i;
      for (i = iC; i < iC + len; i += 2) {
        var cp = P(i + 1, 0, base + 4.2), yy = yawOf(i);
        OB(mb, cp[0], cp[1], cp[2], yy, hB * 1.5, 8.4, ds * 2.05, shade(WOOD, 0.9 + H2(i, 110, seed) * 0.2), 0);
        if ((i - iC) % 4 === 0) for (var sdw = -1; sdw <= 1; sdw += 2) { var wp = P(i + 1, sdw * (hB * 0.75 + 0.1), base + 4.6); OB(mb, wp[0], wp[1], wp[2], yy, 0.3, 1.5, 1.2, [1.0, 0.75, 0.35], 0.95); light(T, wp[0], wp[1], wp[2], 6, [1.0, 0.72, 0.3], 0.3); }
      }
      var rp = P(iC + len / 2, 0, base + 9.2); OB(mb, rp[0], rp[1], rp[2], yawOf(iC), hB * 1.7, 1.0, len * ds * 1.1, shade(WOODD, 1.0), 0);
      mb.ell(rp[0], rp[1] + 0.9, rp[2], hB * 0.85, 0.55, len * ds * 0.55, 8, 3, SNOW, 0.05, 0.06);
      var chp = P(iC + len * 0.7, hB * 0.4, base + 11); mb.cyl(chp[0], chp[1], chp[2], 0.9, 0.9, 3.5, 7, [0.32, 0.28, 0.28], 0); mb.ell(chp[0], chp[1] + 3.6, chp[2], 1.0, 0.3, 1.0, 6, 3, SNOW, 0.05, 0.05);
    })();
    function mast(frac, hgt, snapTop, yardLen) {
      var i = r0 + Math.round(nR * frac), mp = P(i, 0, deckH(i) + 0.4), yy = yawOf(i);
      mb.cyl(mp[0], mp[1], mp[2], 1.5, 1.1, hgt, 8, shade(WOOD, 0.8), 0);
      for (var b = 0; b < 3; b++) mb.cyl(mp[0], mp[1] + 2 + b * (hgt / 3.4), mp[2], 1.62 - b * 0.18, 1.62 - b * 0.18, 0.28, 8, [0.2, 0.2, 0.25], 0);
      if (snapTop) { mb.push().translate(mp[0], mp[1] + hgt, mp[2]); mb.cone(0, 0, 0, 1.1, 2.4, 5, shade(WOODL, 0.85), 0, true); mb.pop(); }
      mb.ell(mp[0], mp[1] + 0.6, mp[2], 3.2, 1.0, 3.2, 8, 3, SNOW, 0.04, 0.06);
      if (yardLen) { // verga con vela hecha jirones
        var yh = hgt * 0.72; OB(mb, mp[0], mp[1] + yh, mp[2], yy, yardLen, 0.55, 0.55, shade(WOOD, 0.75), 0, 0, 0.07);
        for (var j = 0; j < 9; j++) { var xj = (j - 4) * yardLen / 9.5, drop = 3.5 + H2(j, i, seed) * 7; OB(mb, mp[0] + T.rx[i] * xj, mp[1] + yh - drop / 2 - 0.3, mp[2] + T.rz[i] * xj + 0.2, yy, yardLen / 9.7, drop, 0.14, shade([0.84, 0.80, 0.70], 0.8 + H2(j, 5 + i, seed) * 0.3), 0, 0, (H2(j, 9, seed) - 0.5) * 0.1); }
        for (var sdr = -1; sdr <= 1; sdr += 2) { var ep = P(i, sdr * hullB(i) * 0.85, deckH(i) + 0.5); // cabos del aparejo
          var mx = (mp[0] + ep[0]) / 2, my = (mp[1] + hgt * 0.8 + ep[1]) / 2, mz = (mp[2] + ep[2]) / 2, dx = ep[0] - mp[0], dy = ep[1] - (mp[1] + hgt * 0.8), dz = ep[2] - mp[2], ll = Math.hypot(dx, dy, dz);
          mb.push().translate(mx, my, mz).rotY(Math.atan2(dx, dz)).rotX(-Math.asin(dy / ll)); mb.box(0, 0, 0, 0.1, 0.1, ll, [0.44, 0.38, 0.26], 0); mb.pop(); }
      }
    }
    mast(0.5, 26, true, 17); mast(0.82, 11, true, 0);
    // palo caido atravesado sobre la cubierta, con vela enredada
    (function () {
      var i = r0 + Math.round(nR * 0.66), mp = P(i, -3, deckH(i) + 1.6), mq = P(i + 18, hullB(i) * 0.9, deckH(i) + 4);
      var dx = mq[0] - mp[0], dy = mq[1] - mp[1], dz = mq[2] - mp[2], ll = Math.hypot(dx, dy, dz);
      mb.push().translate((mp[0] + mq[0]) / 2, (mp[1] + mq[1]) / 2, (mp[2] + mq[2]) / 2).rotY(Math.atan2(dx, dz)).rotX(-Math.asin(dy / ll));
      mb.cyl(0, 0, -ll / 2, 0.9, 0.9, 0.001, 6, WOOD, 0); mb.push().rotX(PI / 2); mb.cyl(0, -ll / 2, 0, 0.9, 0.7, ll, 8, shade(WOOD, 0.85), 0); mb.pop();
      mb.box(0.3, 0.9, 0, 0.14, 1.8, ll * 0.7, [0.82, 0.78, 0.68], 0); mb.ell(0, 1.9, 0, 0.5, 0.2, ll * 0.34, 6, 3, SNOW, 0.04, 0.05);
      mb.pop();
    })();
    // barriles, cajas y ancla sobre la cubierta; montones de nieve al pie del casco
    for (ii = r0 + 6; ii < r1 - 4; ii += 9) {
      if (H2(ii, 120, seed) > 0.62) continue;
      var bd = (H2(ii, 121, seed) - 0.5) * hullB(ii) * 1.2, bq = P(ii, bd, deckH(ii) + 0.6);
      if (H2(ii, 122, seed) > 0.5) { mb.cyl(bq[0], bq[1], bq[2], 0.85, 1.0, 1.0, 8, shade(WOOD, 0.8), 0); mb.cyl(bq[0], bq[1] + 1.0, bq[2], 1.0, 0.85, 1.0, 8, shade(WOOD, 0.8), 0); mb.ell(bq[0], bq[1] + 2.0, bq[2], 0.9, 0.2, 0.9, 6, 3, SNOW, 0.05, 0.04); }
      else { OB(mb, bq[0], bq[1] + 1.1, bq[2], H2(ii, 123, seed) * 6, 2.2, 2.2, 2.2, shade(WOODL, 0.8), 0); mb.ell(bq[0], bq[1] + 2.35, bq[2], 1.2, 0.25, 1.2, 6, 3, SNOW, 0.05, 0.05); }
    }
    for (ii = r0 - 2; ii <= r1 + 2; ii += 7) for (var sg = -1; sg <= 1; sg += 2) {
      var sp = P(ii + Math.round((H2(ii, 133, seed) - 0.5) * 5), sg * (hullB(Math.min(r1, Math.max(r0, ii))) + 0.2 + H2(ii, 130 + sg, seed) * 3.2), -1.3);
      mb.ell(sp[0], sp[1] + 0.2, sp[2], 4.5 + H2(ii, 131, seed) * 3.5, 1.1 + H2(ii, 132, seed) * 1.1, 8 + H2(ii, 134, seed) * 5, 8, 4, mix3(SNOW, [0.84, 0.92, 1.0], 0.35), 0.04, 0.2);
    }
    (function () { // ancla grande apoyada en el casco, cerca de la proa
      var i = r0 + Math.round(nR * 0.78), ap = P(i, hullB(i) + 0.9, YB + 6.5), yy = yawOf(i) + PI / 2, ak = [0.20, 0.22, 0.27];
      mb.push().translate(ap[0], ap[1], ap[2]).rotY(yy).rotZ(0.25); mb.box(0, 0, 0, 0.6, 9, 0.6, ak, 0); mb.box(0, 4.2, 0, 3.6, 0.55, 0.55, ak, 0);
      mb.box(-1.8, -3.6, 0, 0.55, 1.8, 0.5, ak, 0); mb.box(1.8, -3.6, 0, 0.55, 1.8, 0.5, ak, 0); mb.box(0, -4.4, 0, 4.2, 0.5, 0.5, ak, 0); mb.ell(0, 4.8, 0, 0.9, 0.9, 0.3, 7, 4, ak, 0, 0.05); mb.pop();
    })();
    // carambanos y cristales de hielo en el casco y la borda
    for (ii = r0 + 3; ii < r1 - 2; ii += 3) for (var s3 = -1; s3 <= 1; s3 += 2) {
      if (H2(ii, 140 + s3, seed) > 0.55) continue;
      var ip2 = P(ii, s3 * hullB(ii) * 0.92, deckH(ii) + 0.3); mb.push().translate(ip2[0], ip2[1], ip2[2]).rotX(PI); mb.cone(0, 0, 0, 0.3 + H2(ii, 141, seed) * 0.3, 1.6 + H2(ii, 142, seed) * 3.0, 5, ICEC, 0.4, true); mb.pop();
    }
    for (ii = r0 + 10; ii < r1 - 6; ii += 23) {
      var cs = (ii / 23 & 1) ? 1 : -1, cq = P(ii, cs * (hullB(ii) + 3.5), -0.8), gc = [[0.5, 0.9, 1.0], [0.62, 0.78, 1.0]][ii & 1];
      mb.push().translate(cq[0], cq[1], cq[2]); mb.crystal(0, 0, 0, 1.1, 5.2, gc, 0.7, 6); mb.push().rotZ(0.5); mb.crystal(0.3, 0, 0, 0.7, 3.4, shade(gc, 0.9), 0.7, 5); mb.pop(); mb.pop();
      light(T, cq[0], cq[1] + 3, cq[2], 9, gc, 0.2);
    }
    // explanada de nieve entre el casco y el borde de las bermas (las filas de la cueva no llevan bermas)
    mb.up = true; mb.ref = null;
    for (ii = r0 - 2; ii < r1 + 2; ii += 2) for (var sa = -1; sa <= 1; sa += 2) {
      if (ii % 40 === 0) mb.cut();
      var ib = Math.max(r0, Math.min(r1, ii)), ib2 = Math.max(r0, Math.min(r1, ii + 2)), b0 = hullB(ib) - 1.0, b1 = hullB(ib2) - 1.0, D1 = hw + 26;
      var a0 = P(ii, sa * b0, -1.2), a1 = P(ii + 2, sa * b1, -1.2), a2 = P(ii + 2, sa * D1, -1.5), a3 = P(ii, sa * D1, -1.5);
      mb.quad(a0, a1, a2, a3, shade(mix3(SNOW, [0.84, 0.92, 1.0], 0.3 + 0.25 * H2(ii >> 1, sa, seed + 50)), 0.96 + H2(ii, sa, seed) * 0.06), 0);
    }
    mb.ref = null; mb.up = false;
  };

  /* ============================ CASTILLO: interior (salon / mazmorra / murallas) ============================ */
  var STONE = [0.46, 0.50, 0.70], STONEL = [0.60, 0.64, 0.84], STONED = [0.30, 0.33, 0.52], BLUEC = [0.18, 0.30, 0.78], METAL = [0.30, 0.34, 0.45];
  S.castleTube = function (c) {
    var T = c.T, mb = c.mb, P = c.P, r0 = c.r0, r1 = c.r1, hw = c.hw, seed = c.seed + (c.br || 0) * 17, K = 24, ii, kk;
    function ribIn(i) { if (i <= r0 + 1 || i >= r1 - 1) return 0; var m = (i - r0 - 5) % 10; if (m < 0) m += 10; return (m === 0 || m === 1) ? 1.1 : ((m === 9 || m === 2) ? 0.4 : 0); }
    function ring(i, k) {
      var phi = PI * k / K, cs = Math.cos(phi), sn = Math.sin(phi), edge = (k === 0 || k === K), ins = ribIn(i), H = T.caveH(i) - ins * 0.8;
      return P(i, -(hw + 0.5 - ins) * cs, H * sn + (edge ? -0.4 : 0));
    }
    c.ring = ring;
    var rowI = null, axis;
    mb.cut();
    for (ii = r0; ii <= r1; ii++) {
      if ((ii - r0) % 20 === 0) mb.cut();
      var I1 = []; for (kk = 0; kk <= K; kk++) I1.push(ring(ii, kk));
      axis = P(ii, 0, T.caveH(ii) * 0.4);
      if (rowI) {
        var ribHere = ribIn(ii) > 0.5 || ribIn(ii - 1) > 0.5, mw = (ii - r0) % 14;
        for (kk = 0; kk < K; kk++) {
          var blk = Math.floor((ii + (kk & 1)) / 2), h = H2(blk, kk, seed + 5), sn2 = Math.sin(PI * (kk + 0.5) / K), col, em = 0;
          col = ribHere ? shade(STONEL, 0.88 + h * 0.2) : shade(STONE, 0.8 + 0.32 * h);
          if (!ribHere && kk % 3 === 0) col = shade(col, 0.88); // hiladas de sillares
          if (!ribHere && (kk === 6 || kk === 7 || kk === K - 7 || kk === K - 8) && mw >= 3 && mw <= 8) { // vidrieras de hielo iluminadas por la aurora
            if (mw === 3 || mw === 8 || kk === 6 || kk === K - 7) col = shade(STONED, 0.9); else { col = [0.45, 0.85, 1.0]; em = 0.85; }
          }
          col = mix3(col, ICEC, smooth(0.78, 1.0, sn2) * 0.4 + (H2(ii >> 1, kk, seed + 8) > 0.93 ? 0.5 : 0)); // escarcha en la boveda
          col = mix3(col, SNOW, (1 - smooth(0.05, 0.22, sn2)) * 0.55);
          inQuad(mb, rowI[kk], rowI[kk + 1], I1[kk + 1], I1[kk], axis, col, em);
        }
      }
      rowI = I1;
    }
    var side, phi3;
    for (ii = r0 + 4; ii < r1 - 3; ii++) {
      var m14 = (ii - r0) % 14, Hc = T.caveH(ii);
      if (m14 === 7) { // antorcha en la pared (alterna lados)
        side = (((ii - r0) / 14 | 0) & 1) ? 1 : -1; var wp = ring(ii, side > 0 ? K - 3 : 3), ax = P(ii, 0, Hc * 0.3), tp = lerp3(wp, ax, 0.04);
        mb.box(tp[0], tp[1], tp[2], 0.5, 0.18, 0.5, METAL, 0); mb.box(tp[0], tp[1] + 0.5, tp[2], 0.2, 1.0, 0.2, [0.3, 0.2, 0.12], 0);
        mb.push().translate(tp[0], tp[1] + 1.0, tp[2]); mb.cone(0, 0, 0, 0.42, 1.3, 6, [1.0, 0.62, 0.16], 1); mb.cone(0, 0.1, 0, 0.24, 0.9, 5, [1.0, 0.9, 0.5], 1); mb.pop();
        light(T, tp[0], tp[1] + 1.4, tp[2], 8, [1.0, 0.6, 0.22], 0.36);
      }
      if (m14 === 0 && ii > r0 + 6) { // estandartes colgando de la boveda
        for (side = -1; side <= 1; side += 2) {
          var bx = side * hw * 0.74, archY = Hc * Math.sqrt(Math.max(0.05, 1 - Math.pow(bx / (hw + 0.5), 2))), bp = P(ii, bx, archY - 3.7), yy = Math.atan2(T.tx[ii], T.tz[ii]), bi = ((ii - r0) / 14 | 0) & 1;
          OB(mb, bp[0], bp[1], bp[2], yy, 0.14, 6.6, 3.0, bi ? [0.93, 0.95, 1.0] : BLUEC, 0.15);
          OB(mb, bp[0], bp[1] + 0.6, bp[2], yy, 0.2, 1.4, 1.4, [1.0, 0.82, 0.3], 0.55, 0, 0.785); // emblema dorado
          OB(mb, bp[0], bp[1] + 3.45, bp[2], yy, 0.3, 0.3, 3.4, METAL, 0);
          for (var fq = -1; fq <= 1; fq += 2) { mb.push().translate(bp[0] + T.rx[ii] * 0 , bp[1] - 3.3, bp[2] + fq * 1.0).rotX(PI); mb.cone(0, 0, 0, 0.3, 0.8, 4, [1.0, 0.82, 0.3], 0.3, true); mb.pop(); }
        }
      }
      if (m14 === 3) for (var q = 0; q < 2; q++) { // carambanos de la boveda
        if (H2(ii, 10 + q, seed) > 0.55) continue;
        var kq = 4 + Math.floor(H2(ii, 12 + q, seed) * (K - 8)), ip = ring(ii, kq);
        mb.push().translate(ip[0], ip[1] + 0.2, ip[2]).rotX(PI); mb.cone(0, 0, 0, 0.3 + H2(ii, q, seed) * 0.4, 2.0 + H2(ii, 20 + q, seed) * 3.5, 5, ICEC, 0.4, true); mb.pop();
      }
      if ((ii - r0) % 11 === 5) { // cristales de hielo brillantes en las esquinas del suelo
        side = (((ii - r0) / 11 | 0) & 1) ? 1 : -1; var cp = P(ii, side * (hw - 0.3), 0.2), gc = [[0.45, 0.9, 1.0], [0.62, 0.7, 1.0], [0.75, 0.55, 1.0]][ii % 3];
        mb.push().translate(cp[0], cp[1], cp[2]); mb.crystal(0, 0, 0, 0.8, 3.4 + H2(ii, 2, seed) * 1.6, gc, 0.8, 6); mb.push().rotZ(0.5 * side); mb.crystal(0.1, 0, 0, 0.5, 2.1, shade(gc, 0.9), 0.8, 5); mb.pop(); mb.pop();
        light(T, cp[0], cp[1] + 2, cp[2], 6, gc, 0.2);
      }
      if (c.main && (ii - r0) % 36 === 18) { // araña de luces colgando del centro de la boveda
        var chp = P(ii, 0, T.caveH(ii) - 3.6);
        mb.box(chp[0], chp[1] + 2.0, chp[2], 0.1, 3.4, 0.1, METAL, 0); mb.cyl(chp[0], chp[1], chp[2], 1.6, 1.6, 0.18, 12, METAL, 0);
        for (var cn = 0; cn < 8; cn++) { var ca = cn / 8 * 2 * PI; mb.box(chp[0] + Math.cos(ca) * 1.5, chp[1] + 0.55, chp[2] + Math.sin(ca) * 1.5, 0.16, 0.5, 0.16, [0.95, 0.95, 0.85], 0); mb.cone(chp[0] + Math.cos(ca) * 1.5, chp[1] + 0.8, chp[2] + Math.sin(ca) * 1.5, 0.14, 0.34, 4, [1.0, 0.8, 0.35], 1); }
        light(T, chp[0], chp[1] + 0.6, chp[2], 11, [1.0, 0.8, 0.45], 0.4);
      }
    }
    // rastrillos (portcullis) alzados en la entrada y la salida
    [r0 + 1, r1 - 1].forEach(function (gi) {
      var yy = Math.atan2(T.tx[gi], T.tz[gi]), Hg = T.caveH(gi);
      for (var d = -hw + 1.2; d <= hw - 1.1; d += 1.7) {
        var archY = Hg * Math.sqrt(Math.max(0.01, 1 - Math.pow(d / (hw + 0.5), 2))), ln = Math.min(6.5, archY - 4.5); if (ln < 0.8) continue;
        var bp = P(gi, d, archY - ln / 2 - 0.15); mb.mat = 5; OB(mb, bp[0], bp[1], bp[2], yy, 0.22, ln, 0.22, METAL, 0); mb.cone(bp[0], bp[1] - ln / 2, bp[2], 0.2, 0.6, 4, [0.7, 0.74, 0.85], 0.04, false); mb.mat = 0;
      }
      for (var hy = 0; hy < 3; hy++) { var hp = P(gi, 0, Hg - 2.6 - hy * 1.9), ww = hw * 1.7 * Math.sqrt(Math.max(0.05, 1 - Math.pow((Hg - 2.6 - hy * 1.9) / Hg, 2))); mb.mat = 5; OB(mb, hp[0], hp[1], hp[2], yy, ww, 0.2, 0.2, METAL, 0); mb.mat = 0; }
    });
    mb.ref = null; mb.up = false;
  };

  /* ============================ CASTILLO: fortaleza exterior ============================ */
  S.castleExterior = function (c) {
    var T = c.T, mb = c.mb, P = c.P, r0 = c.r0, r1 = c.r1, hw = c.hw, seed = c.seed, C = T.castle, off = C.off, hwB = C.W / 2, K = 24, ds = T.ds, ii, kk;
    var Wc = off + hwB + 8, Hw = 29, rc = (r0 + r1) >> 1, routes = [{ d: -off, a: hwB + 0.5 }, { d: 0, a: hw + 0.5 }, { d: off, a: hwB + 0.5 }];
    function yawOf(i) { return Math.atan2(T.tx[i], T.tz[i]); }
    function stoneCol(a, b, tone) { var h = H2(a, b, seed + 31), c = shade(STONE, (tone || 1) * (0.78 + 0.36 * h)); if ((a + b) % 5 === 0) c = shade(c, 0.9); return mix3(c, SNOW, Math.max(0, H2(a >> 1, b, seed + 33) - 0.9) * 5); }
    // rejilla de sillares en un plano vertical entre dos puntos base (a y b) de y0 a y1
    function grid(pa, pb, y0, y1, cw, ch, ref, tone, tag) {
      var len = Math.hypot(pb[0] - pa[0], pb[2] - pa[2]), nx = Math.max(1, Math.round(len / cw)), ny = Math.max(1, Math.round((y1 - y0) / ch)), i, j;
      for (j = 0; j < ny; j++) for (i = 0; i < nx; i++) {
        var u0 = i / nx, u1 = (i + 1) / nx, ya = y0 + (y1 - y0) * j / ny, yb = y0 + (y1 - y0) * (j + 1) / ny;
        var A = [pa[0] + (pb[0] - pa[0]) * u0, pa[1] + ya, pa[2] + (pb[2] - pa[2]) * u0], B = [pa[0] + (pb[0] - pa[0]) * u1, pa[1] + ya, pa[2] + (pb[2] - pa[2]) * u1];
        var C2 = [B[0], pa[1] + yb, B[2]], D = [A[0], pa[1] + yb, A[2]];
        mb.up = false; mb.ref = ref; mb.quad(A, B, C2, D, stoneCol(i + (tag || 0), j, tone), 0); mb.ref = null;
      }
    }
    var inside = P(rc, 0, Hw * 0.5);
    mb.cut();
    // ---- caras delanteras (entrada) y traseras (salida) con tres puertas en arco ----
    [[r0, -1], [r1, 1]].forEach(function (fe) {
      var i = fe[0], Hc = T.caveH(i), j;
      mb.cut();
      routes.forEach(function (R) {
        var aw = R.a + 2.4, Ht = Hc + 5.2, prevA = null, prevO = null;
        for (kk = 0; kk <= K; kk++) {
          var phi = PI * kk / K, cs = Math.cos(phi), sn = Math.sin(phi), A = P(i, R.d - R.a * cs, Hc * sn + (kk === 0 || kk === K ? -0.4 : 0));
          var tmax = Math.min(Math.abs(cs) < 1e-6 ? 1e9 : aw / Math.abs(cs), sn < 1e-6 ? 1e9 : Ht / sn), O = P(i, R.d - tmax * cs, tmax * sn + (kk === 0 || kk === K ? -0.4 : 0));
          if (prevA) { mb.up = false; mb.ref = inside; mb.quad(prevA, A, O, prevO, shade(STONEL, 0.85 + H2(kk, i, seed) * 0.25), 0); mb.ref = null; }
          prevA = A; prevO = O;
        }
        // clave del arco (piedra con hielo) y antorchas de la puerta
        var kp = P(i, R.d, Hc + 0.6); OB(mb, kp[0], kp[1] + 0.7, kp[2], yawOf(i), 2.0, 1.8, 1.4, shade(STONEL, 1.05), 0);
        for (var sd = -1; sd <= 1; sd += 2) { var tq = P(i + fe[1] * -1, R.d + sd * (R.a + 1.2), 6.4); mb.box(tq[0], tq[1], tq[2], 0.5, 1.6, 0.5, [0.3, 0.2, 0.12], 0); mb.push().translate(tq[0], tq[1] + 0.8, tq[2]); mb.cone(0, 0, 0, 0.5, 1.5, 6, [1.0, 0.6, 0.16], 1); mb.pop(); light(T, tq[0], tq[1] + 1.4, tq[2], 9, [1.0, 0.6, 0.22], 0.4); }
      });
      // muro entre puertas y a los lados, y banda sobre las puertas
      var edges = [-Wc, -off - routes[0].a - 2.4, -off + routes[0].a + 2.4, -routes[1].a - 2.4, routes[1].a + 2.4, off - routes[2].a - 2.4, off + routes[2].a + 2.4, Wc];
      for (j = 0; j < edges.length; j += 2) { var pa = P(i, edges[j], -1.6), pb = P(i, edges[j + 1], -1.6); grid(pa, pb, 0, Hw + 1.6, 2.8, 3.3, inside, 1, j); }
      var topA = P(i, -off - routes[0].a - 2.4, 0), topB = P(i, off + routes[2].a + 2.4, 0); grid([topA[0], T.py[i] + Hc + 5.2, topA[2]], [topB[0], T.py[i] + Hc + 5.2, topB[2]], 0, Hw - Hc - 5.2, 2.8, 3.1, inside, 1.04, 9);
      var cb = P(i + fe[1] * -0.5, 0, Hc + 5.3); OB(mb, cb[0], cb[1], cb[2], yawOf(i), (off + routes[2].a + 2.4) * 2, 0.7, 1.4, shade(STONEL, 1.0), 0);
      // escudo / emblema de hielo sobre la puerta central
      var ep = P(i + fe[1] * -0.7, 0, Hc + 11.5); OB(mb, ep[0], ep[1], ep[2], yawOf(i), 7.5, 8.5, 0.8, shade(BLUEC, 0.9), 0.1); OB(mb, ep[0], ep[1], ep[2], yawOf(i), 5.4, 6.4, 1.0, [0.93, 0.96, 1.0], 0.2); OB(mb, ep[0], ep[1], ep[2], yawOf(i), 2.0, 5.2, 1.2, [0.55, 0.85, 1.0], 0.8); OB(mb, ep[0], ep[1], ep[2], yawOf(i), 4.6, 1.8, 1.2, [0.55, 0.85, 1.0], 0.8);
      light(T, ep[0], ep[1], ep[2], 10, [0.5, 0.85, 1.0], 0.3);
    });
    // ---- muros laterales ----
    for (var sg = -1; sg <= 1; sg += 2) {
      for (ii = r0; ii < r1; ii += 3) {
        if ((ii - r0) % 30 === 0) mb.cut();
        var pa2 = P(ii, sg * Wc, -1.6), pb2 = P(Math.min(r1, ii + 3), sg * Wc, -1.6);
        grid(pa2, pb2, 0, Hw + 1.6, 3.2, 3.3, inside, 1, ii);
        if (((ii - r0) / 3 | 0) % 4 === 2) for (var wy = 0; wy < 2; wy++) { // ventanas iluminadas de la muralla
          var wq = P(ii + 1.5, sg * (Wc + 0.15), 14 + wy * 6.4); OB(mb, wq[0], wq[1], wq[2], yawOf(ii), 0.4, 3.2, 2.0, [0.2, 0.22, 0.4], 0); OB(mb, wq[0], wq[1], wq[2], yawOf(ii), 0.55, 2.4, 1.3, [0.55, 0.9, 1.0], 0.9);
        }
      }
    }
    // ---- terraza superior con nieve, almenas y carambanos ----
    mb.up = true; mb.ref = null;
    for (ii = r0; ii < r1; ii += 4) { if ((ii - r0) % 40 === 0) mb.cut(); var t0 = P(ii, -Wc, Hw + 1.6), t1 = P(ii + 4, -Wc, Hw + 1.6), t2 = P(ii + 4, Wc, Hw + 1.6), t3 = P(ii, Wc, Hw + 1.6); mb.quad(t0, t1, t2, t3, shade(mix3(SNOW, [0.8, 0.88, 1.0], 0.3), 0.97 + H2(ii, 3, seed) * 0.05), 0); }
    mb.up = false;
    for (sg = -1; sg <= 1; sg += 2) for (ii = r0; ii <= r1; ii += 3) {
      var mp = P(ii, sg * (Wc - 0.5), Hw + 1.6 + 1.1), yy = yawOf(ii);
      if (!((ii - r0) / 3 & 1)) { OB(mb, mp[0], mp[1], mp[2], yy, 1.5, 2.3, 2.3, shade(STONEL, 0.9 + H2(ii, 5, seed) * 0.2), 0); mb.ell(mp[0], mp[1] + 1.2, mp[2], 0.9, 0.22, 1.0, 5, 3, SNOW, 0.05, 0.04); }
      else if (H2(ii, 6, seed) > 0.4) { mb.push().translate(P(ii, sg * (Wc + 0.2), Hw + 1.0)[0], Hw * 0 + T.py[ii] + Hw + 1.0, P(ii, sg * (Wc + 0.2), 0)[2]).rotX(PI); mb.cone(0, 0, 0, 0.28, 1.6 + H2(ii, 7, seed) * 2.6, 5, ICEC, 0.45, true); mb.pop(); }
    }
    for (var ef = 0; ef < 2; ef++) for (var ed = -Wc; ed <= Wc; ed += 3.2) { // almenas frente y fondo
      var ei = ef ? r1 - 1 : r0 + 1, mp2 = P(ei, ed, Hw + 1.6 + 1.1); if (Math.floor((ed + Wc) / 3.2) & 1) continue; OB(mb, mp2[0], mp2[1], mp2[2], yawOf(ei), 2.0, 2.3, 1.5, shade(STONEL, 0.9 + H2(ed * 3, ef, seed) * 0.2), 0);
    }
    // ---- torres (esquinas y mitad de los muros) con tejado conico azul, ventanas y banderas ----
    function tower(i, d, R, Ht, roofH) {
      var tp = P(i, d, -1.6), yy = yawOf(i);
      mb.cyl(tp[0], tp[1], tp[2], R + 0.9, R + 0.9, 3.2, 14, shade(STONED, 1), 0); // base
      for (var lv = 0; lv < Math.floor(Ht / 3.3); lv++) mb.cyl(tp[0], tp[1] + 3.2 + lv * 3.3, tp[2], R, R, 3.3, 14, shade(STONE, 0.82 + H2(lv, i + 1, seed + 41) * 0.3), 0);
      var topY = tp[1] + 3.2 + Math.floor(Ht / 3.3) * 3.3;
      mb.cyl(tp[0], topY, tp[2], R + 1.3, R + 0.7, 1.4, 14, shade(STONEL, 1), 0); // corona
      mb.push().translate(tp[0], topY + 1.4, tp[2]); mb.cone(0, 0, 0, R + 1.5, roofH, 14, [0.26, 0.32, 0.72], 0.06); mb.cone(0, roofH - 0.01, 0, 0.5, 2.4, 6, [1.0, 0.82, 0.3], 0.5); mb.pop();
      mb.ell(tp[0], topY + 2.2, tp[2], R + 1.4, 0.7, R + 1.4, 14, 3, SNOW, 0.05, 0.05);
      var fp = [tp[0], topY + 1.4 + roofH + 2.4, tp[2]]; mb.box(fp[0], fp[1] + 2.5, fp[2], 0.14, 5.4, 0.14, [0.8, 0.82, 0.9], 0); OB(mb, fp[0] + 1.2, fp[1] + 4.3, fp[2], yy, 2.4, 1.3, 0.1, BLUEC, 0.3);
      for (var w = 0; w < 4; w++) { var a = w * PI / 2 + 0.4, wy = tp[1] + 8 + (w & 1) * 5.5; OB(mb, tp[0] + Math.cos(a) * (R + 0.05), wy, tp[2] + Math.sin(a) * (R + 0.05), -a + PI / 2, 0.5, 2.6, 1.6, [0.55, 0.9, 1.0], 0.9); light(T, tp[0] + Math.cos(a) * (R + 1), wy, tp[2] + Math.sin(a) * (R + 1), 6, [0.5, 0.85, 1.0], 0.22); }
      for (var q = 0; q < 6; q++) { var aa = q / 6 * 2 * PI; mb.push().translate(tp[0] + Math.cos(aa) * (R - 0.4), topY + 0.2, tp[2] + Math.sin(aa) * (R - 0.4)).rotX(PI); mb.cone(0, 0, 0, 0.3, 2.0 + H2(q, i, seed) * 2.6, 5, ICEC, 0.45, true); mb.pop(); }
    }
    tower(r0 + 3, -Wc, 7.0, Hw + 8, 15); tower(r0 + 3, Wc, 7.0, Hw + 8, 15); tower(r1 - 3, -Wc, 7.0, Hw + 8, 15); tower(r1 - 3, Wc, 7.0, Hw + 8, 15);
    tower(rc - 30, -Wc, 5.4, Hw + 2, 11); tower(rc - 30, Wc, 5.4, Hw + 2, 11); tower(rc + 30, -Wc, 5.4, Hw + 2, 11); tower(rc + 30, Wc, 5.4, Hw + 2, 11);
    // ---- torreon central sobre la terraza ----
    (function () {
      var kp = P(rc, 0, Hw + 1.6), yy = yawOf(rc), kw = 26, kl = 20, kh = 36, i;
      mb.cut();
      var gx = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
      for (var lv = 0; lv < kh / 3.3; lv++) {
        var cy = kp[1] + lv * 3.3 + 1.65;
        OB(mb, kp[0], cy, kp[2], yy, kw, 3.3, kl * ds * 0.9, shade(STONE, 0.8 + H2(lv, 1, seed + 51) * 0.34), 0);
        if (lv >= 2 && lv % 2 === 0) for (var s2 = -1; s2 <= 1; s2 += 2) for (var wq = -2; wq <= 2; wq += 2) { var w1 = P(rc, wq * 4.2, 0); OB(mb, w1[0] + Math.cos(yy) * 0 + T.tx[rc] * s2 * (kl * ds * 0.45 + 0.05), cy, w1[2] + T.tz[rc] * s2 * (kl * ds * 0.45 + 0.05), yy, 1.7, 2.3, 0.3, [0.55, 0.9, 1.0], 0.9); }
      }
      for (i = 0; i < 4; i++) { // torrecillas de las esquinas
        var tq = P(rc + gx[i][1] * kl * 0.44, gx[i][0] * kw * 0.5, Hw + 1.6), ty = tq[1] + kh * 0.0;
        mb.cyl(tq[0], tq[1], tq[2], 3.3, 3.3, kh + 9, 10, shade(STONEL, 0.95), 0); mb.push().translate(tq[0], tq[1] + kh + 9, tq[2]); mb.cone(0, 0, 0, 4.2, 9, 10, [0.30, 0.38, 0.8], 0.06); mb.cone(0, 8.9, 0, 0.35, 2.2, 5, [1.0, 0.82, 0.3], 0.5); mb.pop(); mb.ell(tq[0], tq[1] + kh + 9.8, tq[2], 3.6, 0.5, 3.6, 10, 3, SNOW, 0.05, 0.05);
      }
      mb.push().translate(kp[0], kp[1] + kh, kp[2]); mb.cone(0, 0, 0, kw * 0.52, 24, 4, [0.24, 0.30, 0.7], 0.06); mb.cone(0, 23.9, 0, 0.7, 5, 6, [1.0, 0.82, 0.3], 0.55); mb.pop();
      mb.ell(kp[0], kp[1] + kh + 1.0, kp[2], kw * 0.55, 1.1, kw * 0.55, 8, 3, SNOW, 0.05, 0.06);
      var fl = [kp[0], kp[1] + kh + 24 + 5, kp[2]]; mb.box(fl[0], fl[1] + 2.4, fl[2], 0.16, 5, 0.16, [0.8, 0.82, 0.9], 0); OB(mb, fl[0] + 1.6, fl[1] + 4, fl[2], yy, 3.2, 1.6, 0.1, [0.95, 0.97, 1.0], 0.3);
      light(T, kp[0], kp[1] + kh * 0.5, kp[2], 26, [0.5, 0.85, 1.0], 0.22); light(T, kp[0], kp[1] + kh + 12, kp[2], 24, [0.6, 0.8, 1.0], 0.18);
    })();
    // ---- cristales de hielo gigantes en los tejados, y explanada de nieve alrededor ----
    for (ii = r0 + 8; ii < r1 - 6; ii += 17) for (var cs2 = -1; cs2 <= 1; cs2 += 2) {
      if (H2(ii, 150 + cs2, seed) > 0.7) continue;
      var cq = P(ii, cs2 * (Wc - 4 - H2(ii, 151, seed) * 6), Hw + 1.6), gc = [[0.5, 0.9, 1.0], [0.62, 0.78, 1.0], [0.75, 0.65, 1.0]][ii % 3];
      mb.push().translate(cq[0], cq[1], cq[2]); mb.crystal(0, 0, 0, 1.4, 6.5 + H2(ii, 152, seed) * 3, gc, 0.75, 6); mb.push().rotZ(0.5); mb.crystal(0.4, 0, 0, 0.9, 4.2, shade(gc, 0.9), 0.75, 5); mb.pop(); mb.pop();
      light(T, cq[0], cq[1] + 4, cq[2], 10, gc, 0.2);
    }
    mb.up = true; mb.ref = null;
    for (ii = r0 - 6; ii < r1 + 6; ii += 3) for (var sa = -1; sa <= 1; sa += 2) {
      if (ii % 30 === 0) mb.cut();
      var a0 = P(ii, sa * (Wc - 1), -1.3), a1 = P(ii + 3, sa * (Wc - 1), -1.3), a2 = P(ii + 3, sa * (Wc + 26), -1.6), a3 = P(ii, sa * (Wc + 26), -1.6);
      mb.quad(a0, a1, a2, a3, shade(mix3(SNOW, [0.82, 0.9, 1.0], 0.3 + 0.2 * H2(ii >> 1, sa, seed + 60)), 0.96 + H2(ii, sa, seed) * 0.06), 0);
    }
    mb.ref = null; mb.up = false;
  };

  /* ============================ CIUDAD NAVIDENA ============================ */
  var BUL = [[1.0, 0.2, 0.22], [1.0, 0.82, 0.25], [0.25, 0.95, 0.42], [0.3, 0.62, 1.0], [1.0, 0.45, 0.92], [1.0, 0.6, 0.2]];
  S.xmas = function (c) {
    var T = c.T, P = c.P, hw = c.hw, N = c.N, ds = T.ds, seed = c.seed, rnd = PG.rng(seed * 11 + 5), px = T.px, py = T.py, pz = T.pz, rx = T.rx, rz = T.rz, i, k;
    var cell = c.cell, groundAt = c.groundAt, qn = { i: 0, dist: 0 };
    function bermY(d) { d = Math.abs(d) - hw; if (d <= 1.8) return 0.05 + 0.9 * Math.max(0, d) / 1.8; if (d <= 6) return 0.95 - 2.1 * (d - 1.8) / 4.2; return -1.15 - 0.35 * Math.min(1, (d - 6) / 20); }
    function bulb(mb, x, y, z, ci, sz) { mb.box(x, y, z, sz || 0.3, sz || 0.3, sz || 0.3, BUL[ci % BUL.length], 1); }
    function post(mb, x, y, z, hgt, yawIn) { // farola con forma de baston de caramelo; devuelve la punta del gancho
      for (var s = 0; s < Math.round(hgt); s++) mb.cyl(x, y + s, z, 0.17, 0.17, 1.0, 6, (s & 1) ? [0.96, 0.96, 0.98] : [0.88, 0.14, 0.16], 0);
      var hx = x + Math.sin(yawIn) * 0.6, hz = z + Math.cos(yawIn) * 0.6;
      mb.box(x + Math.sin(yawIn) * 0.3, y + hgt + 0.1, z + Math.cos(yawIn) * 0.3, 0.3, 0.3, 0.3, [0.88, 0.14, 0.16], 0); mb.box(hx, y + hgt - 0.05, hz, 0.28, 0.5, 0.28, [0.96, 0.96, 0.98], 0);
      return [hx, y + hgt - 0.6, hz];
    }
    function xtree(mb, x, y, z, h, sd, glow) {
      var r = h * 0.34, ly = h * 0.12, kk2;
      mb.cyl(x, y - 0.3, z, h * 0.04, h * 0.05, h * 0.18, 6, [0.36, 0.24, 0.14], 0);
      for (var L = 0; L < 4; L++) {
        var ry = y + h * (0.1 + L * 0.2), rr = r * (1 - L * 0.2), hh = h * 0.34;
        mb.cone(x, ry, z, rr, hh, 8, shade([0.08, 0.34 + 0.04 * L, 0.2], 0.9 + H2(L, sd, seed) * 0.2), 0.04);
        mb.ell(x, ry + 0.2, z, rr * 0.92, 0.28, rr * 0.92, 8, 2, SNOW, 0.05, 0.05);
      }
      var nb = 22;
      for (kk2 = 0; kk2 < nb; kk2++) { var u = kk2 / nb, rad = r * (1 - u * 0.86) * 0.92, an = u * 4.6 * PI + sd; bulb(mb, x + Math.cos(an) * rad, y + h * (0.16 + u * 0.66), z + Math.sin(an) * rad, kk2 + sd, 0.3 + h * 0.012); }
      for (kk2 = 0; kk2 < 7; kk2++) { var u2 = (kk2 + 0.5) / 7, rad2 = r * (1 - u2 * 0.8) * 0.8, an2 = u2 * 9 + sd * 2; mb.ell(x + Math.cos(an2) * rad2, y + h * (0.14 + u2 * 0.6), z + Math.sin(an2) * rad2, 0.34, 0.34, 0.34, 5, 3, BUL[(kk2 + sd) % BUL.length], 0.5, 0.04); }
      mb.push().translate(x, y + h * 0.98, z); mb.crystal(0, 0, 0, h * 0.045, h * 0.12, [1.0, 0.88, 0.3], 1, 5); mb.pop();
      if (glow) light(T, x, y + h * 0.55, z, h * 0.9, [1.0, 0.82, 0.5], 0.2);
    }
    var tris0 = 0;
    // ---- farolas, guirnaldas y arcos de luces a lo largo de toda la pista ----
    var span = 8, nPost = 0;
    for (var sd = -1; sd <= 1; sd += 2) {
      var prev = null;
      for (i = 4; i < N - 2; i += span) {
        if (c.inCaveRow[i] || c.skipSide(sd, i)) { prev = null; continue; }
        var x = px[i] + rx[i] * sd * (hw + 2.6), z = pz[i] + rz[i] * sd * (hw + 2.6), y = py[i] + 0.4, mb = cell(x, z), yawIn = Math.atan2(-rx[i] * sd, -rz[i] * sd);
        var tip = post(mb, x, y, z, 6.4, yawIn);
        mb.box(tip[0], tip[1], tip[2], 0.5, 0.7, 0.5, [1.0, 0.85, 0.5], 1);
        if (nPost++ % 2 === 0) light(T, tip[0], tip[1], tip[2], 10, [1.0, 0.8, 0.45], 0.34);
        if (prev && Math.hypot(prev[0] - tip[0], prev[2] - tip[2]) < 22) { // guirnalda con bombillas
          for (k = 1; k < 6; k++) { var f = k / 6, gx = prev[0] + (tip[0] - prev[0]) * f, gz = prev[2] + (tip[2] - prev[2]) * f, gy = prev[1] + (tip[1] - prev[1]) * f - Math.sin(f * PI) * 1.1 + 0.55; bulb(mb, gx, gy, gz, k + i, 0.3); }
          mb.push().translate((prev[0] + tip[0]) / 2, (prev[1] + tip[1]) / 2 - 0.2, (prev[2] + tip[2]) / 2).rotY(Math.atan2(tip[0] - prev[0], tip[2] - prev[2])); mb.box(0, 0, 0, 0.05, 0.05, Math.hypot(prev[0] - tip[0], prev[2] - tip[2]), [0.12, 0.34, 0.2], 0); mb.pop();
        }
        prev = tip;
        // baston de caramelo decorativo cada cierto tramo
        if ((i / span) % 3 === 1) { var cx2 = px[i] + rx[i] * sd * (hw + 4.2), cz2 = pz[i] + rz[i] * sd * (hw + 4.2), cy2 = py[i] + bermY(hw + 4.2); for (k = 0; k < 4; k++) mb.cyl(cx2, cy2 + k * 0.8, cz2, 0.22, 0.22, 0.8, 6, (k & 1) ? [0.96, 0.96, 0.98] : [0.88, 0.14, 0.16], 0); mb.box(cx2 + 0.25, cy2 + 3.4, cz2, 0.7, 0.4, 0.4, [0.88, 0.14, 0.16], 0); mb.box(cx2 + 0.55, cy2 + 3.05, cz2, 0.4, 0.4, 0.4, [0.96, 0.96, 0.98], 0); }
      }
    }
    for (i = 30; i < N - 20; i += 44) { // arcos de luces sobre la calzada
      if (c.inCaveRow[i] || c.skipSide(-1, i) || c.skipSide(1, i) || (c.gateRows || []).some(function (g) { return Math.abs(g - i) < 22; })) continue;
      var mb2 = cell(px[i], pz[i]), aR = hw + 1.6, ay = py[i] + 0.2, yaw = Math.atan2(T.tx[i], T.tz[i]);
      for (var sa = -1; sa <= 1; sa += 2) { var pp = P(i, sa * aR, 0.1); for (k = 0; k < 8; k++) mb2.cyl(pp[0], pp[1] + k, pp[2], 0.2, 0.2, 1.0, 6, (k & 1) ? [0.96, 0.96, 0.98] : [0.88, 0.14, 0.16], 0); mb2.ell(pp[0], pp[1] + 8.1, pp[2], 0.6, 0.6, 0.6, 5, 3, [0.15, 0.55, 0.28], 0.1, 0.05); mb2.ell(pp[0], pp[1] + 7.2, pp[2], 0.5, 0.5, 0.35, 5, 3, [0.9, 0.12, 0.14], 0.2, 0.05); }
      for (k = 0; k <= 22; k++) { var a = PI * k / 22, bp = P(i, -Math.cos(a) * aR, 8.2 + Math.sin(a) * 4.4); bulb(mb2, bp[0], bp[1], bp[2], k, 0.34); if (k % 2 === 0) { var gp = P(i, -Math.cos(a) * aR, 8.2 + Math.sin(a) * 4.4 - 0.9); mb2.cone(gp[0], gp[1] - 0.8, gp[2], 0.12, 0.7, 4, [0.12, 0.5, 0.25], 0.1, false); } }
      var tpa = P(i, 0, 12.9); mb2.push().translate(tpa[0], tpa[1] + 0.8, tpa[2]).rotY(yaw); mb2.crystal(0, 0, 0, 0.9, 2.4, [1.0, 0.88, 0.3], 1, 5); mb2.pop();
      for (var bl = -1; bl <= 1; bl += 2) { var ob = P(i, bl * 3.2, 11.2); mb2.box(ob[0], ob[1], ob[2], 0.05, 1.6, 0.05, [0.9, 0.9, 0.9], 0); mb2.ell(ob[0], ob[1] - 1.1, ob[2], 0.55, 0.55, 0.55, 6, 4, BUL[(i + bl) & 3], 0.6, 0.04); }
      light(T, tpa[0], tpa[1] - 1.5, tpa[2], 17, [1.0, 0.85, 0.55], 0.3);
    }
    // ---- regalos, muñecos de nieve y arboles decorados junto a la pista ----
    function away(x, z, minD) { T.nearest(x, z, qn); return qn.dist >= minD && !(c.inCaveRow[qn.i] && qn.dist < hw + 44); }
    for (i = 0; i < 70; i++) {
      var gi = Math.floor(rnd() * N), gs = rnd() < 0.5 ? -1 : 1, gd = hw + 4.5 + rnd() * 7, gx = px[gi] + rx[gi] * gs * gd, gz = pz[gi] + rz[gi] * gs * gd;
      if (!away(gx, gz, hw + 4)) continue;
      var gmb = cell(gx, gz), gy = groundAt(gx, gz), n = 1 + Math.floor(rnd() * 3);
      for (k = 0; k < n; k++) {
        var s = 1.2 + rnd() * 1.4, bx = gx + (rnd() - 0.5) * 3, bz = gz + (rnd() - 0.5) * 3, yw = rnd() * 6, cc = BUL[Math.floor(rnd() * 5)], by = groundAt(bx, bz);
        gmb.push().translate(bx, by + s / 2 - 0.1, bz).rotY(yw); gmb.box(0, 0, 0, s, s, s, shade(cc, 0.8), 0.12); gmb.box(0, 0, 0, s + 0.06, s + 0.06, s * 0.18, [1.0, 0.9, 0.5], 0.5); gmb.box(0, 0, 0, s * 0.18, s + 0.06, s + 0.06, [1.0, 0.9, 0.5], 0.5);
        gmb.ell(0, s / 2 + 0.2, 0, s * 0.3, s * 0.2, s * 0.3, 5, 3, [1.0, 0.9, 0.5], 0.5, 0.05); gmb.ell(0, s / 2 + 0.06, 0, s * 0.5, s * 0.07, s * 0.5, 6, 2, SNOW, 0.05, 0.05); gmb.pop();
      }
    }
    for (i = 0; i < 46; i++) { // muñecos de nieve con bufanda y gorro
      var ni = Math.floor(rnd() * N), ns = rnd() < 0.5 ? -1 : 1, nd = hw + 5 + rnd() * 20, nx = px[ni] + rx[ni] * ns * nd, nz = pz[ni] + rz[ni] * ns * nd;
      if (!away(nx, nz, hw + 4.5)) continue;
      var nmb = cell(nx, nz), ny = groundAt(nx, nz) - 0.1, sc = 0.9 + rnd() * 0.8, face = Math.atan2(px[ni] - nx, pz[ni] - nz), scol = BUL[Math.floor(rnd() * 3)];
      nmb.push().translate(nx, ny, nz).rotY(face).scale(sc, sc, sc);
      nmb.ell(0, 1.0, 0, 1.15, 1.0, 1.15, 8, 5, SNOW, 0.05, 0.03); nmb.ell(0, 2.3, 0, 0.85, 0.78, 0.85, 8, 5, SNOW, 0.05, 0.03); nmb.ell(0, 3.3, 0, 0.62, 0.58, 0.62, 8, 5, SNOW, 0.05, 0.03);
      nmb.cyl(0, 2.85, 0, 0.7, 0.7, 0.28, 8, scol, 0.1); nmb.box(0.55, 2.4, 0.3, 0.24, 1.0, 0.4, scol, 0.1);
      nmb.cone(0, 3.3, 0.55, 0.12, 0.8, 5, [1.0, 0.5, 0.1], 0.1); nmb.box(-0.2, 3.5, 0.5, 0.12, 0.12, 0.1, [0.05, 0.05, 0.08], 0); nmb.box(0.2, 3.5, 0.5, 0.12, 0.12, 0.1, [0.05, 0.05, 0.08], 0);
      nmb.cyl(0, 3.78, 0, 0.62, 0.62, 0.12, 8, [0.12, 0.12, 0.16], 0); nmb.cyl(0, 3.88, 0, 0.4, 0.4, 0.8, 8, [0.12, 0.12, 0.16], 0); nmb.box(0, 4.05, 0, 0.82, 0.2, 0.82, [0.8, 0.12, 0.14], 0.1);
      for (k = 0; k < 3; k++) nmb.box(0, 1.9 + k * 0.45, 0.9, 0.14, 0.14, 0.1, [0.05, 0.05, 0.08], 0);
      nmb.pop();
    }
    for (i = 0; i < 90; i++) { // arboles de navidad decorados
      var ti = Math.floor(rnd() * N), ts = rnd() < 0.5 ? -1 : 1, td = hw + 9 + Math.pow(rnd(), 1.4) * 55, tx = px[ti] + rx[ti] * ts * td + (rnd() - 0.5) * 6, tz = pz[ti] + rz[ti] * ts * td + (rnd() - 0.5) * 6;
      if (!away(tx, tz, hw + 8)) continue;
      xtree(cell(tx, tz), tx, groundAt(tx, tz), tz, 8 + rnd() * 9, i, i % 6 === 0);
    }
    // ---- casitas de la ciudad (ventanas encendidas, tejado nevado, guirnaldas en el alero) ----
    var HP = [[0.86, 0.45, 0.42], [0.45, 0.62, 0.86], [0.92, 0.78, 0.45], [0.55, 0.78, 0.6], [0.78, 0.56, 0.82]];
    for (i = 0; i < 70; i++) {
      var hi = Math.floor(rnd() * N), hs = rnd() < 0.5 ? -1 : 1, hd = hw + 17 + rnd() * 26, hx = px[hi] + rx[hi] * hs * hd, hz = pz[hi] + rz[hi] * hs * hd;
      if (!away(hx, hz, hw + 15)) continue;
      var hmb = cell(hx, hz), hy = groundAt(hx, hz) - 0.2, hyaw = Math.atan2(px[hi] - hx, pz[hi] - hz) + (rnd() - 0.5) * 0.3, W = 6 + rnd() * 3, Dp = 5 + rnd() * 2.5, Hh = 4 + rnd() * 2, col = HP[i % HP.length];
      hmb.push().translate(hx, hy, hz).rotY(hyaw);
      hmb.box(0, Hh / 2, 0, W, Hh, Dp, shade(col, 0.9 + rnd() * 0.2), 0.04);
      for (var rs = -1; rs <= 1; rs += 2) { hmb.push().translate(0, Hh + 1.1, rs * Dp * 0.27).rotX(rs * 0.62); hmb.box(0, 0, 0, W + 0.9, 0.35, Dp * 0.68, [0.5, 0.26, 0.22], 0); hmb.box(0, 0.26, 0, W + 0.8, 0.22, Dp * 0.66, SNOW, 0.05); hmb.pop(); }
      hmb.box(W * 0.28, Hh + 2.4, -Dp * 0.2, 0.9, 1.8, 0.9, [0.45, 0.32, 0.3], 0); hmb.box(W * 0.28, Hh + 3.4, -Dp * 0.2, 1.1, 0.3, 1.1, SNOW, 0.05);
      hmb.box(0, 1.2, Dp / 2 + 0.05, 1.3, 2.4, 0.2, [0.4, 0.22, 0.14], 0); hmb.ell(0, 1.9, Dp / 2 + 0.2, 0.5, 0.5, 0.15, 6, 3, [0.15, 0.5, 0.25], 0.1, 0.04); hmb.ell(0, 1.4, Dp / 2 + 0.28, 0.2, 0.2, 0.1, 5, 3, [0.9, 0.12, 0.14], 0.3, 0.04);
      for (var wv = -1; wv <= 1; wv += 2) { hmb.box(wv * W * 0.32, Hh * 0.55, Dp / 2 + 0.06, 1.3, 1.3, 0.14, [1.0, 0.82, 0.45], 0.95); hmb.box(wv * W * 0.32, Hh * 0.55, Dp / 2 + 0.1, 0.1, 1.3, 0.1, [0.4, 0.26, 0.18], 0); hmb.box(wv * W * 0.32, Hh * 0.55, Dp / 2 + 0.1, 1.3, 0.1, 0.1, [0.4, 0.26, 0.18], 0); }
      for (k = 0; k < 7; k++) bulb(hmb, -W / 2 + 0.4 + k * (W - 0.8) / 6, Hh + 0.15 - ((k & 1) ? 0.15 : 0), Dp / 2 + 0.15, k + i, 0.28);
      hmb.pop();
      var wl = [hx + Math.sin(hyaw) * (Dp / 2 + 2), hy + 2.5, hz + Math.cos(hyaw) * (Dp / 2 + 2)]; if (i % 2 === 0) light(T, wl[0], wl[1], wl[2], 9, [1.0, 0.8, 0.45], 0.3);
    }
    // ---- espectadores repartidos por todo el mapa ----
    T.specs = T.specs || [];
    for (i = 6; i < N - 6; i += 5 + Math.floor(rnd() * 8)) {
      if (c.inCaveRow[i] || (c.gateRows || []).some(function (g) { return Math.abs(g - i) < 36; })) continue;
      var ss = rnd() < 0.5 ? -1 : 1, grp = 2 + Math.floor(rnd() * 4);
      if (c.skipSide(ss, i)) continue;
      for (k = 0; k < grp; k++) {
        var sdl = hw + 3.5 + rnd() * 1.4, sx = px[i] + rx[i] * ss * sdl + T.tx[i] * (k - grp / 2) * 1.5, sz = pz[i] + rz[i] * ss * sdl + T.tz[i] * (k - grp / 2) * 1.5, sy = py[i] + bermY(sdl) - 0.25;
        T.specs.push({ x: sx, y: sy, z: sz, yaw: Math.atan2(px[i] - sx, pz[i] - sz) + (rnd() - 0.5) * 0.5, k: Math.floor(rnd() * 90) });
      }
    }
    // ---- el gran arbol de navidad de la plaza (en el punto mas alejado de la pista dentro del circuito) ----
    var bestD = -1, bx0 = 0, bz0 = 0, bb = T.bbox, gxs, gzs;
    for (gxs = bb.x0; gxs <= bb.x1; gxs += 30) for (gzs = bb.z0; gzs <= bb.z1; gzs += 30) { T.nearest(gxs, gzs, qn); if (qn.dist > bestD) { bestD = qn.dist; bx0 = gxs; bz0 = gzs; } }
    if (bestD > 50) {
      var gb = cell(bx0, bz0), gy0 = groundAt(bx0, bz0), H = 52, Rb = 19;
      gb.cyl(bx0, gy0 - 0.4, bz0, 24, 24, 0.8, 24, mix3(SNOW, [0.86, 0.92, 1.0], 0.3), 0.04); gb.cyl(bx0, gy0 + 0.3, bz0, 22.4, 22.4, 0.3, 24, [0.92, 0.2, 0.22], 0.15);
      gb.cyl(bx0, gy0 - 0.2, bz0, 3.4, 4.0, 10, 10, [0.36, 0.24, 0.14], 0);
      for (var L = 0; L < 6; L++) { var ry = gy0 + 4 + L * 7.2, rr = Rb * (1 - L * 0.15), hh = 14; gb.cone(bx0, ry, bz0, rr, hh, 14, shade([0.08, 0.34 + 0.03 * L, 0.2], 0.92 + H2(L, 3, seed) * 0.16), 0.04); gb.ell(bx0, ry + 0.4, bz0, rr * 0.93, 0.6, rr * 0.93, 14, 2, SNOW, 0.05, 0.05); }
      for (var sp = 0; sp < 4; sp++) for (k = 0; k < 70; k++) { var u = k / 70, rad = Rb * (1 - u * 0.9) * 0.95, an = u * 5.2 * PI + sp * PI / 2; bulb(gb, bx0 + Math.cos(an) * rad, gy0 + 5 + u * (H - 8), bz0 + Math.sin(an) * rad, k + sp, 0.5); }
      for (k = 0; k < 90; k++) { var u3 = (k + 0.5) / 90, rad3 = Rb * (1 - u3 * 0.85) * 0.82, an3 = u3 * 31 + k * 0.7; gb.ell(bx0 + Math.cos(an3) * rad3, gy0 + 5 + u3 * (H - 9), bz0 + Math.sin(an3) * rad3, 0.8, 0.8, 0.8, 6, 4, BUL[k % BUL.length], 0.6, 0.04); }
      gb.push().translate(bx0, gy0 + H - 3, bz0); gb.crystal(0, 0, 0, 3.2, 9.5, [1.0, 0.88, 0.3], 1, 5); gb.push().rotY(PI / 4); gb.crystal(0, 0, 0, 2.2, 6.4, [1.0, 0.95, 0.6], 1, 4); gb.pop(); gb.pop();
      for (k = 0; k < 14; k++) { var ga = k / 14 * 2 * PI, gr = 26 + (k % 2) * 4, s2 = 2 + (k % 3), gcx = bx0 + Math.cos(ga) * gr, gcz = bz0 + Math.sin(ga) * gr;
        gb.push().translate(gcx, gy0 + s2 / 2, gcz).rotY(ga); gb.box(0, 0, 0, s2, s2, s2, shade(BUL[k % 5], 0.8), 0.12); gb.box(0, 0, 0, s2 + 0.06, s2 + 0.06, s2 * 0.18, [1.0, 0.9, 0.5], 0.5); gb.box(0, 0, 0, s2 * 0.18, s2 + 0.06, s2 + 0.06, [1.0, 0.9, 0.5], 0.5); gb.pop(); }
      for (k = 0; k < 16; k++) { var pa2 = k / 16 * 2 * PI, ppx = bx0 + Math.cos(pa2) * 33, ppz = bz0 + Math.sin(pa2) * 33, pym = gy0; for (var q = 0; q < 6; q++) gb.cyl(ppx, pym + q, ppz, 0.18, 0.18, 1.0, 6, (q & 1) ? [0.96, 0.96, 0.98] : [0.88, 0.14, 0.16], 0); gb.box(ppx, pym + 6.3, ppz, 0.5, 0.7, 0.5, [1.0, 0.85, 0.5], 1); }
      light(T, bx0, gy0 + 16, bz0, 60, [1.0, 0.8, 0.45], 0.2); light(T, bx0, gy0 + 34, bz0, 50, [1.0, 0.85, 0.55], 0.2); light(T, bx0, gy0 + H, bz0, 34, [1.0, 0.9, 0.5], 0.36); light(T, bx0, gy0 + 4, bz0, 44, [1.0, 0.5, 0.4], 0.16);
      T.bigTree = { x: bx0, z: bz0, y: gy0 };
    }
  };
})();
