/* Malla visual estatica de una pista (calzada, bermas, vallas, rampas, fosos, terreno, arboles, montanas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;
  var shade = PG.shade, mix3 = PG.mix3, smooth = PG.smooth;

  PG.buildTrackMesh = function (T) {
    var th = T.theme, def = T.def, mb = new PG.MB(), rnd = PG.rng(def.seed * 3 + 1);
    mb.rnd = PG.rng(def.seed + 5);
    var W = T.W, hw = W / 2, N = T.N, C = T.cols, ds = T.ds, px = T.px, py = T.py, pz = T.pz, rx = T.rx, rz = T.rz;
    var snow = th.snow, iceC = th.ice, i, j, k;
    var cw = W / C;
    var inCaveRow = new Uint8Array(N + 2), caveR = [], inHallRow = new Uint8Array(N + 2), caveInnerFn = null;
    if (T.hall) for (k = Math.round(T.hall.s0 / ds); k <= Math.round(T.hall.s1 / ds); k++) if (k >= 0 && k <= N) inHallRow[k] = 1;
    for (k = 0; k < (T.caves || []).length; k++) {
      var cr0 = Math.round(T.caves[k].s0 / ds), cr1 = Math.round(T.caves[k].s1 / ds);
      caveR.push([cr0, cr1]);
      for (i = Math.max(0, cr0 - 2); i <= Math.min(N, cr1 + 2); i++) inCaveRow[i] = 1;
    }

    var skipMain = { '-1': new Uint8Array(N + 3), '1': new Uint8Array(N + 3) };
    (T.branches || []).forEach(function (B) { // donde ramal y pista se solapan o casi: sin bermas ni vallas en el lado que se comunica
      for (var j = 0; j <= B.Nb; j++) if (B.gap[j] < hw + B.W / 2 + 0.5) for (var q = -3; q <= 3; q++) { var ii = B.i0 + j + q; if (ii >= 0 && ii <= N + 2) skipMain[B.side][ii] = 1; }
    });
    function P(i, d, dy) { return [px[i] + rx[i] * d, py[i] + dy, pz[i] + rz[i] * d]; }
    function PW(ii, d, dy) { // indice con envoltura para circuitos
      if (T.closed) ii = ((ii % N) + N) % N; else ii = Math.max(0, Math.min(N, ii));
      return P(ii, d, dy);
    }
    function jit(c, a) { return shade(c, 1 + (rnd() - 0.5) * a); }

    /* ---- calzada de hielo ---- */
    mb.up = true; mb.ref = null;
    var startRow = Math.round(T.startS / ds), finRow = Math.round(T.finishS / ds);
    var holeWarn = {};
    for (k = 0; k < T.holes.length; k++) { if (T.holes[k].br) continue; var hr0 = Math.round(T.holes[k].s0 / ds); for (i = hr0 - 3; i < hr0; i++) holeWarn[i] = 1; }
    // v3.6: hielo liso. Color por vertice con ruido continuo de baja frecuencia (sin tono aleatorio por triangulo ni ajedrez) y normales suavizadas.
    var rdSeed = def.seed * 7.31 + 2.7;
    function rh(a, b) { var x = Math.sin(a * 127.1 + b * 311.7 + rdSeed) * 43758.5453; return x - Math.floor(x); }
    function vn(x, y) { var xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi; fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
      return (rh(xi, yi) * (1 - fx) + rh(xi + 1, yi) * fx) * (1 - fy) + (rh(xi, yi + 1) * (1 - fx) + rh(xi + 1, yi + 1) * fx) * fy; }
    var iceDeep = mix3(iceC, [0.55, 0.78, 0.98], 0.35), iceFrost = mix3(iceC, [1, 1, 1], 0.45), edgeC = def.whiteRoad ? [0.66, 0.78, 0.92] : mix3(iceC, snow, 0.55);
    function roadCol(s, d) {
      var n1 = vn(s * 0.035, d * 0.07), n2 = vn(s * 0.09 + 9, d * 0.12), strk = vn(s * 0.02 + 3, d * 0.16), c; // v3.9: sin bandas largas a lo largo de la pista (antes d*0.7 = rayas)
      if (def.whiteRoad) { c = mix3([0.945, 0.965, 0.99], [0.99, 0.995, 1.0], n1 * 0.7 + n2 * 0.3); }
      else { c = mix3(iceC, iceDeep, Math.max(0, strk - 0.4) * 0.55 * (0.5 + n1 * 0.5)); c = mix3(c, iceFrost, Math.max(0, n2 - 0.5) * 0.6 * n1); }
      var ad = Math.abs(d), e = Math.max(0, Math.min(1, (ad - (hw - 3.2)) / 3.2)); e = e * e * (3 - 2 * e); // borde: transicion suave a nieve compactada
      return mix3(shade(c, 0.97 + n1 * 0.06), edgeC, e * (def.whiteRoad ? 0.9 : 0.8));
    }
    var rdChunk0 = mb.chunks.length - 1;
    for (i = 0; i < N; i++) {
      if (i % 40 === 0) mb.cut();
      for (j = 0; j < C; j++) {
        var dm = -hw + (j + 0.5) * cw, sm = (i + 0.5) * ds;
        if (T.inHole(sm, dm)) continue;
        var d0 = -hw + j * cw, d1 = d0 + cw;
        var chk = (i === startRow || i === startRow - 1 || (T.type === 'sprint' && (i === finRow || i === finRow - 1)));
        var a = P(i, d0, T.bankAt(i * ds, d0)), b = P(i, d1, T.bankAt(i * ds, d1)), c = P(i + 1, d1, T.bankAt((i + 1) * ds, d1)), d = P(i + 1, d0, T.bankAt((i + 1) * ds, d0));
        if (chk || holeWarn[i]) {
          var col = chk ? ((((i + j) & 1) === 0) ? [0.97, 0.97, 0.97] : [0.08, 0.1, 0.14]) : (((j + i) & 1) ? [1.0, 0.72, 0.15] : [0.18, 0.2, 0.26]);
          mb.quad(a, b, c, d, col, 0.12);
        } else {
          var ca = roadCol(i * ds, d0), cb = roadCol(i * ds, d1), cc = roadCol((i + 1) * ds, d1), cd = roadCol((i + 1) * ds, d0);
          mb.tri(a, b, c, ca, 0, [ca, cb, cc]); mb.tri(a, c, d, ca, 0, [ca, cc, cd]);
        }
      }
    }
    PG.smoothMesh({ chunks: mb.chunks.slice(rdChunk0) }, 0.9);

    /* ---- bermas y falda de nieve ---- */
    var offs = [hw, hw + 1.8, hw + 6, hw + 26], hts = [0.05, 0.95, -1.15, -1.5];
    // v3.9: holgura entre bordes de calzada (pista principal <-> atajo) por fila, y desnivel entre ambas. La falda de nieve se recorta a la mitad de esa holgura
    // para que NUNCA pase por encima del otro camino (antes se extendia hasta 26-34 m y cubria la calzada vecina como una malla flotante).
    var mainClr = { '-1': new Float32Array(N + 3).fill(99), '1': new Float32Array(N + 3).fill(99) }, mainDy = { '-1': new Float32Array(N + 3), '1': new Float32Array(N + 3) };
    (T.branches || []).forEach(function (B) {
      for (var j = 0; j <= B.Nb; j++) for (var q = -3; q <= 3; q++) {
        var ii = B.i0 + j + q; if (T.closed) ii = ((ii % N) + N) % N; if (ii < 0 || ii > N + 2) continue;
        if (B.clr[j] < mainClr[B.side][ii]) { mainClr[B.side][ii] = B.clr[j]; mainDy[B.side][ii] = B.py[j] - B.mainY[j]; }
      }
    });
    // anillos [distancia, altura] de la falda: completa si hay sitio; si no, corta en el punto medio entre los dos caminos y a la misma altura absoluta
    function skirtRings(base, fullOffs, fullHts, c, dyOther) {
      var ds2 = [], hs2 = [], k3;
      if (c >= 9) { // hay sitio: perfil completo, pero nunca mas alla de la mitad de la holgura (la falda de un camino no puede llegar a pisar el otro, aunque este mas bajo)
        var dmax = (c - 0.3) * 0.5;
        for (k3 = 0; k3 < fullOffs.length; k3++) {
          if (fullOffs[k3] - base <= dmax) { ds2.push(fullOffs[k3]); hs2.push(fullHts[k3]); continue; }
          if (k3 > 0) { var tt2 = (dmax - (fullOffs[k3 - 1] - base)) / (fullOffs[k3] - fullOffs[k3 - 1]); ds2.push(base + dmax); hs2.push(fullHts[k3 - 1] + (fullHts[k3] - fullHts[k3 - 1]) * tt2); }
          break;
        }
        return [ds2, hs2];
      }
      var half = Math.max(0.05, (c - 0.3) * 0.5), d1 = Math.min(1.8, half * 0.55);
      var hEnd = Math.max(-1.2, Math.min(0.0, dyOther * 0.5 - 0.35)), h1 = 0.05 + 0.9 * Math.max(0, Math.min(1, (half - 0.4) / 1.8));
      return [[base, base + d1, base + half], [0.05, Math.min(h1, 0.05 + 0.9 * d1 / 1.8), hEnd]];
    }
    for (var side = -1; side <= 1; side += 2) {
      mb.cut();
      for (i = 0; i < N; i += 2) {
        if (i % 40 === 0) mb.cut();
        if (inCaveRow[i] || inCaveRow[Math.min(i + 2, N)]) continue;
        if (skipMain[side][i] || skipMain[side][i + 2]) continue;
        var i1 = Math.min(i + 2, N);
        var cMn = Math.min(mainClr[side][i], mainClr[side][i1]), skr = skirtRings(hw, offs, hts, cMn, (mainDy[side][i] + mainDy[side][i1]) * 0.5);
        for (k = 0; k < skr[0].length - 1 && k < 3; k++) {
          var col2 = jit(k === 0 ? mix3(snow, iceC, 0.15) : snow, 0.07);
          if (inHallRow[i]) col2 = jit(k === 0 ? [0.26, 0.23, 0.24] : [0.17, 0.14, 0.15], 0.25);
          var q0 = P(i, side * skr[0][k], skr[1][k]), q1 = P(i1, side * skr[0][k], skr[1][k]), q2 = P(i1, side * skr[0][k + 1], skr[1][k + 1]), q3 = P(i, side * skr[0][k + 1], skr[1][k + 1]);
          mb.quad(q0, q1, q2, q3, col2);
        }
      }
    }

    /* ---- rampas, pads y fosos (PF = funcion de posicion de la pista o del ramal que los contiene; indices de fila de la pista principal) ---- */
    function buildRamp(R, PF) {
      mb.cut();
      var r0 = Math.round(R.s0 / ds), rn = Math.round(R.len / ds), top = R.h, i;
      var cen = PF(r0 + (rn >> 1), (R.d0 + R.d1) / 2, top * 0.4);
      mb.ref = cen; mb.up = false;
      for (i = 0; i < rn; i++) {
        var h0 = top * i / rn + 0.03, h1 = top * (i + 1) / rn + 0.03;
        var stripe = (i & 1) ? [0.93, 0.98, 1.0] : [0.45, 0.78, 0.98];
        if (R.jump) stripe = (i & 1) ? [1.0, 0.85, 0.35] : [0.97, 0.97, 1.0];
        var ra = PF(r0 + i, R.d0, h0), rb = PF(r0 + i, R.d1, h0), rc = PF(r0 + i + 1, R.d1, h1), rd = PF(r0 + i + 1, R.d0, h1);
        mb.quad(ra, rb, rc, rd, stripe, 0.12);
        // laterales
        mb.quad(PF(r0 + i, R.d0, 0), PF(r0 + i + 1, R.d0, 0), rd, ra, [0.55, 0.78, 0.95]);
        mb.quad(PF(r0 + i, R.d1, 0), PF(r0 + i + 1, R.d1, 0), rc, rb, [0.55, 0.78, 0.95]);
      }
      mb.quad(PF(r0 + rn, R.d0, 0), PF(r0 + rn, R.d1, 0), PF(r0 + rn, R.d1, top + 0.03), PF(r0 + rn, R.d0, top + 0.03), [0.35, 0.55, 0.8]);
      mb.ref = null;
    }
    // v2.9: turbos = franja oscura con flechas de neon pintadas en el suelo que avanzan (6 cuadros de animacion que game.js alterna)
    var PAD_FR = 6, padFr = []; for (var pfi = 0; pfi < PAD_FR; pfi++) padFr.push(new PG.MB());
    var padCount = 0;
    function buildPad(PD, PF) {
      mb.cut(); mb.up = true; mb.ref = null;
      var p0 = Math.round(PD.s / ds), pn = Math.max(1, Math.round(PD.len / ds)), i, d0 = PD.d0, d1 = PD.d1, dm = (d0 + d1) / 2, ww = Math.abs(d1 - d0);
      for (i = 0; i < pn; i++) {
        var pc = (i & 1) ? [0.05, 0.08, 0.20] : [0.07, 0.10, 0.24];
        mb.quad(PF(p0 + i, d0, 0.06), PF(p0 + i, d1, 0.06), PF(p0 + i + 1, d1, 0.06), PF(p0 + i + 1, d0, 0.06), pc, 0.18);
        var rl = [0.2, 0.95, 1.0];
        mb.quad(PF(p0 + i, d0, 0.08), PF(p0 + i, d0 + 0.35, 0.08), PF(p0 + i + 1, d0 + 0.35, 0.08), PF(p0 + i + 1, d0, 0.08), rl, 1);
        mb.quad(PF(p0 + i, d1 - 0.35, 0.08), PF(p0 + i, d1, 0.08), PF(p0 + i + 1, d1, 0.08), PF(p0 + i + 1, d1 - 0.35, 0.08), rl, 1);
      }
      function lp(rowF, d, y) { var r0 = Math.floor(rowF), f = rowF - r0, a = PF(r0, d, y), b = PF(r0 + 1, d, y); return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f]; }
      var pitch = 3.4, hc = 1.9, th = 0.85, dl = d0 + 0.9, dr = d1 - 0.9, saveMb = mb, lenM = pn * ds, fr, k;
      for (fr = 0; fr < PAD_FR; fr++) {
        mb = padFr[fr]; mb.cut(); mb.up = true; mb.ref = null;
        for (k = -1; k * pitch < lenM; k++) {
          var sM = (k + fr / PAD_FR) * pitch + 0.6; if (sM < 0.3 || sM + hc + th > lenM - 0.3) continue;
          var fz = Math.min(1, sM / Math.max(1, lenM)), col = [0.25 + 0.65 * fz, 1.0, 0.55 + 0.4 * (1 - fz)];
          var r0 = p0 + sM / ds, r1 = p0 + (sM + hc) / ds, rt = th / ds;
          var rA = r0, rB = r1, rT = rt; // brazo izquierdo y derecho de una flecha "chevron" que apunta hacia delante
          mb.quad(lp(rA, dl, 0.11), lp(rB, dm, 0.11), lp(rB + rT, dm, 0.11), lp(rA + rT, dl, 0.11), col, 1);
          mb.quad(lp(rA, dr, 0.11), lp(rB, dm, 0.11), lp(rB + rT, dm, 0.11), lp(rA + rT, dr, 0.11), col, 1);
        }
      }
      mb = saveMb; mb.up = true; padCount++;
    }
    function buildHole(H, PF, hwv) {
      mb.cut();
      var h0i = Math.round(H.s0 / ds), h1i = Math.round(H.s1 / ds), depth = 11;
      var midI = (h0i + h1i) >> 1, dm2 = (H.d0 + H.d1) / 2;
      var floorY = -depth;
      mb.up = true; mb.ref = null;
      mb.quad(PF(h0i, H.d0, floorY), PF(h0i, H.d1, floorY), PF(h1i, H.d1, floorY), PF(h1i, H.d0, floorY), [0.04, 0.09, 0.2]);
      // paredes hacia el interior (la referencia queda en el exterior de cada pared)
      var cols3 = [[0.72, 0.88, 1.0], [0.38, 0.6, 0.85], [0.14, 0.26, 0.5]];
      mb.ref = null; mb.up = false;
      for (var b = 0; b < 3; b++) {
        var y0 = -b * depth / 3, y1 = -(b + 1) * depth / 3;
        var cc = cols3[b];
        mb.ref = PF(h0i - 8, dm2, -4);
        mb.quad(PF(h0i, H.d0, y0), PF(h0i, H.d1, y0), PF(h0i, H.d1, y1), PF(h0i, H.d0, y1), cc);
        mb.ref = PF(h1i + 8, dm2, -4);
        mb.quad(PF(h1i, H.d0, y0), PF(h1i, H.d1, y0), PF(h1i, H.d1, y1), PF(h1i, H.d0, y1), shade(cc, 1.08));
        mb.ref = PF(midI, H.d0 - 14, -4);
        mb.quad(PF(h0i, H.d0, y0), PF(h1i, H.d0, y0), PF(h1i, H.d0, y1), PF(h0i, H.d0, y1), shade(cc, 0.92));
        mb.ref = PF(midI, H.d1 + 14, -4);
        mb.quad(PF(h0i, H.d1, y0), PF(h1i, H.d1, y0), PF(h1i, H.d1, y1), PF(h0i, H.d1, y1), shade(cc, 0.92));
      }
      mb.ref = null;
      // carteles de peligro a los lados de la entrada
      for (var sd = -1; sd <= 1; sd += 2) {
        var wp = PF(h0i - 2, sd * (hwv + 0.8), 0);
        mb.box(wp[0], wp[1] + 1.1, wp[2], 0.3, 2.2, 0.3, [0.3, 0.2, 0.15]);
        mb.box(wp[0], wp[1] + 2.3, wp[2], 1.5, 1.0, 0.2, [1.0, 0.75, 0.1], 0.2);
      }
    }
    for (k = 0; k < T.ramps.length; k++) if (!T.ramps[k].br) buildRamp(T.ramps[k], P);
    for (k = 0; k < T.pads.length; k++) if (!T.pads[k].br) buildPad(T.pads[k], P);
    for (k = 0; k < T.holes.length; k++) if (!T.holes[k].br) buildHole(T.holes[k], P, hw);

    /* ---- vallas ---- */
    if (!def.canyon) {
      var span = def.type === 'sprint' ? 6 : 6;
      for (side = -1; side <= 1; side += 2) {
        mb.cut();
        for (i = 0; i < N; i += span) {
          if (i % 42 === 0) mb.cut();
          var ia = i, ib = Math.min(i + span, N);
          if (inCaveRow[ia] || inCaveRow[ib] || skipMain[side][ia] || skipMain[side][ib]) continue;
          var pa = P(ia, side * (hw + 0.9), 0), pb = P(ib, side * (hw + 0.9), 0);
          mb.ref = null; mb.up = false;
          mb.box(pa[0], pa[1] + 0.65, pa[2], 0.28, 1.3, 0.28, [0.45, 0.3, 0.2]);
          mb.box(pa[0], pa[1] + 1.33, pa[2], 0.38, 0.14, 0.38, snow);
          var mx = (pa[0] + pb[0]) / 2, mz = (pa[2] + pb[2]) / 2, my = (pa[1] + pb[1]) / 2;
          var dx = pb[0] - pa[0], dz = pb[2] - pa[2], dy = pb[1] - pa[1], len = Math.sqrt(dx * dx + dy * dy + dz * dz);
          var yaw = Math.atan2(dx, dz), pitch = -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz));
          for (var rl = 0; rl < 2; rl++) {
            mb.push().translate(mx, my + 0.5 + rl * 0.5, mz).rotY(yaw).rotX(pitch);
            mb.box(0, 0, 0, 0.12, 0.13, len, [0.5, 0.34, 0.22]);
            mb.pop();
          }
        }
      }
    }

    /* ---- cuevas / tuneles de roca ---- */
    (function () {
      if (!caveR.length) return;
      var K = 14, seed = def.seed, crystalTheme = th.aurora > 0 && def.theme === 'crystal';
      function hash(a, b) { var x = Math.sin(a * 127.1 + b * 311.7 + seed * 3.3) * 43758.5453; return x - Math.floor(x); }
      var rockIn = mix3(th.rock, T.volcano ? [0.26, 0.12, 0.08] : [0.10, 0.16, 0.34], 0.55), rockOut = th.rock;
      var gl = T.volcano ? [[1.0, 0.55, 0.15], [1.0, 0.38, 0.1], [1.0, 0.75, 0.28], [0.95, 0.45, 0.2]] : crystalTheme ? [[0.85, 0.5, 1.0], [0.5, 0.7, 1.0], [1.0, 0.55, 0.9], [0.55, 1.0, 0.95]] : [[0.4, 0.95, 1.0], [0.65, 0.72, 1.0], [0.55, 1.0, 0.88], [0.8, 0.9, 1.0]];
      function inner(i, kk) {
        var phi = PI * kk / K, c = Math.cos(phi), sn = Math.sin(phi), edge = (kk === 0 || kk === K);
        var H = T.caveH(i) + (edge ? 0 : (hash(i >> 1, kk) - 0.5) * 1.8);
        var dd = -(hw + 0.5) * c * (edge ? 1 : 1 + (hash(i >> 1, kk + 40) - 0.5) * 0.07);
        return P(i, dd, H * sn + (edge ? -0.4 : 0));
      }
      caveInnerFn = inner;
      function outer(i, kk) {
        var phi = PI * kk / K, c = Math.cos(phi), sn = Math.sin(phi), edge = (kk === 0 || kk === K);
        var H = T.caveH(i) + 1 + (edge ? 0 : (hash(i >> 1, kk + 80) - 0.5) * 3.2);
        var dd = -(hw + 24) * c * (edge ? 1 : 1 + (hash(i >> 1, kk + 120) - 0.5) * 0.12);
        return P(i, dd, -3.2 + (H + 8) * sn);
      }
      for (var cv = 0; cv < caveR.length; cv++) {
        var r0 = caveR[cv][0], r1 = caveR[cv][1], ii, kk;
        var rowI = null, rowO = null;
        for (ii = r0; ii <= r1; ii++) {
          if ((ii - r0) % 24 === 0) mb.cut();
          var I1 = [], O1 = [];
          for (kk = 0; kk <= K; kk++) { I1.push(inner(ii, kk)); O1.push(outer(ii, kk)); }
          if (rowI) {
            for (kk = 0; kk < K; kk++) {
              // interior: normal hacia el eje
              var h = hash(ii, kk + 7), cin = shade(rockIn, 0.55 + h * 0.5), em = 0;
              var cy0 = (rowI[kk][1] + rowI[kk + 1][1] + I1[kk][1] + I1[kk + 1][1]) / 4 - py[ii];
              var cd = (kk + 0.5 - K / 2) / (K / 2) * (hw + 0.5);
              if (h > 0.955 && kk > 1 && kk < K - 1) { cin = gl[(ii + kk) & 3]; em = 0.85; }
              if (T.caves[cv].tun) { // v2.7: aberturas oscuras de cuevas laterales en las paredes, con borde de lava
                var hb = (ii / 9) | 0, hs = hash(hb, 61 + cv) > 0.5 ? 1 : 0, hOn = hash(hb, 71 + cv) > 0.45, hkk = hs ? [2, 3] : [K - 4, K - 3];
                var hr = ii - hb * 9;
                if (hOn && hr >= 1 && hr <= 7 && (kk === hkk[0] || kk === hkk[1])) {
                  var edgeH = (hr === 1 || hr === 7);
                  cin = edgeH ? [0.9, 0.38, 0.1] : [0.015, 0.015, 0.02]; em = edgeH ? 0.45 : 0;
                }
              }
              mb.up = false; mb.ref = P(ii, cd * 2.0, cy0 * 2 - 5);
              mb.quad(rowI[kk], rowI[kk + 1], I1[kk + 1], I1[kk], cin, em);
              // exterior: normal hacia afuera
              var h2 = hash(ii, kk + 21), sn2 = Math.sin(PI * (kk + 0.5) / K);
              var cout = mix3(rockOut, snow, smooth(0.35, 0.8, sn2 + (h2 - 0.5) * 0.3));
              mb.ref = P(ii, 0, 5);
              mb.quad(rowO[kk], rowO[kk + 1], O1[kk + 1], O1[kk], jit(cout, 0.12), 0);
            }
          }
          var faceHall = T.hall && ((ii === r1 && T.caves[cv].s1 === T.hall.s0) || (ii === r0 && T.caves[cv].s0 === T.hall.s1));
          if ((ii === r0 || ii === r1) && !faceHall) { // portal de entrada/salida
            mb.ref = P(ii === r0 ? ii + 14 : ii - 14, 0, 5);
            for (kk = 0; kk < K; kk++) mb.quad(I1[kk], I1[kk + 1], O1[kk + 1], O1[kk], jit(mix3(rockOut, snow, 0.25 + 0.4 * Math.sin(PI * (kk + 0.5) / K)), 0.1), 0);
          }
          rowI = I1; rowO = O1;
        }
        mb.ref = null;
        // estalactitas
        for (ii = r0 + 3; ii < r1 - 2; ii += 3) {
          var nS = 1 + (hash(ii, 3) > 0.6 ? 1 : 0);
          for (var q = 0; q < nS; q++) {
            var kq = 3 + Math.floor(hash(ii, 9 + q) * (K - 5)), pt = inner(ii, kq), sz = 0.6 + hash(ii, 11 + q) * 0.9, hh = 2.2 + hash(ii, 15 + q) * 5.0;
            mb.push().translate(pt[0], pt[1] + 0.2, pt[2]).rotX(PI);
            mb.cone(0, 0, 0, sz, hh, 5, shade(mix3(rockIn, [0.55, 0.8, 1.0], 0.25), 0.8 + hash(ii, q) * 0.5), 0, true);
            mb.pop();
          }
        }
        // grupos de cristales luminosos en las paredes
        for (ii = r0 + 6; ii < r1 - 4; ii += 9) {
          var sd = ((ii / 9) & 1) ? 1 : -1, cp = P(ii, sd * (hw - 0.2), 0.1), gc = gl[(ii / 9 + cv) & 3];
          mb.push().translate(cp[0], cp[1], cp[2]);
          mb.crystal(0, 0, 0, 0.8, 3.2 + hash(ii, 2) * 1.6, gc, 0.8, 6);
          mb.push().rotY(hash(ii, 5) * 6).rotZ(0.5); mb.crystal(0.1, 0, 0, 0.55, 2.2, shade(gc, 0.9), 0.8, 5); mb.pop();
          mb.push().rotY(hash(ii, 6) * 6).rotZ(-0.5); mb.crystal(-0.1, 0, 0.1, 0.5, 1.9, shade(gc, 1.05), 0.8, 5); mb.pop();
          mb.pop();
        }
        // cristales grandes en los portales
        for (var pe = 0; pe < 2; pe++) for (var sdd = -1; sdd <= 1; sdd += 2) {
          var pi_ = pe ? r1 : r0, pc = P(pi_, sdd * (hw + 3.2), -0.6), g3 = gl[(pe * 2 + (sdd > 0 ? 1 : 0)) & 3];
          mb.push().translate(pc[0], pc[1], pc[2]);
          mb.crystal(0, 0, 0, 1.2, 5.5, g3, 0.85, 6);
          mb.push().rotY(1.2).rotZ(0.5); mb.crystal(0.2, 0, 0, 0.8, 3.6, shade(g3, 0.9), 0.85, 5); mb.pop();
          mb.pop();
        }
      }
      mb.ref = null; mb.up = false;
    })();

    /* ---- v2.7: gran camara del volcan dentro de la montana (cupula de roca, volcan interior, lagos de lava, chimenea al crater) ---- */
    T.hallGlow = null;
    (function () {
      if (!T.hall || !T.volcano || !caveInnerFn) return;
      var seed = def.seed, K = 14, WD = 80, HD = 88, FLOOR = -3.4; // v2.8: camara algo mas estrecha (los tuneles laterales la rodean por fuera)
      function hash(a, b) { var x = Math.sin(a * 127.1 + b * 311.7 + seed * 5.9) * 43758.5453; return x - Math.floor(x); }
      var r0 = Math.round(T.hall.s0 / ds), r1 = Math.round(T.hall.s1 / ds), rm = (r0 + r1) >> 1, ii, kk;
      function dome(i, kk) {
        var phi = PI * kk / K, c = Math.cos(phi), sn = Math.sin(phi), edge = (kk === 0 || kk === K);
        var wob = 1 + 0.05 * Math.sin(i * 0.11 + seed);
        var W_ = WD * wob * (edge ? 1 : 1 + (hash(i >> 1, kk + 300) - 0.5) * 0.10), H_ = HD * wob * (edge ? 1 : 1 + (hash(i >> 1, kk + 340) - 0.5) * 0.14);
        return P(i, -W_ * c, FLOOR + (H_ - FLOOR) * sn);
      }
      var LAVA = [[1.0, 0.36, 0.06], [1.0, 0.55, 0.12], [1.0, 0.72, 0.2]];
      var rowD = null;
      for (ii = r0; ii <= r1; ii++) {
        if ((ii - r0) % 8 === 0) mb.cut();
        var D1 = []; for (kk = 0; kk <= K; kk++) D1.push(dome(ii, kk));
        if (rowD) {
          for (kk = 0; kk < K; kk++) {
            var h = hash(ii, kk + 7), cd = shade([0.17, 0.14, 0.15], 0.7 + h * 0.7), em = 0;
            if (h > 0.94) { cd = LAVA[(ii + kk) % 3]; em = 0.8; }
            else if (h < 0.08) cd = [0.30, 0.26, 0.26];
            var qx = (rowD[kk][0] + rowD[kk + 1][0] + D1[kk][0] + D1[kk + 1][0]) / 4, qy = (rowD[kk][1] + rowD[kk + 1][1] + D1[kk][1] + D1[kk + 1][1]) / 4, qz = (rowD[kk][2] + rowD[kk + 1][2] + D1[kk][2] + D1[kk + 1][2]) / 4;
            var ax_ = P(ii, 0, 18); mb.up = false; mb.ref = [2 * qx - ax_[0], 2 * qy - ax_[1], 2 * qz - ax_[2]];
            // cuevas laterales: huecos oscuros con borde de lava
            var hb = (ii / 10) | 0, hs = hash(hb, 91) > 0.5 ? 1 : 0, hOn = hash(hb, 93) > 0.35, hkk = hs ? [1, 2] : [K - 3, K - 2], hr = ii - hb * 10;
            if (hOn && hr >= 1 && hr <= 8 && (kk === hkk[0] || kk === hkk[1])) { var eH = (hr === 1 || hr === 8); cd = eH ? [0.9, 0.38, 0.1] : [0.012, 0.012, 0.018]; em = eH ? 0.45 : 0; }
            mb.quad(rowD[kk], rowD[kk + 1], D1[kk + 1], D1[kk], cd, em);
          }
        }
        // paredes de los extremos con la boca del tunel
        if (ii === r0 || ii === r1) {
          var I1 = []; for (kk = 0; kk <= K; kk++) I1.push(caveInnerFn(ii, kk));
          mb.ref = ii === r0 ? P(r0 - 10, 0, 10) : P(r1 + 10, 0, 10); mb.up = false;
          for (kk = 0; kk < K; kk++) { var hc = hash(ii, kk + 400), cc = hc > 0.8 ? [1.0, 0.42, 0.1] : shade([0.2, 0.16, 0.17], 0.7 + hc * 0.6); mb.quad(I1[kk], I1[kk + 1], D1[kk + 1], D1[kk], cc, hc > 0.8 ? 0.6 : 0); }
        }
        rowD = D1;
      }
      mb.ref = null; mb.up = false;
      // estalactitas de roca en el techo
      for (var sti = 0; sti < 46; sti++) {
        var si_ = r0 + 3 + Math.floor(hash(sti, 500) * (r1 - r0 - 6)), sk_ = 3 + Math.floor(hash(sti, 501) * (K - 5)), sp = dome(si_, sk_), ssz = 1.3 + hash(sti, 502) * 2.2, shh = 7 + hash(sti, 503) * 16;
        mb.push().translate(sp[0], sp[1] + 0.3, sp[2]).rotX(PI);
        mb.cone(0, 0, 0, ssz, shh, 6, shade([0.24, 0.20, 0.21], 0.8 + hash(sti, 504) * 0.5), 0, true);
        mb.pop();
      }
      // pilares de roca con vetas de lava junto a las paredes
      for (var pi2 = 0; pi2 < 14; pi2++) {
        var pr = r0 + 6 + Math.floor(hash(pi2, 510) * (r1 - r0 - 12)), pdd = (hash(pi2, 511) > 0.5 ? 1 : -1) * (hw + 24 + hash(pi2, 512) * 30), pp = P(pr, pdd, FLOOR), phh = 12 + hash(pi2, 513) * 30;
        if (Math.abs(pdd + 45) < 40) continue; // el volcan y su lago ocupan ese lado
        mb.push().translate(pp[0], pp[1], pp[2]).rotY(hash(pi2, 514) * 6);
        mb.cone(0, 0, 0, 3.5 + hash(pi2, 515) * 3, phh, 6, [0.18, 0.15, 0.16], 0, true);
        mb.cone(0, 0, 0, 3.6 + hash(pi2, 515) * 3, phh * 0.35, 6, [1.0, 0.42, 0.1], 0.7, true);
        mb.pop();
      }
      // lagos de lava (a nivel del suelo, brillantes)
      function lavaDisc(cx, cz, y, rIn, rOut, seg, tag) {
        mb.up = true; mb.ref = null;
        for (var a = 0; a < seg; a++) {
          var a0 = 2 * PI * a / seg, a1 = 2 * PI * (a + 1) / seg, hl = hash(a, tag), lc = hl > 0.7 ? [0.22, 0.12, 0.08] : LAVA[(a + tag) % 3];
          var q = [[cx + Math.cos(a0) * rIn, y, cz + Math.sin(a0) * rIn], [cx + Math.cos(a0) * rOut, y, cz + Math.sin(a0) * rOut], [cx + Math.cos(a1) * rOut, y, cz + Math.sin(a1) * rOut], [cx + Math.cos(a1) * rIn, y, cz + Math.sin(a1) * rIn]];
          mb.quad(q[0], q[3], q[2], q[1], lc, hl > 0.7 ? 0.15 : 0.95);
        }
      }
      var cone = P(rm, -45, 0), baseY = py[rm] + FLOOR + 0.5;
      mb.cut();
      lavaDisc(cone[0], cone[2], baseY + 0.25, 18, 33, 28, 1);
      lavaDisc(cone[0], cone[2], baseY + 0.3, 30, 33, 28, 2);
      [[-100, +54, 13], [+90, +56, 11], [-45, +60, 10], [+120, -60, 9]].forEach(function (pl, q) {
        var pc = P(rm + pl[0] / 1.5 | 0, pl[1], 0); if (Math.abs(pl[1]) < 45) return;
        lavaDisc(pc[0], pc[2], baseY + 0.2, 0.01, pl[2], 12, 7 + q);
      });
      // volcan interior: cono oscuro con rios de lava y crater incandescente
      mb.cut();
      var CS = 20, CK = 7, cg = [], cv0, cv1;
      var cveins = []; for (cv0 = 0; cv0 < 8; cv0++) cveins.push({ j: Math.floor(hash(cv0, 520) * CS), len: 0.55 + hash(cv0, 521) * 0.45 });
      for (cv0 = 0; cv0 <= CK; cv0++) {
        var t = cv0 / CK, rrC = 25 - 19 * Math.pow(t, 0.9), yyC = 50 * Math.pow(t, 1.5), row = [];
        for (cv1 = 0; cv1 <= CS; cv1++) { var aC = 2 * PI * (cv1 % CS) / CS, wob2 = 1 + 0.08 * Math.sin(cv1 * 2.3 + cv0); row.push([cone[0] + Math.cos(aC) * rrC * wob2, baseY + yyC, cone[2] + Math.sin(aC) * rrC * wob2]); }
        cg.push(row);
      }
      mb.up = false; mb.ref = [cone[0], baseY - 20, cone[2]];
      for (cv0 = 0; cv0 < CK; cv0++) for (cv1 = 0; cv1 < CS; cv1++) {
        var lv = false, t0 = cv0 / CK;
        for (var qv = 0; qv < cveins.length; qv++) { var ddv = Math.min(Math.abs(cv1 - cveins[qv].j), CS - Math.abs(cv1 - cveins[qv].j)); if (ddv < 1 && (1 - t0) < cveins[qv].len) lv = true; }
        var ccol = lv ? mix3([1.0, 0.36, 0.06], [1.0, 0.72, 0.2], hash(cv0, cv1)) : shade([0.20, 0.17, 0.18], 0.7 + hash(cv0 + 5, cv1) * 0.6);
        var A_ = cg[cv0][cv1], B_ = cg[cv0][cv1 + 1], C_ = cg[cv0 + 1][cv1 + 1], D_ = cg[cv0 + 1][cv1];
        mb.tri(A_, D_, C_, ccol, lv ? 0.85 : 0); mb.tri(A_, C_, B_, ccol, lv ? 0.85 : 0);
      }
      // crater del volcan interior
      mb.up = true; mb.ref = null;
      var topC = baseY + 50, cflo = topC - 7;
      for (cv1 = 0; cv1 < CS; cv1++) {
        var A2 = cg[CK][cv1], B2 = cg[CK][cv1 + 1], F1 = [cone[0] + (A2[0] - cone[0]) * 0.55, cflo, cone[2] + (A2[2] - cone[2]) * 0.55], F2 = [cone[0] + (B2[0] - cone[0]) * 0.55, cflo, cone[2] + (B2[2] - cone[2]) * 0.55];
        mb.tri(A2, B2, F2, [0.5, 0.18, 0.06], 0.6); mb.tri(A2, F2, F1, [0.55, 0.2, 0.06], 0.6);
        mb.tri([cone[0], cflo, cone[2]], F1, F2, mix3([1.0, 0.5, 0.1], [1.0, 0.85, 0.3], (cv1 & 1) * 0.6), 1.0);
      }
      T.hallGlow = { x: cone[0], y: topC + 6, z: cone[2], x2: px[rm], z2: pz[rm], y2: py[rm] + HD * 0.9 };
      // chimenea de lava: sube desde el techo hasta el crater de la montana
      if (T.volcanoFloor !== undefined) {
        var chB = py[rm] + HD * 0.9, chT = T.volcanoFloor + 3, CHS = 12, CHR = 13, cxh = px[rm], czh = pz[rm], CHK = 6;
        mb.cut(); mb.up = false;
        for (var ck2 = 0; ck2 < CHK; ck2++) {
          var y0c = chB + (chT - chB) * ck2 / CHK, y1c = chB + (chT - chB) * (ck2 + 1) / CHK, ccg = mix3([1.0, 0.6, 0.16], [1.0, 0.36, 0.08], ck2 / CHK);
          for (cv1 = 0; cv1 < CHS; cv1++) {
            var a0c = 2 * PI * cv1 / CHS, a1c = 2 * PI * (cv1 + 1) / CHS;
            mb.ref = [cxh + Math.cos(a0c) * 40, (y0c + y1c) / 2, czh + Math.sin(a0c) * 40];
            mb.quad([cxh + Math.cos(a0c) * CHR, y0c, czh + Math.sin(a0c) * CHR], [cxh + Math.cos(a1c) * CHR, y0c, czh + Math.sin(a1c) * CHR], [cxh + Math.cos(a1c) * CHR, y1c, czh + Math.sin(a1c) * CHR], [cxh + Math.cos(a0c) * CHR, y1c, czh + Math.sin(a0c) * CHR], shade(ccg, 0.85 + hash(ck2, cv1) * 0.3), 0.75);
          }
        }
      }
      mb.ref = null; mb.up = false;
    })();

    /* ---- arcos de salida y meta, tribunas y espectadores ---- */
    var FONT = {
      M: ['10001', '11011', '10101', '10101', '10001', '10001', '10001'], E: ['11111', '10000', '10000', '11110', '10000', '10000', '11111'],
      T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'], A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'],
      S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], L: ['10000', '10000', '10000', '10000', '10000', '10000', '11111'],
      J: ['00111', '00010', '00010', '00010', '00010', '10010', '01100'], O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'],
      G: ['01110', '10001', '10000', '10111', '10001', '10001', '01111'], U: ['10001', '10001', '10001', '10001', '10001', '10001', '01110'],
      I: ['11111', '00100', '00100', '00100', '00100', '00100', '11111'], D: ['11110', '10001', '10001', '10001', '10001', '10001', '11110']
    };
    // fuente de trazos (x 0..1, y 0..1.4)
    var STROKE = {
      S: [[[0.95, 1.12], [0.82, 1.28], [0.5, 1.37], [0.2, 1.3], [0.06, 1.12], [0.14, 0.9], [0.5, 0.72], [0.86, 0.54], [0.95, 0.3], [0.8, 0.1], [0.5, 0.03], [0.2, 0.1], [0.05, 0.28]]],
      A: [[[0.0, 0.0], [0.5, 1.4], [1.0, 0.0]], [[0.2, 0.5], [0.8, 0.5]]],
      L: [[[0.08, 1.4], [0.08, 0.0], [0.95, 0.0]]],
      I: [[[0.5, 1.4], [0.5, 0.0]], [[0.2, 1.4], [0.8, 1.4]], [[0.2, 0.0], [0.8, 0.0]]],
      D: [[[0.08, 1.4], [0.08, 0.0]], [[0.08, 1.4], [0.5, 1.4], [0.85, 1.2], [0.97, 0.7], [0.85, 0.2], [0.5, 0.0], [0.08, 0.0]]],
      M: [[[0.06, 0.0], [0.06, 1.4], [0.5, 0.5], [0.94, 1.4], [0.94, 0.0]]],
      E: [[[0.95, 1.4], [0.08, 1.4], [0.08, 0.0], [0.95, 0.0]], [[0.08, 0.7], [0.75, 0.7]]],
      T: [[[0.0, 1.4], [1.0, 1.4]], [[0.5, 1.4], [0.5, 0.0]]]
    };
    var gateRows = [];
    function gate(sIdx, word) {
      mb.cut(); gateRows.push(sIdx);
      var white = [0.97, 0.97, 0.97], blk = [0.1, 0.12, 0.16], red = [0.85, 0.17, 0.2];
      mb.ref = null; mb.up = false;
      for (var sd2 = -1; sd2 <= 1; sd2 += 2) {
        var g = P(sIdx, sd2 * (hw + 2.0), 0);
        mb.box(g[0], g[1] + 7.9, g[2], 1.2, 15.8, 1.2, red);
        mb.box(g[0], g[1] + 2.0, g[2], 1.3, 0.8, 1.3, white);
        mb.box(g[0], g[1] + 5.6, g[2], 1.3, 0.8, 1.3, white);
        mb.box(g[0], g[1] + 16.2, g[2], 1.8, 0.9, 1.8, [1.0, 0.85, 0.3], 0.5);
      }
      var yaw2 = Math.atan2(T.tx[sIdx % (N + 1)], T.tz[sIdx % (N + 1)]);
      var nChk = 14, wCell = (W + 5) / nChk;
      for (var cc2 = 0; cc2 < nChk; cc2++) for (var rr = 0; rr < 2; rr++) {
        var dpos = -(W + 5) / 2 + (cc2 + 0.5) * wCell;
        var pp = P(sIdx, dpos, 8.2 + rr * 0.8);
        mb.push().translate(pp[0], pp[1], pp[2]).rotY(yaw2);
        mb.box(0, 0, 0, wCell, 0.8, 1.2, ((cc2 + rr) & 1) ? white : blk, 0.15);
        mb.pop();
      }
      // cartel con la palabra
      var cp = P(sIdx, 0, 12.6);
      mb.push().translate(cp[0], cp[1], cp[2]).rotY(yaw2);
      mb.box(0, 0, 0, W + 4, 5.2, 0.7, [0.06, 0.1, 0.24]);
      mb.box(0, 2.75, 0, W + 4.4, 0.4, 0.9, [1.0, 0.85, 0.3], 0.55); mb.box(0, -2.75, 0, W + 4.4, 0.4, 0.9, [1.0, 0.85, 0.3], 0.55);
      // v3.7: letras con trazo redondeado (antes eran cuadritos tipo pixel art)
      var LW = 3.1, LH = 4.3, gapL = 1.0, sr = 0.27, totW = word.length * LW + (word.length - 1) * gapL, x0 = totW / 2;
      for (var li = 0; li < word.length; li++) {
        var strokes = STROKE[word.charAt(li)], offX = -x0 + li * (LW + gapL);
        for (var sk = 0; sk < strokes.length; sk++) {
          var pl = strokes[sk];
          for (var pi3 = 0; pi3 < pl.length; pi3++) {
            var ax = -(offX + pl[pi3][0] * LW), ay = pl[pi3][1] * (LH / 1.4) - LH / 2 + 0.0;
            for (var fz = -1; fz <= 1; fz += 2) {
              mb.push().translate(ax, ay, fz * 0.4).rotX(1.5708); mb.cyl(0, 0, 0, sr, sr, 0.34, 8, [1.0, 0.95, 0.75], 0.9); mb.pop();
            }
            if (pi3 > 0) {
              var bx2 = -(offX + pl[pi3 - 1][0] * LW), by2 = pl[pi3 - 1][1] * (LH / 1.4) - LH / 2, dxs = ax - bx2, dys = ay - by2, ln = Math.sqrt(dxs * dxs + dys * dys);
              for (var fz2 = -1; fz2 <= 1; fz2 += 2) { mb.push().translate((ax + bx2) / 2, (ay + by2) / 2, fz2 * 0.4).rotZ(Math.atan2(dys, dxs)); mb.box(0, 0, 0, ln, sr * 2, 0.34, [1.0, 0.95, 0.75], 0.9); mb.pop(); }
            }
          }
        }
      }
      mb.pop();
    }
    // espectador: pinguino de pie mirando hacia la pista (coordenadas locales, +z = hacia donde mira)
    var SP_COL = [[0.95, 0.25, 0.25], [0.2, 0.55, 0.95], [1.0, 0.8, 0.2], [0.3, 0.8, 0.45], [0.8, 0.35, 0.9], [1.0, 0.55, 0.15]];
    function spectator(x, y, z, yaw, k) {
      k = Math.abs(Math.floor(k) | 0);
      var c1 = SP_COL[k % 6], c2 = SP_COL[(k * 5 + 2) % 6], pose = k % 4, sc = 1.15 + (k % 3) * 0.08;
      mb.push().translate(x, y, z).rotY(yaw).scale(sc, sc, sc);
      mb.ell(0, 0.8, 0, 0.56, 0.82, 0.5, 6, 2, [0.07, 0.09, 0.15], 0);
      mb.ell(0, 0.72, 0.26, 0.4, 0.62, 0.3, 6, 2, [0.96, 0.98, 1.0], 0);
      mb.ell(0, 1.78, 0.02, 0.42, 0.38, 0.4, 6, 2, [0.09, 0.11, 0.18], 0);
      mb.box(0, 1.72, 0.46, 0.22, 0.12, 0.32, [1.0, 0.62, 0.12]);
      mb.box(-0.14, 1.88, 0.38, 0.09, 0.09, 0.08, [1, 1, 1]); mb.box(0.14, 1.88, 0.38, 0.09, 0.09, 0.08, [1, 1, 1]);
      mb.box(0, 1.46, 0.0, 0.72, 0.14, 0.62, c2);
      mb.ell(0, 2.08, 0, 0.44, 0.3, 0.44, 6, 2, c1, 0);
      mb.box(-0.2, 0.06, 0.18, 0.28, 0.12, 0.4, [1.0, 0.62, 0.12]); mb.box(0.2, 0.06, 0.18, 0.28, 0.12, 0.4, [1.0, 0.62, 0.12]);
      var upL = pose === 1 || pose === 2, upR = pose === 2 || pose === 3;
      mb.push().translate(-0.6, 1.2, 0).rotZ(upL ? -2.5 : -0.35); mb.box(0, -0.3, 0, 0.14, 0.62, 0.3, [0.07, 0.09, 0.15]); mb.pop();
      mb.push().translate(0.6, 1.2, 0).rotZ(upR ? 2.5 : 0.35); mb.box(0, -0.3, 0, 0.14, 0.62, 0.3, [0.07, 0.09, 0.15]); mb.pop();
      mb.pop();
    }
    // los espectadores no van en la malla: son pinguinos reales (animados) que dibuja el juego. Se guarda su puesto.
    T.specs = [];
    function addSpec(x, y, z, yawLocal, k) {
      mb.push().translate(x, y, z).rotY(yawLocal);
      var m = mb.m; T.specs.push({ x: m[12], y: m[13], z: m[14], yaw: Math.atan2(m[8], m[10]), k: k | 0 });
      mb.pop();
    }
    function wi(i) { return T.closed ? ((i % N) + N) % N : Math.max(0, Math.min(N, i)); }
    function stand(rowC, side) {
      rowC = Math.round(rowC); var r0 = rowC - 12, r1 = rowC + 9, i2, k2, n2 = 0;
      for (i2 = r0; i2 < r1; i2 += 2) {
        var ii2 = wi(i2 + 1), pc = P(ii2, 0, 0), yawT = Math.atan2(T.tx[ii2], T.tz[ii2]), pitT = -Math.asin(Math.max(-0.9, Math.min(0.9, T.sl[ii2])));
        if (i2 % 8 === r0 % 8) mb.cut();
        mb.push().translate(pc[0], pc[1], pc[2]).rotY(yawT).rotX(pitT);
        for (k2 = 0; k2 < 3; k2++) {
          var dOff = side * (hw + 4.4 + k2 * 2.7), lx = -dOff, top = 0.3 + k2 * 1.35;
          mb.box(lx, (top - 1.4) / 2, 0, 2.7, top + 1.4, 3.0, ((i2 >> 1) + k2) & 1 ? [0.22, 0.38, 0.7] : [0.88, 0.92, 0.98]);
          var cnt = (i2 + k2) % 3 === 0 ? 2 : 1;
          for (var q3 = 0; q3 < cnt; q3++) {
            n2++; if ((n2 * 7) % 10 === 0) continue;
            // mirar hacia la pista: +z local mira hacia lx decreciente cuando side>0
            addSpec(lx + (q3 - 0.5) * 0.15, top, -0.8 + q3 * 1.6 + (n2 % 3) * 0.1, side > 0 ? PI / 2 : -PI / 2, n2 + Math.abs(i2));
          }
        }
        mb.pop();
      }
      // banderines y globos
      for (i2 = r0; i2 < r1; i2 += 3) {
        var fp = P(wi(i2), side * (hw + 2.2), 0), fc = SP_COL[(Math.abs(i2) + (side > 0 ? 1 : 0) + 4) % 6];
        mb.box(fp[0], fp[1] + 2.6, fp[2], 0.12, 5.2, 0.12, [0.9, 0.9, 0.95]);
        mb.box(fp[0] - side * 0.1, fp[1] + 4.7, fp[2], 0.1, 0.9, 1.4, fc, 0.35);
        if (i2 % 2 === 0) { var bp = P(wi(i2), side * (hw + 6), 0); mb.box(bp[0], bp[1] + 3.2, bp[2], 0.04, 6, 0.04, [1, 1, 1]); mb.ell(bp[0], bp[1] + 6.9, bp[2], 0.55, 0.7, 0.55, 6, 3, SP_COL[(Math.abs(i2) * 3 + 1) % 6], 0.7); }
      }
    }
    // ---- v2.8: tunel de roca de un camino lateral de la montana (misma forma que las cuevas: arco interior, cascara exterior, estalactitas y cristales de lava) ----
    function buildTube(B, cvB, PB) {
      var K = 14, hwB = B.W / 2, i0 = B.i0, seedB = def.seed + B.id * 13, kk, ji;
      function hsh(a, b) { var x = Math.sin(a * 127.1 + b * 311.7 + seedB * 3.3) * 43758.5453; return x - Math.floor(x); }
      var rockInB = mix3(th.rock, [0.26, 0.12, 0.08], 0.55), glB = [[1.0, 0.55, 0.15], [1.0, 0.38, 0.1], [1.0, 0.75, 0.28], [0.95, 0.45, 0.2]];
      function binner(j, k) {
        var phi = PI * k / K, c = Math.cos(phi), sn = Math.sin(phi), edge = (k === 0 || k === K);
        var H = T.caveH(i0 + j) + (edge ? 0 : (hsh(j >> 1, k) - 0.5) * 1.8), dd = -(hwB + 0.5) * c * (edge ? 1 : 1 + (hsh(j >> 1, k + 40) - 0.5) * 0.07);
        return PB(i0 + j, dd, H * sn + (edge ? -0.4 : 0));
      }
      function bouter(j, k) {
        var phi = PI * k / K, c = Math.cos(phi), sn = Math.sin(phi), edge = (k === 0 || k === K);
        var H = T.caveH(i0 + j) + 1 + (edge ? 0 : (hsh(j >> 1, k + 80) - 0.5) * 3.2), dd = -(hwB + 24) * c * (edge ? 1 : 1 + (hsh(j >> 1, k + 120) - 0.5) * 0.12);
        return PB(i0 + j, dd, -3.2 + (H + 8) * sn);
      }
      var rowI = null, rowO = null;
      mb.cut();
      for (ji = cvB.j0; ji <= cvB.j1; ji++) {
        if ((ji - cvB.j0) % 24 === 0) mb.cut();
        var I1 = [], O1 = [];
        for (kk = 0; kk <= K; kk++) { I1.push(binner(ji, kk)); O1.push(bouter(ji, kk)); }
        if (rowI) {
          for (kk = 0; kk < K; kk++) {
            var h = hsh(ji, kk + 7), cin = shade(rockInB, 0.55 + h * 0.5), em = 0;
            var cy0 = (rowI[kk][1] + rowI[kk + 1][1] + I1[kk][1] + I1[kk + 1][1]) / 4 - B.py[ji], cd = (kk + 0.5 - K / 2) / (K / 2) * (hwB + 0.5);
            if (h > 0.955 && kk > 1 && kk < K - 1) { cin = glB[(ji + kk) & 3]; em = 0.85; }
            var hb = (ji / 9) | 0, hs = hsh(hb, 61) > 0.5 ? 1 : 0, hOn = hsh(hb, 71) > 0.45, hkk = hs ? [2, 3] : [K - 4, K - 3], hr = ji - hb * 9;
            if (hOn && hr >= 1 && hr <= 7 && (kk === hkk[0] || kk === hkk[1])) { var edgeH = (hr === 1 || hr === 7); cin = edgeH ? [0.9, 0.38, 0.1] : [0.015, 0.015, 0.02]; em = edgeH ? 0.45 : 0; }
            mb.up = false; mb.ref = PB(i0 + ji, cd * 2.0, cy0 * 2 - 5);
            mb.quad(rowI[kk], rowI[kk + 1], I1[kk + 1], I1[kk], cin, em);
            var h2 = hsh(ji, kk + 21), sn2 = Math.sin(PI * (kk + 0.5) / K), cout = (T.volcano && Math.hypot(B.px[ji] - T.volcano.x, B.pz[ji] - T.volcano.z) < 150) ? shade(mix3(rockInB, [0.34, 0.30, 0.28], 0.25), 0.7 + h2 * 0.5) : mix3(th.rock, snow, smooth(0.35, 0.8, sn2 + (h2 - 0.5) * 0.3));
            mb.ref = PB(i0 + ji, 0, 5);
            mb.quad(rowO[kk], rowO[kk + 1], O1[kk + 1], O1[kk], jit(cout, 0.12), 0);
          }
        }
        if (ji === cvB.j0 || ji === cvB.j1) { // portal de entrada/salida
          mb.ref = PB(i0 + (ji === cvB.j0 ? ji + 14 : ji - 14), 0, 5);
          for (kk = 0; kk < K; kk++) mb.quad(I1[kk], I1[kk + 1], O1[kk + 1], O1[kk], jit(mix3(th.rock, snow, 0.25 + 0.4 * Math.sin(PI * (kk + 0.5) / K)), 0.1), 0);
        }
        rowI = I1; rowO = O1;
      }
      mb.ref = null;
      for (ji = cvB.j0 + 3; ji < cvB.j1 - 2; ji += 3) { // estalactitas
        var nS = 1 + (hsh(ji, 3) > 0.6 ? 1 : 0);
        for (var q = 0; q < nS; q++) {
          var kq = 3 + Math.floor(hsh(ji, 9 + q) * (K - 5)), pt = binner(ji, kq), sz = 0.6 + hsh(ji, 11 + q) * 0.9, hh = 2.2 + hsh(ji, 15 + q) * 5.0;
          mb.push().translate(pt[0], pt[1] + 0.2, pt[2]).rotX(PI);
          mb.cone(0, 0, 0, sz, hh, 5, shade(mix3(rockInB, [0.55, 0.8, 1.0], 0.25), 0.8 + hsh(ji, q) * 0.5), 0, true);
          mb.pop();
        }
      }
      for (ji = cvB.j0 + 6; ji < cvB.j1 - 4; ji += 9) { // grupos de cristales de lava en las paredes
        var sd = ((ji / 9) & 1) ? 1 : -1, cp = PB(i0 + ji, sd * (hwB - 0.2), 0.1), gc = glB[(ji / 9 + B.id) & 3];
        mb.push().translate(cp[0], cp[1], cp[2]);
        mb.crystal(0, 0, 0, 0.8, 3.2 + hsh(ji, 2) * 1.6, gc, 0.8, 6);
        mb.push().rotY(hsh(ji, 5) * 6).rotZ(0.5); mb.crystal(0.1, 0, 0, 0.55, 2.2, shade(gc, 0.9), 0.8, 5); mb.pop();
        mb.push().rotY(hsh(ji, 6) * 6).rotZ(-0.5); mb.crystal(-0.1, 0, 0.1, 0.5, 1.9, shade(gc, 1.05), 0.8, 5); mb.pop();
        mb.pop();
      }
      for (var pe = 0; pe < 2; pe++) for (var sdd = -1; sdd <= 1; sdd += 2) { // cristales grandes en los portales
        var pi_ = pe ? cvB.j1 : cvB.j0, pc = PB(i0 + pi_, sdd * (hwB + 3.2), -0.6), g3 = glB[(pe * 2 + (sdd > 0 ? 1 : 0)) & 3];
        mb.push().translate(pc[0], pc[1], pc[2]);
        mb.crystal(0, 0, 0, 1.2, 5.5, g3, 0.85, 6);
        mb.push().rotY(1.2).rotZ(0.5); mb.crystal(0.2, 0, 0, 0.8, 3.6, shade(g3, 0.9), 0.85, 5); mb.pop();
        mb.pop();
      }
      mb.ref = null; mb.up = false;
    }
    // ---- atajos: calzada propia (franjas naranja y celeste), bermas, vallas, saltos, cartel de entrada ----
    function buildBranchMesh(B) {
      var CB = Math.round(B.W / cw), hwB = B.W / 2, Nb = B.Nb, i0 = B.i0, j, c, side2, k2;
      function PBr(ii, d, dy) { var jj = Math.max(0, Math.min(Nb, ii - i0)); return [B.px[jj] + B.rx[jj] * d, B.py[jj] + dy, B.pz[jj] + B.rz[jj] * d]; }
      var CLRb = hw + hwB + 0.5, wallSide = -B.side;
      function near(jj) { return B.gap[Math.max(0, Math.min(Nb, jj))] < CLRb; }
      var cvB = (T.bcaves || []).filter(function (q) { return q.br === B.id; })[0];
      function inTube(jj) { return !!cvB && jj >= cvB.j0 - 2 && jj <= cvB.j1 + 2; } // dentro del tunel lateral: sin bermas ni vallas
      mb.cut(); mb.up = true; mb.ref = null;
      var base = mix3(iceC, [0.62, 0.95, 1.0], 0.4);
      // v2.9: en la union con la pista principal el ramal no se dibuja encima de ella (sin franjas que se crucen ni suelos sobrepuestos):
      // solo se pintan las celdas del ramal que quedan fuera de la calzada principal
      function onMainRoad(x, z, rowC) {
        var best = 1e9, q2, ii, e2x, e2z;
        for (q2 = -16; q2 <= 16; q2++) {
          ii = rowC + q2; if (T.closed) ii = ((ii % N) + N) % N; else ii = Math.max(0, Math.min(N, ii));
          e2x = px[ii] - x; e2z = pz[ii] - z; e2x = e2x * e2x + e2z * e2z; if (e2x < best) best = e2x;
        }
        return Math.sqrt(best) < hw + 0.15;
      }
      // fila principal mas cercana a un punto: [x, z, rx, rz]
      function mainFrame(x, z, rowC) {
        var best = 1e9, q2, ii, bi = -1, e2x, e2z;
        for (q2 = -16; q2 <= 16; q2++) {
          ii = rowC + q2; if (T.closed) ii = ((ii % N) + N) % N; else ii = Math.max(0, Math.min(N, ii));
          e2x = px[ii] - x; e2z = pz[ii] - z; e2x = e2x * e2x + e2z * e2z; if (e2x < best) { best = e2x; bi = ii; }
        }
        return bi < 0 ? null : [px[bi], pz[bi], rx[bi], rz[bi]];
      }
      mb.cut(); var brC0 = mb.chunks.length - 1;
      for (j = 0; j < Nb; j++) {
        if (j % 36 === 0) mb.cut();
        var sm = B.s0 + (j + 0.5) * ds;
        for (c = 0; c < CB; c++) {
          var dm = -hwB + (c + 0.5) * cw, dA = -hwB + c * cw, dB2 = dA + cw;
          if (T.inHole(sm, dm, B.id)) continue;
          // v3.7: solo se omite la celda si TODA ella cae sobre la calzada principal (antes se omitia por el centro y quedaban rendijas dentadas con el vacio visible)
          var nOn = 0;
          if (B.gap[j] < hw + hwB + 3) nOn = (onMainRoad(B.px[j] + B.rx[j] * dA, B.pz[j] + B.rz[j] * dA, i0 + j) ? 1 : 0) + (onMainRoad(B.px[j] + B.rx[j] * dB2, B.pz[j] + B.rz[j] * dB2, i0 + j) ? 1 : 0) +
              (onMainRoad(B.px[j + 1] + B.rx[j + 1] * dA, B.pz[j + 1] + B.rz[j + 1] * dA, i0 + j + 1) ? 1 : 0) + (onMainRoad(B.px[j + 1] + B.rx[j + 1] * dB2, B.pz[j + 1] + B.rz[j + 1] * dB2, i0 + j + 1) ? 1 : 0);
          if (nOn === 4) continue;
          // v3.9: una celda que toca la calzada principal no lleva franja de borde (no se ve una raya blanca/naranja pintada sobre la pista)
          var edge = (c === 0 || c === CB - 1) && nOn === 0, col;
          // v3.9: mismo hielo que la pista principal (color por vertice con el mismo ruido continuo), sin tono distinto ni ajedrez: el atajo ya no parece una lamina encima
          var sB0 = B.s0 + j * ds, sB1 = sB0 + ds, cA0 = roadCol(sB0, dA), cB0 = roadCol(sB0, dB2), cC0 = roadCol(sB1, dB2), cD0 = roadCol(sB1, dA);
          col = cA0;
          if (edge) col = (j & 2) ? [1.0, 0.58, 0.16] : [0.97, 0.97, 1.0];
          var a2 = PBr(i0 + j, dA, 0.04), b2 = PBr(i0 + j, dB2, 0.04), c2 = PBr(i0 + j + 1, dB2, 0.04), d2 = PBr(i0 + j + 1, dA, 0.04);
          if (nOn > 0) { // v3.9: la celda se recorta en el borde de la calzada principal: nada del atajo se dibuja casi a ras ENCIMA de la pista (en GPUs de 16 bits de profundidad eso parpadeaba como una malla)
            var mq = mainFrame(B.px[j] + B.rx[j] * (dA + dB2) * 0.5, B.pz[j] + B.rz[j] * (dA + dB2) * 0.5, i0 + j), poly = [a2, b2, c2, d2], clip = [], pi2, cur, prv, vc, vp;
            if (mq) {
              for (pi2 = 0; pi2 < poly.length; pi2++) {
                cur = poly[pi2]; prv = poly[(pi2 + poly.length - 1) % poly.length];
                vc = B.side * ((cur[0] - mq[0]) * mq[2] + (cur[2] - mq[1]) * mq[3]) - (hw - 0.1); vp = B.side * ((prv[0] - mq[0]) * mq[2] + (prv[2] - mq[1]) * mq[3]) - (hw - 0.1);
                if ((vc >= 0) !== (vp >= 0)) { var tk = vp / (vp - vc); clip.push([prv[0] + (cur[0] - prv[0]) * tk, prv[1] + (cur[1] - prv[1]) * tk, prv[2] + (cur[2] - prv[2]) * tk]); }
                if (vc >= 0) clip.push(cur);
              }
              for (pi2 = 1; pi2 + 1 < clip.length; pi2++) mb.tri(clip[0], clip[pi2], clip[pi2 + 1], col, 0);
              continue;
            }
          }
          if (edge) mb.quad(a2, b2, c2, d2, col, 0.2); else { mb.tri(a2, b2, c2, cA0, 0, [cA0, cB0, cC0]); mb.tri(a2, c2, d2, cA0, 0, [cA0, cC0, cD0]); }
        }
      }
      mb.cut(); PG.smoothMesh({ chunks: mb.chunks.slice(brC0, mb.chunks.length - 1) }, 0.9);
      // bermas y falda de nieve (no en el lado que da a la pista mientras estan pegadas)
      // v3.7: altura del ramal sobre la pista principal en cada fila: la falda de nieve baja hasta el nivel del suelo de al lado (el atajo ya no 'flota')
      var liftB = new Float32Array(Nb + 2);
      for (j = 0; j <= Nb; j++) { var bgl = 1e18, ymn = 0, qj; for (qj = i0 + j - 14; qj <= i0 + j + 14; qj++) { var jq = T.closed ? ((qj % N) + N) % N : Math.max(0, Math.min(N, qj)), exq = px[jq] - B.px[j], ezq = pz[jq] - B.pz[j], eeq = exq * exq + ezq * ezq; if (eeq < bgl) { bgl = eeq; ymn = py[jq]; } } liftB[j] = Math.max(0, Math.min(8, B.py[j] - ymn)); }
      var offs2 = [hwB, hwB + 1.8, hwB + 6, hwB + 20, hwB + 34], hts2 = [0.05, 0.95, -1.15, -1.5, -1.7];
      for (side2 = -1; side2 <= 1; side2 += 2) {
        mb.cut();
        for (j = 0; j < Nb; j += 2) {
          if (j % 40 === 0) mb.cut();
          if (side2 === wallSide && (near(j) || near(j + 2))) continue;
          if (inTube(j) || inTube(j + 2)) continue;
          var j1 = Math.min(j + 2, Nb);
          // v3.9: en el lado que mira a la pista principal la falda se recorta a la holgura disponible (no cubre la calzada vecina)
          var cMb = Math.min(B.clr[j], B.clr[j1]);
          var rg = (side2 === wallSide && cMb < 400) ? skirtRings(hwB, offs2, hts2, cMb, -(B.py[j] - B.mainY[j] + B.py[j1] - B.mainY[j1]) * 0.5) : null;
          var nR = rg ? rg[0].length - 1 : 4;
          for (k2 = 0; k2 < nR; k2++) {
            var col2 = jit(k2 === 0 ? mix3(snow, iceC, 0.15) : snow, 0.07);
            var dr = function (kr, lf) { return kr <= 1 ? 0 : (kr === 2 ? 0.45 * lf : lf); };
            if (rg) { mb.quad(PBr(i0 + j, side2 * rg[0][k2], rg[1][k2]), PBr(i0 + j1, side2 * rg[0][k2], rg[1][k2]), PBr(i0 + j1, side2 * rg[0][k2 + 1], rg[1][k2 + 1]), PBr(i0 + j, side2 * rg[0][k2 + 1], rg[1][k2 + 1]), col2); continue; }
            mb.quad(PBr(i0 + j, side2 * offs2[k2], hts2[k2] - dr(k2, liftB[j])), PBr(i0 + j1, side2 * offs2[k2], hts2[k2] - dr(k2, liftB[j1])), PBr(i0 + j1, side2 * offs2[k2 + 1], hts2[k2 + 1] - dr(k2 + 1, liftB[j1])), PBr(i0 + j, side2 * offs2[k2 + 1], hts2[k2 + 1] - dr(k2 + 1, liftB[j])), col2);
          }
        }
      }
      // vallas
      if (!def.canyon) for (side2 = -1; side2 <= 1; side2 += 2) {
        mb.cut();
        for (j = 0; j < Nb; j += 6) {
          if (j % 42 === 0) mb.cut();
          var jb = Math.min(j + 6, Nb);
          if (side2 === wallSide && (near(j) || near(jb))) continue;
          if (inTube(j) || inTube(jb)) continue;
          var pa = PBr(i0 + j, side2 * (hwB + 0.9), 0), pb = PBr(i0 + jb, side2 * (hwB + 0.9), 0);
          mb.ref = null; mb.up = false;
          mb.box(pa[0], pa[1] + 0.65, pa[2], 0.28, 1.3, 0.28, [0.45, 0.3, 0.2]);
          mb.box(pa[0], pa[1] + 1.33, pa[2], 0.38, 0.14, 0.38, [1.0, 0.6, 0.18], 0.3);
          var mx = (pa[0] + pb[0]) / 2, mz = (pa[2] + pb[2]) / 2, my = (pa[1] + pb[1]) / 2, dx = pb[0] - pa[0], dz = pb[2] - pa[2], dy = pb[1] - pa[1], len = Math.sqrt(dx * dx + dy * dy + dz * dz);
          var yaw = Math.atan2(dx, dz), pitch = -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz));
          for (var rl = 0; rl < 2; rl++) { mb.push().translate(mx, my + 0.5 + rl * 0.5, mz).rotY(yaw).rotX(pitch); mb.box(0, 0, 0, 0.12, 0.13, len, rl ? [1.0, 0.6, 0.18] : [0.5, 0.34, 0.22]); mb.pop(); }
        }
      }
      // rampas, turbos y grieta del atajo
      T.ramps.forEach(function (R) { if (R.br === B.id) buildRamp(R, PBr); });
      T.pads.forEach(function (PD) { if (PD.br === B.id) buildPad(PD, PBr); });
      T.holes.forEach(function (H) { if (H.br === B.id) buildHole(H, PBr, hwB); });
      if (cvB) buildTube(B, cvB, PBr);
      // v3.0: flechas de neon animadas (chevrons que avanzan, como los turbos) sobre los dos caminos. Cada camino tiene su propia hilera
      // (cian = pista principal, naranja = atajo), con 10 m entre ejes, asi que nunca se tocan ni se superponen.
      var NEON_MAIN = [0.25, 0.95, 1.0], NEON_BR = [1.0, 0.55, 0.12];
      function animChevrons(pf, rowA, rowB, dC, halfW, col) {
        var pitch = 4.6, hc = 1.7, thk = 0.75, lenM = (rowB - rowA) * ds, saveMb = mb, fr, kc;
        function lpa(rowF, d, y) { var r0 = Math.floor(rowF), f = rowF - r0, A = pf(r0, d, y), Bq = pf(r0 + 1, d, y); return [A[0] + (Bq[0] - A[0]) * f, A[1] + (Bq[1] - A[1]) * f, A[2] + (Bq[2] - A[2]) * f]; }
        for (fr = 0; fr < PAD_FR; fr++) {
          mb = padFr[fr]; mb.cut(); mb.up = true; mb.ref = null;
          for (kc = -1; kc * pitch < lenM; kc++) {
            var sM = (kc + fr / PAD_FR) * pitch + 0.3; if (sM < 0.2 || sM + hc + thk > lenM - 0.2) continue;
            var r0 = rowA + sM / ds, r1 = rowA + (sM + hc) / ds, rt = thk / ds;
            mb.quad(lpa(r0, dC - halfW, 0.13), lpa(r1, dC, 0.13), lpa(r1 + rt, dC, 0.13), lpa(r0 + rt, dC - halfW, 0.13), col, 1);
            mb.quad(lpa(r0, dC + halfW, 0.13), lpa(r1, dC, 0.13), lpa(r1 + rt, dC, 0.13), lpa(r0 + rt, dC + halfW, 0.13), col, 1);
          }
        }
        mb = saveMb; mb.up = true; padCount++;
      }
      mb.cut(); mb.ref = null; mb.up = true;
      var m60 = Math.round(66 / ds), m6 = Math.round(8 / ds), m34 = Math.round(36 / ds);
      // antes de separarse: las dos opciones lado a lado sobre la pista principal (cian = seguir, naranja = atajo)
      animChevrons(PW, B.i0 - m60, B.i0 - m6, -B.side * 5.0, 1.75, NEON_MAIN);
      animChevrons(PW, B.i0 - m60, B.i0 - m6, B.side * 5.0, 1.75, NEON_BR);
      // ya separados: una hilera por camino, centrada en cada uno
      var jsep = Math.max(0, Math.min(Nb - m34 - 2, B.j0 + 2));
      animChevrons(PBr, i0 + jsep, i0 + jsep + m34, 0, 1.75, NEON_BR);
      animChevrons(PW, B.i0 + jsep, B.i0 + jsep + m34, 0, 1.75, NEON_MAIN);
      mb.up = false;
    }
    gate(startRow % N, T.type === 'sprint' ? 'SALIDA' : 'META');
    if (T.type === 'sprint') gate(finRow, 'META');
    T.branches.forEach(buildBranchMesh);

    // v2.8/v2.9: aviso de agua antes de la laguna: franjas de olas pintadas en la calzada (sin cartel) y boyas
    if (T.lake) (function () {
      var rS = Math.round(T.lake.s0 / ds), k;
      // franjas de olas azules pintadas sobre la calzada (cada vez mas juntas al acercarse al agua)
      mb.up = true; mb.ref = null;
      var rr0 = Math.max(2, rS - 40), stripe = 0;
      for (k = rr0; k < rS - 1; k += 4 - (k > rS - 16 ? 1 : 0), stripe++) {
        for (var wv = 0; wv < 6; wv++) {
          var d0 = -hw + 1 + wv * ((hw * 2 - 2) / 6), d1 = d0 + (hw * 2 - 2) / 6 * 0.62, ph = (wv & 1) ? 1 : 0;
          var A1 = P(k + ph, d0, 0.09), B1 = P(k + ph, d1, 0.09), C1 = P(k + ph + 1, d1, 0.09), D1 = P(k + ph + 1, d0, 0.09);
          mb.quad(A1, B1, C1, D1, [0.15, 0.55, 0.98], 0.5);
        }
      }
      mb.up = false;
    })();
    for (var gi2 = 0; gi2 < gateRows.length; gi2++) { var gr = gateRows[gi2]; if (T.closed || (gr > 14 && gr < N - 12)) { stand(gr, -1); stand(gr, 1); } }

    // v3.2: la meta es un pequeno "complejo": torre de control con cabina de cristal y antena, pantalla gigante, podio de ganadores,
    // mastiles de luz y guirnaldas de banderines sobre la pista (todo en la malla estatica: no cuesta nada al dibujar)
    function landmark(sIdx, word) {
      mb.cut(); mb.ref = null; mb.up = false;
      var yawL = Math.atan2(T.tx[sIdx % (N + 1)], T.tz[sIdx % (N + 1)]), k, sd3;
      var CONC = [0.78, 0.82, 0.9], DK = [0.16, 0.2, 0.3], RED = [0.85, 0.17, 0.2], GLS = [0.45, 0.85, 1.0];
      // torre de control (lado derecho, detras de las gradas)
      var tp0 = P(sIdx, hw + 25, 0);
      mb.push().translate(tp0[0], tp0[1], tp0[2]).rotY(yawL);
      mb.box(0, -3, 0, 9, 12, 9, CONC);                       // zocalo hundido (evita que flote sobre el terreno)
      mb.box(0, 3.6, 0, 7.4, 1.0, 7.4, DK);
      mb.cyl(0, 4.1, 0, 2.2, 1.7, 22, 10, CONC);               // fuste
      for (k = 0; k < 5; k++) mb.box(0, 6 + k * 4.4, 0, 3.7, 0.5, 3.7, k & 1 ? RED : [1, 1, 1]);
      mb.cyl(0, 26.2, 0, 3.4, 3.7, 3.4, 10, GLS, 0.7);         // cabina de cristal luminosa
      mb.cyl(0, 25.7, 0, 4.2, 4.2, 0.5, 10, DK);
      mb.cone(0, 29.6, 0, 4.0, 2.2, 10, RED);                  // techo
      mb.box(0, 34.2, 0, 0.3, 8, 0.3, [0.85, 0.88, 0.95]);       // antena
      mb.ell(0, 38.4, 0, 0.55, 0.55, 0.55, 6, 4, [1.0, 0.3, 0.25], 1);
      for (sd3 = -1; sd3 <= 1; sd3 += 2) { mb.box(sd3 * 2.4, 31.7, 0, 0.18, 1.8, 0.18, [0.8, 0.82, 0.9]); mb.ell(sd3 * 2.4, 32.8, 0, 0.35, 0.35, 0.35, 5, 3, [1.0, 0.9, 0.3], 1); }
      mb.pop();
      // pantalla gigante en el lado izquierdo, sobre dos postes
      var sp0 = P(sIdx, -(hw + 25), 0);
      mb.push().translate(sp0[0], sp0[1], sp0[2]).rotY(yawL + PI);
      mb.box(-4.5, 0, 0, 1.0, 22, 1.0, DK); mb.box(4.5, 0, 0, 1.0, 22, 1.0, DK);
      mb.box(0, 13.5, 0, 14.5, 7.4, 1.0, DK);
      mb.box(0, 13.5, 0.55, 13.4, 6.3, 0.2, [0.1, 0.55, 0.95], 0.8);
      mb.box(0, 13.5, 0.7, 12.6, 0.5, 0.15, [1.0, 0.95, 0.6], 0.95);
      for (k = 0; k < 6; k++) mb.box(-5.5 + k * 2.2, 14.8 + (k % 2) * 0.4, 0.72, 1.5, 0.7 + (k % 3) * 0.5, 0.1, [1, 1, 1], 0.9);
      mb.pop();
      // podio 1-2-3 pegado a la tribuna derecha
      var pd0 = P(sIdx, hw + 14, 0);
      mb.push().translate(pd0[0], pd0[1], pd0[2]).rotY(yawL);
      mb.box(0, -1.2, 0, 8.4, 3, 3.2, CONC);
      mb.box(0, 0.7, 0, 2.8, 2.6, 3.0, [1.0, 0.82, 0.22]);       // 1o
      mb.box(2.8, 0.1, 0, 2.8, 1.4, 3.0, [0.82, 0.86, 0.92]);    // 2o
      mb.box(-2.8, -0.2, 0, 2.8, 0.8, 3.0, [0.82, 0.5, 0.25]);   // 3o
      mb.pop();
      // mastiles de luz junto a cada poste de la meta
      for (sd3 = -1; sd3 <= 1; sd3 += 2) {
        var lm = P(sIdx, sd3 * (hw + 9), 0);
        mb.box(lm[0], lm[1] + 7, lm[2], 0.35, 14, 0.35, [0.7, 0.72, 0.8]);
        mb.box(lm[0], lm[1] + 14.2, lm[2], 2.2, 0.5, 1.1, DK);
        for (k = -1; k <= 1; k++) mb.box(lm[0] + k * 0.7, lm[1] + 13.85, lm[2], 0.5, 0.2, 0.5, [1.0, 0.98, 0.85], 1);
      }
      // guirnalda de banderines entre los dos postes de la meta (2 cuerdas, colgando)
      var gA = P(sIdx, hw + 2.0, 15.4), gB = P(sIdx, -(hw + 2.0), 15.4);
      for (var gl2 = 0; gl2 < 2; gl2++) {
        var off = gl2 ? 4 : -4;
        for (k = 0; k < 22; k++) {
          var t0 = k / 22, t1 = (k + 0.5) / 22, t2 = (k + 1) / 22, sag0 = -Math.sin(t0 * PI) * 1.6, sag1 = -Math.sin(t1 * PI) * 1.6 - 1.1, sag2 = -Math.sin(t2 * PI) * 1.6;
          var cx0 = gA[0] + (gB[0] - gA[0]) * t0, cz0 = gA[2] + (gB[2] - gA[2]) * t0, cx2 = gA[0] + (gB[0] - gA[0]) * t2, cz2 = gA[2] + (gB[2] - gA[2]) * t2, cx1 = (cx0 + cx2) / 2, cz1 = (cz0 + cz2) / 2;
          var fx = Math.sin(yawL) * off, fz = Math.cos(yawL) * off;
          mb.tri([cx0 + fx, gA[1] + sag0 + (gA[1] ? 0 : 0), cz0 + fz], [cx2 + fx, gA[1] + sag2, cz2 + fz], [cx1 + fx, gA[1] + sag1 + 0.0, cz1 + fz], SP_COL[(k + gl2 * 3) % 6], 0.4);
        }
      }
    }
    for (var gi3 = 0; gi3 < gateRows.length; gi3++) { var gq = gateRows[gi3]; if (T.closed || (gq > 14 && gq < N - 12)) landmark(gq); }

    /* ---- terreno ---- */
    var nn = { i: 0, dist: 0 }, waterY = -1e9;
    if (def.water) { var mn = 1e9; for (i = 0; i <= N; i++) if (py[i] < mn) mn = py[i]; waterY = mn - 9; }
    T.waterY = waterY;
    function hgt(x, z, out) {
      T.nearest(x, z, nn);
      var base = (T.branches.length ? T.blendY(x, z) : nn.y) - 1.5, dist = nn.dist, n = PG.fbm(x / 120, z / 120, def.seed), hh;
      if (def.canyon) { var nc = PG.fbm(x / 210 + 5, z / 210 - 3, def.seed + 4); hh = base + smooth(hw + 24, hw + 96, dist) * def.hills * (0.85 + 0.35 * nc) + smooth(hw + 110, hw + 320, dist) * 56 * n; } // v3.2: muros menos verticales y sin dientes (antes parecian cristales huecos)
      else if (def.water) hh = base - smooth(hw + 28, hw + 120, dist) * (def.hills + 24) + (n - 0.5) * 4;
      else hh = base + smooth(hw + 28, hw + 190, dist) * def.hills * (0.10 + 1.0 * n * n * 1.5);
      if (T.volcano) { var vV = T.volcano, rrV = Math.hypot(x - vV.x, z - vV.z), mkV = 1 - smooth(vV.R * 0.80, vV.R * 1.0, rrV); if (mkV > 0) hh = hh + (base - 1.8 - hh) * mkV; }
      if (out) { out.dist = dist; out.i = nn.i; }
      return hh;
    }
    T.hgt = function (x, z) { return hgt(x, z, null); };
    var bb = T.bbox, margin = 430, cs = def.canyon ? 15 : 20;
    var gx0 = Math.floor((bb.x0 - margin) / cs), gx1 = Math.ceil((bb.x1 + margin) / cs), gz0 = Math.floor((bb.z0 - margin) / cs), gz1 = Math.ceil((bb.z1 + margin) / cs);
    var nx = gx1 - gx0 + 1, nz = gz1 - gz0 + 1;
    var V = new Float32Array(nx * nz * 3), Dd = new Float32Array(nx * nz), tmp = { dist: 0, i: 0 };
    var hr = PG.rng(def.seed * 17 + 3);
    for (var gz = 0; gz < nz; gz++) for (var gx = 0; gx < nx; gx++) {
      var xx = (gx0 + gx) * cs + (hr() - 0.5) * cs * (def.canyon ? 0.25 : 0.45), zz = (gz0 + gz) * cs + (hr() - 0.5) * cs * (def.canyon ? 0.25 : 0.45);
      var yy = hgt(xx, zz, tmp) + (hr() - 0.5) * 1.2;
      if (def.water && yy < waterY) yy = waterY;
      var o3 = (gz * nx + gx) * 3; V[o3] = xx; V[o3 + 1] = yy; V[o3 + 2] = zz; Dd[gz * nx + gx] = tmp.dist;
    }
    var skip = hw + 22;
    mb.ref = null; mb.up = true;
    function TV(gx, gz) { var o = (gz * nx + gx) * 3; return [V[o], V[o + 1], V[o + 2]]; }
    var BLK = 6, terrC0 = mb.chunks.length - 1, snowDrift = function (x, z) { var n1 = vn(x * 0.011 + 40, z * 0.011), n2 = vn(x * 0.045, z * 0.045 + 7); return mix3(shade(snow, 0.985 + n2 * 0.035), [0.84, 0.92, 1.0], 0.5 * n1); };
    for (var bz = 0; bz < nz - 1; bz += BLK) for (var bx = 0; bx < nx - 1; bx += BLK) {
      mb.cut();
      for (gz = bz; gz < Math.min(nz - 1, bz + BLK); gz++) for (gx = bx; gx < Math.min(nx - 1, bx + BLK); gx++) {
      if (Dd[gz * nx + gx] < skip || Dd[gz * nx + gx + 1] < skip || Dd[(gz + 1) * nx + gx] < skip || Dd[(gz + 1) * nx + gx + 1] < skip) continue;
      var v00 = TV(gx, gz), v10 = TV(gx + 1, gz), v11 = TV(gx + 1, gz + 1), v01 = TV(gx, gz + 1);
      var tris = (((gx + gz) & 1) ? [[v00, v10, v11], [v00, v11, v01]] : [[v00, v10, v01], [v10, v11, v01]]);
      for (var tq = 0; tq < 2; tq++) {
        var A = tris[tq][0], B = tris[tq][1], Cc = tris[tq][2];
        var ux = B[0] - A[0], uy = B[1] - A[1], uz = B[2] - A[2], vx = Cc[0] - A[0], vy = Cc[1] - A[1], vz = Cc[2] - A[2];
        var nxx = uy * vz - uz * vy, nyy = uz * vx - ux * vz, nzz = ux * vy - uy * vx, nl = Math.sqrt(nxx * nxx + nyy * nyy + nzz * nzz) || 1;
        var slope = Math.abs(nyy) / nl, avgY = (A[1] + B[1] + Cc[1]) / 3, tcol, snowTri = false;
        if (def.water && avgY <= waterY + 0.05 && A[1] <= waterY + 0.01 && B[1] <= waterY + 0.01 && Cc[1] <= waterY + 0.01) tcol = [0.16, 0.42, 0.58];
        else if (slope < 0.74) { // v3.0: roca opaca con estratos (antes los muros azul palido parecian transparentes)
          var rkc = mix3(th.rock, [0.30, 0.31, 0.37], th.rock[2] > th.rock[0] ? 0.55 : 0.18);
          var strata = 0.9 + 0.12 * Math.sin(avgY * 0.42 + (A[0] + A[2]) * 0.01);
          tcol = shade(mix3(rkc, snow, smooth(0.45, 0.74, slope) * 0.3), strata * (0.78 + 0.5 * slope));
        }
        else { tcol = snow; snowTri = true; }
        var tem = tcol[2] > tcol[0] + 0.2 && def.water ? 0.1 : 0;
        if (T.volcano) { // suelo de la camara del volcan: basalto oscuro con manchas de lava
          var tcx = (A[0] + B[0] + Cc[0]) / 3, tcz = (A[2] + B[2] + Cc[2]) / 3, rrT = Math.hypot(tcx - T.volcano.x, tcz - T.volcano.z);
          if (rrT < T.volcano.R * 0.9) {
            var nl = PG.fbm(tcx / 20, tcz / 20, def.seed + 9);
            if (nl > 0.70 && Math.abs((tcx - T.volcano.x) * T.volcano.ax + (tcz - T.volcano.z) * T.volcano.az) < T.volcano.hall + 6) { tcol = mix3([1.0, 0.36, 0.06], [1.0, 0.7, 0.18], hr() ); tem = 0.9; }
            else { tcol = mix3([0.16, 0.13, 0.14], [0.27, 0.23, 0.23], nl); tem = 0; }
          }
        }
        if (snowTri && !T.volcano) { var cA = snowDrift(A[0], A[2]), cB = snowDrift(B[0], B[2]), cC = snowDrift(Cc[0], Cc[2]); mb.tri(A, B, Cc, cA, tem, [cA, cB, cC]); } // v3.7: nieve suave (color continuo, sin tono por triangulo)
        else { tcol = jit(tcol, 0.08); mb.tri(A, B, Cc, tcol, tem); }
      }
    }
    }
    PG.smoothMesh({ chunks: mb.chunks.slice(terrC0) }, 0.88); // normales suaves en las lomas de nieve (la roca empinada sigue facetada)
    mb.up = false; mb.ref = null;

    /* ---- decoracion: arboles, rocas, cristales, montanas, icebergs ---- */
    function groundAt(x, z) { return hgt(x, z, null); }
    var treeCol = th.tree, cells = {}, mainMB = mb, CELL = 160;
    function cellMB(x, z) {
      var key = Math.floor(x / CELL) + ',' + Math.floor(z / CELL);
      var c = cells[key]; if (!c) { c = cells[key] = new PG.MB(); c.rnd = PG.rng(Math.abs(Math.floor(x / CELL) * 73 + Math.floor(z / CELL) * 31) + 7); }
      mb = c; return c;
    }
    var treePal = [[0.36, 0.24, 0.14], snow, treeCol, shade(treeCol, 0.62)];
    function pine(x, y, z, sc, near) {
      mb.ref = null;
      var k = sc * 2.7;
      mb.push().translate(x, y - 0.15, z).rotY(rnd() * 6.283).scale(k, k * (0.9 + rnd() * 0.3), k);
      mb.fbx(near ? PG.FBX.tree : PG.FBX.tree2, treePal, 0.12);
      mb.pop();
    }
    function inVolc(x, z, pad) { var vv = T.volcano; return !!vv && Math.hypot(x - vv.x, z - vv.z) < vv.R * 1.1 + pad; }
    var placed = 0, tries = 0, qn = { i: 0, dist: 0 };
    var maxTrees = def.trees;
    while (placed < maxTrees && tries < maxTrees * 4) {
      tries++;
      var ti = Math.floor(rnd() * N), tside = rnd() < 0.5 ? -1 : 1;
      var off = hw + 9 + Math.pow(rnd(), 1.7) * (def.canyon ? 30 : 130);
      var tx_ = px[ti] + rx[ti] * tside * off + (rnd() - 0.5) * 8, tz_ = pz[ti] + rz[ti] * tside * off + (rnd() - 0.5) * 8;
      T.nearest(tx_, tz_, qn);
      if (qn.dist < hw + 8) continue;
      if (inVolc(tx_, tz_, 6)) continue;
      if (inCaveRow[qn.i] && qn.dist < hw + 44) continue;
      var nearGate = false; for (var gq = 0; gq < gateRows.length; gq++) var gdi = Math.abs(qn.i - gateRows[gq]); if (T.closed) gdi = Math.min(gdi, N - gdi); if (gdi < 30 && qn.dist < hw + 36) nearGate = true;
      if (nearGate) continue;
      var ty_ = groundAt(tx_, tz_);
      if (def.water && ty_ <= waterY + 0.5) continue;
      cellMB(tx_, tz_);
      pine(tx_, ty_ - 0.2, tz_, 0.8 + rnd() * 0.9, off < 38);
      placed++;
    }
    // rocas con nieve
    var rocks = def.canyon ? 90 : 70;
    for (i = 0; i < rocks; i++) {
      var ri = Math.floor(rnd() * N), rs = rnd() < 0.5 ? -1 : 1, ro = hw + 8 + rnd() * 70;
      var rxp = px[ri] + rx[ri] * rs * ro, rzp = pz[ri] + rz[ri] * rs * ro;
      T.nearest(rxp, rzp, qn); if (inVolc(rxp, rzp, 6) || qn.dist < hw + 7 || (inCaveRow[qn.i] && qn.dist < hw + 44)) continue;
      var ryp = groundAt(rxp, rzp); if (def.water && ryp <= waterY + 0.5) continue;
      var rsz = 1.5 + rnd() * 3.5;
      cellMB(rxp, rzp); mb.ref = null;
      mb.push().translate(rxp, ryp - 0.2, rzp).rotY(rnd() * 6.283).scale(rsz * 2.4, rsz * 2.4 * (0.8 + rnd() * 0.5), rsz * 2.4);
      mb.fbx(PG.FBX.mont2, [shade(th.rock, 0.85 + rnd() * 0.3), snow], 0.1, undefined, [0, 0.09, 0]);
      mb.pop();
    }
    // cristales decorativos junto a la pista (como en el arte conceptual)
    var nCr = 9;
    for (i = 0; i < nCr; i++) {
      var ci = Math.floor((i + 0.5) / nCr * N); if (inCaveRow[ci]) continue;
      var cs2 = i % 2 ? -1 : 1, co = hw + 6 + rnd() * 5;
      var cx_ = px[ci] + rx[ci] * cs2 * co, cz_ = pz[ci] + rz[ci] * cs2 * co, cy_ = py[ci] - 1.2;
      cellMB(cx_, cz_); mb.ref = null;
      mb.ell(cx_, cy_ + 0.5, cz_, 3.2, 1.2, 3.0, 7, 3, shade(th.rock, 0.8), 0, 0.15);
      var cc3 = [[0.55, 0.95, 1.0], [0.7, 0.75, 1.0], [0.6, 1.0, 0.9]][i % 3];
      mb.push().translate(cx_, cy_ + 1.0, cz_);
      mb.crystal(0, 0, 0, 0.9, 3.8, cc3, 0.6, 6);
      mb.push().rotZ(0.45); mb.crystal(0.2, 0, 0, 0.6, 2.8, shade(cc3, 0.9), 0.6, 5); mb.pop();
      mb.push().rotZ(-0.5); mb.crystal(-0.2, 0, 0.1, 0.65, 2.6, shade(cc3, 1.05), 0.6, 5); mb.pop();
      mb.pop();
    }
    // montanas lejanas (v3.0: siempre apoyadas en el suelo — la base se hunde hasta el punto mas bajo de su contorno —, opacas y lejos de la calzada)
    var nMt = def.canyon ? 20 : 30, mt = 0, mtries = 0;
    while (mt < nMt && mtries < 900) {
      mtries++;
      var mi = Math.floor(rnd() * N), ms = rnd() < 0.5 ? -1 : 1;
      var mh = 55 + rnd() * 85, isFbx = true;
      var mk = mh / 0.40 * (0.9 + rnd() * 0.2), fp = 0.54 * mk; // fp: radio real de la base (nada de montanas encima de la pista)
      var mo = hw + fp + 70 + rnd() * 150;
      var mx_ = px[mi] + rx[mi] * ms * mo + (rnd() - 0.5) * 40, mz_ = pz[mi] + rz[mi] * ms * mo + (rnd() - 0.5) * 40;
      T.nearest(mx_, mz_, qn); if (qn.dist < hw + fp + 60 || inVolc(mx_, mz_, fp + 40)) continue;
      var my_ = groundAt(mx_, mz_), ringMin = my_;
      for (var rg = 0; rg < 12; rg++) { var ra = rg / 12 * 6.2832; ringMin = Math.min(ringMin, groundAt(mx_ + Math.cos(ra) * fp * 0.8, mz_ + Math.sin(ra) * fp * 0.8)); }
      my_ = ringMin;
      if (def.water) my_ = Math.max(my_, waterY - 6);
      cellMB(mx_, mz_); mb.ref = null;
      (T.mountains = T.mountains || []).push({ x: mx_, z: mz_, r: fp, h: mh });
      var mrk = shade(mix3(th.rock, [0.46, 0.46, 0.52], 0.45), 0.62 + rnd() * 0.25);
      mb.push().translate(mx_, my_ - 12, mz_).rotY(rnd() * 6.283).scale(mk, mk * 0.98, mk);
      mb.fbx(PG.FBX[mt % 2 ? 'mont1' : 'mont2'], [mrk, mix3(snow, [0.93, 0.96, 1.0], 0.5)], 0.08, undefined, [0, mt % 2 ? 0.13 : 0.09, 0]); // v3.1: caras orientadas hacia afuera (antes la mitad quedaba al reves y la montana se veia hueca/transparente)
      mb.pop();
      mt++;
    }
    // iglues (modelo del usuario) junto a la pista, con la entrada mirando hacia ella
    var nIg = def.water ? 4 : 6, ig = 0, igt = 0;
    while (ig < nIg && igt < 300) {
      igt++;
      var gi = Math.floor((ig + 0.3 + rnd() * 0.4) / nIg * N) % N, gs2 = rnd() < 0.5 ? -1 : 1, go = hw + 14 + rnd() * 26;
      var gx = px[gi] + rx[gi] * gs2 * go, gz = pz[gi] + rz[gi] * gs2 * go;
      T.nearest(gx, gz, qn); if (inVolc(gx, gz, 6) || qn.dist < hw + 11 || (inCaveRow[qn.i] && qn.dist < hw + 44)) continue;
      var gy = groundAt(gx, gz); if (def.water && gy <= waterY + 0.6) continue;
      var gk = 8 + rnd() * 4, gdx = px[gi] - gx, gdz = pz[gi] - gz;
      cellMB(gx, gz); mb.ref = null;
      mb.push().translate(gx, gy - 0.1, gz).rotY(Math.atan2(-gdx, -gdz) + (rnd() - 0.5) * 0.5).scale(gk, gk, gk);
      mb.fbx(PG.FBX.iglu, [mix3(snow, [0.82, 0.92, 1.0], 0.35), [0.10, 0.16, 0.28]], 0.06, [0.28, 0.1], [0, 0.12, 0]);
      mb.pop();
      ig++;
    }
    // icebergs
    if (def.water) {
      var nIc = 60, ic = 0, itr = 0;
      while (ic < nIc && itr < 800) {
        itr++;
        var ii = Math.floor(rnd() * N), is = rnd() < 0.5 ? -1 : 1, io = hw + 50 + rnd() * 320;
        var ix = px[ii] + rx[ii] * is * io, iz = pz[ii] + rz[ii] * is * io;
        T.nearest(ix, iz, qn); if (qn.dist < hw + 45) continue;
        if (groundAt(ix, iz) > waterY + 0.1) continue;
        var isz = 6 + rnd() * 22;
        cellMB(ix, iz); mb.ref = null;
        mb.cone(ix, waterY - 3, iz, isz, isz * (0.8 + rnd() * 0.8), 5 + Math.floor(rnd() * 3), [0.88, 0.96, 1.0], 0.08, true);
        mb.cone(ix + isz * 0.4, waterY - 3, iz + isz * 0.2, isz * 0.6, isz * 0.7, 5, [0.74, 0.9, 1.0], 0.08, true);
        ic++;
      }
    }

    /* ---- laguna (v2.7): superficie del agua plana, dique de salida, algas, coral y peces bajo el agua ---- */
    T.waterMesh = null; T.fishMesh = null; T.fish = [];
    if (T.lake) {
      var wm = new PG.MB(), Ys = T.lake.y, WW = hw + 66, wr0 = Math.max(0, Math.round(T.lake.s0 / ds) - 34), wr1 = Math.min(N, Math.round(T.lake.s1 / ds) + 1), rr_;
      function WP(row, d, y) { var ii = Math.max(0, Math.min(N, row)); return [px[ii] + rx[ii] * d, y, pz[ii] + rz[ii] * d]; }
      function both(a, b, c, d2, col, emi) {
        wm.ref = [a[0], a[1] + 3000, a[2]]; wm.quad(a, b, c, d2, col, emi);
        wm.ref = [a[0], a[1] - 3000, a[2]]; wm.quad(a, b, c, d2, col, emi);
      }
      // superficie facetada (cuadros de ~8 m con tonos alternos para que se note el oleaje)
      var nDw = Math.round(WW * 2 / 8);
      for (rr_ = wr0; rr_ < wr1; rr_ += 3) {
        if ((rr_ - wr0) % 12 === 0) wm.cut();
        var rb = Math.min(wr1, rr_ + 3);
        for (var dq = 0; dq < nDw; dq++) {
          var da = -WW + dq * 8, db2 = da + 8, hsh = Math.sin((rr_ * 12.9898 + dq * 78.233) + def.seed) * 43758.5453; hsh -= Math.floor(hsh);
          var cc = shade([0.10, 0.44, 0.84], 0.88 + hsh * 0.26);
          both(WP(rr_, da, Ys), WP(rr_, db2, Ys), WP(rb, db2, Ys), WP(rb, da, Ys), cc, 0.18 + (hsh > 0.8 ? 0.2 : 0));
        }
      }
      // dique de roca en el extremo de salida: tapa el borde del agua (la pista pasa por encima, a ras de la superficie)
      wm.cut();
      var dm = PG.shade([0.46, 0.56, 0.70], 1);
      for (var sdD = -1; sdD <= 1; sdD += 2) {
        var d0 = sdD * (hw + 1.4), d1 = sdD * WW;
        var A_ = WP(wr1, d0, Ys + 1.0), B_ = WP(wr1, d1, Ys + 1.0), C_ = WP(wr1, d1, Ys - 14), D_ = WP(wr1, d0, Ys - 14);
        wm.ref = WP(wr1 - 30, (d0 + d1) / 2, Ys); wm.quad(A_, B_, C_, D_, dm, 0);          // cara hacia aguas abajo (la que se ve)
        wm.ref = WP(wr1 + 30, (d0 + d1) / 2, Ys + 5); wm.quad(A_, B_, C_, D_, shade(dm, 0.8), 0);
        wm.ref = [A_[0], A_[1] + 40, A_[2]]; wm.quad(A_, B_, WP(wr1 - 3, d1, Ys + 1.0), WP(wr1 - 3, d0, Ys + 1.0), shade(dm, 1.1), 0); // corona
      }
      // algas y coral en el fondo, junto a la pista
      var sw = 0, ntry = 0, wr_in0 = Math.round(T.lake.s0 / ds) + 4, wr_in1 = wr1 - 6;
      while (sw < 80 && ntry < 600) {
        ntry++;
        var wr = wr_in0 + Math.floor(rnd() * Math.max(1, wr_in1 - wr_in0)), wsd = rnd() < 0.5 ? -1 : 1, wo = hw + 3 + rnd() * 26;
        var wx_ = px[wr] + rx[wr] * wsd * wo, wz_ = pz[wr] + rz[wr] * wsd * wo;
        T.nearest(wx_, wz_, qn); if (qn.dist < hw + 3) continue;
        var wy_ = groundAt(wx_, wz_); if (wy_ > Ys - 2.5) continue; cellMB(wx_, wz_); mb.ref = null;
        var depthHere = Ys - wy_;
        if (rnd() < 0.7) {
          for (var bl = 0; bl < 3; bl++) {
            var hh2 = Math.min(depthHere - 1.5, 3.5 + rnd() * 5), wg = mix3([0.1, 0.5, 0.25], [0.3, 0.75, 0.35], rnd());
            mb.cone(wx_ + (rnd() - 0.5) * 2.4, wy_ - 0.3, wz_ + (rnd() - 0.5) * 2.4, 0.5 + rnd() * 0.3, Math.max(1.5, hh2), 4, wg, 0.1, true);
          }
        } else {
          var cc2 = [[1.0, 0.45, 0.5], [1.0, 0.65, 0.3], [0.8, 0.4, 0.9]][Math.floor(rnd() * 3)];
          mb.ell(wx_, wy_ + 0.6, wz_, 1.6 + rnd(), 1.2 + rnd() * 0.8, 1.6 + rnd(), 6, 3, cc2, 0.12, 0.2);
          mb.cone(wx_ + 0.8, wy_, wz_, 0.8, 3.2 + rnd() * 2, 5, shade(cc2, 1.1), 0.15, true);
        }
        sw++;
      }
      // peces (se animan en game.js): y relativa al centro de la pista en su fila
      for (var fi = 0; fi < 36; fi++) {
        var fs_ = T.lake.s0 + 40 + rnd() * (T.lake.s1 - T.lake.s0 - 80), fr_ = Math.round(fs_ / ds), dep = Ys - py[fr_];
        if (dep < 5) continue;
        T.fish.push({ s: fs_, d: (rnd() - 0.5) * (hw * 2 + 36), y: 1.4 + rnd() * Math.max(0.5, dep - 4.2), ph: rnd() * 6.283, sp: 0.5 + rnd() * 1.2, sc: 0.7 + rnd() * 0.9, t: Math.floor(rnd() * 3) });
      }
      // boyas rojas y blancas que marcan la pista sobre el agua
      for (var by_ = wr_in0 + 2; by_ < wr1 - 3; by_ += 7) for (var bs_ = -1; bs_ <= 1; bs_ += 2) {
        var bx_ = px[by_] + rx[by_] * bs_ * (hw + 1.2), bz_ = pz[by_] + rz[by_] * bs_ * (hw + 1.2);
        if (Ys - py[by_] < 1.5) continue;
        cellMB(bx_, bz_); mb.ref = null;
        var bc_ = ((by_ / 7) & 1) ? [0.95, 0.2, 0.18] : [0.97, 0.97, 0.97];
        mb.ell(bx_, Ys + 0.1, bz_, 0.75, 0.9, 0.75, 6, 3, bc_, 0.25);
        mb.box(bx_, Ys + 1.5, bz_, 0.1, 1.3, 0.1, [0.2, 0.2, 0.25]);
      }
      T.waterMesh = wm.finish();
      var fm = new PG.MB(); fm.ref = null; fm.up = false;
      fm.ell(0, 0, 0, 0.32, 0.5, 1.1, 6, 4, [1.0, 0.62, 0.22], 0.05, 0.1);
      fm.ref = [0, 0, 0.9];
      fm.tri([0, 0, -0.9], [0.0, 0.5, -1.7], [0, -0.5, -1.7], [1.0, 0.45, 0.15], 0.05);
      fm.ref = [0, -2, 0]; fm.tri([0, 0.45, 0.4], [0, 0.95, -0.3], [0, 0.4, -0.5], [0.95, 0.4, 0.15], 0.05);
      fm.ref = [0.0, 0, 0]; fm.tri([0.3, 0.1, 0.5], [0.9, 0.0, 0.1], [0.3, -0.2, 0.0], [1.0, 0.7, 0.3], 0.05); fm.tri([-0.3, 0.1, 0.5], [-0.9, 0.0, 0.1], [-0.3, -0.2, 0.0], [1.0, 0.7, 0.3], 0.05);
      T.fishMesh = fm.finish();
    }

    var volcMesh = null;
    /* ---- montana del volcan (la pista la atraviesa por dentro): ladera de roca con nieve en lo alto y crater con lava ---- */
    if (T.volcano) {
      var VO = T.volcano, vm = new PG.MB(), vr = PG.rng(def.seed + 5), vS = 128, vK = 40, vj, vk, vtmp = { i: 0, dist: 0 };
      var vRim = VO.rc, vR = VO.R, vHH = VO.H;
      function mtU(k) { return 1 - Math.pow(1 - k / vK, 1.6); } // mas anillos junto al pie
      function mtH(u) { return vHH * Math.pow(1 - u, 1.1); } // v2.8: falda suave en el pie (ya no es un acantilado que tapa las bocas de los tuneles) y mas empinada arriba
      // v2.8: la roca de la montana nunca atraviesa los tuneles: sobre la boca de cada tunel la ladera se apoya en la cascara exterior de la cueva
      var tubePts = [];
      T.caves.forEach(function (cq) { if (!cq.tun) return; for (var rr0 = Math.round(cq.s0 / ds); rr0 <= Math.round(cq.s1 / ds); rr0 += 2) tubePts.push([px[rr0], pz[rr0], hw + 24, T.caveH(rr0) + 5.0]); });
      (T.bcaves || []).forEach(function (cq) { var Bq = T.branches[cq.br - 1]; for (var jq = cq.j0; jq <= cq.j1; jq += 2) tubePts.push([Bq.px[jq], Bq.pz[jq], Bq.W / 2 + 24, T.caveH(Bq.i0 + jq) + 5.0]); });
      function tubeEnv(X, Z) {
        var best = 0;
        for (var tq = 0; tq < tubePts.length; tq++) {
          var tp = tubePts[tq], ex = X - tp[0], ez = Z - tp[1], e2 = ex * ex + ez * ez, rch = tp[2];
          if (e2 < rch * rch) { var ev = tp[3] * Math.sqrt(1 - e2 / (rch * rch)); if (ev > best) best = ev; }
        }
        return best;
      }
      var veins = [];
      for (vj = 0; vj < 7; vj++) veins.push({ j: Math.floor(vr() * vS), len: 0.10 + vr() * 0.16 });
      var vgrid = [], vcol = [];
      function vpoint(j, k) {
        var u = mtU(k), a = 2 * Math.PI * (j % vS) / vS, rr = vR * (vRim + u * (1 - vRim));
        var X = VO.x + Math.cos(a) * rr, Z = VO.z + Math.sin(a) * rr;
        T.nearest(X, Z, vtmp);
        var nz = 1 + 0.07 * Math.sin((j % vS) / vS * 6.2832 * 9 + u * 4) + 0.05 * Math.sin((j % vS) * 1.7 + u * 11);
        var hh0 = mtH(u) * nz - 3.5;
        if (tubePts.length && u > 0.45) hh0 = Math.max(hh0, tubeEnv(X, Z) - 0.8);
        return [X, vtmp.y + hh0, Z];
      }
      for (vk = 0; vk <= vK; vk++) { var vrow = []; for (vj = 0; vj <= vS; vj++) vrow.push(vpoint(vj, vk)); vgrid.push(vrow); }
      vm.ref = [VO.x, vgrid[0][0][1] - 60, VO.z]; vm.up = false;
      var mrock = th.rock;
      for (vk = 0; vk < vK; vk++) {
        var u0 = mtU(vk) , hf = mtH(u0) / vHH;
        vm.cut();
        for (vj = 0; vj < vS; vj++) {
          var col, emi = 0, lava = false;
          for (var vv = 0; vv < veins.length; vv++) {
            var dd = Math.min(Math.abs(vj - veins[vv].j), vS - Math.abs(vj - veins[vv].j));
            if (dd < 1.1 && u0 < veins[vv].len && vr() < 0.9) lava = true;
          }
          var gv = 0.9 + vr() * 0.2;
          if (lava) { col = mix3([1.0, 0.36, 0.06], [1.0, 0.7, 0.15], vr() * 0.7); emi = 0.8; }
          else if (u0 < 0.05) { col = [0.16, 0.12, 0.12]; }
          else {
            col = shade(mix3(mrock, [0.34, 0.30, 0.28], 0.45), gv);
            if (hf > 0.78) col = mix3(col, snow, Math.min(1, (hf - 0.78) / 0.12 + (vr() - 0.5) * 0.5));
            else if (hf < 0.30 && vr() < 0.12) col = mix3(col, [0.30, 0.42, 0.28], 0.35); // matorrales en la base
            if (vr() < 0.06) col = shade(col, 0.85);
          }
          var a = vgrid[vk][vj], b = vgrid[vk][vj + 1], c = vgrid[vk + 1][vj + 1], d = vgrid[vk + 1][vj];
          vm.tri(a, d, c, col, emi); vm.tri(a, c, b, col, emi);
        }
      }
      // crater: pared interior, lava incandescente y chimenea
      vm.ref = null; vm.up = true;
      var cR = vR * vRim, cFloor = vgrid[0][0][1] - 30, cr0 = [], cr1 = [];
      for (vj = 0; vj <= vS; vj++) {
        var ca = 2 * Math.PI * (vj % vS) / vS;
        cr0.push([VO.x + Math.cos(ca) * cR, vgrid[0][vj][1], VO.z + Math.sin(ca) * cR]);
        cr1.push([VO.x + Math.cos(ca) * cR * 0.55, cFloor, VO.z + Math.sin(ca) * cR * 0.55]);
      }
      for (vj = 0; vj < vS; vj++) {
        vm.tri(cr0[vj], cr0[vj + 1], cr1[vj + 1], [0.30, 0.10, 0.06], 0.3); vm.tri(cr0[vj], cr1[vj + 1], cr1[vj], [0.34, 0.11, 0.06], 0.3);
        vm.tri([VO.x, cFloor, VO.z], cr1[vj], cr1[vj + 1], mix3([1.0, 0.45, 0.08], [1.0, 0.8, 0.25], (vj & 1) * 0.5), 1.0);
      }
      vm.up = false; vm.ref = null;
      T.volcanoTop = vgrid[0][0][1]; T.volcanoFloor = cFloor;
      volcMesh = vm.finish();
    }

    T.padMeshes = padCount ? padFr.map(function (m) { return m.finish(); }) : null;
    var parts = [mainMB.finish()];
    if (volcMesh) parts.push(volcMesh);
    for (var ck in cells) parts.push(cells[ck].finish());
    T.mesh = PG.mergeMeshes(parts);
  };
})();
