/* Malla visual estatica de una pista (calzada, bermas, vallas, rampas, fosos, terreno, arboles, montanas) */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;
  var shade = PG.shade, mix3 = PG.mix3, smooth = PG.smooth;

  PG.buildTrackMesh = function (T) {
    var th = T.theme, def = T.def, mb = new PG.MB(), rnd = PG.rng(def.seed * 3 + 1);
    mb.rnd = PG.rng(def.seed + 5);
    var W = T.W, hw = W / 2, N = T.N, C = T.cols, ds = T.ds, px = T.px, py = T.py, pz = T.pz, rx = T.rx, rz = T.rz;
    var snow = th.snow, iceC = th.ice, i, j, k;
    var cw = W / C;

    function P(i, d, dy) { return [px[i] + rx[i] * d, py[i] + dy, pz[i] + rz[i] * d]; }
    function PW(ii, d, dy) { // indice con envoltura para circuitos
      if (T.closed) ii = ((ii % N) + N) % N; else ii = Math.max(0, Math.min(N, ii));
      return P(ii, d, dy);
    }
    function jit(c, a) { return shade(c, 1 + (rnd() - 0.5) * a); }

    /* ---- calzada de hielo ---- */
    mb.up = true; mb.ref = null;
    var startRow = Math.round(T.startS / ds), finRow = Math.round(T.finishS / ds);
    var holeWarn = {};
    for (k = 0; k < T.holes.length; k++) { var hr0 = Math.round(T.holes[k].s0 / ds); for (i = hr0 - 3; i < hr0; i++) holeWarn[i] = 1; }
    for (i = 0; i < N; i++) {
      for (j = 0; j < C; j++) {
        var dm = -hw + (j + 0.5) * cw, sm = (i + 0.5) * ds;
        if (T.inHole(sm, dm)) continue;
        var d0 = -hw + j * cw, d1 = d0 + cw;
        var col;
        var edge = (j < 2 || j >= C - 2);
        if (edge) col = mix3(iceC, snow, 0.55);
        else col = iceC;
        col = jit(col, 0.10);
        if (((i + j) & 1) === 0) col = shade(col, 0.985);
        var chk = (i === startRow || i === startRow - 1 || (T.type === 'sprint' && (i === finRow || i === finRow - 1)));
        if (chk) col = (((i + j) & 1) === 0) ? [0.97, 0.97, 0.97] : [0.08, 0.1, 0.14];
        else if (holeWarn[i]) col = ((j + i) & 1) ? [1.0, 0.72, 0.15] : [0.18, 0.2, 0.26];
        var a = P(i, d0, 0), b = P(i, d1, 0), c = P(i + 1, d1, 0), d = P(i + 1, d0, 0);
        if (chk || holeWarn[i]) mb.quad(a, b, c, d, col, 0.12);
        else { mb.tri(a, b, c, jit(col, 0.10), 0); mb.tri(a, c, d, jit(col, 0.10), 0); }
      }
    }

    /* ---- bermas y falda de nieve ---- */
    var offs = [hw, hw + 1.8, hw + 6, hw + 26], hts = [0.05, 0.95, -1.15, -1.5];
    for (var side = -1; side <= 1; side += 2) {
      for (i = 0; i < N; i += 2) {
        var i1 = Math.min(i + 2, N);
        for (k = 0; k < 3; k++) {
          var col2 = jit(k === 0 ? mix3(snow, iceC, 0.15) : snow, 0.07);
          var q0 = P(i, side * offs[k], hts[k]), q1 = P(i1, side * offs[k], hts[k]), q2 = P(i1, side * offs[k + 1], hts[k + 1]), q3 = P(i, side * offs[k + 1], hts[k + 1]);
          mb.quad(q0, q1, q2, q3, col2);
        }
      }
    }

    /* ---- rampas ---- */
    for (k = 0; k < T.ramps.length; k++) {
      var R = T.ramps[k], r0 = Math.round(R.s0 / ds), rn = Math.round(R.len / ds), top = R.h;
      var cen = P(r0 + (rn >> 1), (R.d0 + R.d1) / 2, top * 0.4);
      mb.ref = cen; mb.up = false;
      for (i = 0; i < rn; i++) {
        var h0 = top * i / rn + 0.03, h1 = top * (i + 1) / rn + 0.03;
        var stripe = (i & 1) ? [0.93, 0.98, 1.0] : [0.45, 0.78, 0.98];
        if (R.jump) stripe = (i & 1) ? [1.0, 0.85, 0.35] : [0.97, 0.97, 1.0];
        var ra = P(r0 + i, R.d0, h0), rb = P(r0 + i, R.d1, h0), rc = P(r0 + i + 1, R.d1, h1), rd = P(r0 + i + 1, R.d0, h1);
        mb.quad(ra, rb, rc, rd, stripe, 0.12);
        // laterales
        mb.quad(P(r0 + i, R.d0, 0), P(r0 + i + 1, R.d0, 0), rd, ra, [0.55, 0.78, 0.95]);
        mb.quad(P(r0 + i, R.d1, 0), P(r0 + i + 1, R.d1, 0), rc, rb, [0.55, 0.78, 0.95]);
      }
      mb.quad(P(r0 + rn, R.d0, 0), P(r0 + rn, R.d1, 0), P(r0 + rn, R.d1, top + 0.03), P(r0 + rn, R.d0, top + 0.03), [0.35, 0.55, 0.8]);
      mb.ref = null;
    }

    /* ---- pads de impulso ---- */
    mb.up = true;
    for (k = 0; k < T.pads.length; k++) {
      var PD = T.pads[k], p0 = Math.round(PD.s / ds), pn = Math.round(PD.len / ds);
      for (i = 0; i < pn; i++) {
        var pc = (i & 1) ? [1.0, 0.82, 0.15] : [1.0, 0.45, 0.1];
        mb.quad(P(p0 + i, PD.d0, 0.06), P(p0 + i, PD.d1, 0.06), P(p0 + i + 1, PD.d1, 0.06), P(p0 + i + 1, PD.d0, 0.06), pc, 0.6);
      }
    }

    /* ---- fosos (huecos) ---- */
    for (k = 0; k < T.holes.length; k++) {
      var H = T.holes[k], h0i = Math.round(H.s0 / ds), h1i = Math.round(H.s1 / ds), depth = 11;
      var midI = (h0i + h1i) >> 1, dm2 = (H.d0 + H.d1) / 2;
      var floorY = -depth;
      mb.up = true; mb.ref = null;
      mb.quad(P(h0i, H.d0, floorY), P(h0i, H.d1, floorY), P(h1i, H.d1, floorY), P(h1i, H.d0, floorY), [0.04, 0.09, 0.2]);
      // paredes hacia el interior (la referencia queda en el exterior de cada pared)
      var cols3 = [[0.72, 0.88, 1.0], [0.38, 0.6, 0.85], [0.14, 0.26, 0.5]];
      var inner = P(midI, dm2, -4);
      mb.ref = null; mb.up = false;
      for (var b = 0; b < 3; b++) {
        var y0 = -b * depth / 3 + (b === 0 ? 0 : 0), y1 = -(b + 1) * depth / 3;
        var cc = cols3[b];
        // pared de entrada (s0), mirando +s -> referencia detras
        mb.ref = P(h0i - 8, dm2, -4);
        mb.quad(P(h0i, H.d0, y0), P(h0i, H.d1, y0), P(h0i, H.d1, y1), P(h0i, H.d0, y1), cc);
        mb.ref = P(h1i + 8, dm2, -4);
        mb.quad(P(h1i, H.d0, y0), P(h1i, H.d1, y0), P(h1i, H.d1, y1), P(h1i, H.d0, y1), shade(cc, 1.08));
        mb.ref = P(midI, H.d0 - 14, -4);
        mb.quad(P(h0i, H.d0, y0), P(h1i, H.d0, y0), P(h1i, H.d0, y1), P(h0i, H.d0, y1), shade(cc, 0.92));
        mb.ref = P(midI, H.d1 + 14, -4);
        mb.quad(P(h0i, H.d1, y0), P(h1i, H.d1, y0), P(h1i, H.d1, y1), P(h0i, H.d1, y1), shade(cc, 0.92));
      }
      mb.ref = null;
      // carteles de peligro a los lados de la entrada
      for (var sd = -1; sd <= 1; sd += 2) {
        var wp = P(h0i - 2, sd * (hw + 0.8), 0);
        mb.box(wp[0], wp[1] + 1.1, wp[2], 0.3, 2.2, 0.3, [0.3, 0.2, 0.15]);
        mb.box(wp[0], wp[1] + 2.3, wp[2], 1.5, 1.0, 0.2, [1.0, 0.75, 0.1], 0.2);
      }
    }

    /* ---- vallas ---- */
    if (!def.canyon) {
      var span = def.type === 'sprint' ? 6 : 6;
      for (side = -1; side <= 1; side += 2) {
        for (i = 0; i < N; i += span) {
          var ia = i, ib = Math.min(i + span, N);
          var pa = P(ia, side * (hw + 0.9), 0), pb = P(ib, side * (hw + 0.9), 0);
          mb.ref = null; mb.up = false;
          mb.box(pa[0], pa[1] + 0.65, pa[2], 0.28, 1.3, 0.28, [0.45, 0.3, 0.2]);
          mb.box(pa[0], pa[1] + 1.33, pa[2], 0.38, 0.14, 0.38, snow);
          var mx = (pa[0] + pb[0]) / 2, mz = (pa[2] + pb[2]) / 2, my = (pa[1] + pb[1]) / 2;
          var dx = pb[0] - pa[0], dz = pb[2] - pa[2], dy = pb[1] - pa[1], len = Math.sqrt(dx * dx + dy * dy + dz * dz);
          var yaw = Math.atan2(dx, dz), pitch = -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz));
          for (var rl = 0; rl < 2; rl++) {
            mb.push().translate(mx, my + 0.5 + rl * 0.5, mz).rotY(yaw).rotX(pitch);
            mb.box(0, 0, 0, 0.12, 0.13, len, [0.5, 0.34, 0.22]);
            mb.pop();
          }
        }
      }
    }

    /* ---- arcos de salida y meta ---- */
    function gate(sIdx) {
      var white = [0.97, 0.97, 0.97], blk = [0.1, 0.12, 0.16], red = [0.85, 0.17, 0.2];
      mb.ref = null; mb.up = false;
      for (var sd2 = -1; sd2 <= 1; sd2 += 2) {
        var g = P(sIdx, sd2 * (hw + 2.0), 0);
        mb.box(g[0], g[1] + 4.2, g[2], 1.2, 8.4, 1.2, red);
        mb.box(g[0], g[1] + 2.0, g[2], 1.3, 0.8, 1.3, white);
        mb.box(g[0], g[1] + 5.6, g[2], 1.3, 0.8, 1.3, white);
      }
      var yaw2 = Math.atan2(T.tx[sIdx % (N + 1)], T.tz[sIdx % (N + 1)]);
      var nChk = 14, wCell = (W + 5) / nChk;
      for (var cc2 = 0; cc2 < nChk; cc2++) for (var rr = 0; rr < 2; rr++) {
        var dpos = -(W + 5) / 2 + (cc2 + 0.5) * wCell;
        var pp = P(sIdx, dpos, 8.2 + rr * 0.8);
        mb.push().translate(pp[0], pp[1], pp[2]).rotY(yaw2);
        mb.box(0, 0, 0, wCell, 0.8, 1.2, ((cc2 + rr) & 1) ? white : blk, 0.15);
        mb.pop();
      }
    }
    gate(startRow % N);
    if (T.type === 'sprint') gate(finRow);

    /* ---- terreno ---- */
    var nn = { i: 0, dist: 0 }, waterY = -1e9;
    if (def.water) { var mn = 1e9; for (i = 0; i <= N; i++) if (py[i] < mn) mn = py[i]; waterY = mn - 9; }
    T.waterY = waterY;
    function hgt(x, z, out) {
      T.nearest(x, z, nn);
      var base = py[nn.i] - 1.5, dist = nn.dist, n = PG.fbm(x / 120, z / 120, def.seed), hh;
      if (def.canyon) hh = base + smooth(hw + 26, hw + 58, dist) * def.hills * (0.75 + 0.55 * n) + smooth(hw + 70, hw + 300, dist) * 70 * n;
      else if (def.water) hh = base - smooth(hw + 28, hw + 120, dist) * (def.hills + 24) + (n - 0.5) * 4;
      else hh = base + smooth(hw + 28, hw + 190, dist) * def.hills * (0.10 + 1.0 * n * n * 1.5);
      if (out) { out.dist = dist; out.i = nn.i; }
      return hh;
    }
    T.hgt = function (x, z) { return hgt(x, z, null); };
    var bb = T.bbox, margin = 430, cs = 20;
    var gx0 = Math.floor((bb.x0 - margin) / cs), gx1 = Math.ceil((bb.x1 + margin) / cs), gz0 = Math.floor((bb.z0 - margin) / cs), gz1 = Math.ceil((bb.z1 + margin) / cs);
    var nx = gx1 - gx0 + 1, nz = gz1 - gz0 + 1;
    var V = new Float32Array(nx * nz * 3), Dd = new Float32Array(nx * nz), tmp = { dist: 0, i: 0 };
    var hr = PG.rng(def.seed * 17 + 3);
    for (var gz = 0; gz < nz; gz++) for (var gx = 0; gx < nx; gx++) {
      var xx = (gx0 + gx) * cs + (hr() - 0.5) * cs * 0.45, zz = (gz0 + gz) * cs + (hr() - 0.5) * cs * 0.45;
      var yy = hgt(xx, zz, tmp) + (hr() - 0.5) * 1.2;
      if (def.water && yy < waterY) yy = waterY;
      var o3 = (gz * nx + gx) * 3; V[o3] = xx; V[o3 + 1] = yy; V[o3 + 2] = zz; Dd[gz * nx + gx] = tmp.dist;
    }
    var skip = hw + 22;
    mb.ref = null; mb.up = true;
    function TV(gx, gz) { var o = (gz * nx + gx) * 3; return [V[o], V[o + 1], V[o + 2]]; }
    for (gz = 0; gz < nz - 1; gz++) for (gx = 0; gx < nx - 1; gx++) {
      if (Dd[gz * nx + gx] < skip || Dd[gz * nx + gx + 1] < skip || Dd[(gz + 1) * nx + gx] < skip || Dd[(gz + 1) * nx + gx + 1] < skip) continue;
      var v00 = TV(gx, gz), v10 = TV(gx + 1, gz), v11 = TV(gx + 1, gz + 1), v01 = TV(gx, gz + 1);
      var tris = (((gx + gz) & 1) ? [[v00, v10, v11], [v00, v11, v01]] : [[v00, v10, v01], [v10, v11, v01]]);
      for (var tq = 0; tq < 2; tq++) {
        var A = tris[tq][0], B = tris[tq][1], Cc = tris[tq][2];
        var ux = B[0] - A[0], uy = B[1] - A[1], uz = B[2] - A[2], vx = Cc[0] - A[0], vy = Cc[1] - A[1], vz = Cc[2] - A[2];
        var nxx = uy * vz - uz * vy, nyy = uz * vx - ux * vz, nzz = ux * vy - uy * vx, nl = Math.sqrt(nxx * nxx + nyy * nyy + nzz * nzz) || 1;
        var slope = Math.abs(nyy) / nl, avgY = (A[1] + B[1] + Cc[1]) / 3, tcol;
        if (def.water && avgY <= waterY + 0.05 && A[1] <= waterY + 0.01 && B[1] <= waterY + 0.01 && Cc[1] <= waterY + 0.01) tcol = [0.16, 0.42, 0.58];
        else if (slope < 0.74) tcol = mix3(th.rock, snow, smooth(0.45, 0.74, slope) * 0.4);
        else tcol = mix3(snow, [0.82, 0.9, 0.98], 0.0);
        tcol = jit(tcol, 0.08);
        mb.tri(A, B, Cc, tcol, tcol[2] > tcol[0] + 0.2 && def.water ? 0.1 : 0);
      }
    }
    mb.up = false; mb.ref = null;

    /* ---- decoracion: arboles, rocas, cristales, montanas, icebergs ---- */
    function groundAt(x, z) { return hgt(x, z, null); }
    var treeCol = th.tree;
    function pine(x, y, z, sc) {
      mb.ref = null;
      var layers = 3;
      mb.cyl(x, y - 0.3, z, 0.28 * sc, 0.2 * sc, 1.5 * sc, 4, [0.35, 0.24, 0.16]);
      for (var l = 0; l < layers; l++) {
        var yb = y + (1.0 + l * 1.5) * sc, rr = (2.3 - l * 0.55) * sc, hh = (2.4 - l * 0.2) * sc;
        mb.cone(x, yb, z, rr, hh, 6, shade(treeCol, 0.92 + 0.08 * l), 0, true);
        mb.cone(x, yb + hh * 0.36, z, rr * 0.66 * 1.05, hh * 0.64 * 1.03, 6, snow, 0.04, true);
      }
    }
    var placed = 0, tries = 0, qn = { i: 0, dist: 0 };
    var maxTrees = def.trees;
    while (placed < maxTrees && tries < maxTrees * 4) {
      tries++;
      var ti = Math.floor(rnd() * N), tside = rnd() < 0.5 ? -1 : 1;
      var off = hw + 9 + Math.pow(rnd(), 1.7) * (def.canyon ? 30 : 130);
      var tx_ = px[ti] + rx[ti] * tside * off + (rnd() - 0.5) * 8, tz_ = pz[ti] + rz[ti] * tside * off + (rnd() - 0.5) * 8;
      T.nearest(tx_, tz_, qn);
      if (qn.dist < hw + 8) continue;
      var ty_ = groundAt(tx_, tz_);
      if (def.water && ty_ <= waterY + 0.5) continue;
      pine(tx_, ty_ - 0.2, tz_, 0.8 + rnd() * 0.9);
      placed++;
    }
    // rocas con nieve
    var rocks = def.canyon ? 90 : 70;
    for (i = 0; i < rocks; i++) {
      var ri = Math.floor(rnd() * N), rs = rnd() < 0.5 ? -1 : 1, ro = hw + 8 + rnd() * 70;
      var rxp = px[ri] + rx[ri] * rs * ro, rzp = pz[ri] + rz[ri] * rs * ro;
      T.nearest(rxp, rzp, qn); if (qn.dist < hw + 7) continue;
      var ryp = groundAt(rxp, rzp); if (def.water && ryp <= waterY + 0.5) continue;
      var rsz = 1.5 + rnd() * 3.5;
      mb.ref = null;
      mb.ell(rxp, ryp + rsz * 0.3, rzp, rsz, rsz * 0.75, rsz * 0.9, 6, 4, shade(th.rock, 0.85 + rnd() * 0.3), 0, 0.2);
      mb.ell(rxp, ryp + rsz * 0.75, rzp, rsz * 0.7, rsz * 0.32, rsz * 0.65, 6, 3, snow);
    }
    // cristales decorativos junto a la pista (como en el arte conceptual)
    var nCr = 9;
    for (i = 0; i < nCr; i++) {
      var ci = Math.floor((i + 0.5) / nCr * N), cs2 = i % 2 ? -1 : 1, co = hw + 6 + rnd() * 5;
      var cx_ = px[ci] + rx[ci] * cs2 * co, cz_ = pz[ci] + rz[ci] * cs2 * co, cy_ = py[ci] - 1.2;
      mb.ref = null;
      mb.ell(cx_, cy_ + 0.5, cz_, 3.2, 1.2, 3.0, 7, 3, shade(th.rock, 0.8), 0, 0.15);
      var cc3 = [[0.55, 0.95, 1.0], [0.7, 0.75, 1.0], [0.6, 1.0, 0.9]][i % 3];
      mb.push().translate(cx_, cy_ + 1.0, cz_);
      mb.crystal(0, 0, 0, 0.9, 3.8, cc3, 0.6, 6);
      mb.push().rotZ(0.45); mb.crystal(0.2, 0, 0, 0.6, 2.8, shade(cc3, 0.9), 0.6, 5); mb.pop();
      mb.push().rotZ(-0.5); mb.crystal(-0.2, 0, 0.1, 0.65, 2.6, shade(cc3, 1.05), 0.6, 5); mb.pop();
      mb.pop();
    }
    // montanas lejanas (la base siempre queda fuera de la calzada)
    var nMt = def.canyon ? 20 : 34, mt = 0, mtries = 0;
    while (mt < nMt && mtries < 900) {
      mtries++;
      var mi = Math.floor(rnd() * N), ms = rnd() < 0.5 ? -1 : 1;
      var mh = 55 + rnd() * 90, mr = mh * (0.85 + rnd() * 0.35);
      var mo = hw + mr * 0.8 + 70 + rnd() * 160;
      var mx_ = px[mi] + rx[mi] * ms * mo + (rnd() - 0.5) * 40, mz_ = pz[mi] + rz[mi] * ms * mo + (rnd() - 0.5) * 40;
      T.nearest(mx_, mz_, qn); if (qn.dist < hw + mr * 0.8 + 50) continue;
      var my_ = groundAt(mx_, mz_);
      if (def.water) my_ = Math.max(my_, waterY);
      mb.ref = null;
      mb.cone(mx_, my_ - 8, mz_, mr, mh, 7, shade(th.rock, 0.8 + rnd() * 0.3), 0, true);
      mb.cone(mx_, my_ - 8 + mh * 0.5, mz_, mr * 0.5 * 1.03, mh * 0.5 * 1.02, 7, snow, 0.05, true);
      mt++;
    }
    // icebergs
    if (def.water) {
      var nIc = 60, ic = 0, itr = 0;
      while (ic < nIc && itr < 800) {
        itr++;
        var ii = Math.floor(rnd() * N), is = rnd() < 0.5 ? -1 : 1, io = hw + 50 + rnd() * 320;
        var ix = px[ii] + rx[ii] * is * io, iz = pz[ii] + rz[ii] * is * io;
        T.nearest(ix, iz, qn); if (qn.dist < hw + 45) continue;
        if (groundAt(ix, iz) > waterY + 0.1) continue;
        var isz = 6 + rnd() * 22;
        mb.ref = null;
        mb.cone(ix, waterY - 3, iz, isz, isz * (0.8 + rnd() * 0.8), 5 + Math.floor(rnd() * 3), [0.88, 0.96, 1.0], 0.08, true);
        mb.cone(ix + isz * 0.4, waterY - 3, iz + isz * 0.2, isz * 0.6, isz * 0.7, 5, [0.74, 0.9, 1.0], 0.08, true);
        ic++;
      }
    }

    T.mesh = mb.finish();
  };
})();
