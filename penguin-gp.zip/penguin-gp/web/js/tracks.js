/* Pistas: trazado, consultas de suelo/rampas/huecos y colocacion de obstaculos y poderes */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI, TAU = Math.PI * 2;

  /* ---------- temas visuales ---------- */
  PG.THEMES = {
    day: { top: [0.28, 0.52, 0.88], hor: [0.80, 0.91, 0.99], bot: [0.80, 0.90, 0.98], fog: [0.80, 0.91, 0.99], fogN: 120, fogF: 560,
      sun: [0.45, 0.80, 0.40], sunCol: [1.0, 0.96, 0.88], amb: [0.60, 0.68, 0.80], gnd: [0.46, 0.52, 0.64],
      snow: [0.97, 0.98, 1.0], ice: [0.58, 0.76, 0.93], rock: [0.52, 0.56, 0.66], tree: [0.16, 0.45, 0.28], aurora: 0, flakes: 0.35 },
    glacier: { top: [0.22, 0.46, 0.84], hor: [0.74, 0.90, 1.0], bot: [0.72, 0.88, 1.0], fog: [0.74, 0.90, 1.0], fogN: 110, fogF: 520,
      sun: [0.30, 0.85, 0.30], sunCol: [0.95, 0.98, 1.0], amb: [0.58, 0.70, 0.86], gnd: [0.42, 0.55, 0.72],
      snow: [0.95, 0.98, 1.0], ice: [0.42, 0.74, 0.98], rock: [0.45, 0.58, 0.74], tree: [0.14, 0.42, 0.30], aurora: 0, flakes: 0.3 },
    night: { top: [0.02, 0.05, 0.18], hor: [0.14, 0.30, 0.50], bot: [0.10, 0.20, 0.38], fog: [0.12, 0.24, 0.42], fogN: 80, fogF: 460,
      sun: [-0.3, 0.7, 0.5], sunCol: [0.55, 0.65, 1.0], amb: [0.42, 0.52, 0.76], gnd: [0.22, 0.28, 0.46],
      snow: [0.82, 0.90, 1.0], ice: [0.38, 0.62, 0.95], rock: [0.30, 0.36, 0.52], tree: [0.07, 0.28, 0.28], aurora: 1, flakes: 0.4 },
    sunset: { top: [0.30, 0.28, 0.58], hor: [1.0, 0.72, 0.50], bot: [0.95, 0.62, 0.48], fog: [0.98, 0.70, 0.56], fogN: 110, fogF: 520,
      sun: [0.75, 0.30, 0.55], sunCol: [1.0, 0.72, 0.45], amb: [0.66, 0.58, 0.68], gnd: [0.50, 0.40, 0.52],
      snow: [1.0, 0.94, 0.92], ice: [0.55, 0.74, 0.92], rock: [0.62, 0.42, 0.40], tree: [0.14, 0.34, 0.26], aurora: 0, flakes: 0.25 },
    dusk: { top: [0.12, 0.30, 0.55], hor: [0.58, 0.84, 0.92], bot: [0.36, 0.62, 0.78], fog: [0.56, 0.82, 0.92], fogN: 120, fogF: 560,
      sun: [-0.5, 0.45, 0.6], sunCol: [1.0, 0.88, 0.70], amb: [0.58, 0.70, 0.82], gnd: [0.38, 0.52, 0.64],
      snow: [0.96, 0.99, 1.0], ice: [0.46, 0.80, 0.94], rock: [0.48, 0.58, 0.68], tree: [0.14, 0.40, 0.30], aurora: 0, flakes: 0.3 },
    storm: { top: [0.34, 0.38, 0.46], hor: [0.66, 0.70, 0.76], bot: [0.62, 0.66, 0.72], fog: [0.64, 0.68, 0.74], fogN: 40, fogF: 330,
      sun: [0.2, 0.9, 0.2], sunCol: [0.8, 0.84, 0.9], amb: [0.58, 0.62, 0.70], gnd: [0.40, 0.44, 0.52],
      snow: [0.92, 0.94, 0.97], ice: [0.50, 0.66, 0.84], rock: [0.40, 0.44, 0.52], tree: [0.12, 0.30, 0.26], aurora: 0, flakes: 1.0 }
  };

  /* ---------- generadores de trazado ---------- */
  function circuitPath(o) {
    var pts = [], n = 900, i, k;
    for (i = 0; i < n; i++) {
      var th = TAU * i / n, r = 1;
      for (k = 0; k < o.harm.length; k++) r += o.harm[k][1] * Math.cos(o.harm[k][0] * th + o.harm[k][2]);
      var y = o.y0 || 0;
      for (k = 0; k < o.hy.length; k++) y += o.hy[k][1] * Math.sin(o.hy[k][0] * th + o.hy[k][2]);
      pts.push([o.R * o.sx * r * Math.cos(th), y, o.R * o.sz * r * Math.sin(th)]);
    }
    return { pts: pts, closed: true };
  }
  function sprintPath(o) {
    var pts = [], x = 0, z = 0, step = 1, n = Math.floor(o.len / step), k, j;
    for (k = 0; k <= n; k++) {
      var u = k * step, phi = o.phi0 || 0;
      for (j = 0; j < o.turn.length; j++) phi += o.turn[j][0] * Math.sin(TAU * u / o.turn[j][1] + o.turn[j][2]);
      var y = o.y0 - o.slope * u;
      for (j = 0; j < o.hills.length; j++) y += o.hills[j][0] * Math.sin(TAU * u / o.hills[j][1] + o.hills[j][2]);
      pts.push([x, y, z]);
      x += Math.sin(phi) * step; z += Math.cos(phi) * step;
    }
    return { pts: pts, closed: false };
  }

  /* ---------- definicion de las 6 pistas ---------- */
  PG.TRACKS = [
    {
      id: 0, name: 'Valle Nevado', type: 'circuit', theme: 'day', blurb: 'Circuito amplio entre pinos. Ideal para empezar.',
      path: function () { return circuitPath({ R: 150, sx: 1.55, sz: 1.0, harm: [[2, 0.08, 0.6], [3, 0.05, 1.9]], y0: 0, hy: [[1, 5, 0.5], [2, 2.5, 1.0]] }); },
      auto: { jumps: [{ f: 0.30, len: 17, mode: 'full' }, { f: 0.74, len: 15, mode: 'L' }], ramps: [{ f: 0.14 }, { f: 0.52 }, { f: 0.86 }],
        rock: 7, ice: 5, snowman: 4, seal: 1, ball: 0, gates: 1, rows: 7, pads: 5, crystals: 2 },
      hills: 38, trees: 900, seed: 11
    },
    {
      id: 1, name: 'Descenso del Glaciar', type: 'sprint', theme: 'glacier', blurb: 'Bajada larga de A a B con grietas y saltos.',
      path: function () { return sprintPath({ len: 2700, y0: 40, slope: 0.115, phi0: 0, turn: [[0.80, 920, 0.4], [0.42, 430, 2.0]], hills: [[5, 330, 0.7], [2.5, 140, 2.1]] }); },
      auto: { jumps: [{ f: 0.22, len: 18, mode: 'full' }, { f: 0.47, len: 14, mode: 'mid' }, { f: 0.72, len: 20, mode: 'full' }, { f: 0.88, len: 15, mode: 'R' }],
        ramps: [{ f: 0.08 }, { f: 0.35 }, { f: 0.60 }], rock: 12, ice: 9, snowman: 3, seal: 4, ball: 3, gates: 3, rows: 9, pads: 8, crystals: 3 },
      hills: 46, trees: 800, seed: 23
    },
    {
      id: 2, name: 'Circuito Aurora', type: 'circuit', theme: 'night', blurb: 'De noche bajo la aurora. Curvas con cristales.',
      path: function () { return circuitPath({ R: 135, sx: 1.40, sz: 1.0, harm: [[2, 0.12, 2.4], [4, 0.04, 0.3]], y0: 2, hy: [[1, 4, 2.0], [3, 3.0, 0.4]] }); },
      auto: { jumps: [{ f: 0.26, len: 17, mode: 'full' }, { f: 0.58, len: 16, mode: 'R' }, { f: 0.82, len: 15, mode: 'mid' }], ramps: [{ f: 0.12 }, { f: 0.44 }, { f: 0.70 }],
        rock: 8, ice: 7, snowman: 3, seal: 2, ball: 2, gates: 2, rows: 7, pads: 5, crystals: 3 },
      hills: 36, trees: 800, seed: 37
    },
    {
      id: 3, name: 'Canon Congelado', type: 'sprint', theme: 'sunset', blurb: 'Paredes de roca, atardecer y muchos obstaculos.',
      path: function () { return sprintPath({ len: 2900, y0: 60, slope: 0.15, phi0: 0, turn: [[0.95, 760, 1.2], [0.40, 300, 0.3]], hills: [[6, 300, 1.0], [3, 120, 0.2]] }); },
      auto: { jumps: [{ f: 0.18, len: 17, mode: 'full' }, { f: 0.40, len: 15, mode: 'L' }, { f: 0.62, len: 19, mode: 'full' }, { f: 0.84, len: 16, mode: 'mid' }],
        ramps: [{ f: 0.06 }, { f: 0.30 }, { f: 0.52 }, { f: 0.76 }], rock: 16, ice: 12, snowman: 3, seal: 3, ball: 4, gates: 4, rows: 9, pads: 8, crystals: 3 },
      hills: 95, canyon: true, trees: 380, seed: 49
    },
    {
      id: 4, name: 'Bahia de los Icebergs', type: 'circuit', theme: 'dusk', blurb: 'Plataforma de hielo sobre el mar con saltos largos.',
      path: function () { return circuitPath({ R: 170, sx: 1.25, sz: 1.0, harm: [[3, 0.10, 0.8], [5, 0.035, 1.4]], y0: 4, hy: [[1, 6, 0.9], [2, 3.5, 2.6]] }); },
      auto: { jumps: [{ f: 0.20, len: 19, mode: 'full' }, { f: 0.45, len: 16, mode: 'L' }, { f: 0.78, len: 20, mode: 'full' }], ramps: [{ f: 0.10 }, { f: 0.34 }, { f: 0.62 }, { f: 0.90 }],
        rock: 5, ice: 8, snowman: 2, seal: 3, ball: 2, gates: 2, rows: 7, pads: 6, crystals: 3 },
      hills: 20, water: true, trees: 260, seed: 53
    },
    {
      id: 5, name: 'Cumbre de la Tormenta', type: 'sprint', theme: 'storm', blurb: 'La bajada mas rapida, con ventisca y poca vision.',
      path: function () { return sprintPath({ len: 3100, y0: 90, slope: 0.17, phi0: 0, turn: [[1.00, 640, 2.2], [0.50, 250, 1.0]], hills: [[6, 280, 0.2], [3, 110, 1.4]] }); },
      auto: { jumps: [{ f: 0.16, len: 18, mode: 'full' }, { f: 0.36, len: 16, mode: 'mid' }, { f: 0.56, len: 20, mode: 'full' }, { f: 0.74, len: 16, mode: 'L' }, { f: 0.90, len: 17, mode: 'R' }],
        ramps: [{ f: 0.06 }, { f: 0.27 }, { f: 0.46 }, { f: 0.66 }], rock: 16, ice: 14, snowman: 4, seal: 4, ball: 5, gates: 4, rows: 10, pads: 9, crystals: 4 },
      hills: 60, trees: 450, seed: 71
    }
  ];

  var COLS = 13; // columnas de la calzada (2 m c/u con W=26)

  /* ---------- construccion ---------- */
  PG.buildTrack = function (def, opts) {
    opts = opts || {};
    var T = { def: def, id: def.id, name: def.name, type: def.type, theme: PG.THEMES[def.theme], themeName: def.theme };
    T.W = 26; T.cols = COLS;
    T.laps = def.type === 'circuit' ? 3 : 1;
    var path = def.path(), dense = path.pts, closed = path.closed;
    T.closed = closed;

    // longitud acumulada
    var cum = [0], k, i;
    for (k = 1; k < dense.length; k++) {
      var a = dense[k - 1], b = dense[k];
      cum.push(cum[k - 1] + Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]));
    }
    var total = cum[cum.length - 1];
    if (closed) {
      var l0 = dense[dense.length - 1], f0 = dense[0];
      total += Math.hypot(f0[0] - l0[0], f0[1] - l0[1], f0[2] - l0[2]);
    }
    var N = closed ? Math.round(total / 1.5) : Math.floor(total / 1.5);
    var ds = closed ? total / N : 1.5;
    T.N = N; T.ds = ds; T.L = N * ds;
    var px = new Float32Array(N + 1), py = new Float32Array(N + 1), pz = new Float32Array(N + 1);
    var seg = 0, nd = dense.length;
    for (i = 0; i <= N; i++) {
      var s = i * ds;
      while (seg < nd - 1 && cum[seg + 1] < s) seg++;
      var A = dense[seg], B, segLen, sOff = s - cum[seg];
      if (seg < nd - 1) { B = dense[seg + 1]; segLen = cum[seg + 1] - cum[seg]; }
      else { B = dense[0]; segLen = total - cum[seg]; }
      var tt = segLen > 0 ? Math.min(1, sOff / segLen) : 0;
      px[i] = A[0] + (B[0] - A[0]) * tt; py[i] = A[1] + (B[1] - A[1]) * tt; pz[i] = A[2] + (B[2] - A[2]) * tt;
    }
    if (closed) { px[N] = px[0]; py[N] = py[0]; pz[N] = pz[0]; }
    // tangentes
    var tx = new Float32Array(N + 1), tz = new Float32Array(N + 1), sl = new Float32Array(N + 1), rx = new Float32Array(N + 1), rz = new Float32Array(N + 1);
    function idx(j) { if (closed) { j = ((j % N) + N) % N; return j; } return j < 0 ? 0 : (j > N ? N : j); }
    for (i = 0; i <= N; i++) {
      var ia = idx(i - 1), ib = idx(i + 1);
      var dx = px[ib] - px[ia], dy = py[ib] - py[ia], dz = pz[ib] - pz[ia];
      var l3 = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1, lh = Math.sqrt(dx * dx + dz * dz) || 1;
      tx[i] = dx / lh; tz[i] = dz / lh; sl[i] = dy / l3;
      rx[i] = -tz[i]; rz[i] = tx[i];
    }
    // curvatura (positiva = giro a la derecha)
    var yaw = new Float32Array(N + 1), cv = new Float32Array(N + 1), ya = Math.atan2(tx[0], tz[0]);
    for (i = 0; i <= N; i++) { var yy = Math.atan2(tx[i], tz[i]); ya += PG.angDiff(ya, yy); yaw[i] = ya; }
    var cv0 = new Float32Array(N + 1);
    for (i = 0; i <= N; i++) { var i1 = idx(i - 3), i2 = idx(i + 3); var dyaw = (closed ? PG.angDiff(Math.atan2(tx[i1], tz[i1]), Math.atan2(tx[i2], tz[i2])) : yaw[i2] - yaw[i1]); cv0[i] = -dyaw / (6 * ds); }
    for (i = 0; i <= N; i++) { var sum = 0, c = 0; for (var q = -3; q <= 3; q++) { sum += cv0[idx(i + q)]; c++; } cv[i] = sum / c; }
    T.px = px; T.py = py; T.pz = pz; T.tx = tx; T.tz = tz; T.sl = sl; T.rx = rx; T.rz = rz; T.cv = cv; T.yawArr = yaw;

    // coordenadas de carrera
    if (T.type === 'circuit') { T.startS = 0; T.D = T.L * T.laps; T.finishS = 0; }
    else { T.startS = 40; T.finishS = T.L - 70; T.D = T.finishS - T.startS; }

    T.wrapS = function (s) { if (T.closed) { s = s % T.L; if (s < 0) s += T.L; return s; } return s < 0 ? 0 : (s > T.L - 0.01 ? T.L - 0.01 : s); };
    T.uToS = function (u) { return T.type === 'circuit' ? T.wrapS(u) : T.wrapS(u + T.startS); };
    // diferencia con signo (b - a) respetando el cierre del circuito
    T.dS = function (a, b) {
      var d = b - a;
      if (T.closed) { if (d > T.L / 2) d -= T.L; else if (d < -T.L / 2) d += T.L; }
      return d;
    };
    var Q = { x: 0, y: 0, z: 0, tx: 0, tz: 1, rx: -1, rz: 0, sl: 0, cv: 0, yaw: 0, i: 0, f: 0 };
    T.q = function (s) { // interpolacion del centro de la pista
      s = T.wrapS(s);
      var fi = s / ds, i0 = Math.floor(fi), f = fi - i0;
      if (i0 >= N) { i0 = N - 1; f = 1; }
      var i1 = i0 + 1;
      Q.i = i0; Q.f = f;
      Q.x = px[i0] + (px[i1] - px[i0]) * f; Q.y = py[i0] + (py[i1] - py[i0]) * f; Q.z = pz[i0] + (pz[i1] - pz[i0]) * f;
      Q.tx = tx[i0] + (tx[i1] - tx[i0]) * f; Q.tz = tz[i0] + (tz[i1] - tz[i0]) * f;
      var tl = Math.sqrt(Q.tx * Q.tx + Q.tz * Q.tz) || 1; Q.tx /= tl; Q.tz /= tl;
      Q.rx = -Q.tz; Q.rz = Q.tx;
      Q.sl = sl[i0] + (sl[i1] - sl[i0]) * f; Q.cv = cv[i0] + (cv[i1] - cv[i0]) * f;
      Q.yaw = Math.atan2(Q.tx, Q.tz);
      return Q;
    };

    // ------ caracteristicas ------
    T.ramps = []; T.holes = []; T.obs = []; T.boxes = []; T.pads = []; T.crys = []; T.busy = [];
    genFeatures(T, def, closed);

    // altura del suelo (o -1e9 si hay hueco)
    T.NOGROUND = -1e9;
    T.inHole = function (s, d) {
      for (var h = 0; h < T.holes.length; h++) {
        var H = T.holes[h];
        if (s >= H.s0 && s < H.s1 && d >= H.d0 && d < H.d1) return H;
      }
      return null;
    };
    T.ground = function (s, d) {
      s = T.wrapS(s);
      if (T.inHole(s, d)) return T.NOGROUND;
      var fi = s / ds, i0 = Math.floor(fi); if (i0 >= N) i0 = N - 1;
      var y = py[i0] + (py[i0 + 1] - py[i0]) * (fi - i0);
      for (var r = 0; r < T.ramps.length; r++) {
        var R = T.ramps[r];
        if (s >= R.s0 && s < R.s0 + R.len && d >= R.d0 && d <= R.d1) y += R.h * (s - R.s0) / R.len;
      }
      return y;
    };
    // altura del centro sin rampas (referencia)
    T.centerY = function (s) { s = T.wrapS(s); var fi = s / ds, i0 = Math.floor(fi); if (i0 >= N) i0 = N - 1; return py[i0] + (py[i0 + 1] - py[i0]) * (fi - i0); };
    T.worldPos = function (s, d, out) { var q = T.q(s); out[0] = q.x + q.rx * d; out[2] = q.z + q.rz * d; return out; };

    // distancia al centro mas cercano (para terreno y decoracion)
    T.nearest = function (x, z, out) {
      var best = 1e18, bi = 0, step = 8, j;
      for (j = 0; j <= N; j += step) { var ddx = px[j] - x, ddz = pz[j] - z, dd = ddx * ddx + ddz * ddz; if (dd < best) { best = dd; bi = j; } }
      var lo = bi - step, hi = bi + step; best = 1e18;
      var bj = bi;
      for (j = lo; j <= hi; j++) {
        var jj = closed ? ((j % N) + N) % N : Math.max(0, Math.min(N, j));
        var ex = px[jj] - x, ez = pz[jj] - z, ee = ex * ex + ez * ez;
        if (ee < best) { best = ee; bj = jj; }
      }
      out.i = bj; out.dist = Math.sqrt(best);
      return out;
    };
    T.bbox = (function () {
      var x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
      for (var j = 0; j <= N; j++) { if (px[j] < x0) x0 = px[j]; if (px[j] > x1) x1 = px[j]; if (pz[j] < z0) z0 = pz[j]; if (pz[j] > z1) z1 = pz[j]; }
      return { x0: x0, x1: x1, z0: z0, z1: z1 };
    })();

    // miniatura 2D normalizada
    T.thumb = (function () {
      var b = T.bbox, w = b.x1 - b.x0, h = b.z1 - b.z0, sc = 1 / Math.max(w, h), out = [];
      for (var j = 0; j <= N; j += 6) out.push([(px[j] - b.x0) * sc, (pz[j] - b.z0) * sc]);
      return { pts: out, w: w * sc, h: h * sc, sc: sc };
    })();

    if (!opts.noMesh && PG.buildTrackMesh) PG.buildTrackMesh(T);
    return T;
  };

  /* ---------- colocacion de caracteristicas ---------- */
  function genFeatures(T, def, closed) {
    var A = def.auto, rnd = PG.rng(def.seed * 7919 + 13), W = T.W, ds = T.ds;
    function fs(f) { return T.type === 'circuit' ? f * T.L : T.startS + f * T.D; }
    function snap(s) { return Math.round(s / ds) * ds; }
    function busy(s0, s1, pad) { T.busy.push([s0 - pad, s1 + pad]); }
    function isBusy(s, pad) {
      pad = pad || 0;
      for (var i = 0; i < T.busy.length; i++) if (s > T.busy[i][0] - pad && s < T.busy[i][1] + pad) return true;
      return false;
    }
    // cuadricula de salida/meta ocupada
    if (T.type === 'circuit') busy(-40, 40, 0), busy(T.L - 50, T.L + 5, 0);
    else busy(0, T.startS + 45, 0), busy(T.finishS - 20, T.L, 0);

    var j, n;
    // saltos: rampa + hueco
    for (j = 0; j < A.jumps.length; j++) {
      var J = A.jumps[j], lip = snap(fs(J.f)), len = Math.round(J.len / ds) * ds;
      var hole = { s0: lip, s1: lip + len, d0: -13, d1: 13, mode: J.mode };
      if (J.mode === 'L') { hole.d0 = -13; hole.d1 = 1; }
      else if (J.mode === 'R') { hole.d0 = -1; hole.d1 = 13; }
      else if (J.mode === 'mid') { hole.d0 = -7; hole.d1 = 7; }
      T.holes.push(hole);
      if (J.mode === 'full') {
        var rl = Math.round(9 / ds) * ds;
        T.ramps.push({ s0: lip - rl, len: rl, h: 2.5, d0: -13, d1: 13, jump: true });
        busy(lip - rl - 40, lip + len + 12, 0);
      } else {
        // rampa opcional del lado libre para saltar por encima
        var rl2 = Math.round(8 / ds) * ds;
        var rd0 = J.mode === 'L' ? 3 : (J.mode === 'R' ? -13 : 9), rd1 = J.mode === 'L' ? 13 : (J.mode === 'R' ? -3 : 13);
        if (J.mode === 'mid') { T.ramps.push({ s0: lip - rl2 - 30, len: rl2, h: 1.6, d0: -13, d1: -9, jump: false }); }
        else T.ramps.push({ s0: lip - rl2 - 30, len: rl2, h: 1.6, d0: rd0, d1: rd1, jump: false });
        busy(lip - rl2 - 55, lip + len + 12, 0);
      }
    }
    // rampas sueltas
    for (j = 0; j < A.ramps.length; j++) {
      var s0 = snap(fs(A.ramps[j].f)), rl3 = Math.round(8 / ds) * ds;
      if (isBusy(s0, 14)) { s0 = snap(s0 + 60); if (isBusy(s0, 14)) continue; }
      T.ramps.push({ s0: s0, len: rl3, h: 2.1, d0: -6, d1: 6, jump: false });
      busy(s0 - 6, s0 + rl3 + 18, 0);
    }
    // pads de impulso
    var tries, placed = 0;
    for (tries = 0; tries < 400 && placed < A.pads; tries++) {
      var sp = snap(fs(0.02 + rnd() * 0.94));
      if (isBusy(sp, 12)) continue;
      var dc = Math.floor((rnd() * 4 - 2)) * 2 + 0; // -4,-2,0,2 -> d0
      T.pads.push({ s: sp, len: 9, d0: dc - 3 + 0, d1: dc + 3 + 0 }); busy(sp - 4, sp + 13, 0); placed++;
    }
    // filas de cajas de objeto
    for (n = 0; n < A.rows; n++) {
      var sr = snap(fs(0.04 + 0.90 * (n + 0.5) / A.rows));
      var guard = 0;
      while (isBusy(sr, 10) && guard++ < 30) sr = snap(sr + 8);
      if (guard >= 30) continue;
      var layout = rnd();
      var ds2 = layout < 0.5 ? [-7.5, -2.5, 2.5, 7.5] : (layout < 0.75 ? [-8, -4, 0, 4, 8] : [-6, 0, 6]);
      for (var q2 = 0; q2 < ds2.length; q2++) T.boxes.push({ s: sr, d: ds2[q2], row: n });
      busy(sr - 5, sr + 5, 0);
    }
    // cristales de habilidad
    for (n = 0; n < A.crystals; n++) {
      var sc = snap(fs(0.10 + 0.80 * (n + 0.35 + rnd() * 0.3) / A.crystals)), g2 = 0;
      while (isBusy(sc, 12) && g2++ < 40) sc = snap(sc + 9);
      T.crys.push({ s: sc, d: (rnd() < 0.5 ? -1 : 1) * (2 + rnd() * 6), got: 0 });
      busy(sc - 6, sc + 6, 0);
    }
    // obstaculos
    function addObs(type, s, d, extra) {
      var def2 = { rock: { r: 1.7, hit: 'rock' }, ice: { r: 1.5, hit: 'ice' }, snowman: { r: 1.2, hit: 'snowman' }, seal: { r: 1.7, hit: 'seal' }, ball: { r: 1.9, hit: 'ball' } }[type];
      var o = { type: type, s: s, d: d, r: def2.r, hit: def2.hit, mov: (type === 'seal' || type === 'ball'), yaw: rnd() * TAU, var: rnd() };
      if (extra) for (var kk in extra) o[kk] = extra[kk];
      T.obs.push(o); return o;
    }
    function freeObs(s, d, rr) {
      for (var i = 0; i < T.obs.length; i++) { var o = T.obs[i]; if (Math.abs(o.s - s) < 7 && Math.abs(o.d - d) < rr + o.r + 3) return false; }
      return true;
    }
    // compuertas: fila de obstaculos con un hueco de paso
    for (n = 0; n < A.gates; n++) {
      var sg = snap(fs(0.07 + 0.84 * (n + 0.5) / A.gates + (rnd() - 0.5) * 0.04)), g3 = 0;
      while (isBusy(sg, 12) && g3++ < 40) sg = snap(sg + 8);
      if (g3 >= 40) continue;
      var gap = (rnd() * 2 - 1) * 7, typ = rnd() < 0.5 ? 'rock' : 'ice';
      for (var dd = -10; dd <= 10; dd += 4.2) { if (Math.abs(dd - gap) < 4.4) continue; addObs(typ, sg, dd); }
      busy(sg - 8, sg + 8, 0);
    }
    var kinds = ['rock', 'ice', 'snowman', 'seal', 'ball'];
    for (var kd = 0; kd < kinds.length; kd++) {
      var cnt = A[kinds[kd]] || 0, put = 0;
      for (tries = 0; tries < 600 && put < cnt; tries++) {
        var so = snap(fs(0.03 + rnd() * 0.93)), dobs = (rnd() * 2 - 1) * (W / 2 - 4);
        if (isBusy(so, 10) || !freeObs(so, dobs, 2)) continue;
        if (kinds[kd] === 'seal') addObs('seal', so, 0, { amp: 7 + rnd() * 2, w: 0.9 + rnd() * 0.5, ph: rnd() * TAU });
        else if (kinds[kd] === 'ball') addObs('ball', so, 0, { v: 6 + rnd() * 2, ph: rnd() * 40 });
        else addObs(kinds[kd], so, dobs);
        put++; busy(so - 3, so + 3, 0);
      }
    }
    T.obs.sort(function (a, b) { return a.s - b.s; });
  }

  // posicion de un obstaculo en el instante t (segundos de carrera)
  PG.obsPos = function (T, o, t, out) {
    if (o.type === 'seal') { out[0] = o.s; out[1] = o.amp * Math.sin(t * o.w + o.ph); }
    else if (o.type === 'ball') {
      var span = T.W + 8, x = ((t * o.v + o.ph) % span + span) % span;
      out[0] = o.s; out[1] = -T.W / 2 - 4 + x;
    } else { out[0] = o.s; out[1] = o.d; }
    return out;
  };
})();
