/* Pistas: trazado, consultas de suelo/rampas/huecos y colocacion de obstaculos y poderes */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI, TAU = Math.PI * 2;

  /* ---------- temas visuales ---------- */
  PG.THEMES = {
    day: { top: [0.28, 0.52, 0.88], hor: [0.80, 0.91, 0.99], bot: [0.80, 0.90, 0.98], fog: [0.80, 0.91, 0.99], fogN: 220, fogF: 1100,
      sun: [0.45, 0.80, 0.40], sunCol: [1.0, 0.96, 0.88], amb: [0.60, 0.68, 0.80], gnd: [0.46, 0.52, 0.64],
      snow: [0.97, 0.98, 1.0], ice: [0.58, 0.76, 0.93], rock: [0.52, 0.56, 0.66], tree: [0.16, 0.45, 0.28], aurora: 0, flakes: 0.35 },
    glacier: { top: [0.22, 0.46, 0.84], hor: [0.74, 0.90, 1.0], bot: [0.72, 0.88, 1.0], fog: [0.74, 0.90, 1.0], fogN: 210, fogF: 1050,
      sun: [0.30, 0.85, 0.30], sunCol: [0.95, 0.98, 1.0], amb: [0.58, 0.70, 0.86], gnd: [0.42, 0.55, 0.72],
      snow: [0.95, 0.98, 1.0], ice: [0.42, 0.74, 0.98], rock: [0.45, 0.58, 0.74], tree: [0.14, 0.42, 0.30], aurora: 0, flakes: 0.3 },
    night: { top: [0.02, 0.05, 0.18], hor: [0.14, 0.30, 0.50], bot: [0.10, 0.20, 0.38], fog: [0.12, 0.24, 0.42], fogN: 150, fogF: 850,
      sun: [-0.3, 0.7, 0.5], sunCol: [0.55, 0.65, 1.0], amb: [0.42, 0.52, 0.76], gnd: [0.22, 0.28, 0.46],
      snow: [0.82, 0.90, 1.0], ice: [0.38, 0.62, 0.95], rock: [0.30, 0.36, 0.52], tree: [0.07, 0.28, 0.28], aurora: 1, flakes: 0.4 },
    sunset: { top: [0.30, 0.28, 0.58], hor: [1.0, 0.72, 0.50], bot: [0.95, 0.62, 0.48], fog: [0.98, 0.70, 0.56], fogN: 210, fogF: 1050,
      sun: [0.75, 0.30, 0.55], sunCol: [1.0, 0.72, 0.45], amb: [0.66, 0.58, 0.68], gnd: [0.50, 0.40, 0.52],
      snow: [1.0, 0.94, 0.92], ice: [0.55, 0.74, 0.92], rock: [0.62, 0.42, 0.40], tree: [0.14, 0.34, 0.26], aurora: 0, flakes: 0.25 },
    dusk: { top: [0.12, 0.30, 0.55], hor: [0.58, 0.84, 0.92], bot: [0.36, 0.62, 0.78], fog: [0.56, 0.82, 0.92], fogN: 220, fogF: 1100,
      sun: [-0.5, 0.45, 0.6], sunCol: [1.0, 0.88, 0.70], amb: [0.58, 0.70, 0.82], gnd: [0.38, 0.52, 0.64],
      snow: [0.96, 0.99, 1.0], ice: [0.46, 0.80, 0.94], rock: [0.48, 0.58, 0.68], tree: [0.14, 0.40, 0.30], aurora: 0, flakes: 0.3 },
    crystal: { top: [0.08, 0.05, 0.26], hor: [0.34, 0.28, 0.62], bot: [0.22, 0.18, 0.46], fog: [0.26, 0.22, 0.52], fogN: 130, fogF: 800,
      sun: [0.2, 0.85, 0.3], sunCol: [0.75, 0.70, 1.0], amb: [0.50, 0.50, 0.80], gnd: [0.28, 0.26, 0.52],
      snow: [0.86, 0.88, 1.0], ice: [0.46, 0.60, 0.98], rock: [0.36, 0.32, 0.58], tree: [0.10, 0.30, 0.36], aurora: 1, flakes: 0.2 },
    volcano: { top: [0.26, 0.50, 0.86], hor: [0.78, 0.90, 0.98], bot: [0.78, 0.88, 0.96], fog: [0.72, 0.86, 0.97], fogN: 260, fogF: 1250,
      sun: [0.40, 0.80, 0.45], sunCol: [1.0, 0.96, 0.88], amb: [0.60, 0.67, 0.78], gnd: [0.44, 0.50, 0.60],
      snow: [0.97, 0.98, 1.0], ice: [0.56, 0.75, 0.93], rock: [0.44, 0.42, 0.44], tree: [0.16, 0.45, 0.28], aurora: 0, flakes: 0.3 },
    lagoon: { top: [0.12, 0.42, 0.78], hor: [0.72, 0.94, 0.99], bot: [0.55, 0.85, 0.95], fog: [0.66, 0.91, 0.98], fogN: 240, fogF: 1150,
      sun: [0.3, 0.8, 0.4], sunCol: [1.0, 0.98, 0.9], amb: [0.58, 0.72, 0.88], gnd: [0.40, 0.58, 0.74],
      snow: [0.96, 0.99, 1.0], ice: [0.40, 0.80, 0.97], rock: [0.40, 0.55, 0.68], tree: [0.14, 0.44, 0.34], aurora: 0, flakes: 0.2 },
    dawn: { top: [0.26, 0.28, 0.66], hor: [1.0, 0.76, 0.66], bot: [0.92, 0.66, 0.66], fog: [0.96, 0.74, 0.70], fogN: 190, fogF: 1000,
      sun: [0.7, 0.28, 0.6], sunCol: [1.0, 0.76, 0.58], amb: [0.66, 0.60, 0.76], gnd: [0.48, 0.42, 0.62],
      snow: [1.0, 0.95, 0.97], ice: [0.58, 0.72, 0.95], rock: [0.50, 0.42, 0.56], tree: [0.14, 0.34, 0.30], aurora: 0, flakes: 0.3 },
    wreck: { top: [0.20, 0.30, 0.46], hor: [0.62, 0.74, 0.84], bot: [0.56, 0.68, 0.80], fog: [0.58, 0.70, 0.80], fogN: 110, fogF: 760,
      sun: [0.5, 0.55, 0.4], sunCol: [0.95, 0.90, 0.84], amb: [0.52, 0.60, 0.72], gnd: [0.36, 0.44, 0.58],
      snow: [0.94, 0.97, 1.0], ice: [0.38, 0.58, 0.80], rock: [0.40, 0.46, 0.58], tree: [0.12, 0.34, 0.26], aurora: 0, flakes: 0.7 },
    castle: { top: [0.07, 0.08, 0.27], hor: [0.40, 0.38, 0.68], bot: [0.26, 0.26, 0.54], fog: [0.30, 0.30, 0.58], fogN: 150, fogF: 900,
      sun: [0.3, 0.7, 0.3], sunCol: [0.72, 0.80, 1.0], amb: [0.48, 0.54, 0.82], gnd: [0.26, 0.30, 0.54],
      snow: [0.88, 0.92, 1.0], ice: [0.40, 0.66, 0.97], rock: [0.42, 0.46, 0.66], tree: [0.10, 0.32, 0.34], aurora: 1, flakes: 0.5 },
    xmas: { top: [0.02, 0.04, 0.17], hor: [0.13, 0.22, 0.48], bot: [0.10, 0.18, 0.38], fog: [0.10, 0.20, 0.40], fogN: 170, fogF: 950,
      sun: [-0.2, 0.7, 0.5], sunCol: [0.72, 0.76, 1.0], amb: [0.46, 0.54, 0.80], gnd: [0.26, 0.32, 0.50],
      snow: [0.86, 0.92, 1.0], ice: [0.38, 0.64, 0.95], rock: [0.32, 0.38, 0.54], tree: [0.07, 0.30, 0.22], aurora: 1, flakes: 0.8 },
    storm: { top: [0.34, 0.38, 0.46], hor: [0.66, 0.70, 0.76], bot: [0.62, 0.66, 0.72], fog: [0.64, 0.68, 0.74], fogN: 70, fogF: 520,
      sun: [0.2, 0.9, 0.2], sunCol: [0.8, 0.84, 0.9], amb: [0.58, 0.62, 0.70], gnd: [0.40, 0.44, 0.52],
      snow: [0.92, 0.94, 0.97], ice: [0.50, 0.66, 0.84], rock: [0.40, 0.44, 0.52], tree: [0.12, 0.30, 0.26], aurora: 0, flakes: 1.0 }
  };

  /* ---------- generadores de trazado ---------- */
  function circuitPath(o) {
    var pts = [], n = 900, i, k;
    for (i = 0; i < n; i++) {
      var th = TAU * i / n, r = 1;
      for (k = 0; k < o.harm.length; k++) r += o.harm[k][1] * Math.cos(o.harm[k][0] * th + o.harm[k][2]);
      var y = o.y0 || 0;
      for (k = 0; k < o.hy.length; k++) y += o.hy[k][1] * Math.sin(o.hy[k][0] * th + o.hy[k][2]);
      pts.push([o.R * o.sx * r * Math.cos(th), y, o.R * o.sz * r * Math.sin(th)]);
    }
    return { pts: pts, closed: true };
  }
  // circuito poligonal con esquinas redondeadas (radio r por esquina). Devuelve tambien el indice de cada esquina
  // (para colocar los atajos), y empieza en la mitad del tramo `o.start` (una recta larga).
  // perfil de altura del ascenso: sube con extremos suaves (rs..rs+up), meseta hasta el labio (lip) y baja suave despues
  PG.CLIMB12 = { c0: 4, c1: 5, off: 0, rs: -105, up: 110, H: 17, lip: 22, down: 60, gap: 17 };
  PG.climbBump = function (u, b) {
    function sst(a) { a = Math.max(0, Math.min(1, a)); return a * a * (3 - 2 * a); }
    if (u <= b.rs) return 0;
    if (u < b.rs + b.up) { var tt = (u - b.rs) / b.up; return b.H * (0.4 * sst(tt) + 0.6 * tt); }
    if (u <= b.lip) return b.H;
    return b.H * (1 - sst((u - b.lip) / b.down));
  };
  function polyPath(o) {
    var P = o.pts, n = P.length, R = o.r, i, k, segs = [], pts = [], corners = [], STEP = 3;
    if (o.sc) P = P.map(function (p) { return [p[0] * o.sc, p[1] * o.sc]; });
    function rr(i2) { return Array.isArray(R) ? (R[i2] === undefined ? R[R.length - 1] : R[i2]) : R; }
    var F = [];
    for (i = 0; i < n; i++) {
      var A = P[(i + n - 1) % n], B = P[i], C = P[(i + 1) % n];
      var d1x = B[0] - A[0], d1z = B[1] - A[1], l1 = Math.hypot(d1x, d1z); d1x /= l1; d1z /= l1;
      var d2x = C[0] - B[0], d2z = C[1] - B[1], l2 = Math.hypot(d2x, d2z); d2x /= l2; d2z /= l2;
      var cr = d1x * d2z - d1z * d2x, th = Math.atan2(Math.abs(cr), d1x * d2x + d1z * d2z), r = rr(i), t = r * Math.tan(th / 2);
      F.push({ B: B, d1: [d1x, d1z], d2: [d2x, d2z], sg: cr >= 0 ? 1 : -1, th: th, r: r, t: t, S: [B[0] - d1x * t, B[1] - d1z * t], E: [B[0] + d2x * t, B[1] + d2z * t] });
    }
    for (i = 0; i < n; i++) {
      var f = F[i], g = F[(i + 1) % n];
      // arco de la esquina i
      var nx = -f.d1[1] * f.sg, nz = f.d1[0] * f.sg, cx = f.S[0] + nx * f.r, cz = f.S[1] + nz * f.r;
      var na = Math.max(2, Math.ceil(f.r * f.th / STEP)), vx = f.S[0] - cx, vz = f.S[1] - cz;
      for (k = 0; k < na; k++) {
        var ph = f.sg * f.th * k / na, cs = Math.cos(ph), sn = Math.sin(ph);
        pts.push([cx + vx * cs - vz * sn, cz + vx * sn + vz * cs]);
        if (k === (na >> 1)) corners[i] = pts.length - 1;
      }
      // recta hasta la siguiente esquina
      var sl = Math.hypot(g.S[0] - f.E[0], g.S[1] - f.E[1]), ns = Math.max(1, Math.floor(sl / 4));
      for (k = 0; k < ns; k++) pts.push([f.E[0] + (g.S[0] - f.E[0]) * k / ns, f.E[1] + (g.S[1] - f.E[1]) * k / ns]);
      if (i === (o.start || 0)) o._mid = pts.length - 1 - (ns >> 1);
    }
    // girar el anillo para que el inicio (s=0) caiga en la mitad del tramo de salida
    var m = pts.length, shift = o._mid || 0, out = [], ci = [], tot = 0;
    for (i = 0; i < m; i++) { var a2 = pts[(shift + i) % m], b2 = pts[(shift + i + 1) % m]; tot += Math.hypot(b2[0] - a2[0], b2[1] - a2[1]); }
    var cum = 0;
    for (i = 0; i < m; i++) {
      var q0 = pts[(shift + i) % m], q1 = pts[(shift + i + 1) % m], th2 = TAU * cum / tot, y = o.y0 || 0;
      for (k = 0; k < o.hy.length; k++) y += o.hy[k][1] * Math.sin(o.hy[k][0] * th2 + o.hy[k][2]);
      out.push([q0[0], y, q0[1]]);
      cum += Math.hypot(q1[0] - q0[0], q1[1] - q0[1]);
    }
    for (i = 0; i < n; i++) ci[i] = ((corners[i] - shift) % m + m) % m;
    if (o.bump) { // v4.4: tramo que sube (cubierta de un barco enterrado e inclinado) y vuelve a bajar tras el salto
      var cb = [0], bm = o.bump;
      for (i = 1; i < m; i++) cb.push(cb[i - 1] + Math.hypot(out[i][0] - out[i - 1][0], out[i][2] - out[i - 1][2]));
      var scb = (cb[ci[bm.c0]] + cb[ci[bm.c1]]) / 2 + (bm.off || 0);
      for (i = 0; i < m; i++) out[i][1] += PG.climbBump(cb[i] - scb, bm);
    }
    return { pts: out, closed: true, corners: ci };
  }
  PG.polyPath = polyPath;
  function sprintPath(o) {
    var pts = [], x = 0, z = 0, step = 1, n = Math.floor(o.len / step), k, j;
    function sstep(a) { a = Math.max(0, Math.min(1, a)); return a * a * (3 - 2 * a); }
    function base(u) { var ph = o.phi0 || 0; for (var jj = 0; jj < o.turn.length; jj++) ph += o.turn[jj][0] * Math.sin(TAU * u / o.turn[jj][1] + o.turn[jj][2]); return ph; }
    var steep = o.steep, hold = steep ? base(steep.u0) : 0, hold2 = o.hold ? base(o.hold.u0) : 0;
    for (k = 0; k <= n; k++) {
      var u = k * step, phi = base(u), y = o.y0 - o.slope * u;
      var wfl = o.flat ? sstep((u - o.flat.u0) / 90) * (1 - sstep((u - o.flat.u1) / 90)) : 0;
      for (j = 0; j < o.hills.length; j++) y += o.hills[j][0] * Math.sin(TAU * u / o.hills[j][1] + o.hills[j][2]) * (1 - wfl);
      if (steep) { // recta muy inclinada: el rumbo se congela y la pendiente aumenta con transicion suave
        var wz = sstep((u - steep.u0) / 180) * (1 - sstep((u - steep.u1) / 240));
        phi = phi + (hold - phi) * wz;
      }
      if (o.hold) { var wz2 = sstep((u - o.hold.u0) / 160) * (1 - sstep((u - o.hold.u1) / 160)); phi = phi + (hold2 - phi) * wz2; } // v4.3: tramo recto (el castillo)
      if (o.wig) { var wg = o.wig, wzw = sstep((u - wg.u0) / 90) * (1 - sstep((u - wg.u1) / 90)); phi += wg.A * Math.sin(TAU * (u - wg.u0) / wg.P) * wzw; } // v4.4: curvas seguidas dentro del castillo
      pts.push([x, y, z]);
      x += Math.sin(phi) * step; z += Math.cos(phi) * step;
    }
    if (o.flat) { var ex2 = 0; for (k = 0; k <= n; k++) { var u3 = k * step, wf3 = sstep((u3 - o.flat.u0) / 90) * (1 - sstep((u3 - o.flat.u1) / 90)); ex2 += (o.flat.slope - o.slope) * wf3 * step; pts[k][1] -= ex2; } }
    if (o.dip) { // cuenca de la laguna: la pista se hunde (entrada en pendiente), sigue por el fondo y sube de nuevo
      var dp = o.dip;
      for (k = 0; k <= n; k++) { var u4 = k * step; pts[k][1] -= dp.D * sstep((u4 - (dp.u0 - dp.rin)) / dp.rin) * (1 - sstep((u4 - dp.u1) / dp.rout)); }
    }
    if (steep) { // altura: integral de la pendiente extra (suavizada) a lo largo de u
      var extra = 0;
      for (k = 0; k <= n; k++) {
        var u2 = k * step, e = (steep.slope - o.slope) * sstep((u2 - steep.u0) / 90) * (1 - sstep((u2 - steep.u1) / 90));
        extra += e * step; pts[k][1] -= extra;
      }
    }
    return { pts: pts, closed: false };
  }

  var VOLC_PTS = [[0,-330],[300,-94],[540,300],[-540,280],[-440,-230]]; // el lado largo (3er tramo) atraviesa la montana del volcan

  /* ---------- definicion de las pistas ---------- */
  // v4.2: el azul del hielo era demasiado claro en varias pistas: se oscurece (mas cuanto mas claro) y se satura un poco
  (function () {
    for (var k in PG.THEMES) {
      var ic = PG.THEMES[k].ice; if (!ic) continue;
      var lum = (ic[0] + ic[1] + ic[2]) / 3, f = lum > 0.72 ? 0.74 : (lum > 0.62 ? 0.80 : 0.88);
      PG.THEMES[k].ice = [ic[0] * f * 0.94, ic[1] * f * 0.98, Math.min(1, ic[2] * f * 1.04)];
    }
  })();
  PG.TRACKS = [
    {
      id: 0, name: 'Valle Nevado', type: 'circuit', theme: 'day', blurb: 'Circuito con colinas suaves, una cueva corta y buenas bajadas. Ideal para empezar.',
      path: function () { return polyPath({ pts: [[-360, -170], [330, -210], [440, 150], [40, 330], [-380, 110]], sc: 0.78, r: 55, start: 0, y0: 0, hy: [[2, 14, 0.5], [3, 7, 1.0], [5, 4.5, 2.2], [7, 3.2, 0.3]] }); },
      cuts: [{ c: 2, a: 215, b: 215, lift: 3 }],
      auto: { jumps: [{ f: 0.30, len: 17, mode: 'full' }, { f: 0.80, len: 15, mode: 'L' }], ramps: [{ f: 0.14 }, { f: 0.52 }, { f: 0.90 }],
        rock: 8, ice: 6, snowman: 5, seal: 1, ball: 0, gates: 1, rows: 11, pads: 5, crystals: 7 },
      caves: [{ f0: 0.57, f1: 0.70, ic: 0.5 }],
      hills: 38, trees: 800, seed: 11
    },
    {
      id: 1, name: 'Descenso del Glaciar', type: 'sprint', theme: 'glacier', blurb: 'Bajada empinada de A a B con grietas, saltos y dos cuevas de hielo.',
      path: function () { return sprintPath({ len: 3300, y0: 40, slope: 0.18, phi0: 0, turn: [[0.80, 920, 0.4], [0.42, 430, 2.0]], hills: [[8, 300, 0.7], [3, 120, 2.1]] }); },
      auto: { jumps: [{ f: 0.20, len: 18, mode: 'full' }, { f: 0.47, len: 14, mode: 'mid' }, { f: 0.70, len: 20, mode: 'full' }, { f: 0.93, len: 15, mode: 'R' }],
        ramps: [{ f: 0.08 }, { f: 0.56 }, { f: 0.62 }], rock: 14, ice: 11, snowman: 4, seal: 5, ball: 4, gates: 3, rows: 14, pads: 8, crystals: 9 },
      caves: [{ f0: 0.27, f1: 0.40 }, { f0: 0.76, f1: 0.87 }],
      hills: 46, trees: 700, seed: 23
    },
    {
      id: 2, name: 'Circuito Aurora', type: 'circuit', theme: 'night', blurb: 'De noche bajo la aurora. Montaña rusa con cueva de cristales.',
      path: function () { return polyPath({ pts: [[-420, -150], [150, -300], [430, -90], [330, 200], [-60, 90], [-330, 330]], sc: 0.76, r: [55, 55, 55, 55, 50, 55], start: 0, y0: 2, hy: [[2, 15, 2.0], [3, 8, 0.4], [8, 3.2, 1.1]] }); },
      cuts: [{ c: 2, a: 175, b: 225 }],
      auto: { jumps: [{ f: 0.26, len: 17, mode: 'full' }, { f: 0.50, len: 16, mode: 'R' }, { f: 0.88, len: 15, mode: 'mid' }], ramps: [{ f: 0.12 }, { f: 0.40 }, { f: 0.80 }],
        rock: 10, ice: 8, snowman: 4, seal: 2, ball: 2, gates: 2, rows: 11, pads: 5, crystals: 8 },
      caves: [{ f0: 0.58, f1: 0.74 }],
      hills: 36, trees: 700, seed: 37
    },
    {
      id: 3, name: 'Canon Congelado', type: 'sprint', theme: 'sunset', blurb: 'Paredes de roca, atardecer, curvas rápidas y un túnel en la roca.',
      path: function () { return sprintPath({ len: 3550, y0: 60, slope: 0.20, phi0: 0, turn: [[0.95, 760, 1.2], [0.40, 300, 0.3]], hills: [[9, 290, 1.0], [3.5, 115, 0.2]] }); },
      auto: { jumps: [{ f: 0.16, len: 17, mode: 'full' }, { f: 0.38, len: 15, mode: 'L' }, { f: 0.62, len: 19, mode: 'full' }, { f: 0.90, len: 16, mode: 'mid' }],
        ramps: [{ f: 0.06 }, { f: 0.30 }, { f: 0.52 }, { f: 0.80 }], rock: 19, ice: 14, snowman: 4, seal: 4, ball: 5, gates: 4, rows: 14, pads: 8, crystals: 9 },
      caves: [{ f0: 0.68, f1: 0.82 }],
      hills: 95, canyon: true, trees: 340, seed: 49
    },
    {
      id: 4, name: 'Bahia de los Icebergs', type: 'circuit', theme: 'dusk', blurb: 'Plataforma de hielo sobre el mar con rampas, saltos largos y subidas.',
      path: function () { return polyPath({ pts: [[-330, -230], [380, -190], [330, 130], [-20, 90], [-60, 340], [-420, 220]], sc: 0.77, r: 55, start: 0, y0: 4, hy: [[2, 15, 0.9], [3, 8, 2.6], [5, 4.5, 0.7], [7, 3.6, 0.4]] }); },
      cuts: [{ c: 2, a: 200, b: 200, lift: 6 }, { c: 4, a: 170, b: 180 }],
      auto: { jumps: [{ f: 0.20, len: 19, mode: 'full' }, { f: 0.45, len: 16, mode: 'L' }, { f: 0.78, len: 20, mode: 'full' }], ramps: [{ f: 0.10 }, { f: 0.34 }, { f: 0.62 }, { f: 0.90 }],
        rock: 6, ice: 10, snowman: 2, seal: 4, ball: 2, gates: 2, rows: 11, pads: 6, crystals: 8 },
      hills: 20, water: true, trees: 220, seed: 53
    },
    {
      id: 5, name: 'Cumbre de la Tormenta', type: 'sprint', theme: 'storm', blurb: 'La bajada más rápida, con ventisca, cueva y poca visión.',
      path: function () { return sprintPath({ len: 3750, y0: 90, slope: 0.22, phi0: 0, turn: [[1.00, 640, 2.2], [0.50, 250, 1.0]], hills: [[10, 270, 0.2], [3.5, 105, 1.4]] }); },
      auto: { jumps: [{ f: 0.14, len: 18, mode: 'full' }, { f: 0.34, len: 16, mode: 'mid' }, { f: 0.58, len: 20, mode: 'full' }, { f: 0.80, len: 16, mode: 'L' }, { f: 0.94, len: 17, mode: 'R' }],
        ramps: [{ f: 0.06 }, { f: 0.25 }, { f: 0.47 }, { f: 0.68 }], rock: 19, ice: 17, snowman: 5, seal: 5, ball: 6, gates: 4, rows: 15, pads: 9, crystals: 10 },
      caves: [{ f0: 0.40, f1: 0.52 }],
      hills: 60, trees: 400, seed: 71
    },
    {
      id: 6, name: 'Gruta de Cristal', type: 'sprint', theme: 'crystal', blurb: 'Descenso extremo casi todo por cuevas de cristales brillantes.',
      path: function () { return sprintPath({ len: 3200, y0: 100, slope: 0.24, phi0: 0, turn: [[0.85, 700, 0.8], [0.45, 280, 2.4]], hills: [[10, 260, 0.4], [3.5, 100, 1.7]] }); },
      auto: { jumps: [{ f: 0.355, len: 17, mode: 'full' }, { f: 0.685, len: 16, mode: 'mid' }, { f: 0.95, len: 15, mode: 'R' }],
        ramps: [{ f: 0.07 }, { f: 0.22 }, { f: 0.52 }, { f: 0.82 }], rock: 14, ice: 14, snowman: 2, seal: 4, ball: 0, gates: 4, rows: 15, pads: 9, crystals: 10 },
      caves: [{ f0: 0.11, f1: 0.27 }, { f0: 0.43, f1: 0.60 }, { f0: 0.76, f1: 0.89 }],
      hills: 70, canyon: true, trees: 160, seed: 91
    },
    {
      id: 7, name: 'Montaña Rusa Helada', type: 'circuit', theme: 'glacier', blurb: 'Circuito de colinas gigantes: sube, baja y vuela. Con túnel de hielo.',
      path: function () { return polyPath({ pts: [[-420, -220], [400, -260], [470, 120], [100, 160], [-120, 420], [-480, 260]], sc: 0.78, r: 58, start: 0, y0: 6, hy: [[2, 24, 0.3], [3, 11, 1.2], [9, 5.5, 2.0]] }); },
      cuts: [{ c: 2, a: 200, b: 200, lift: 7 }, { c: 4, a: 190, b: 200 }],
      auto: { jumps: [{ f: 0.28, len: 18, mode: 'full' }, { f: 0.84, len: 16, mode: 'L' }], ramps: [{ f: 0.10 }, { f: 0.48 }, { f: 0.64 }, { f: 0.92 }],
        rock: 10, ice: 10, snowman: 4, seal: 2, ball: 2, gates: 2, rows: 12, pads: 7, crystals: 9 },
      caves: [{ f0: 0.64, f1: 0.74 }],
      hills: 42, trees: 600, seed: 97
    },
    {
      id: 8, name: 'Picada Mortal', type: 'sprint', theme: 'day', blurb: 'Bajada larga por una ladera nevada: pista blanca, a toda velocidad entre algunos pinos. Termina en una cueva con picos de hielo.',
      path: function () { return sprintPath({ len: 2500, y0: 290, slope: 0.26, phi0: 0, turn: [[0.70, 640, 0.6], [0.34, 260, 2.0]], hills: [[2.2, 260, 0.4], [1.0, 110, 1.2]] }); },
      auto: { jumps: [],
        ramps: [{ f: 0.18 }, { f: 0.55 }], rock: 3, ice: 3, snowman: 2, seal: 0, ball: 0, tree: 3, gates: 4, rows: 9, pads: 7, crystals: 9 },
      caves: [{ f0: 0.72, f1: 0.91, ic: 1.2 }], treeGates: true, whiteRoad: true,
      hills: 40, trees: 520, seed: 113
    },
    {
      id: 9, name: 'Volcán Ardiente', type: 'circuit', theme: 'volcano', blurb: 'La pista atraviesa una enorme montaña por dentro: túneles, cuevas y una gran cámara con un volcán y lava. Al salir, pista normal.',
      path: function () { return polyPath({ pts: VOLC_PTS, r: 62, start: 0, y0: 4, hy: [[2, 10, 0.4], [3, 6, 2.2], [5, 3, 1.0], [9, 1.6, 0.3]] }); },
      // v2.8: tres caminos para cruzar la montana: el del medio (tunel, gran camara del volcan y tunel) y dos tuneles laterales (izquierdo y derecho) que rodean la camara
      cuts: [{ c: 4, a: 240, b: 140 },
        { mt: 1, sgn: -1, f: 480, ramp: 232, off: 108, W: 22, pAI: 0.22, pads: 4 },
        { mt: 1, sgn: 1, f: 480, ramp: 232, off: 108, W: 22, pAI: 0.22, pads: 4 }],
      auto: { jumps: [{ f: 0.15, len: 18, mode: 'full' }, { f: 0.80, len: 16, mode: 'mid' }], ramps: [{ f: 0.08 }, { f: 0.24 }, { f: 0.70 }, { f: 0.92 }],
        rock: 10, ice: 6, snowman: 1, seal: 0, ball: 3, gates: 2, rows: 11, pads: 6, crystals: 8 },
      mountain: { c0: 2, c1: 3, Rb: 235, H: 215, tun: 261, hall: 72 },
      hills: 16, trees: 420, seed: 131
    },
    {
      id: 10, name: 'Laguna Sumergida', type: 'sprint', theme: 'lagoon', blurb: 'Bajada de A a B que se hunde en una laguna: te zambulles, nadas flotando y aleteando, y sales a la pista normal.',
      path: function () { return sprintPath({ len: 3000, y0: 60, slope: 0.17, phi0: 0, turn: [[0.70, 820, 1.0], [0.38, 380, 2.6]], hills: [[7, 280, 0.3], [2.5, 110, 1.4]], flat: { u0: 1120, u1: 1780, slope: 0 }, dip: { u0: 1270, u1: 1600, D: 10, rin: 150, rout: 130 } }); },
      auto: { jumps: [{ f: 0.16, len: 17, mode: 'full' }, { f: 0.80, len: 16, mode: 'L' }, { f: 0.92, len: 15, mode: 'mid' }],
        ramps: [{ f: 0.08 }, { f: 0.28 }, { f: 0.72 }, { f: 0.86 }], rock: 12, ice: 9, snowman: 2, seal: 4, ball: 3, gates: 3, rows: 13, pads: 8, crystals: 9 },
      caves: [{ f0: 0.86, f1: 0.95, ic: 0.5 }], lake: { fa: 0.45, fb: 0.55, D: 10, off: 0.8, scan: [0.24, 0.76] },
      hills: 70, canyon: true, trees: 200, seed: 151
    },
    {
      id: 11, name: 'Serpiente del Abismo', type: 'sprint', theme: 'dawn', blurb: 'Muchísimas curvas seguidas y, casi al final, una recta larguísima e inclinadísima.',
      path: function () { return sprintPath({ len: 3300, y0: 330, slope: 0.15, phi0: 0, turn: [[0.85, 400, 0.5], [0.45, 220, 2.0], [0.2, 130, 4.0]], hills: [[4, 190, 0.7], [1.6, 85, 2.5]], steep: { u0: 2560, u1: 2960, slope: 0.95 } }); },
      auto: { jumps: [{ f: 0.22, len: 16, mode: 'mid' }, { f: 0.50, len: 17, mode: 'full' }, { f: 0.72, len: 15, mode: 'R' }],
        ramps: [{ f: 0.08 }, { f: 0.30 }, { f: 0.62 }, { f: 0.93 }], rock: 12, ice: 10, snowman: 3, seal: 3, ball: 3, gates: 4, rows: 14, pads: 9, crystals: 9 },
      hills: 60, trees: 380, seed: 173
    },
    {
      id: 12, name: 'Naufragio Helado', type: 'circuit', theme: 'wreck', blurb: 'Cementerio de barcos varados en el hielo. Cruzas tres: uno de lado por un boquete del casco, otro de frente por la proa y uno enterrado e inclinado cuya cubierta sube hasta una rampa de salto.',
      path: function () { return polyPath({ pts: [[-300, -250], [360, -300], [500, 60], [330, 330], [-330, 300], [-480, -40]], sc: 1.0, r: 58, start: 0, y0: 3, hy: [[2, 7, 0.6], [3, 4, 2.0], [5, 2.5, 0.8], [7, 1.5, 1.9]], bump: PG.CLIMB12 }); },
      cuts: [{ c: 3, a: 170, b: 170 }],
      auto: { jumps: [{ f: 0.12, len: 17, mode: 'full' }, { f: 0.40, len: 15, mode: 'L' }, { f: 0.92, len: 16, mode: 'mid' }], ramps: [{ f: 0.06 }, { f: 0.20 }, { f: 0.34 }, { f: 0.47 }, { f: 0.86 }],
        rock: 6, ice: 7, snowman: 3, seal: 2, ball: 2, gates: 3, rows: 11, pads: 6, crystals: 7, air: 6 },
      ships: [{ k: 'side', c0: 1, c1: 2, len: 54 }, { k: 'bow', c0: 3, c1: 4, len: 170 }], climb: PG.CLIMB12, hills: 34, trees: 200, seed: 211
    },
    {
      id: 13, name: 'Castillo Congelado', type: 'sprint', theme: 'castle', blurb: 'Bajada de A a B: entras por la puerta de un enorme castillo de hielo y recorres su interior larguísimo, con curvas y tres caminos (salón, mazmorra y murallas) llenos de péndulos, trampas y rampas. Después, un tramo de pista normal hasta la meta.',
      path: function () { return sprintPath({ len: 3900, y0: 90, slope: 0.17, phi0: 0, turn: [[0.70, 880, 0.9], [0.38, 400, 2.2]], hills: [[7, 300, 0.5], [2.5, 120, 1.7]], flat: { u0: 2040, u1: 3140, slope: 0.05 }, hold: { u0: 2080, u1: 3130 }, wig: { u0: 2450, u1: 3000, A: 0.6, P: 275 } }); },
      auto: { jumps: [{ f: 0.12, len: 17, mode: 'full' }, { f: 0.28, len: 15, mode: 'L' }, { f: 0.88, len: 18, mode: 'full' }, { f: 0.95, len: 15, mode: 'R' }],
        ramps: [{ f: 0.06 }, { f: 0.19 }, { f: 0.25 }, { f: 0.43 }, { f: 0.50 }, { f: 0.91 }], rock: 8, ice: 9, snowman: 3, seal: 3, ball: 3, gates: 4, rows: 12, pads: 7, crystals: 9, air: 7 },
      castle: { f: 0.665, len: 880, off: 34, W: 22, corr: 300, hall: 80, exit: 80 }, hills: 40, trees: 380, seed: 233
    },
    {
      id: 14, name: 'Ciudad Navideña', type: 'circuit', theme: 'xmas', blurb: 'La ciudad de los pingüinos en Navidad: luces, árboles decorados, iglús, regalos y espectadores por todo el mapa.',
      path: function () { return polyPath({ pts: [[-400, -200], [350, -270], [470, 80], [230, 330], [-140, 190], [-430, 290]], sc: 1.0, r: 64, start: 0, y0: 4, hy: [[2, 11, 1.2], [3, 6, 0.3], [5, 3.5, 2.1], [7, 2.2, 0.6]] }); },
      cuts: [{ c: 2, a: 240, b: 240 }],
      auto: { jumps: [{ f: 0.26, len: 17, mode: 'full' }, { f: 0.58, len: 15, mode: 'R' }, { f: 0.88, len: 16, mode: 'L' }], ramps: [{ f: 0.10 }, { f: 0.22 }, { f: 0.42 }, { f: 0.50 }, { f: 0.72 }, { f: 0.94 }],
        rock: 3, ice: 8, snowman: 5, seal: 2, ball: 2, gates: 3, rows: 12, pads: 6, crystals: 8, air: 8 },
      xmas: true, hills: 26, trees: 300, seed: 257
    }
  ];

  var COLS = 13; // columnas de la calzada (2 m c/u con W=26)

  /* ---------- construccion ---------- */
  PG.buildTrack = function (def, opts) {
    opts = opts || {};
    var T = { def: def, id: def.id, name: def.name, type: def.type, theme: PG.THEMES[def.theme], themeName: def.theme };
    T.W = 26; T.cols = COLS;
    T.laps = def.type === 'circuit' ? 3 : 1;
    var path = def.path(), dense = path.pts, closed = path.closed;
    T.closed = closed;
    T.cornerIdx = path.corners || null;

    // longitud acumulada
    var cum = [0], k, i;
    for (k = 1; k < dense.length; k++) {
      var a = dense[k - 1], b = dense[k];
      cum.push(cum[k - 1] + Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]));
    }
    var total = cum[cum.length - 1];
    if (closed) {
      var l0 = dense[dense.length - 1], f0 = dense[0];
      total += Math.hypot(f0[0] - l0[0], f0[1] - l0[1], f0[2] - l0[2]);
    }
    T.cornerS = (path.corners || []).map(function (ci) { return cum[ci]; });
    var N = closed ? Math.round(total / 1.5) : Math.floor(total / 1.5);
    var ds = closed ? total / N : 1.5;
    T.N = N; T.ds = ds; T.L = N * ds;
    var px = new Float32Array(N + 1), py = new Float32Array(N + 1), pz = new Float32Array(N + 1);
    var seg = 0, nd = dense.length;
    for (i = 0; i <= N; i++) {
      var s = i * ds;
      while (seg < nd - 1 && cum[seg + 1] < s) seg++;
      var A = dense[seg], B, segLen, sOff = s - cum[seg];
      if (seg < nd - 1) { B = dense[seg + 1]; segLen = cum[seg + 1] - cum[seg]; }
      else { B = dense[0]; segLen = total - cum[seg]; }
      var tt = segLen > 0 ? Math.min(1, sOff / segLen) : 0;
      px[i] = A[0] + (B[0] - A[0]) * tt; py[i] = A[1] + (B[1] - A[1]) * tt; pz[i] = A[2] + (B[2] - A[2]) * tt;
    }
    if (closed) { px[N] = px[0]; py[N] = py[0]; pz[N] = pz[0]; }
    // tangentes
    var tx = new Float32Array(N + 1), tz = new Float32Array(N + 1), sl = new Float32Array(N + 1), rx = new Float32Array(N + 1), rz = new Float32Array(N + 1);
    function idx(j) { if (closed) { j = ((j % N) + N) % N; return j; } return j < 0 ? 0 : (j > N ? N : j); }
    for (i = 0; i <= N; i++) {
      var ia = idx(i - 1), ib = idx(i + 1);
      var dx = px[ib] - px[ia], dy = py[ib] - py[ia], dz = pz[ib] - pz[ia];
      var l3 = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1, lh = Math.sqrt(dx * dx + dz * dz) || 1;
      tx[i] = dx / lh; tz[i] = dz / lh; sl[i] = dy / l3;
      rx[i] = -tz[i]; rz[i] = tx[i];
    }
    // curvatura (positiva = giro a la derecha)
    var yaw = new Float32Array(N + 1), cv = new Float32Array(N + 1), ya = Math.atan2(tx[0], tz[0]);
    for (i = 0; i <= N; i++) { var yy = Math.atan2(tx[i], tz[i]); ya += PG.angDiff(ya, yy); yaw[i] = ya; }
    var cv0 = new Float32Array(N + 1);
    for (i = 0; i <= N; i++) { var i1 = idx(i - 3), i2 = idx(i + 3); var dyaw = (closed ? PG.angDiff(Math.atan2(tx[i1], tz[i1]), Math.atan2(tx[i2], tz[i2])) : yaw[i2] - yaw[i1]); cv0[i] = -dyaw / (6 * ds); }
    for (i = 0; i <= N; i++) { var sum = 0, c = 0; for (var q = -3; q <= 3; q++) { sum += cv0[idx(i + q)]; c++; } cv[i] = sum / c; }
    T.px = px; T.py = py; T.pz = pz; T.tx = tx; T.tz = tz; T.sl = sl; T.rx = rx; T.rz = rz; T.cv = cv; T.yawArr = yaw;

    // coordenadas de carrera
    if (T.type === 'circuit') { T.startS = 0; T.D = T.L * T.laps; T.finishS = 0; }
    else { T.startS = 40; T.finishS = T.L - 70; T.D = T.finishS - T.startS; }

    T.wrapS = function (s) { if (T.closed) { s = s % T.L; if (s < 0) s += T.L; return s; } return s < 0 ? 0 : (s > T.L - 0.01 ? T.L - 0.01 : s); };
    T.uToS = function (u) { return T.type === 'circuit' ? T.wrapS(u) : T.wrapS(u + T.startS); };
    // diferencia con signo (b - a) respetando el cierre del circuito
    T.dS = function (a, b) {
      var d = b - a;
      if (T.closed) { if (d > T.L / 2) d -= T.L; else if (d < -T.L / 2) d += T.L; }
      return d;
    };
    var Q = { x: 0, y: 0, z: 0, tx: 0, tz: 1, rx: -1, rz: 0, sl: 0, cv: 0, yaw: 0, i: 0, f: 0 };
    T.branches = [];
    // br efectivo: un ramal solo existe entre su s0 y su s1; fuera de ahi se usa la pista principal
    T.eff = function (s, br) { if (!br) return 0; var B = T.branches[br - 1]; return (B && s >= B.s0 && s <= B.s1) ? br : 0; };
    T.hwOf = function (br) { return br ? T.branches[br - 1].W / 2 : T.W / 2; };
    T.kkOf = function (br) { return br ? T.branches[br - 1].kk : 1; };
    T.q = function (s, br) { // interpolacion del centro de la pista (o de un ramal)
      s = T.wrapS(s);
      if (br) { var B = T.branches[br - 1]; if (B && s >= B.s0 && s <= B.s1) return qBranch(B, s); }
      var fi = s / ds, i0 = Math.floor(fi), f = fi - i0;
      if (i0 >= N) { i0 = N - 1; f = 1; }
      var i1 = i0 + 1;
      Q.i = i0; Q.f = f;
      Q.x = px[i0] + (px[i1] - px[i0]) * f; Q.y = py[i0] + (py[i1] - py[i0]) * f; Q.z = pz[i0] + (pz[i1] - pz[i0]) * f;
      Q.tx = tx[i0] + (tx[i1] - tx[i0]) * f; Q.tz = tz[i0] + (tz[i1] - tz[i0]) * f;
      var tl = Math.sqrt(Q.tx * Q.tx + Q.tz * Q.tz) || 1; Q.tx /= tl; Q.tz /= tl;
      Q.rx = -Q.tz; Q.rz = Q.tx;
      Q.sl = sl[i0] + (sl[i1] - sl[i0]) * f; Q.cv = cv[i0] + (cv[i1] - cv[i0]) * f;
      Q.yaw = Math.atan2(Q.tx, Q.tz);
      return Q;
    };
    function qBranch(B, s) {
      var fi = (s - B.s0) / ds, i0 = Math.floor(fi), f = fi - i0;
      if (i0 >= B.Nb) { i0 = B.Nb - 1; f = 1; }
      var i1 = i0 + 1;
      Q.i = B.i0 + i0; Q.f = f;
      Q.x = B.px[i0] + (B.px[i1] - B.px[i0]) * f; Q.y = B.py[i0] + (B.py[i1] - B.py[i0]) * f; Q.z = B.pz[i0] + (B.pz[i1] - B.pz[i0]) * f;
      Q.tx = B.tx[i0] + (B.tx[i1] - B.tx[i0]) * f; Q.tz = B.tz[i0] + (B.tz[i1] - B.tz[i0]) * f;
      var tl = Math.sqrt(Q.tx * Q.tx + Q.tz * Q.tz) || 1; Q.tx /= tl; Q.tz /= tl;
      Q.rx = -Q.tz; Q.rz = Q.tx;
      Q.sl = B.sl[i0] + (B.sl[i1] - B.sl[i0]) * f; Q.cv = B.cv[i0] + (B.cv[i1] - B.cv[i0]) * f;
      Q.yaw = Math.atan2(Q.tx, Q.tz);
      return Q;
    }

    buildBranches(T, def);

    // ------ caracteristicas ------
    T.ramps = []; T.holes = []; T.obs = []; T.boxes = []; T.pads = []; T.crys = []; T.busy = [];
    genFeatures(T, def, closed);

    // altura del suelo (o -1e9 si hay hueco)
    T.NOGROUND = -1e9;
    T.inHole = function (s, d, br) {
      br = br || 0;
      for (var h = 0; h < T.holes.length; h++) {
        var H = T.holes[h];
        if ((H.br || 0) === br && s >= H.s0 && s < H.s1 && d >= H.d0 && d < H.d1) return H;
      }
      return null;
    };
    T.ground = function (s, d, br) {
      s = T.wrapS(s); br = T.eff(s, br);
      if (T.inHole(s, d, br)) return T.NOGROUND;
      var y, fi, i0;
      if (br) { var B = T.branches[br - 1]; fi = (s - B.s0) / ds; i0 = Math.min(B.Nb - 1, Math.floor(fi)); y = B.py[i0] + (B.py[i0 + 1] - B.py[i0]) * (fi - i0); }
      else { fi = s / ds; i0 = Math.floor(fi); if (i0 >= N) i0 = N - 1; y = py[i0] + (py[i0 + 1] - py[i0]) * (fi - i0); }
      for (var r = 0; r < T.ramps.length; r++) {
        var R = T.ramps[r];
        if ((R.br || 0) === br && s >= R.s0 && s < R.s0 + R.len && d >= R.d0 && d <= R.d1) y += R.h * (s - R.s0) / R.len;
      }
      if (!br && T.caves.length) y += T.bankAt(s, d);
      if (!br && T.lake && s >= T.lake.s0 && s <= T.lake.s1 && y < T.lake.y) y = T.lake.y; // en la laguna la superficie del agua hace de suelo (se flota)
      return y;
    };
    // altura del centro sin rampas (referencia)
    T.centerY = function (s, br) {
      s = T.wrapS(s); br = T.eff(s, br);
      if (br) { var B = T.branches[br - 1], fb = (s - B.s0) / ds, ib = Math.min(B.Nb - 1, Math.floor(fb)); return B.py[ib] + (B.py[ib + 1] - B.py[ib]) * (fb - ib); }
      var fi = s / ds, i0 = Math.floor(fi); if (i0 >= N) i0 = N - 1; return py[i0] + (py[i0 + 1] - py[i0]) * (fi - i0);
    };
    T.worldPos = function (s, d, out, br) { var q = T.q(s, br); out[0] = q.x + q.rx * d; out[2] = q.z + q.rz * d; return out; };

    // distancia al centro mas cercano (para terreno y decoracion)
    T.nearest = function (x, z, out) {
      var best = 1e18, bi = 0, step = 8, j;
      for (j = 0; j <= N; j += step) { var ddx = px[j] - x, ddz = pz[j] - z, dd = ddx * ddx + ddz * ddz; if (dd < best) { best = dd; bi = j; } }
      var lo = bi - step, hi = bi + step; best = 1e18;
      var bj = bi;
      for (j = lo; j <= hi; j++) {
        var jj = closed ? ((j % N) + N) % N : Math.max(0, Math.min(N, j));
        var ex = px[jj] - x, ez = pz[jj] - z, ee = ex * ex + ez * ez;
        if (ee < best) { best = ee; bj = jj; }
      }
      out.i = bj; out.dist = Math.sqrt(best); out.y = py[bj]; out.br = 0;
      for (var bq = 0; bq < T.branches.length; bq++) { // los ramales tambien cuentan como pista (terreno, arboles, etc.)
        var BB = T.branches[bq], bd = 1e18, bk = 0;
        for (j = 0; j <= BB.Nb; j += 2) { var qx = BB.px[j] - x, qz = BB.pz[j] - z, qd = qx * qx + qz * qz; if (qd < bd) { bd = qd; bk = j; } }
        if (bd < best) { best = bd; out.dist = Math.sqrt(bd); out.i = BB.i0 + bk; out.y = BB.py[bk]; out.br = bq + 1; }
      }
      return out;
    };
    // v3.7: altura mezclada del suelo cerca de varias calzadas (pista y atajos): evita escalones/acantilados en el terreno entre dos caminos a distinta altura
    T.blendY = function (x, z) {
      var sw = 0, sy = 0, j, best, bk, w, d;
      function add(dist, y, hwR) { w = 1 / Math.pow(Math.max(0, dist - hwR) + 7, 2.2); sw += w; sy += w * y; }
      best = 1e18; bk = 0; for (j = 0; j <= N; j += 3) { var ddx = px[j] - x, ddz = pz[j] - z, dd = ddx * ddx + ddz * ddz; if (dd < best) { best = dd; bk = j; } }
      add(Math.sqrt(best), py[bk], T.W / 2);
      for (var bq = 0; bq < T.branches.length; bq++) {
        var BB = T.branches[bq]; best = 1e18; bk = 0;
        for (j = 0; j <= BB.Nb; j += 2) { var qx = BB.px[j] - x, qz = BB.pz[j] - z, qd = qx * qx + qz * qz; if (qd < best) { best = qd; bk = j; } }
        add(Math.sqrt(best), BB.py[bk], BB.W / 2);
      }
      return sy / sw;
    };
    T.bbox = (function () {
      var x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
      for (var j = 0; j <= N; j++) { if (px[j] < x0) x0 = px[j]; if (px[j] > x1) x1 = px[j]; if (pz[j] < z0) z0 = pz[j]; if (pz[j] > z1) z1 = pz[j]; }
      return { x0: x0, x1: x1, z0: z0, z1: z1 };
    })();

    // miniatura 2D normalizada
    T.thumb = (function () {
      var b = T.bbox, w = b.x1 - b.x0, h = b.z1 - b.z0, sc = 1 / Math.max(w, h), out = [];
      for (var j = 0; j <= N; j += 6) out.push([(px[j] - b.x0) * sc, (pz[j] - b.z0) * sc]);
      var brs = T.branches.map(function (B) { var o2 = []; for (var jb = 0; jb <= B.Nb; jb += 3) o2.push([(B.px[jb] - b.x0) * sc, (B.pz[jb] - b.z0) * sc]); return o2; });
      return { pts: out, w: w * sc, h: h * sc, sc: sc, br: brs };
    })();

    if (!opts.noMesh && PG.buildTrackMesh) PG.buildTrackMesh(T);
    return T;
  };

  /* ---------- atajos (ramales) ----------
     Un ramal es un camino aparte (su propia curva en el mundo) que sale de la pista en s0, corta una curva cerrada y vuelve a unirse en s1.
     Se indexa con las mismas filas y la misma coordenada s que la pista principal, pero es mas corto (kk = largo principal / largo del ramal):
     quien lo toma avanza mas "s" por metro recorrido, asi que la clasificacion se calcula igual para todos. */
  function buildBranches(T, def) {
    T.branches = [];
    var cuts = (def.cuts || []).slice();
    if (def.castle) { // v4.3: castillo (A->B): dos caminos laterales (mazmorra a la izquierda, murallas a la derecha) ademas del salon central
      var CS = def.castle; cuts.push({ mt: 1, at: 1, sgn: -1, f: 0, ramp: CS.hall, off: CS.off, W: CS.W, castle: 'dungeon', pAI: 0.3 }); cuts.push({ mt: 1, at: 1, sgn: 1, f: 0, ramp: CS.hall, off: CS.off, W: CS.W, castle: 'walls', pAI: 0.3 });
    }
    if (!cuts.length || ((!T.cornerS || !T.cornerS.length) && !def.castle)) return;
    var ds = T.ds, ci, k, j, i;
    function snapS(s) { return Math.round(s / ds) * ds; }
    var cp = function (q) { return { x: q.x, y: q.y, z: q.z, yaw: q.yaw, sl: q.sl }; };
    for (ci = 0; ci < cuts.length; ci++) {
      var c = cuts[ci], apex, s0, s1;
      if (c.mt) { var scMt = c.at ? snapS(T.startS + def.castle.f * T.D) : snapS((T.cornerS[def.mountain.c0] + T.cornerS[def.mountain.c1]) / 2); if (c.at) { var csB = def.castle; s0 = snapS(scMt - csB.len / 2 + csB.corr); s1 = snapS(scMt + csB.len / 2 - csB.exit); } else { s0 = snapS(scMt - c.f); s1 = snapS(scMt + c.f); } }
      else { if (!T.cornerS || T.cornerS[c.c] === undefined) continue; apex = T.cornerS[c.c]; s0 = snapS(apex - c.a); s1 = snapS(apex + c.b); }
      var A = cp(T.q(s0)), B = cp(T.q(s1)), dYaw = PG.angDiff(A.yaw, B.yaw), side = c.mt ? c.sgn : (dYaw < 0 ? 1 : -1), half = Math.abs(dYaw) / 2;
      var ang0 = half * (c.e === undefined ? 0.85 : c.e), ang1 = ang0;
      var y0 = A.yaw - side * ang0, y1 = B.yaw + side * ang1;
      var chord = Math.hypot(B.x - A.x, B.z - A.z), m0 = chord * (c.k === undefined ? 0.5 : c.k), m1 = m0;
      var d0x = Math.sin(y0), d0z = Math.cos(y0), d1x = Math.sin(y1), d1z = Math.cos(y1);
      var sA = A.sl / Math.sqrt(Math.max(0.05, 1 - A.sl * A.sl)), sB = B.sl / Math.sqrt(Math.max(0.05, 1 - B.sl * B.sl));
      var M = 600, fx = [], fy = [], fz = [], cumB = [0];
      for (k = 0; k <= M; k++) {
        var t = k / M, t2 = t * t, t3 = t2 * t, h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
        if (c.mt) { // ruta lateral: la pista principal desplazada hacia un lado con una transicion suave (coseno) al separarse y al volver a unirse
          var smt = s0 + (s1 - s0) * t, qmt = T.q(smt), xm = Math.min(1, (smt - s0) / c.ramp, (s1 - smt) / c.ramp), lat = c.sgn * c.off * 0.5 * (1 - Math.cos(Math.PI * xm));
          fx.push(qmt.x + qmt.rx * lat); fz.push(qmt.z + qmt.rz * lat); fy.push(qmt.y);
        } else {
          fx.push(h00 * A.x + h10 * m0 * d0x + h01 * B.x + h11 * m1 * d1x);
          fz.push(h00 * A.z + h10 * m0 * d0z + h01 * B.z + h11 * m1 * d1z);
          fy.push(h00 * A.y + h10 * m0 * sA + h01 * B.y + h11 * m1 * sB);
        }
        if (k) cumB.push(cumB[k - 1] + Math.hypot(fx[k] - fx[k - 1], fy[k] - fy[k - 1], fz[k] - fz[k - 1]));
      }
      var Lb = cumB[M], Nb = Math.round((s1 - s0) / ds);
      var Br = { id: ci + 1, c: c, s0: s0, s1: s1, i0: Math.round(s0 / ds), Nb: Nb, W: c.W || 18, side: side, L: Lb, kk: (s1 - s0) / Lb, dsB: Lb / Nb,
        px: new Float32Array(Nb + 1), py: new Float32Array(Nb + 1), pz: new Float32Array(Nb + 1),
        tx: new Float32Array(Nb + 1), tz: new Float32Array(Nb + 1), rx: new Float32Array(Nb + 1), rz: new Float32Array(Nb + 1), sl: new Float32Array(Nb + 1), cv: new Float32Array(Nb + 1) };
      var seg = 0;
      for (i = 0; i <= Nb; i++) {
        var sv = Lb * i / Nb; while (seg < M - 1 && cumB[seg + 1] < sv) seg++;
        var tt = (sv - cumB[seg]) / ((cumB[seg + 1] - cumB[seg]) || 1);
        Br.px[i] = fx[seg] + (fx[seg + 1] - fx[seg]) * tt; Br.py[i] = fy[seg] + (fy[seg + 1] - fy[seg]) * tt; Br.pz[i] = fz[seg] + (fz[seg + 1] - fz[seg]) * tt;
      }
      // altura: mientras el ramal y la pista se solapan, el ramal queda a la misma altura (sin escalones ni 'paredes' al cruzar de uno a otro)
      var mj0 = Math.round(s0 / ds) - 8, mj1 = Math.round(s0 / ds) + Nb + 8;
      for (i = 0; i <= Nb; i++) {
        var bgm = 1e18, bjm = 0;
        for (j = Math.round(s0 / ds) + i - 45; j <= Math.round(s0 / ds) + i + 45; j++) { var jm = T.closed ? ((j % T.N) + T.N) % T.N : Math.max(0, Math.min(T.N, j)), exm = T.px[jm] - Br.px[i], ezm = T.pz[jm] - Br.pz[i], eem = exm * exm + ezm * ezm; if (eem < bgm) { bgm = eem; bjm = jm; } }
        var wB = PG.smooth(T.W / 2 + Br.W / 2, T.W / 2 + Br.W / 2 + 22, Math.sqrt(bgm));
        Br.py[i] = T.py[bjm] + (Br.py[i] - T.py[bjm]) * wB * 0.0; // v3.7: el atajo sigue el perfil de altura de la pista (sin caminos elevados ni colgados)
        Br.pyRaw = Br.pyRaw || new Float32Array(Nb + 1); Br.pyRaw[i] = Br.py[i];
        // v3.9: altura EXACTA de la pista principal bajo este punto (interpolada entre filas) y holgura entre bordes de calzada
        Br.mainY = Br.mainY || new Float32Array(Nb + 1); Br.clr = Br.clr || new Float32Array(Nb + 1);
        var tq9 = ((Br.px[i] - T.px[bjm]) * T.tx[bjm] + (Br.pz[i] - T.pz[bjm]) * T.tz[bjm]) / T.ds, jn9 = bjm + (tq9 > 0 ? 1 : -1);
        jn9 = T.closed ? ((jn9 % T.N) + T.N) % T.N : Math.max(0, Math.min(T.N, jn9));
        Br.mainY[i] = T.py[bjm] + (T.py[jn9] - T.py[bjm]) * Math.min(1, Math.abs(tq9));
        Br.clr[i] = Math.sqrt(bgm) - T.W / 2 - Br.W / 2;
        if (false && c.lift) Br.py[i] += c.lift * PG.smooth(T.W / 2 + Br.W / 2 + 12, T.W / 2 + Br.W / 2 + 46, Math.sqrt(bgm)); // v3.2: camino elevado: el atajo sube y vuelve a bajar (suave, sin escalones)
      }
      for (i = 0; i <= Nb; i++) { var sm4 = 0, cn4 = 0; for (var q4 = -5; q4 <= 5; q4++) { var i4 = Math.max(0, Math.min(Nb, i + q4)); sm4 += Br.pyRaw[i4]; cn4++; } Br.py[i] = (i < 3 || i > Nb - 3) ? Br.pyRaw[i] : sm4 / cn4; }
      // v3.9: pegado a la pista (holgura < 2 m) el atajo usa exactamente su altura; se despega suavemente hasta los 10 m (sin laminas flotantes encima de la calzada)
      for (i = 0; i <= Nb; i++) { var wMain = 1 - PG.smooth(2, 10, Br.clr[i]); Br.py[i] = Br.py[i] + (Br.mainY[i] - Br.py[i]) * wMain; }
      var yawB = new Float32Array(Nb + 1), ya = 0;
      for (i = 0; i <= Nb; i++) {
        var ia = Math.max(0, i - 1), ib = Math.min(Nb, i + 1), dx = Br.px[ib] - Br.px[ia], dy = Br.py[ib] - Br.py[ia], dz = Br.pz[ib] - Br.pz[ia];
        var l3 = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1, lh = Math.sqrt(dx * dx + dz * dz) || 1;
        Br.tx[i] = dx / lh; Br.tz[i] = dz / lh; Br.sl[i] = dy / l3; Br.rx[i] = -Br.tz[i]; Br.rz[i] = Br.tx[i];
        var yy = Math.atan2(Br.tx[i], Br.tz[i]); if (i === 0) ya = yy; else ya += PG.angDiff(ya, yy); yawB[i] = ya;
      }
      var cv0 = new Float32Array(Nb + 1);
      for (i = 0; i <= Nb; i++) { var i1 = Math.max(0, i - 3), i2 = Math.min(Nb, i + 3); cv0[i] = -(yawB[i2] - yawB[i1]) / (Math.max(1, i2 - i1) * Br.dsB); }
      for (i = 0; i <= Nb; i++) { var sm = 0, cn = 0; for (var qq = -3; qq <= 3; qq++) { var ix = Math.max(0, Math.min(Nb, i + qq)); sm += cv0[ix]; cn++; } Br.cv[i] = sm / cn; }
      // separacion con la pista principal (para saber donde se solapan: sin vallas ni bermas hasta separarse)
      var gap = new Float32Array(Nb + 1), mi0 = Br.i0 - 6, mi1 = Br.i0 + Nb + 6;
      for (i = 0; i <= Nb; i++) {
        var bg = 1e18;
        for (j = mi0; j <= mi1; j++) { var jj = T.closed ? ((j % T.N) + T.N) % T.N : Math.max(0, Math.min(T.N, j)), ex = T.px[jj] - Br.px[i], ez = T.pz[jj] - Br.pz[i], ee = ex * ex + ez * ez; if (ee < bg) bg = ee; }
        gap[i] = Math.sqrt(bg);
      }
      Br.gap = gap;
      var CLR = T.W / 2 + Br.W / 2 + 6;
      Br.j0 = 0; while (Br.j0 < Nb && gap[Br.j0] < CLR) Br.j0++;           // primera fila ya separada
      Br.j1 = Nb; while (Br.j1 > 0 && gap[Br.j1] < CLR) Br.j1--;           // ultima fila aun separada
      Br.minGap = 1e9; for (i = Br.j0; i <= Br.j1; i++) if (gap[i] < Br.minGap) Br.minGap = gap[i];
      T.branches.push(Br);
    }
  }

  /* ---------- colocacion de caracteristicas ---------- */
  function genFeatures(T, def, closed) {
    var A = def.auto, rnd = PG.rng(def.seed * 7919 + 13), W = T.W, ds = T.ds;
    function fs(f) { return T.type === 'circuit' ? f * T.L : T.startS + f * T.D; }
    function snap(s) { return Math.round(s / ds) * ds; }
    function busy(s0, s1, pad) { T.busy.push([s0 - pad, s1 + pad]); }
    function isBusy(s, pad) {
      pad = pad || 0;
      for (var i = 0; i < T.busy.length; i++) if (s > T.busy[i][0] - pad && s < T.busy[i][1] + pad) return true;
      return false;
    }
    // cuadricula de salida/meta ocupada
    if (T.type === 'circuit') busy(-40, 40, 0), busy(T.L - 50, T.L + 5, 0);
    else busy(0, T.startS + 45, 0), busy(T.finishS - 20, T.L, 0);

    var j, n;
    // zonas de bifurcacion y reunion de los atajos: sin objetos de la pista principal
    T.branches.forEach(function (B) {
      busy(B.s0 - 70, B.s0 + B.j0 * ds + 14, 0);
      busy(B.s0 + B.j1 * ds - 14, B.s1 + 24, 0);
    });
    // cuevas (rangos de s donde la pista pasa por un tunel de roca)
    T.caves = [];
    for (j = 0; j < (def.caves || []).length; j++) T.caves.push({ s0: snap(fs(def.caves[j].f0)), s1: snap(fs(def.caves[j].f1)) });
    // v4.3: barco naufragado (tunel de madera) y castillo congelado (salon central): cuevas con estilo propio
    T.ship = null; T.shipA = null; T.castle = null; T.climb = null;
    (def.ships || []).forEach(function (Sh) {
      if (!T.cornerS || T.cornerS.length <= Sh.c1) return;
      var scS = snap((T.cornerS[Sh.c0] + T.cornerS[Sh.c1]) / 2), hlS = snap(Sh.len / 2);
      T.caves.push({ s0: scS - hlS, s1: scS + hlS, style: Sh.k === 'side' ? 'shipA' : 'ship', H: Sh.k === 'side' ? 22 : 23, ic: 0.3 });
      var rec = { s0: scS - hlS, s1: scS + hlS, sc: scS, hl: hlS, k: Sh.k };
      if (Sh.k === 'side') T.shipA = rec; else T.ship = rec;
      busy(scS - hlS - (Sh.k === 'side' ? 60 : 45), scS + hlS + (Sh.k === 'side' ? 60 : 45), 0);
    });
    if (def.climb && T.cornerS && T.cornerS.length > def.climb.c1) { // barco enterrado: ascenso por la cubierta + rampa + hueco + descenso hasta la pista normal
      var Cl = def.climb, scCl = snap((T.cornerS[Cl.c0] + T.cornerS[Cl.c1]) / 2 + (Cl.off || 0)), lipCl = snap(scCl + Cl.lip), glen = Math.round(Cl.gap * 0.88 / ds) * ds, rlC = Math.round(9 / ds) * ds;
      var holeC = { s0: lipCl, s1: lipCl + glen, d0: -13, d1: 13, mode: 'full' };
      T.holes.push(holeC); T.ramps.push({ s0: lipCl - rlC, len: rlC, h: 2.5, d0: -13, d1: 13, jump: true });
      T.climb = { sc: scCl, s0: snap(scCl + Cl.rs - 10), sUp: snap(scCl + Cl.rs + Cl.up), lip: lipCl, s1: lipCl + glen, sEnd: snap(lipCl + Cl.down + 6), H: Cl.H, hole: holeC, rs: scCl + Cl.rs, up: Cl.up, down: Cl.down, gap: glen };
      T.climbAt = function (s) { return PG.climbBump(s - scCl, Cl); };
      busy(T.climb.s0 - 25, T.climb.sEnd + 10, 0);
    }
    if (def.castle) {
      var Cs = def.castle, scC = snap(fs(Cs.f)), hlC = snap(Cs.len / 2);
      T.caves.push({ s0: scC - hlC, s1: scC + hlC, style: 'castle', H: 19, ic: 0 });
      T.castle = { s0: scC - hlC, s1: scC + hlC, sc: scC, hl: hlC, off: Cs.off, W: Cs.W };
      var Cc = T.castle, hwM = T.W / 2; Cc.g0 = Cc.s0 + Cs.corr; Cc.g1 = Cc.g0 + Cs.hall; Cc.m1 = Cc.s1 - Cs.exit; Cc.m0 = Cc.m1 - Cs.hall;
      // v4.5: una sola entrada -> pasillo largo (solo pista principal) -> salon 1 donde la calzada se abre en 3 caminos -> pantalla con 3 puertas (g1)
      // -> tres tuneles (curvas) -> pantalla con 3 puertas (m0) -> salon 2 donde se reunen -> pasillo corto -> una sola salida
      function smC(a, b, x) { x = Math.max(0, Math.min(1, (x - a) / (b - a))); return x * x * (3 - 2 * x); }
      Cc.inHall = function (s) { return (s >= Cc.g0 && s <= Cc.g1) || (s >= Cc.m0 && s <= Cc.m1); };
      // fraccion de apertura lateral (0 en el pasillo, 1 en la pantalla); es la misma curva (coseno) con la que se separan los ramales
      Cc.fl = function (s) { if (s <= Cc.g0 || s >= Cc.m1) return 0; if (s < Cc.g1) return 0.5 * (1 - Math.cos(Math.PI * (s - Cc.g0) / Cs.hall)); if (s <= Cc.m0) return 1; return 0.5 * (1 + Math.cos(Math.PI * (s - Cc.m0) / Cs.hall)); };
      Cc.tubeW = function (s, hw0) { return Cc.inHall(s) ? Math.max(hw0, Cc.fl(s) * Cs.off + Cs.W / 2 + 1.5) : hw0; };
      Cc.wallW = function (s, hw0) { var nar = hw0 + 12, wid = Cs.off + Cs.W / 2 + 8; return nar + (wid - nar) * Cc.fl(s); };
      Cc.bump = function (s) { return Cc.inHall(s) ? 6 * Cc.fl(s) : 0; }; // el techo del salon es mas alto
      Cc.hallK = function (s) { // 1 dentro de los salones (sin pared curva en la calzada principal para poder pasar a los otros caminos), 0 en pasillos y tuneles
        var k1 = smC(Cc.g0 - 10, Cc.g0 + 22, s) * (1 - smC(Cc.g1, Cc.g1 + 14, s)), k2 = smC(Cc.m0 - 14, Cc.m0, s) * (1 - smC(Cc.m1 - 22, Cc.m1 + 10, s));
        return Math.max(k1, k2);
      };
      busy(scC - hlC - 70, scC + hlC + 70, 0);
    }
    T.caveStyle = function (s, br) {
      var q;
      if (br) { for (q = 0; q < T.bcaves.length; q++) if (T.bcaves[q].br === br && s >= T.bcaves[q].s0 && s <= T.bcaves[q].s1) return T.bcaves[q].style || 'rock'; return null; }
      for (q = 0; q < T.caves.length; q++) if (s >= T.caves[q].s0 && s <= T.caves[q].s1) return T.caves[q].style || 'rock';
      return null;
    };
    // v2.7: montana con un volcan dentro. La pista la cruza por el medio de un tramo recto: tunel, gran camara con el volcan y otro tunel
    T.hall = null; T.volcano = null; T.bcaves = [];
    if (def.mountain && T.cornerS && T.cornerS.length > def.mountain.c1) {
      var Mn = def.mountain, scM = snap((T.cornerS[Mn.c0] + T.cornerS[Mn.c1]) / 2), rowM = Math.round(scM / ds), hh2 = snap(Mn.hall), tn2 = snap(Mn.tun);
      T.caves.push({ s0: scM - tn2, s1: scM - hh2, tun: 1 });
      T.caves.push({ s0: scM + hh2, s1: scM + tn2, tun: 1 });
      T.hall = { s0: scM - hh2, s1: scM + hh2, sc: scM };
      T.volcano = { x: T.px[rowM], z: T.pz[rowM], ax: T.tx[rowM], az: T.tz[rowM], y: T.py[rowM] + 3.5, sc: scM, R: Mn.Rb, H: Mn.H, rc: 0.15, p: 0.8, hall: hh2, tun: tn2 };
      busy(scM - hh2 - 12, scM + hh2 + 12, 0);
      // tuneles de los caminos laterales: desde que el ramal esta a menos de (Rb + 26) m del centro del volcan hasta que sale
      T.bcaves = [];
      T.branches.forEach(function (B) {
        if (!B.c.mt) return;
        var ja = -1, jb = -1, jj;
        for (jj = 0; jj <= B.Nb; jj++) if (Math.hypot(B.px[jj] - T.volcano.x, B.pz[jj] - T.volcano.z) <= Mn.Rb + 26) { if (ja < 0) ja = jj; jb = jj; }
        if (ja >= 0) T.bcaves.push({ br: B.id, s0: B.s0 + ja * ds, s1: B.s0 + jb * ds, j0: ja, j1: jb, tun: 1 });
      });
    }
    if (T.castle) T.branches.forEach(function (B) { // tuneles de los caminos laterales del castillo
      if (!B.c.at) return;
      var ja = Math.round(B.c.ramp / ds), jb = B.Nb - Math.round(B.c.ramp / ds);
      T.bcaves.push({ br: B.id, s0: B.s0 + ja * ds, s1: B.s0 + jb * ds, j0: ja, j1: jb, tun: 0, style: 'castle', H: 17, side: B.c.sgn });
    });
    // v2.7: laguna. La pista se hunde en una cuenca; la superficie del agua es un plano horizontal (T.lake.y) sobre el que se flota y se nada
    T.lake = null; T.lakeDepth = null;
    if (def.lake) {
      var Lk = def.lake, lra = Math.round(fs(Lk.fa) / ds), lrb = Math.round(fs(Lk.fb) / ds), lymin = 1e9, li;
      for (li = lra; li <= lrb; li++) if (T.py[li] < lymin) lymin = T.py[li];
      var lYs = lymin + Lk.D - (Lk.off === undefined ? 0.8 : Lk.off), lIn = null, lOut = null;
      for (li = Math.round(fs(Lk.scan[0]) / ds); li <= Math.round(fs(Lk.scan[1]) / ds); li++) {
        if (T.py[li] < lYs) { if (lIn === null) lIn = li * ds; lOut = li * ds; }
        else if (lIn !== null) break; // solo el primer tramo continuo bajo la superficie
      }
      if (lIn !== null) {
        T.lake = { s0: lIn, s1: lOut, y: lYs };
        busy(lIn - 50, lOut + 50, 0);
        T.lakeDepth = function (s) { if (s < T.lake.s0 || s > T.lake.s1) return 0; var dd = T.lake.y - T.centerY(s); return dd > 0 ? dd : 0; };
      }
    }
    T.inHall = function (s, pad) { var h = T.hall; pad = pad || 0; return !!h && s >= h.s0 - pad && s <= h.s1 + pad; };
    T.inCave = function (s, pad, br) {
      pad = pad || 0;
      if (br) { for (var qb = 0; qb < T.bcaves.length; qb++) if (T.bcaves[qb].br === br && s >= T.bcaves[qb].s0 - pad && s <= T.bcaves[qb].s1 + pad) return true; return false; }
      for (var q = 0; q < T.caves.length; q++) if (s >= T.caves[q].s0 - pad && s <= T.caves[q].s1 + pad) return true;
      return false;
    };
    // geometria de las cuevas: techo (arco elíptico), paredes curvas rodables
    T.caveH = function (i) { // v2.6: cuevas mas altas; v4.3: el barco y el castillo tienen su propia altura
      var s = i * ds, q;
      for (q = 0; q < T.caves.length; q++) if (T.caves[q].H && s >= T.caves[q].s0 - 3 && s <= T.caves[q].s1 + 3) return T.caves[q].H + 0.6 * Math.sin(i * 0.043 + def.seed) + (T.castle && T.caves[q].style === 'castle' ? T.castle.bump(s) : 0);
      for (q = 0; q < T.bcaves.length; q++) if (T.bcaves[q].H && s >= T.bcaves[q].s0 - 3 && s <= T.bcaves[q].s1 + 3) return T.bcaves[q].H + 0.6 * Math.sin(i * 0.043 + def.seed);
      return 32 + 3.2 * Math.sin(i * 0.043 + def.seed);
    };
    T.caveF = function (s, br) { // 0 fuera de la cueva, 1 dentro (con transicion de 12 m en las bocas); los ramales no tienen cuevas
      if (br) return 0;
      for (var q = 0; q < T.caves.length; q++) { var c = T.caves[q]; if (s >= c.s0 && s <= c.s1) return Math.min(1, Math.min(s - c.s0, c.s1 - s) / 12); }
      return 0;
    };
    // v2.9: suelo plano en el centro (hasta 8 m) y pared curva solo en los bordes: acercarte a la orilla ya no te sube por la pared
    T.bankShape = function (d) { var a = Math.abs(d) - 8; return a > 0 ? 0.33 * a * a : 0; };
    T.bankSlope = function (d) { var a = Math.abs(d) - 8; return a > 0 ? 0.66 * a : 0; };
    T.bankF = function (s) { var f = T.caveF(s); return (f > 0 && T.castle) ? f * (1 - T.castle.hallK(s)) : f; }; // v4.5: en los salones del castillo no hay pared curva
    T.bankAt = function (s, d) { var f = T.bankF(s); return f > 0 ? f * T.bankShape(d) : 0; };
    // altura del techo sobre el centro de la pista en (s,d) (Infinity fuera de cuevas)
    T.ceilAt = function (s, d, br) {
      if (br || !T.caves.length || T.caveF(s) <= 0) return 1e9;
      var h = T.caveH(Math.round(s / ds)), x = Math.abs(d) / ((T.castle ? T.castle.tubeW(s, T.W / 2) : T.W / 2) + 0.5); if (x > 0.995) x = 0.995;
      return h * Math.sqrt(1 - x * x);
    };
    // saltos: rampa + hueco
    // altura del centro (la pista aun no expone centerY aqui)
    function cy(s) { s = T.wrapS(s); var fi = s / ds, i0 = Math.floor(fi); if (i0 >= T.N) i0 = T.N - 1; return T.py[i0] + (T.py[i0 + 1] - T.py[i0]) * (fi - i0); }
    // un salto solo es justo si el borde lejano no queda mas alto que el de salida: se desplaza a la zona mas favorable
    function pickLip(lip0, len, maxRise) {
      var span = len / 2 + 60, best = lip0, bestScore = 1e9, k, sg, s2, rise, score;
      for (k = 0; k <= 160; k++) for (sg = (k === 0 ? 1 : -1); sg <= 1; sg += 2) {
        s2 = snap(lip0 + sg * k * ds);
        if (T.type === 'circuit' ? (s2 < 70 || s2 + len > T.L - 80) : (s2 < T.startS + 70 || s2 + len > T.finishS - 50)) continue;
        if (T.inCave(s2, 30) || T.inCave(s2 + len, 30) || isBusy(s2 + len / 2, span)) continue;
        rise = cy(s2 + len) - cy(s2);
        if (rise > maxRise) continue;
        // preferir poca distancia al punto deseado y poca pendiente de subida antes del salto
        score = k * ds + Math.max(0, cy(s2) - cy(s2 - 25)) * 6;
        if (score < bestScore) { bestScore = score; best = s2; }
      }
      return best;
    }
    for (j = 0; j < A.jumps.length; j++) {
      if (A.jumps.length >= 3 && j % 3 === 1) continue; // v3.2: menos huecos (uno de cada tres se quita)
      var J = A.jumps[j], len = Math.max(ds * 2, Math.round(J.len * 0.88 / ds) * ds), lip = pickLip(snap(fs(J.f)), len, J.mode === 'full' ? 0.8 : 0.3);
      var hole = { s0: lip, s1: lip + len, d0: -13, d1: 13, mode: J.mode };
      if (J.mode === 'L') { hole.d0 = -13; hole.d1 = 1; }
      else if (J.mode === 'R') { hole.d0 = -1; hole.d1 = 13; }
      else if (J.mode === 'mid') { hole.d0 = -7; hole.d1 = 7; }
      T.holes.push(hole);
      if (J.mode === 'full') {
        var rl = Math.round(9 / ds) * ds;
        T.ramps.push({ s0: lip - rl, len: rl, h: 2.5, d0: -13, d1: 13, jump: true });
        busy(lip - rl - 40, lip + len + 12, 0);
      } else {
        // rampa opcional del lado libre para saltar por encima
        var rl2 = Math.round(8 / ds) * ds;
        var rd0 = J.mode === 'L' ? 3 : (J.mode === 'R' ? -13 : 9), rd1 = J.mode === 'L' ? 13 : (J.mode === 'R' ? -3 : 13);
        if (J.mode === 'mid') { T.ramps.push({ s0: lip - rl2 - 30, len: rl2, h: 1.6, d0: -13, d1: -9, jump: false }); }
        else T.ramps.push({ s0: lip - rl2 - 30, len: rl2, h: 1.6, d0: rd0, d1: rd1, jump: false });
        busy(lip - rl2 - 55, lip + len + 12, 0);
      }
    }
    // rampas sueltas
    for (j = 0; j < A.ramps.length; j++) {
      var s0 = snap(fs(A.ramps[j].f)), rl3 = Math.round(8 / ds) * ds;
      if (isBusy(s0, 14)) { s0 = snap(s0 + 60); if (isBusy(s0, 14)) continue; }
      T.ramps.push({ s0: s0, len: rl3, h: 2.1, d0: -6, d1: 6, jump: false });
      busy(s0 - 6, s0 + rl3 + 18, 0);
    }
    // pads de impulso
    var tries, placed = 0;
    for (tries = 0; tries < 400 && placed < A.pads; tries++) {
      var sp = snap(fs(0.02 + rnd() * 0.94));
      if (isBusy(sp, 12)) continue;
      var dc = Math.floor((rnd() * 4 - 2)) * 2 + 0; // -4,-2,0,2 -> d0
      T.pads.push({ s: sp, len: 9, d0: dc - 3 + 0, d1: dc + 3 + 0 }); busy(sp - 4, sp + 13, 0); placed++;
    }
    // filas de cajas de objeto
    var nRows = Math.max(5, Math.round(A.rows * 0.6)), nCrys = Math.max(3, Math.round(A.crystals * 0.6)); // v2.4: menos poderes en pista
    for (n = 0; n < nRows; n++) {
      var sr = snap(fs(0.04 + 0.90 * (n + 0.5) / nRows));
      var guard = 0;
      while (isBusy(sr, 10) && guard++ < 30) sr = snap(sr + 8);
      if (guard >= 30) continue;
      var layout = rnd();
      var ds2 = layout < 0.35 ? [-7.5, -2.5, 2.5, 7.5] : (layout < 0.55 ? [-8, -4, 0, 4, 8] : [-6, 0, 6]);
      for (var q2 = 0; q2 < ds2.length; q2++) T.boxes.push({ s: sr, d: ds2[q2], row: n });
      busy(sr - 5, sr + 5, 0);
    }
    // cristales de habilidad
    for (n = 0; n < nCrys; n++) {
      var sc = snap(fs(0.10 + 0.80 * (n + 0.35 + rnd() * 0.3) / nCrys)), g2 = 0;
      while (isBusy(sc, 12) && g2++ < 40) sc = snap(sc + 9);
      T.crys.push({ s: sc, d: (rnd() < 0.5 ? -1 : 1) * (2 + rnd() * 6), got: 0 });
      busy(sc - 6, sc + 6, 0);
    }
    // v3.2.1: poderes sueltos en el techo de las cuevas (solo se alcanzan subiendo por la pared y rodando por el techo)
    T.caves.forEach(function (cv) {
      var len = cv.s1 - cv.s0 - 70; if (len < 50) return;
      var nC = Math.max(2, Math.min(5, Math.floor(len / 55))), dd = [-6, 6, 0, -9, 9];
      for (var qc = 0; qc < nC; qc++) {
        var hs = Math.sin((cv.s0 + qc * 17) * 12.9898 + def.seed * 78.233) * 43758.5453; hs -= Math.floor(hs);
        T.crys.push({ s: snap(cv.s0 + 32 + len * (qc + 0.35 + hs * 0.3) / nC), d: dd[(qc + Math.floor(hs * 5)) % 5], got: 0, ceil: 1 });
      }
    });
    // obstaculos
    function addObs(type, s, d, extra) {
      var def2 = { rock: { r: 1.7, hit: 'rock' }, ice: { r: 1.5, hit: 'ice' }, snowman: { r: 1.2, hit: 'snowman' }, seal: { r: 1.7, hit: 'seal' }, ball: { r: 1.9, hit: 'ball' }, tree: { r: 1.6, hit: 'rock' }, icicle: { r: 1.5, hit: 'ice' }, pend: { r: 2.1, hit: 'ball' }, spike: { r: 1.5, hit: 'spike' }, walker: { r: 1.45, hit: 'walker' } }[type];
      var o = { type: type, s: s, d: d, r: def2.r, hit: def2.hit, mov: (type === 'seal' || type === 'ball' || type === 'pend' || type === 'walker'), yaw: rnd() * TAU, var: rnd() };
      if (extra) for (var kk in extra) o[kk] = extra[kk];
      var stl = T.caveStyle(s, o.br || 0); // v4.3: dentro del barco los obstaculos son cajas y barriles; en el castillo, bloques de piedra
      if ((stl === 'ship' || stl === 'shipA') && (type === 'rock' || type === 'ice')) o.skin = type === 'ice' ? 'barrel' : 'crate';
      else if (stl === 'castle' && (type === 'rock' || type === 'ice')) o.skin = type === 'ice' ? 'iceblk' : 'stone';
      T.obs.push(o); return o;
    }
    function freeObs(s, d, rr) {
      for (var i = 0; i < T.obs.length; i++) { var o = T.obs[i]; if (Math.abs(o.s - s) < 9 && Math.abs(o.d - d) < rr + o.r + 5) return false; }
      return true;
    }
    var GATE_SEP = 60, OBS_SEP = 46;
    // separacion minima entre grupos de obstaculos (en metros de pista) para poder esquivar con calma a alta velocidad
    T.obsS = [];
    function obsSepOK(s, min) { for (var q = 0; q < T.obsS.length; q++) if (Math.abs(T.dS(T.obsS[q], s)) < min) return false; return true; }
    // compuertas: fila de obstaculos con un hueco de paso
    for (n = 0; n < A.gates; n++) {
      var sg = snap(fs(0.07 + 0.84 * (n + 0.5) / A.gates + (rnd() - 0.5) * 0.04)), g3 = 0;
      while ((isBusy(sg, 14) || !obsSepOK(sg, GATE_SEP)) && g3++ < 60) sg = snap(sg + 8);
      if (g3 >= 60) continue;
      var gap = (rnd() * 2 - 1) * 7, typ = def.treeGates ? 'tree' : (rnd() < 0.5 ? 'rock' : 'ice');
      if (T.inCave(sg, 12)) { if (rnd() < 0.9) continue; typ = 'rock'; } // en cuevas: sin arboles ni hielo, rocas muy pocas
      for (var dd = -10.5; dd <= 10.6; dd += 7) { if (Math.abs(dd - gap) < 4.8) continue; addObs(typ, sg, dd); } // separados >= 7 m: siempre hay hueco para esquivar
      busy(sg - 8, sg + 8, 0); T.obsS.push(sg);
    }
    // picos de hielo que caen del techo de las cuevas (filas con un hueco de paso)
    for (j = 0; j < T.caves.length; j++) {
      var cv = (def.caves || [])[j] || { ic: T.caves[j].ic === undefined ? 0.8 : T.caves[j].ic }, dens = (cv.ic === undefined ? 1 : cv.ic) * 0.25; // v2.6: la mitad de picos de hielo
      if (!dens) continue;
      var spacing = 62 / dens;
      for (var si = T.caves[j].s0 + 45; si < T.caves[j].s1 - 30; si += spacing * (0.85 + rnd() * 0.3)) {
        var sIc = snap(si);
        if (isBusy(sIc, 8) && !T.inCave(sIc)) continue;
        var gapIc = (rnd() * 2 - 1) * 6.5, per = 5.2 + rnd() * 2.6, ph = rnd() * per;
        for (var dIc = -9; dIc <= 9.01; dIc += 4.5) {
          if (Math.abs(dIc - gapIc) < 4.6) continue;
          addObs('icicle', sIc, dIc, { per: per, ph: ph + (dIc + 9) * 0.07 });
        }
      }
    }
    var kinds = ['rock', 'ice', 'snowman', 'seal', 'ball', 'tree'];
    for (var kd = 0; kd < kinds.length; kd++) {
      var cnt = A[kinds[kd]] || 0, put = 0;
      if (def.xmas && kinds[kd] === 'seal') cnt = 20; // v4.4: ciudad navideña: pingüinos cargando regalos que cruzan la pista
      for (tries = 0; tries < 600 && put < cnt; tries++) {
        var so = snap(fs(0.03 + rnd() * 0.93)), dobs = (rnd() * 2 - 1) * (W / 2 - 4);
        if (isBusy(so, 16) || !obsSepOK(so, OBS_SEP) || !freeObs(so, dobs, 2)) continue;
        if ((kinds[kd] === 'ball' || kinds[kd] === 'tree' || kinds[kd] === 'ice') && T.inCave(so, 6)) continue;
        if (kinds[kd] === 'rock' && T.inCave(so, 6) && rnd() < 0.95) continue;
        if (kinds[kd] === 'seal' && def.xmas) addObs('walker', so, 0, { amp: W / 2 - 0.4, w: 0.45 + rnd() * 0.25, ph: rnd() * TAU, k: Math.floor(rnd() * 90), gc: Math.floor(rnd() * 5) });
        else if (kinds[kd] === 'seal') addObs('seal', so, 0, { amp: 7 + rnd() * 2, w: 0.9 + rnd() * 0.5, ph: rnd() * TAU });
        else if (kinds[kd] === 'ball') addObs('ball', so, 0, { v: 6 + rnd() * 2, ph: rnd() * 40 });
        else addObs(kinds[kd], so, dobs);
        put++; busy(so - 3, so + 3, 0); T.obsS.push(so);
      }
    }
    // v4.3: poderes flotando: se atrapan saltando desde una rampa (no los recogen los bots)
    var airN = 0, airMax = A.air || 0;
    for (j = 0; j < T.ramps.length && airN < airMax; j++) {
      var RA = T.ramps[j]; if (RA.jump || RA.br) continue;
      var sAir = snap(RA.s0 + RA.len + 11), dAir = (RA.d0 + RA.d1) / 2;
      if (airN % 2 === 0) T.crys.push({ s: sAir, d: dAir, got: 0, air: 3.3 });
      else for (var qa = -1; qa <= 1; qa += 2) T.boxes.push({ s: sAir, d: dAir + qa * 2.6, row: 900 + airN, air: 3.3 });
      airN++;
    }
    // v4.3: contenido del castillo (salon central, mazmorra a la izquierda y murallas a la derecha)
    if (T.castle) (function () {
      var sc = T.castle.sc, kb = 1;
      function pend(s, amp, w, ph, br) { addObs('pend', snap(s), 0, { amp: amp, w: w, ph: ph, br: br || 0 }); }
      function spikes(s, br, hwR, seedK) { // fila de pinchos con dos huecos de paso (periodo comun)
        var per = 3.0 + rnd() * 0.8, ph = rnd() * per, gp = Math.floor(rnd() * 5), n0 = Math.floor(hwR / 3.4), idx = 0;
        for (var d3 = -n0 * 3.4; d3 <= n0 * 3.4 + 0.1; d3 += 3.4, idx++) { if (idx === gp || idx === gp + 1 || (idx === gp + 5 && gp === 0)) continue; addObs('spike', snap(s), d3, { per: per, ph: ph, br: br || 0 }); }
      }
      function blocks(s, br, hwR) { // bloques que caen del techo (como los carambanos pero de piedra), con hueco de paso
        var gp2 = (rnd() * 2 - 1) * 6, per = 5.4 + rnd() * 2, ph = rnd() * per;
        for (var d4 = -hwR + 3; d4 <= hwR - 2.9; d4 += 5.4) { if (Math.abs(d4 - gp2) < 4.9) continue; addObs('icicle', snap(s), d4, { per: per, ph: ph + (d4 + hwR) * 0.05, blk: 1, r: 2.1, br: br || 0 }); }
      }
      function pad(s, br, d0) { T.pads.push({ s: snap(s), len: 9, d0: d0 === undefined ? -4.5 : d0, d1: d0 === undefined ? 4.5 : d0 + 9, br: br || 0 }); }
      function boxrow(s, br, ds3) { ds3.forEach(function (d5) { T.boxes.push({ s: snap(s), d: d5, row: 700 + Math.round(s), br: br || 0 }); }); }
      function ramp(s, hh, d0, d1, br) { var rl4 = Math.round(8 / ds) * ds; T.ramps.push({ s0: snap(s), len: rl4, h: hh, d0: d0, d1: d1, jump: false, br: br || 0 }); return snap(s) + rl4; }
      function air(s, d, br, box) { if (box) { [-2.6, 2.6].forEach(function (q) { T.boxes.push({ s: snap(s), d: d + q, row: 800 + Math.round(s), air: 3.3, br: br || 0 }); }); } else T.crys.push({ s: snap(s), d: d, got: 0, air: 3.3, br: br || 0 }); }
      var CA = T.castle, a0 = CA.s0, g0 = CA.g0, g1 = CA.g1, m0 = CA.m0, m1 = CA.m1, s1c = CA.s1;
      // ---- pasillo de entrada (una sola puerta, solo pista principal): ~200 m de trampas seguidas ----
      pad(a0 + 34, 0); boxrow(a0 + 46, 0, [-7, 0, 7]);
      pend(a0 + 70, 8, 1.6, 0); pend(a0 + 88, 8, 1.6, Math.PI);
      blocks(a0 + 112, 0, 13);
      var e1 = ramp(a0 + 136, 2.2, -6, 6, 0); air(e1 + 11, 0, 0, false);
      spikes(a0 + 164, 0, 12);
      T.crys.push({ s: snap(a0 + 184), d: -5, got: 0 });
      pend(a0 + 200, 8.5, 1.9, 1.0); pend(a0 + 218, 8.5, 1.9, 1.0 + Math.PI);
      blocks(a0 + 240, 0, 13);
      spikes(a0 + 264, 0, 12);
      T.crys.push({ s: snap(g0 - 36), d: 5, got: 0 });
      // ---- salon 1: la calzada se abre en 3 caminos (cian = centro, naranja/magenta = laterales). Sin trampas, solo elegir ----
      boxrow(g0 + 36, 0, [-6, 6]);
      // ---- tres caminos entre las dos pantallas (g1 .. m0): centro = el largo con mas trampas; izquierda = mazmorra; derecha = murallas con grietas ----
      pad(g1 + 14, 0); boxrow(g1 + 28, 0, [-7, 0, 7]);
      pend(g1 + 52, 8, 1.6, 0.5); pend(g1 + 70, 8, 1.6, 0.5 + Math.PI);
      blocks(g1 + 94, 0, 13);
      var e2 = ramp(g1 + 118, 2.2, -6, 6, 0); air(e2 + 11, 0, 0, true);
      spikes(g1 + 146, 0, 12);
      T.crys.push({ s: snap(g1 + 166), d: 5, got: 0 });
      pend(g1 + 182, 8.5, 1.9, 2.0); pend(g1 + 200, 8.5, 1.9, 2.0 + Math.PI);
      blocks(g1 + 224, 0, 13);
      spikes(g1 + 250, 0, 12); pad(m0 - 40, 0);
      T.branches.forEach(function (B) {
        if (!B.c.at) return;
        var hwB = B.W / 2, kk2 = B.kk, id = B.id, q0 = g1;
        if (B.c.castle === 'dungeon') {
          pad(q0 + 14, id); T.crys.push({ s: snap(q0 + 34), d: 0, got: 0, br: id });
          spikes(q0 + 58, id, 9); pend(q0 + 82, 6, 2.1, 0, id); spikes(q0 + 108, id, 9);
          var e3 = ramp(q0 + 132, 2.2, -6, 6, id); air(e3 + 11, 0, id, true);
          pend(q0 + 162, 6, 1.8, 2.0, id); spikes(q0 + 188, id, 9);
          T.crys.push({ s: snap(q0 + 210), d: 3, got: 0, br: id }); blocks(q0 + 232, id, hwB); pad(q0 + 262, id); pend(q0 + 286, 6, 2.0, 0.5, id);
        } else {
          pad(q0 + 14, id); var e4 = ramp(q0 + 32, 2.3, -9, 9, id); air(e4 + 11, 0, id, false);
          var gl2 = Math.round(12.5 * kk2 / ds) * ds, lip2 = snap(q0 + 76), rl5 = Math.round(9 / ds) * ds;
          T.holes.push({ s0: lip2, s1: lip2 + gl2, d0: -hwB - 2, d1: hwB + 2, mode: 'full', br: id }); T.ramps.push({ s0: lip2 - rl5, len: rl5, h: 2.5, d0: -hwB, d1: hwB, jump: true, br: id });
          pad(lip2 + gl2 + 12, id); addObs('ice', snap(q0 + 128), -4, { br: id }); addObs('ice', snap(q0 + 142), 4, { br: id });
          var e5 = ramp(q0 + 162, 2.2, -9, 9, id); air(e5 + 11, 0, id, true);
          var lip3 = snap(q0 + 206); T.holes.push({ s0: lip3, s1: lip3 + gl2, d0: -hwB - 2, d1: hwB + 2, mode: 'full', br: id }); T.ramps.push({ s0: lip3 - rl5, len: rl5, h: 2.5, d0: -hwB, d1: hwB, jump: true, br: id });
          pad(lip3 + gl2 + 12, id); T.crys.push({ s: snap(lip3 + gl2 + 34), d: 0, got: 0, br: id });
          addObs('ice', snap(q0 + 282), -3.6, { br: id }); addObs('ice', snap(q0 + 296), 3.8, { br: id });
        }
      });
      // ---- salon 2 (se reunen) y pasillo corto hasta la unica salida ----
      boxrow(m1 - 30, 0, [-6, 0, 6]);
      pend(m1 + 26, 8, 1.7, 0.7); blocks(m1 + 48, 0, 13);
      T.crys.push({ s: snap(s1c - 14), d: 0, got: 0 });
    })();
    // contenido de los atajos: turbos al entrar y a la mitad, un cristal de habilidad y un salto sobre una grieta (el riesgo)
    T.branches.forEach(function (B) {
      var kk = B.kk, hwB = B.W / 2, sIn = B.s0 + B.j0 * ds + 8 * kk, sEnd = B.s0 + B.j1 * ds, span = sEnd - sIn;
      if (B.c.at) return; // castillo: contenido propio (arriba)
      if (B.c.mt) { // tuneles laterales de la montana: camino largo pero rapido (turbos y cristales, sin grieta)
        var npad = B.c.pads || 3;
        for (var pq = 0; pq < npad; pq++) T.pads.push({ s: snap(sIn + span * (0.04 + 0.9 * pq / npad)), len: 9, d0: -4.5, d1: 4.5, br: B.id });
        T.crys.push({ s: snap(sIn + span * 0.30), d: B.side * 3, got: 0, br: B.id });
        T.crys.push({ s: snap(sIn + span * 0.72), d: -B.side * 3, got: 0, br: B.id });
        addObs('ice', snap(sIn + span * 0.16), -3.8, { br: B.id }); addObs('ice', snap(sIn + span * 0.58), 3.8, { br: B.id });
        return;
      }
      T.pads.push({ s: snap(sIn), len: 9, d0: -4.5, d1: 4.5, br: B.id });
      var gl = Math.round(12.5 * kk / ds) * ds, lip = snap(sIn + span * 0.46), rl = Math.round(9 / ds) * ds;
      // v3.7: el salto sobre la grieta se coloca donde el atajo es mas llano (ahora el atajo sigue el perfil de altura de la pista)
      (function () {
        var bestC = 1e9, bestL = lip, ff, ss, jj, c2, sl2, jA, jB;
        for (ff = 0.28; ff <= 0.68; ff += 0.02) {
          ss = snap(sIn + span * ff); jA = Math.max(0, Math.round((ss - rl - 14 - B.s0) / ds)); jB = Math.min(B.Nb - 1, Math.round((ss + gl + 22 - B.s0) / ds)); c2 = 0;
          for (jj = jA; jj < jB; jj++) { sl2 = (B.py[jj + 1] - B.py[jj]) / ds; c2 = Math.max(c2, Math.abs(sl2) + (sl2 > 0 ? Math.abs(sl2) : 0)); }
          c2 += Math.abs(ff - 0.46) * 0.05;
          if (c2 < bestC) { bestC = c2; bestL = ss; }
        }
        lip = bestL;
      })();
      T.holes.push({ s0: lip, s1: lip + gl, d0: -hwB - 2, d1: hwB + 2, mode: 'full', br: B.id });
      T.ramps.push({ s0: lip - rl, len: rl, h: 2.5, d0: -hwB, d1: hwB, jump: true, br: B.id });
      T.pads.push({ s: snap(lip + gl + 14 * kk), len: 9, d0: -4.5, d1: 4.5, br: B.id });
      T.crys.push({ s: snap(lip + gl + 40 * kk), d: 0, got: 0, br: B.id });
      // dos bloques de hielo antes de la grieta (esquivables)
      addObs('ice', snap(sIn + span * 0.10), -3.6, { br: B.id }); addObs('ice', snap(sIn + span * 0.21), 3.8, { br: B.id });
      B.hole = T.holes[T.holes.length - 1];
    });
    T.obs.sort(function (a, b) { return a.s - b.s; });
  }

  // v4.3: pinchos del castillo: 0 ocultos, 1 aviso (asoman), 2 fuera (hacen dano), 3 se retiran
  PG.spikeState = function (o, t) { var u = (((t + o.ph) % o.per) + o.per) % o.per / o.per; if (u < 0.45) return { ph: 0, f: 0 }; if (u < 0.58) return { ph: 1, f: (u - 0.45) / 0.13 }; if (u < 0.90) return { ph: 2, f: 1 }; return { ph: 3, f: (u - 0.90) / 0.10 }; };
  PG.spikeActive = function (o, t) { var st = PG.spikeState(o, t); return st.ph === 2 || (st.ph === 1 && st.f > 0.6); };
  // posicion de un obstaculo en el instante t (segundos de carrera)
  PG.obsPos = function (T, o, t, out) {
    if (o.type === 'seal' || o.type === 'pend' || o.type === 'walker') { out[0] = o.s; out[1] = o.amp * Math.sin(t * o.w + o.ph); }
    else if (o.type === 'ball') {
      var span = T.W + 8, x = ((t * o.v + o.ph) % span + span) % span;
      out[0] = o.s; out[1] = -T.W / 2 - 4 + x;
    } else { out[0] = o.s; out[1] = o.d; }
    return out;
  };
})();
