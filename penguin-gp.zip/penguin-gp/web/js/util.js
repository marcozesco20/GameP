/* Penguin Slippery - utilidades: matematica, RNG, constructor de mallas low-poly */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var PI = Math.PI;

  PG.clamp = function (x, a, b) { return x < a ? a : (x > b ? b : x); };
  PG.lerp = function (a, b, t) { return a + (b - a) * t; };
  PG.smooth = function (e0, e1, x) {
    var t = (x - e0) / (e1 - e0); t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t);
  };
  PG.angDiff = function (a, b) { // diferencia a->b en [-PI, PI]
    var d = (b - a) % (2 * PI);
    if (d > PI) d -= 2 * PI; else if (d < -PI) d += 2 * PI;
    return d;
  };
  PG.rng = function (seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  };
  PG.hex = function (h) {
    if (typeof h === 'string') h = parseInt(h.replace('#', ''), 16);
    return [(h >> 16 & 255) / 255, (h >> 8 & 255) / 255, (h & 255) / 255];
  };
  PG.shade = function (c, k) { return [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)]; };
  PG.mix3 = function (a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; };

  // ruido de valor 2D suave
  function hash2(ix, iz, seed) {
    var h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263) ^ Math.imul(seed | 0, 1442695041);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }
  PG.noise2 = function (x, z, seed) {
    var ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
    fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz);
    var a = hash2(ix, iz, seed), b = hash2(ix + 1, iz, seed), c = hash2(ix, iz + 1, seed), d = hash2(ix + 1, iz + 1, seed);
    return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fz;
  };
  PG.fbm = function (x, z, seed) {
    return PG.noise2(x, z, seed) * 0.6 + PG.noise2(x * 2.07, z * 2.07, seed + 17) * 0.3 + PG.noise2(x * 4.3, z * 4.3, seed + 31) * 0.1;
  };

  /* ---------- matrices 4x4 (column-major) ---------- */
  var m4 = PG.m4 = {};
  m4.create = function () { var o = new Float32Array(16); o[0] = o[5] = o[10] = o[15] = 1; return o; };
  m4.identity = function (o) { for (var i = 0; i < 16; i++) o[i] = 0; o[0] = o[5] = o[10] = o[15] = 1; return o; };
  m4.mul = function (o, a, b) { // o = a * b
    var a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3], a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7],
      a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11], a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
    for (var j = 0; j < 4; j++) {
      var b0 = b[j * 4], b1 = b[j * 4 + 1], b2 = b[j * 4 + 2], b3 = b[j * 4 + 3];
      o[j * 4] = a00 * b0 + a10 * b1 + a20 * b2 + a30 * b3;
      o[j * 4 + 1] = a01 * b0 + a11 * b1 + a21 * b2 + a31 * b3;
      o[j * 4 + 2] = a02 * b0 + a12 * b1 + a22 * b2 + a32 * b3;
      o[j * 4 + 3] = a03 * b0 + a13 * b1 + a23 * b2 + a33 * b3;
    }
    return o;
  };
  m4.persp = function (o, fovy, aspect, near, far) {
    var f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    for (var i = 0; i < 16; i++) o[i] = 0;
    o[0] = f / aspect; o[5] = f; o[10] = (far + near) * nf; o[11] = -1; o[14] = 2 * far * near * nf;
    return o;
  };
  m4.lookAt = function (o, ex, ey, ez, tx, ty, tz, roll) {
    var zx = ex - tx, zy = ey - ty, zz = ez - tz, l = Math.sqrt(zx * zx + zy * zy + zz * zz) || 1;
    zx /= l; zy /= l; zz /= l;
    var xx = zz, xy = 0, xz = -zx; // up (0,1,0) x z
    l = Math.sqrt(xx * xx + xz * xz) || 1; xx /= l; xz /= l;
    var yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    if (roll) {
      var cr = Math.cos(roll), sr = Math.sin(roll), nxx = xx * cr - yx * sr, nxy = xy * cr - yy * sr, nxz = xz * cr - yz * sr;
      var nyx = yx * cr + xx * sr, nyy = yy * cr + xy * sr, nyz = yz * cr + xz * sr;
      xx = nxx; xy = nxy; xz = nxz; yx = nyx; yy = nyy; yz = nyz;
    }
    o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0;
    o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0;
    o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
    o[12] = -(xx * ex + xy * ey + xz * ez); o[13] = -(yx * ex + yy * ey + yz * ez); o[14] = -(zx * ex + zy * ey + zz * ez); o[15] = 1;
    return o;
  };
  // T * Ry(yaw) * Rx(pitch) * Rz(roll) * S
  m4.trs = function (o, tx, ty, tz, yaw, pitch, roll, sx, sy, sz) {
    var cy = Math.cos(yaw), sy_ = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), cr = Math.cos(roll), sr = Math.sin(roll);
    var a0x = cy, a0y = 0, a0z = -sy_;
    var a1x = sy_ * sp, a1y = cp, a1z = cy * sp;
    var a2x = sy_ * cp, a2y = -sp, a2z = cy * cp;
    o[0] = (cr * a0x + sr * a1x) * sx; o[1] = (cr * a0y + sr * a1y) * sx; o[2] = (cr * a0z + sr * a1z) * sx; o[3] = 0;
    o[4] = (-sr * a0x + cr * a1x) * sy; o[5] = (-sr * a0y + cr * a1y) * sy; o[6] = (-sr * a0z + cr * a1z) * sy; o[7] = 0;
    o[8] = a2x * sz; o[9] = a2y * sz; o[10] = a2z * sz; o[11] = 0;
    o[12] = tx; o[13] = ty; o[14] = tz; o[15] = 1;
    return o;
  };

  /* ---------- constructor de mallas (flat shading, sin indices) ---------- */
  // vertice = 20 bytes: pos f32x3 | normal i8x4 | color u8x4 (a = emisivo)
  var MAXV = 60000;
  function MB() {
    this.chunks = []; this.cur = null; this.m = null; this.stack = [];
    this.ref = null; this.up = false; this.emi = 0;
    this._a = [0, 0, 0]; this._b = [0, 0, 0]; this._c = [0, 0, 0]; this._r = [0, 0, 0];
    this.rnd = PG.rng(12345);
    this.tris = 0;
    this._newChunk(2048);
  }
  MB.prototype._newChunk = function (cap) {
    var buf = new ArrayBuffer(cap * 20);
    this.cur = { cap: cap, n: 0, buf: buf, f: new Float32Array(buf), i8: new Int8Array(buf), u8: new Uint8Array(buf) };
    this.chunks.push(this.cur);
  };
  MB.prototype._ensure = function (k) {
    var c = this.cur;
    if (c.n + k <= c.cap) return;
    if (c.cap < MAXV && c.n + k <= MAXV) {
      var cap = Math.min(MAXV, Math.max(c.cap * 2, c.n + k));
      var buf = new ArrayBuffer(cap * 20);
      new Uint8Array(buf).set(new Uint8Array(c.buf, 0, c.n * 20));
      c.cap = cap; c.buf = buf; c.f = new Float32Array(buf); c.i8 = new Int8Array(buf); c.u8 = new Uint8Array(buf);
    } else {
      this._newChunk(4096);
    }
  };
  function tp(m, x, y, z, o) {
    if (!m) { o[0] = x; o[1] = y; o[2] = z; return; }
    o[0] = m[0] * x + m[4] * y + m[8] * z + m[12];
    o[1] = m[1] * x + m[5] * y + m[9] * z + m[13];
    o[2] = m[2] * x + m[6] * y + m[10] * z + m[14];
  }
  MB.prototype.tri = function (a, b, c, col, emi) {
    var m = this.m, A = this._a, B = this._b, C = this._c;
    tp(m, a[0], a[1], a[2], A); tp(m, b[0], b[1], b[2], B); tp(m, c[0], c[1], c[2], C);
    var ux = B[0] - A[0], uy = B[1] - A[1], uz = B[2] - A[2], vx = C[0] - A[0], vy = C[1] - A[1], vz = C[2] - A[2];
    var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    var len = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (len < 1e-9) return;
    var swap = false;
    if (this.ref) {
      var R = this._r; tp(m, this.ref[0], this.ref[1], this.ref[2], R);
      var cx = (A[0] + B[0] + C[0]) / 3 - R[0], cy = (A[1] + B[1] + C[1]) / 3 - R[1], cz = (A[2] + B[2] + C[2]) / 3 - R[2];
      if (nx * cx + ny * cy + nz * cz < 0) swap = true;
    } else if (this.up && ny < 0) swap = true;
    if (swap) { nx = -nx; ny = -ny; nz = -nz; }
    nx /= len; ny /= len; nz /= len;
    this._ensure(3);
    var ch = this.cur, f = ch.f, i8 = ch.i8, u8 = ch.u8, e = (emi === undefined ? this.emi : emi);
    var r = (col[0] * 255 + 0.5) | 0, g = (col[1] * 255 + 0.5) | 0, bl = (col[2] * 255 + 0.5) | 0, al = (e * 255 + 0.5) | 0;
    var inx = (nx * 127) | 0, iny = (ny * 127) | 0, inz = (nz * 127) | 0;
    for (var k = 0; k < 3; k++) {
      var P = k === 0 ? A : (swap ? (k === 1 ? C : B) : (k === 1 ? B : C));
      var o = ch.n * 5;
      f[o] = P[0]; f[o + 1] = P[1]; f[o + 2] = P[2];
      var ob = ch.n * 20;
      i8[ob + 12] = inx; i8[ob + 13] = iny; i8[ob + 14] = inz; i8[ob + 15] = 0;
      u8[ob + 16] = r; u8[ob + 17] = g; u8[ob + 18] = bl; u8[ob + 19] = al;
      ch.n++;
    }
    this.tris++;
  };
  MB.prototype.quad = function (a, b, c, d, col, emi) { this.tri(a, b, c, col, emi); this.tri(a, c, d, col, emi); };

  // transformaciones
  MB.prototype.push = function () { this.stack.push(this.m); this.m = this.m ? new Float32Array(this.m) : null; return this; };
  MB.prototype.pop = function () { this.m = this.stack.pop(); return this; };
  MB.prototype._apply = function (t) {
    this.m = this.m ? m4.mul(new Float32Array(16), this.m, t) : t;
  };
  MB.prototype.translate = function (x, y, z) { var t = m4.create(); t[12] = x; t[13] = y; t[14] = z; this._apply(t); return this; };
  MB.prototype.scale = function (x, y, z) { var t = m4.create(); t[0] = x; t[5] = y; t[10] = z; this._apply(t); return this; };
  MB.prototype.rotY = function (a) { var t = m4.trs(new Float32Array(16), 0, 0, 0, a, 0, 0, 1, 1, 1); this._apply(t); return this; };
  MB.prototype.rotX = function (a) { var t = m4.trs(new Float32Array(16), 0, 0, 0, 0, a, 0, 1, 1, 1); this._apply(t); return this; };
  MB.prototype.rotZ = function (a) { var t = m4.trs(new Float32Array(16), 0, 0, 0, 0, 0, a, 1, 1, 1); this._apply(t); return this; };

  // primitivas (todas orientan sus caras hacia afuera con un punto interior de referencia)
  MB.prototype.box = function (cx, cy, cz, sx, sy, sz, col, emi) {
    var x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
    var o = this.ref; this.ref = [cx, cy, cz];
    this.quad([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1], col, emi);
    this.quad([x0, y0, z0], [x0, y1, z0], [x0, y1, z1], [x0, y0, z1], col, emi);
    this.quad([x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1], col, emi);
    this.quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], col, emi);
    this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], col, emi);
    this.quad([x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], col, emi);
    this.ref = o;
  };
  MB.prototype.ell = function (cx, cy, cz, rx, ry, rz, seg, rings, col, emi, jit) {
    var o = this.ref; this.ref = [cx, cy, cz];
    var pts = [], i, j;
    for (i = 0; i <= rings; i++) {
      var phi = PI * i / rings, y = Math.cos(phi) * ry, r = Math.sin(phi), row = [];
      for (j = 0; j <= seg; j++) {
        var th = 2 * PI * (j % seg) / seg;
        row.push([cx + Math.cos(th) * r * rx, cy + y, cz + Math.sin(th) * r * rz]);
      }
      pts.push(row);
    }
    for (i = 0; i < rings; i++) for (j = 0; j < seg; j++) {
      var c2 = jit ? PG.shade(col, 1 + (this.rnd() - 0.5) * jit) : col;
      this.tri(pts[i][j], pts[i + 1][j], pts[i + 1][j + 1], c2, emi);
      this.tri(pts[i][j], pts[i + 1][j + 1], pts[i][j + 1], c2, emi);
    }
    this.ref = o;
  };
  MB.prototype.cone = function (cx, cy, cz, r, h, seg, col, emi, nb) {
    var o = this.ref; this.ref = [cx, cy + h * 0.3, cz];
    var apex = [cx, cy + h, cz], base = [cx, cy, cz], j;
    for (j = 0; j < seg; j++) {
      var a0 = 2 * PI * j / seg, a1 = 2 * PI * (j + 1) / seg;
      var p0 = [cx + Math.cos(a0) * r, cy, cz + Math.sin(a0) * r], p1 = [cx + Math.cos(a1) * r, cy, cz + Math.sin(a1) * r];
      this.tri(p0, p1, apex, col, emi);
      if (!nb) this.tri(p0, p1, base, col, emi);
    }
    this.ref = o;
  };
  MB.prototype.cyl = function (cx, cy, cz, r0, r1, h, seg, col, emi) {
    var o = this.ref; this.ref = [cx, cy + h / 2, cz];
    var j, bc = [cx, cy, cz], tc = [cx, cy + h, cz];
    for (j = 0; j < seg; j++) {
      var a0 = 2 * PI * j / seg, a1 = 2 * PI * (j + 1) / seg;
      var b0 = [cx + Math.cos(a0) * r0, cy, cz + Math.sin(a0) * r0], b1 = [cx + Math.cos(a1) * r0, cy, cz + Math.sin(a1) * r0];
      var t0 = [cx + Math.cos(a0) * r1, cy + h, cz + Math.sin(a0) * r1], t1 = [cx + Math.cos(a1) * r1, cy + h, cz + Math.sin(a1) * r1];
      this.quad(b0, b1, t1, t0, col, emi);
      this.tri(b0, b1, bc, col, emi);
      this.tri(t0, t1, tc, col, emi);
    }
    this.ref = o;
  };
  // octaedro alargado (cristales)
  MB.prototype.crystal = function (cx, cy, cz, r, h, col, emi, seg) {
    seg = seg || 6;
    var o = this.ref; this.ref = [cx, cy + h * 0.5, cz];
    var top = [cx, cy + h, cz], bot = [cx, cy, cz], mid = cy + h * 0.38, j;
    for (j = 0; j < seg; j++) {
      var a0 = 2 * PI * j / seg, a1 = 2 * PI * (j + 1) / seg;
      var p0 = [cx + Math.cos(a0) * r, mid, cz + Math.sin(a0) * r], p1 = [cx + Math.cos(a1) * r, mid, cz + Math.sin(a1) * r];
      var k = 0.85 + 0.3 * ((j * 37) % 7) / 7;
      this.tri(p0, p1, top, PG.shade(col, k), emi);
      this.tri(p0, p1, bot, PG.shade(col, k * 0.8), emi);
    }
    this.ref = o;
  };
  // corta el lote actual (para que cada lote quede agrupado espacialmente y se pueda descartar fuera de camara)
  MB.prototype.cut = function () { if (this.cur.n > 0) this._newChunk(1024); };
  MB.prototype.finish = function () {
    var out = [], tris = 0;
    for (var i = 0; i < this.chunks.length; i++) {
      var c = this.chunks[i];
      if (c.n > 0) {
        var f = c.f, x0 = 1e30, y0 = 1e30, z0 = 1e30, x1 = -1e30, y1 = -1e30, z1 = -1e30;
        for (var k = 0, o = 0; k < c.n; k++, o += 5) {
          var x = f[o], y = f[o + 1], z = f[o + 2];
          if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; if (z < z0) z0 = z; if (z > z1) z1 = z;
        }
        out.push({ buf: c.buf.slice(0, c.n * 20), n: c.n, bb: [x0, y0, z0, x1, y1, z1] }); tris += c.n / 3;
      }
    }
    return { chunks: out, tris: tris };
  };
  // une varias mallas ya terminadas en una sola descripcion
  PG.mergeMeshes = function (list) {
    var o = { chunks: [], tris: 0 };
    for (var i = 0; i < list.length; i++) { o.chunks = o.chunks.concat(list[i].chunks); o.tris += list[i].tris; }
    return o;
  };
  PG.MB = MB;
})();
