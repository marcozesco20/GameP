/* Chat de voz de la sala (WebRTC, audio de persona a persona).
   - La señalización (ofertas, respuestas y candidatos ICE) viaja por la misma sala que el resto del juego
     ({t:'rtc', to:id, kind:..., d:...}); el audio va directo entre teléfonos.
   - Cada jugador puede: silenciar su propio micrófono (los demás no lo oyen) y silenciar a quien quiera (o a todos).
   - Sin servidor TURN: casi siempre funciona en el mismo WiFi y en la mayoría de redes; con ciertos datos móviles
     (NAT simétrico) puede no conectar. */
(function () {
  'use strict';
  var PG = window.PG = window.PG || {};
  var STUN = [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }, { urls: 'stun:stun.cloudflare.com:3478' }];
  // servidor de relevo publico gratuito (mejor esfuerzo) para redes que bloquean la conexion directa
  var TURN_PUBLIC = [{ urls: ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turns:openrelay.metered.ca:443?transport=tcp'], username: 'openrelayproject', credential: 'openrelayproject' }];
  function iceConfig() {
    var list = STUN.slice(), custom = '';
    try { custom = (window.localStorage && localStorage.getItem('pg_turn')) || ''; } catch (e) { }
    custom = String(custom || '').trim();
    if (custom) { // formato: turn:host:3478|usuario|clave
      var f = custom.split('|'); list.push({ urls: f[0], username: f[1] || '', credential: f[2] || '' });
    } else list = list.concat(TURN_PUBLIC);
    return { iceServers: list };
  }

  var V = PG.Voice = {
    on: false, joining: false, mic: true, deaf: false, listenOnly: false, stream: null, err: '',
    peers: {}, speakingMe: false, cb: null, send: null, myId: null,
    TEST_FAKE: false
  };
  var ctx = null, meterT = 0, meMeter = null, retries = {};

  function changed() { if (V.cb) { try { V.cb(); } catch (e) { if (window.console) console.error(e); } } }
  function out(o) { if (V.send) V.send(o); }
  V.supported = function () { return !!window.RTCPeerConnection; };
  V.canMic = function () { return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia); };
  V.init = function (send, myId, onChange) { V.send = send; V.myId = myId; V.cb = onChange; };

  /* ---- medidor de nivel (indicador "esta hablando") ---- */
  function getCtx() {
    if (!ctx) { var C = window.AudioContext || window.webkitAudioContext; if (C) { try { ctx = new C(); } catch (e) { ctx = null; } } }
    if (ctx && ctx.state === 'suspended') { try { ctx.resume(); } catch (e) { } }
    return ctx;
  }
  function makeMeter(stream) {
    var c = getCtx(); if (!c || !stream) return null;
    try {
      var src = c.createMediaStreamSource(stream), an = c.createAnalyser(); an.fftSize = 256; src.connect(an);
      return { src: src, an: an, buf: new Uint8Array(an.fftSize), hold: 0 };
    } catch (e) { return null; }
  }
  function level(m) {
    if (!m) return 0;
    m.an.getByteTimeDomainData(m.buf); var s = 0;
    for (var i = 0; i < m.buf.length; i++) { var v = (m.buf[i] - 128) / 128; s += v * v; }
    return Math.sqrt(s / m.buf.length);
  }
  function tickMeters() {
    var ch = false, now = Date.now(), k, p, sp;
    sp = !!(V.on && V.mic && V.stream && level(meMeter) > 0.035);
    if (sp) meMeter.hold = now + 250; else if (meMeter && now < meMeter.hold && V.mic) sp = true;
    if (sp !== V.speakingMe) { V.speakingMe = sp; ch = true; }
    for (k in V.peers) {
      p = V.peers[k]; if (!p.meter) continue;
      var l = level(p.meter), s = l > 0.03 && !p.muted && !V.deaf;
      if (s) p.meter.hold = now + 250; else if (now < p.meter.hold && !p.muted && !V.deaf) s = true;
      if (s !== p.speaking) { p.speaking = s; ch = true; }
    }
    // ¿hay alguien con quien la conexion directa no se ha establecido? entonces mandamos tambien el audio por la sala
    var need = false;
    for (k in V.peers) { p = V.peers[k]; if (p.voice && p.state !== 'connected' && p.since && now - p.since > 4000) need = true; if (p.relayHold && now > p.relayHold && p.speaking && !p.meter) { p.speaking = false; p.relayHold = 0; ch = true; } }
    if (need !== relayNeed) { relayNeed = need; V.relayOn = need; ch = true; }
    if (ch) changed();
  }


  /* ---- respaldo: audio por la propia sala ----
     Si la conexion directa (WebRTC) no llega a establecerse con alguien (algunas redes moviles la bloquean),
     el audio se envia por el mismo canal que usa el juego: voz comprimida (8 kHz, mu-law) en mensajes pequenos. */
  var RELAY_SR = 8000, FRAME = 800, proc = null, procSrc = null, procSink = null, acc = [], accN = 0, relaySeq = 0, relayHold = 0, relayNeed = false, relayStart = 0;
  function mulawEnc(x) { // x en [-1,1] -> byte
    var s = x < 0 ? 0x80 : 0, a = Math.min(1, Math.abs(x)) * 32767 + 132; if (a > 32767) a = 32767;
    var e = 7, m; for (var mask = 0x4000; (a & mask) === 0 && e > 0; e--, mask >>= 1) { }
    m = (a >> (e + 3)) & 0x0F; return (~(s | (e << 4) | m)) & 0xFF;
  }
  function mulawDec(b) {
    b = ~b & 0xFF; var s = b & 0x80, e = (b >> 4) & 7, m = b & 15, v = (((m << 3) + 132) << e) - 132; return (s ? -v : v) / 32768;
  }
  V._mulaw = { enc: mulawEnc, dec: mulawDec };
  function startRelayCapture() {
    var c = getCtx(); if (!c || !V.stream || proc || !c.createScriptProcessor) return;
    try {
      procSrc = c.createMediaStreamSource(V.stream); proc = c.createScriptProcessor(2048, 1, 1);
      procSink = c.createGain(); procSink.gain.value = 0;
      procSrc.connect(proc); proc.connect(procSink); procSink.connect(c.destination);
      var ratio = c.sampleRate / RELAY_SR, pos = 0;
      proc.onaudioprocess = function (ev) {
        if (!V.on || !V.mic || !(relayNeed || V.forceRelay)) { pos = 0; accN = 0; acc.length = 0; return; }
        var inp = ev.inputBuffer.getChannelData(0);
        for (; pos < inp.length; pos += ratio) { var i0 = Math.floor(pos), i1 = Math.min(inp.length - 1, i0 + 1), f = pos - i0; acc.push(inp[i0] * (1 - f) + inp[i1] * f); }
        pos -= inp.length;
        while (acc.length >= FRAME) {
          var fr = acc.splice(0, FRAME), sum = 0, i; for (i = 0; i < FRAME; i++) sum += fr[i] * fr[i];
          var rms = Math.sqrt(sum / FRAME), now = Date.now();
          if (rms > 0.012) relayHold = now + 450;
          if (now < relayHold) {
            var bin = ''; for (i = 0; i < FRAME; i++) bin += String.fromCharCode(mulawEnc(fr[i]));
            out({ t: 'va', d: btoa(bin), q: relaySeq++ & 0xFFFF });
            V.relayTx = (V.relayTx | 0) + 1;
          }
        }
      };
    } catch (e) { proc = null; }
  }
  function stopRelayCapture() {
    try { if (proc) { proc.onaudioprocess = null; proc.disconnect(); } if (procSrc) procSrc.disconnect(); if (procSink) procSink.disconnect(); } catch (e) { }
    proc = procSrc = procSink = null; acc.length = 0;
  }
  function playRelay(p, b64) {
    var c = getCtx(); if (!c) return;
    var bin; try { bin = atob(b64); } catch (e) { return; }
    var n = bin.length; if (n < 80 || n > 4000) return;
    var buf = c.createBuffer(1, n, RELAY_SR), ch = buf.getChannelData(0), sum = 0;
    for (var i = 0; i < n; i++) { var v = mulawDec(bin.charCodeAt(i)); ch[i] = v; sum += v * v; }
    if (!p.gain) { p.gain = c.createGain(); p.gain.connect(c.destination); }
    p.gain.gain.value = (p.muted || V.deaf) ? 0 : 1;
    var src = c.createBufferSource(); src.buffer = buf; src.connect(p.gain);
    var now = c.currentTime;
    if (!p.nextT || p.nextT < now + 0.02) p.nextT = now + 0.16;      // colchon de 160 ms contra el jitter de la red
    else if (p.nextT > now + 0.7) p.nextT = now + 0.16;               // se acumulo retraso: resincroniza
    src.start(p.nextT); p.nextT += n / RELAY_SR;
    p.relayUntil = Date.now() + 700; p.relayFrames = (p.relayFrames | 0) + 1; p.relayLevel = Math.sqrt(sum / n);
    if (!p.muted && !V.deaf) { if (!p.speaking) { p.speaking = true; changed(); } p.relayHold = Date.now() + 350; }
  }

  /* ---- entrar / salir ---- */
  V.join = function () {
    if (V.on || V.joining) return;
    if (!V.supported()) { V.err = 'Tu dispositivo no admite chat de voz.'; changed(); return; }
    V.joining = true; V.err = ''; changed(); getCtx();
    var p;
    if (V.TEST_FAKE) p = Promise.resolve(fakeStream());
    else if (V.canMic()) p = navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
    else p = Promise.reject(new Error('sin micrófono'));
    p.then(function (st) { V.stream = st; V.listenOnly = false; V.mic = true; },
      function () { V.stream = null; V.listenOnly = true; V.mic = false; V.err = 'No hay permiso para el micrófono: solo podrás escuchar. (Dale permiso en los ajustes del teléfono para hablar.)'; })
      .then(function () {
        V.joining = false; V.on = true; applyMic();
        meMeter = V.stream ? makeMeter(V.stream) : null; startRelayCapture();
        try { if (window.NativeNet && window.NativeNet.voiceMode) window.NativeNet.voiceMode(true); } catch (e) { }
        clearInterval(meterT); meterT = setInterval(tickMeters, 120);
        out({ t: 'vjoin' }); changed();
      });
  };
  function fakeStream() { // solo pruebas automáticas: tono de 440 Hz
    var c = getCtx(), o = c.createOscillator(), d = c.createMediaStreamDestination(); o.frequency.value = 440; o.connect(d); o.start(); return d.stream;
  }
  function applyMic() { if (V.stream) V.stream.getAudioTracks().forEach(function (t) { t.enabled = !!V.mic; }); }
  V.setMic = function (on) {
    if (!V.on) return; if (!V.stream) { V.err = 'Sin micrófono: sal del chat de voz y vuelve a entrar tras darle permiso.'; changed(); return; }
    V.mic = !!on; applyMic(); if (!V.mic) V.speakingMe = false; changed();
  };
  V.toggleMic = function () { V.setMic(!V.mic); };
  V.setDeaf = function (d) { V.deaf = !!d; for (var k in V.peers) applyMute(V.peers[k]); changed(); };
  V.toggleDeaf = function () { V.setDeaf(!V.deaf); };
  V.mutePeer = function (id, m) { var p = V.peers[id]; if (!p) return; p.muted = m === undefined ? !p.muted : !!m; applyMute(p); changed(); };
  function applyMute(p) { if (p.audio) p.audio.muted = !!(p.muted || V.deaf); if (p.gain) p.gain.gain.value = (p.muted || V.deaf) ? 0 : 1; if (p.muted || V.deaf) p.speaking = false; }

  function closePc(p) {
    if (p.pc) { try { p.pc.onicecandidate = p.pc.ontrack = p.pc.onconnectionstatechange = null; p.pc.close(); } catch (e) { } p.pc = null; }
    if (p.audio) { try { p.audio.pause(); p.audio.srcObject = null; if (p.audio.parentNode) p.audio.parentNode.removeChild(p.audio); } catch (e) { } p.audio = null; }
    if (p.meter) { try { p.meter.src.disconnect(); } catch (e) { } p.meter = null; }
    p.pend = []; p.remoteSet = false; p.speaking = false; p.state = 'new';
  }
  function dropPeer(id) { var p = V.peers[id]; if (!p) return; closePc(p); delete V.peers[id]; delete retries[id]; }
  V.leave = function (silent) {
    if (V.on && !silent) out({ t: 'vleave' });
    for (var k in V.peers) closePc(V.peers[k]);
    V.peers = {}; retries = {};
    if (V.stream) { V.stream.getTracks().forEach(function (t) { try { t.stop(); } catch (e) { } }); V.stream = null; }
    if (meMeter) { try { meMeter.src.disconnect(); } catch (e) { } meMeter = null; }
    stopRelayCapture(); relayNeed = false; V.relayOn = false;
    try { if (window.NativeNet && window.NativeNet.voiceMode) window.NativeNet.voiceMode(false); } catch (e) { }
    clearInterval(meterT); V.on = false; V.joining = false; V.speakingMe = false; V.listenOnly = false; V.err = '';
    changed();
  };
  V.peerLeft = function (id) { if (V.peers[id]) { dropPeer(id); changed(); } };

  /* ---- conexiones entre jugadores ---- */
  function mkPeer(id) {
    var p = V.peers[id];
    if (!p) p = V.peers[id] = { id: id, pc: null, audio: null, meter: null, voice: false, muted: false, speaking: false, state: 'new', pend: [], remoteSet: false, since: 0, gain: null, nextT: 0, relayUntil: 0, relayHold: 0 };
    return p;
  }
  function sig(to, kind, d) { out({ t: 'rtc', to: to, kind: kind, d: d }); }
  function attachAudio(p, stream) {
    if (p.audio) { p.audio.srcObject = stream; return; }
    var a = document.createElement('audio'); a.autoplay = true; a.setAttribute('playsinline', ''); a.style.display = 'none';
    a.srcObject = stream; a.muted = !!(p.muted || V.deaf); document.body.appendChild(a);
    try { var pr = a.play(); if (pr && pr.catch) pr.catch(function () { }); } catch (e) { }
    p.audio = a; if (p.meter) { try { p.meter.src.disconnect(); } catch (e) { } }
    p.meter = makeMeter(stream);
  }
  function connect(id, offerer) {
    var p = mkPeer(id); if (p.pc) return p;
    var pc = p.pc = new RTCPeerConnection(iceConfig());
    if (V.stream) V.stream.getTracks().forEach(function (t) { pc.addTrack(t, V.stream); });
    else if (offerer) pc.addTransceiver('audio', { direction: 'recvonly' });
    pc.onicecandidate = function (e) { if (e.candidate) sig(id, 'ice', e.candidate.toJSON ? e.candidate.toJSON() : e.candidate); };
    pc.ontrack = function (e) { attachAudio(p, (e.streams && e.streams[0]) || new MediaStream([e.track])); changed(); };
    pc.onconnectionstatechange = function () {
      if (p.pc !== pc) return; p.state = pc.connectionState; changed();
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') retry(id);
    };
    if (offerer) {
      pc.createOffer().then(function (o) { return pc.setLocalDescription(o); }).then(function () {
        sig(id, 'offer', { type: pc.localDescription.type, sdp: pc.localDescription.sdp });
      }).catch(function () { p.state = 'failed'; changed(); });
    }
    return p;
  }
  function retry(id) { // un par de reintentos si la conexion falla
    var p = V.peers[id]; if (!p || !V.on) return;
    retries[id] = (retries[id] | 0) + 1; if (retries[id] > 3) return;
    setTimeout(function () {
      var q = V.peers[id]; if (!q || !V.on || (q.pc && q.state === 'connected')) return;
      closePc(q);
      if (V.myId < id) connect(id, true); else out({ t: 'vhere', to: id });
    }, 1500);
  }
  function meet(from, reply) {
    var p = mkPeer(from); if (!p.voice) p.since = Date.now(); p.voice = true;
    if (p.pc && (p.state === 'failed' || p.state === 'closed' || p.state === 'disconnected')) closePc(p);
    if (V.on) {
      if (reply) out({ t: 'vhere', to: from });
      if (V.myId < from && !V.noRTC) connect(from, true);   // el de menor id llama: evita llamadas cruzadas
    }
    changed();
  }
  // mensajes de la sala: 'vjoin' (todos), 'vhere'/'rtc' (dirigidos, ya filtrados por destinatario), 'vleave'
  V.onMsg = function (m) {
    var from = m.f; if (from === undefined || from === V.myId) return;
    if (m.t === 'vjoin') meet(from, true);
    else if (m.t === 'vhere') meet(from, false);
    else if (m.t === 'vleave') { var p = V.peers[from]; if (p) { closePc(p); p.voice = false; } changed(); }
    else if (m.t === 'rtc') signal(from, m);
    else if (m.t === 'va') { var pr = V.peers[from]; if (V.on && pr && pr.voice && pr.state !== 'connected') playRelay(pr, m.d); }
  };
  function signal(from, m) {
    if (!V.on) return;
    var p = mkPeer(from), pc;
    if (m.kind === 'offer') {
      closePc(p); p.voice = true; pc = connect(from, false).pc;
      pc.setRemoteDescription(m.d).then(function () { p.remoteSet = true; flush(p); return pc.createAnswer(); })
        .then(function (a) { return pc.setLocalDescription(a); })
        .then(function () { sig(from, 'answer', { type: pc.localDescription.type, sdp: pc.localDescription.sdp }); })
        .catch(function () { p.state = 'failed'; changed(); });
    } else if (m.kind === 'answer') {
      if (p.pc && p.pc.signalingState === 'have-local-offer') p.pc.setRemoteDescription(m.d).then(function () { p.remoteSet = true; flush(p); }).catch(function () { });
    } else if (m.kind === 'ice') {
      if (p.pc && p.remoteSet) p.pc.addIceCandidate(m.d).catch(function () { }); else p.pend.push(m.d);
    }
  }
  function flush(p) { var l = p.pend; p.pend = []; l.forEach(function (c) { if (p.pc) p.pc.addIceCandidate(c).catch(function () { }); }); }

  V.stateOf = function (id) { var p = V.peers[id]; if (!p || !p.voice) return 'off'; if (p.state === 'connected' || p.relayUntil > Date.now()) return 'ok'; return p.state === 'failed' && !V.relayOn ? 'fail' : 'wait'; };
})();
